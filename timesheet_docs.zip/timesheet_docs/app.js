const express = require("express");
const cookieParser = require("cookie-parser");
const sessions = require("express-session");
var bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");
const swaggerUi = require("swagger-ui-express"),
  swaggerDocument = require("./swagger.json");
const { authMiddleware } = require("./middlewares/auth"); // load auth middlware
const { errMiddleware } = require("./middlewares/error"); // load error middlware
const moment = require("moment");
const MomentRange = require("moment-range");
const Moment = MomentRange.extendMoment(moment);
const axios = require("axios");
var fileUpload = require("express-fileupload");
// Setup a global variable to resolve application dir path
global.appDir = path.join(__dirname);

var app = express();

//bodyparser
app
  .use(cors({ origin: "*" })) // enable cors
  .use(bodyParser.json({ limit: "2mb" }))
  .use(
    bodyParser.urlencoded({
      limit: "50mb",
      extended: false,
      parameterLimit: 5000,
    })
  );
app.use(
  fileUpload({
    limits: { fileSize: 50 * 1024 * 1024 },
  })
);

app.use("/images", express.static(path.join(__dirname, "images")));

app.use(express.static(path.join(__dirname, "./", "public")));

// add middlewares
app.use(express.static(path.join(__dirname, "./", "build")));

app.get("/timetracker?", (req, res) => {
  res.sendFile(path.join(path.join(__dirname, "./"), "build", "index.html"));
});

app.get("/timetracker/*", (req, res) => {
  res.sendFile(path.join(path.join(__dirname, "./"), "build", "index.html"));
});

app.use("/favicon.ico", express.static(__dirname + "./build/favicon.ico"));

// parsing the incoming data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//serving public file
app.use(express.static(__dirname));

// cookie parser middleware
app.use(cookieParser());

// creating 24 hours from milliseconds
const oneDay = 1000 * 60 * 60 * 2;

//session middleware
app.use(
  sessions({
    secret: "thisismysecrctekeyjbfcuw4t8978u3q049dncsid",
    saveUninitialized: true,
    cookie: { maxAge: oneDay },
    resave: false,
  })
);

//swagger document
app.use(
  "/api-doc",
  swaggerUi.serve,
  swaggerUi.setup(swaggerDocument),
  () => {}
);

// Setup a global variable to resolve application dir path
global.appDir = path.join(__dirname);

// required for local only, comment below code for uat and production env vars will be fetched from azure server
// Setup environment variable
if (process.env.NODE_ENV !== "production" || process.env.NODE_ENV !== "development") {
  require("dotenv").config({
    path: path.join(global.appDir, ".env.development"),
  });
} 

// if (process.env.NODE_ENV === "production") {
//   require("dotenv").config({ path: path.join(global.appDir, ".env") });
// } else {
//   require("dotenv").config({
//     path: path.join(global.appDir, ".env.development"),
//   });
// }

//swagger
var options = {
  customCss: ".swagger-ui .topbar { display: none }",
  swaggerOptions: {
    defaultModelsExpandDepth: -1,
  },
};

//customer
app.get("/", (req, res) => {
  res.json({ servicename: "Timesheet" });
});

app.get("/customer", async function (req, res) {
  var data = await axios.get(
    `https://sandbox-quickbooks.api.intuit.com/v3/company/4620816365249151700/query?query=select * from Customer Where Id = '45'`,
    {
      headers: {
        Authorization:
          "Bearer eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..ft4IMTzSX4Pg7mj1IdAkkw.ubyfoXpTlg-y2TleA81W11ZralZiKUummQkqKweaMIzM_Kd7e3yxc6nX9YZbkgrhd1m5DxN52Q-CSq863KIrP52dOXtMirjNv3xLFm2Ab2sziVIcQloaoLwbaZM14_nB7NzcNeZgsDevS1Qa0OFxGY61EiMQh1NHjg2liBebAOj6TEmQLW9q36yJ1FSLLLIa5tUTWNEsDUDsednwDmPxr8Hgkp3Yl9SPd6_ZIZWOxlmD4kE3dZ0QZZyTG85MO8-JpNaD0ssgPnaaTE6XimU5DyAzTl-N7VYyKy1_cV0I0V1PuOsa2kvscYKbE63pTTR_J4T87ExH2S5kN8ZNSiro2JiE1Fqeiv_SFlARXH6p_gJkEJtOBSiJvOlG10EHwIsIz9bdfFY70KTWIsSMekNsPl-XaWGkUaM4qFmtMJ0B_Ve-N8WisHFkAqjh2hppLS2JcZ5LlKf-qC36pmoZiDDG2Cs-LFzj7DWltV9x2bcn-OVCzh0OHsdTG7n9Fk-mRisMAHqFdo43F0xuYBONmHBtF-m4isYsu29Lw2q8fuLLXKTj1LGXTyJTW9j_xP6K3DwuHlVeoNX6G-pAnffjX3V3o3n96vNbuQei05okjQ6qNeQxpmYeQeyN__WqP7QrnczRL4YrDrkp0lL-qTJhRvcVPfcl2n6IY6Xvk2jhPDPABA9RO8rIlCmC56dhMYBe1YTas3rAY9Brcc_LxCqJu-oLKi8W511OdNZfP1reINrVJDBfD0Q6KWDRuwV2gJSpzCBJ.Kof6MlbhXwXb04zBz8bguQ",
      },
    }
  );
  res.status(200).send(data.data);
});

// Routes definitions files
var indexRouter = require("./routes/v1api/index");
var tokenRouter = require("./routes/v1api/token");
const servicesRouter = require("./routes/v1api/services");
const quickbookRouter = require("./routes/v1api/quickbook");
const customers2Router = require("./routes/v1api/customers2");
const projects2Router = require("./routes/v1api/projects2");
const user2Router = require("./routes/v1api/user2");
// const timeActivityRouter = require("./routes/v1api/timeactivity");
const timesheetsRouter = require("./routes/v1api/timesheets");
const organizationsRouter = require("./routes/v1api/organizations");
const rolesRouter = require("./routes/v1api/roles");
const azureBlobRouter = require("./routes/v1api/azureblob");
const fileRouter = require("./routes/v1api/image");
const annoucementsRouter = require("./routes/v1api/annoucements");
const timesheetCommentsRouter = require("./routes/v1api/timesheet_comments");
const emailConfigRouter = require("./routes/v1api/email_config");
const syncLogsRouter = require("./routes/v1api/sync_logs");
const contryStateCity = require("./routes/v1api/countries_states_cities");
const timesheetDocumentsRouter = require("./routes/v1api/timesheet_documents");
const reportsRouter = require("./routes/v1api/reports");
const globalConfigRouter = require("./routes/v1api/global_config");
const ecdbRouter = require("./routes/v1api/ecdb");
const userLogsRouter = require("./routes/v1api/user_logs");
const migrationRouter = require("./routes/v1api/migration");
const cronjobRouter = require("./routes/v1api/cronjob");
const accountingToolsRouter = require("./routes/v1api/accounting_tools");
const mobileRouter = require("./routes/v1api/mobile");
const employeeDocumentTypeRouter = require("./routes/v1api/employee_document_types");
const employeeDocumentsRouter = require("./routes/v1api/employee_documents");


app.use("/api/v1/index", indexRouter);
app.use("/api/v1/token", authMiddleware, errMiddleware, tokenRouter);
app.use("/api/v1/services", authMiddleware, errMiddleware, servicesRouter);
app.use("/api/v1/quickbook", authMiddleware, errMiddleware, quickbookRouter);
app.use("/api/v1/user2", authMiddleware, errMiddleware, user2Router);


app.use(
  "/api/v1/organizations",
  authMiddleware,
  errMiddleware,
  organizationsRouter
);

app.use(
  "/api/v1/timesheet_comments",
  authMiddleware,
  errMiddleware,
  timesheetCommentsRouter
);
app.use("/api/v1/roles", authMiddleware, errMiddleware, rolesRouter);
app.use("/api/v1/azureblob", azureBlobRouter);
app.use(
  "/api/v1/annoucements",
  authMiddleware,
  errMiddleware,
  annoucementsRouter
);

app.use(
  "/api/v1/emailconfig",
  authMiddleware,
  errMiddleware,
  emailConfigRouter
);

app.use("/api/v1/synclogs", authMiddleware, errMiddleware, syncLogsRouter);
app.use(
  "/api/v1/countrystatecity",
  authMiddleware,
  errMiddleware,
  contryStateCity
);

// app.use(
//   "/api/v1/timeactivity",
//   authMiddleware,
//   errMiddleware,
//   timeActivityRouter
// );
app.use("/api/v1/fileupload", authMiddleware, errMiddleware, fileRouter);

app.use("/api/v1/customers2", authMiddleware, errMiddleware, customers2Router);

app.use("/api/v1/projects2", authMiddleware, errMiddleware, projects2Router);

app.use("/api/v1/timesheets", authMiddleware, errMiddleware, timesheetsRouter);

app.use(
  "/api/v1/timesheet_documents",
  authMiddleware,
  errMiddleware,
  timesheetDocumentsRouter
);

app.use("/api/v1/reports", authMiddleware, errMiddleware, reportsRouter);

app.use("/api/v1/global_config", authMiddleware, errMiddleware, globalConfigRouter);
app.use("/api/v1/ecdb", ecdbRouter);
app.use("/api/v1/user_logs", authMiddleware, errMiddleware, userLogsRouter);
app.use("/api/v1/migration", authMiddleware, errMiddleware, migrationRouter);
app.use("/api/v1/cronjob", cronjobRouter);
app.use("/api/v1/accounting_tools", accountingToolsRouter);
app.use("/api/v1/mobile", mobileRouter);
app.use("/api/v1/employee_document_types", authMiddleware, errMiddleware, employeeDocumentTypeRouter);
app.use("/api/v1/employee_documents", authMiddleware, errMiddleware, employeeDocumentsRouter);

module.exports = app;
