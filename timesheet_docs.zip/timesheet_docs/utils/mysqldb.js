var mysql      = require('mysql2');

var config = {
  host: process.env.HRMS_DB_HOST,
  port: process.env.HRMS_DB_PORT,
  user: process.env.HRMS_DB_USERNAME,
  password: process.env.HRMS_DB_PASSWORD,
  database: process.env.HRMS_DB_DATABASE,
  connectionLimit: 10
};
const pool = new mysql.createPool(config);
module.exports = pool;