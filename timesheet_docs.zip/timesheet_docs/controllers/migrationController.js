const { getMsgFormat, isEmpty } = require("../utils/helpers");
const con = require("../utils/db");
const mysqlcon = require("../utils/mysqldb");
const logger = require("../utils/logger");
var mysql = require('mysql2');
const moment = require("moment");
const {
  secondsToHm,
  InsertTimesheetHistory,
  ResetTimesheetStatus,
  InsertQuickBooksLog,
  UpdateProjectClientManagerDetails
} = require("../utils/timesheet_helpers");
const {
  ROLES,
  TIMESHEET_STATUS,
  TS_COMMENT_TYPE,
  TS_COMMENT_USER_TYPE,
} = require("../constants");

// api for migrate_users
const migrate_users = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {

    let syncUsers = [];
    let org_id = (req.query.org_id && parseInt(req.query.org_id)) || null;
    let employeeTypeMap = {
      1: "Internal",
      2: "W2",
      3: "C2C"
    };
    let rolesMap = {
      1: 1,
      2: 2,
      3: 3,
      4: 3,
      5: 7,
      6: 6,
      7: 6,
      8: 6,
      9: 6,
      10: 6,
      11: 6,
      12: 6,
      13: 6,
      14: 8,
    };
    
    let prefixMap = {
      1: "Mr",
      2: "Ms",
      3: "Mrs",
    };

    if(!org_id){
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "migrate_users";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      

      let [clientdbs] = await mysqlcon.promise().query(`SELECT * from clients WHERE ecdb_org_id = '${org_id}'`);
      clientdbs = (clientdbs && clientdbs.length && clientdbs[0]) || null;

      // console.log(clientdbs);

      // if org db setting found
      if(clientdbs && clientdbs.client_id){

        //// Connect to HRMS Org DB
        let { host, db_name:database, user_name: user, password } = clientdbs;
        // console.log(host, database, user, password);

        var orgdbconfig = {
          host: host,
          port: process.env.HRMS_DB_PORT,
          user: user,
          password: password,
          database: database,
          connectionLimit: 10
        };
        const orgdbcon = new mysql.createPool(orgdbconfig);

        // fetch HRMS users
        let [users] = await orgdbcon.promise().query(`
        SELECT u.*, me.prefix_id, me.date_of_joining, me.date_of_leaving, md.deptname, tbl_countries.country_name, tbl_states.state_name, tbl_cities.city_name, me.work_streetaddress, me.work_zipcode, main_gender.gendername  from main_users u
        LEFT JOIN main_employees me ON (me.user_id = u.id)
        LEFT JOIN main_emppersonaldetails mepd ON (mepd.user_id = u.id)
        LEFT JOIN main_departments md ON (md.id = me.department_id)
        LEFT JOIN tbl_countries tbl_countries ON (tbl_countries.id = me.perm_country)
        LEFT JOIN tbl_states tbl_states ON (tbl_states.id = me.perm_state)
        LEFT JOIN tbl_cities tbl_cities ON (tbl_cities.id = me.perm_city)
        LEFT JOIN main_gender main_gender ON (main_gender.id = mepd.genderid)
        ORDER BY u.id ASC
        `);
        
        // console.log("users", users);

        if(users){

          for(var i = 0; i < users.length; i++){
            let userRow = users[i];
            // console.log("userRow", userRow);
            let user_id = null;

            let employee_type = employeeTypeMap[userRow.employee_type] || null;
            let role_id = rolesMap[userRow.emprole] || 7;
            let prefix = prefixMap[userRow.prefix_id] || null;
            let user_status = (userRow.isactive == 1)? "Active":"Inactive";
            let record_type_status = (userRow.isactive == 1)? "Active":"Inactive";

            let {
              id: hrms_user_id,
              firstname: first_name,
              middle_name = null,
              lastname: last_name,
              userfullname: full_name,
              emailaddress: email,
              gendername: gender = null,
              associate_id: adp_associate_id = null,
              contactnumber: phone_number,
              branch_id = null,
              branch_name = null,
              department_id = null,
              deptname: department_name = null,
              employeeId: employee_id = null,
              ecdb_user_id = null,
              prospective_user_id = null,
              date_of_joining: joining_date = null,
              date_of_leaving: leaving_date = null,
              qb_employee_name = null,
              qb_employee_id = null,
              work_location = null,
              country_name: work_country,
              state_name: work_state,
              city_name: work_city,
              work_streetaddress: work_street_address,
              permanent_address = null,
              work_address = null,
              work_zipcode: zipcode = null,
              email_notifications = true,
              push_notifications = true,
              visa_status = null,
            } = userRow;

            // check user exists in timesheets DB
            email_exists = await con.query(`SELECT * FROM timesheets.get_user_by_email($1, $2)`, [org_id, userRow.emailaddress]);
            email_exists = (email_exists && email_exists.rows[0].j && email_exists.rows[0].j[0]) || null;

            // console.log("email_exists", email_exists)
            if(email_exists && email_exists.id){
              user_id = email_exists.id;
              // update user
              let userData = [
                user_id,
                org_id,
                employee_type,
                role_id,
                prefix,
                first_name,
                middle_name,
                last_name,
                full_name,
                email,
                gender,
                adp_associate_id,
                phone_number,
                branch_id,
                branch_name,
                department_id,
                department_name,
                work_country, // country_name
                work_state, // state_name
                employee_id,
                ecdb_user_id,
                prospective_user_id,
                joining_date,
                leaving_date,
                qb_employee_name,
                qb_employee_id,
                user_status,
                work_location,
                work_country,
                work_state,
                work_city,
                work_street_address,
                "", // work_status
                permanent_address,
                work_address,
                zipcode,
                email_notifications,
                push_notifications,
                1,
                record_type_status,
                visa_status,
                hrms_user_id
              ];
              let updateUser = await con.query(
                `SELECT timesheets.update_hrms_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42)`,
                userData
              );
              updateUser = (updateUser.rows && updateUser.rows[1] && updateUser.rows[1].update_hrms_users && updateUser.rows[1].update_hrms_users[0]) || null;

              syncUsers.push(updateUser);
              // console.log("updateUser", updateUser);

            }
            else{
              // insert user
              let new_employee_id = await con.query(`SELECT timesheets.get_new_employee_id($1)`, [org_id] );
              new_employee_id = (new_employee_id && new_employee_id.rows[0].get_new_employee_id && new_employee_id.rows[0].get_new_employee_id[0]) || null; 
              employee_id = new_employee_id.employee_id || null;

              let userData = [
                org_id,
                employee_type,
                role_id,
                prefix,
                first_name,
                middle_name,
                last_name,
                full_name,
                email,
                gender,
                adp_associate_id,
                phone_number,
                branch_id,
                branch_name,
                department_id,
                department_name,
                work_country, // country_name
                work_state, // state_name
                employee_id,
                ecdb_user_id,
                prospective_user_id,
                joining_date,
                leaving_date,
                qb_employee_name,
                qb_employee_id,
                user_status,
                work_location,
                work_country,
                work_state,
                work_city,
                work_street_address,
                "", // work_status
                permanent_address,
                work_address,
                zipcode,
                email_notifications,
                push_notifications,
                1,
                record_type_status,
                visa_status,
                hrms_user_id
              ];
              

              let insertUser = await con.query(
                `SELECT timesheets.insert_hrms_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
                userData
              );
              insertUser = (insertUser.rows && insertUser.rows[1] && insertUser.rows[1].insert_hrms_users && insertUser.rows[1].insert_hrms_users[0]) || null;
              
              // console.log("insertUser", insertUser);
              syncUsers.push(insertUser);
            }
            
          }
        }

        /////////////////////////

        returnMessage.isError = false;
        returnMessage.message = "HRMS Users Synced Successfully";
        returnMessage.data = syncUsers;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_users";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// api for migrate_projects
const migrate_projects = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {

    let syncClients = [];
    let syncProjects = [];
    let org_id = (req.query.org_id && parseInt(req.query.org_id)) || null;
    
    let projectStatusMap = {
      "initiated": "INITIATED",
      "draft": "INITIATED",
      "in-progress": "IN_PROGRESS",
      "completed": "COMPLETED",
      "cancelled": "CANCELLED",
      
    };

    if(!org_id){
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "migrate_projects";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      

      let [clientdbs] = await mysqlcon.promise().query(`SELECT * from clients WHERE ecdb_org_id = '${org_id}'`);
      clientdbs = (clientdbs && clientdbs.length && clientdbs[0]) || null;

      // console.log(clientdbs);

      // if org db setting found
      if(clientdbs && clientdbs.client_id){

        //// Connect to HRMS Org DB
        let { host, db_name:database, user_name: user, password } = clientdbs;
        // console.log(host, database, user, password);

        var orgdbconfig = {
          host: host,
          port: process.env.HRMS_DB_PORT,
          user: user,
          password: password,
          database: database,
          connectionLimit: 10
        };
        const orgdbcon = new mysql.createPool(orgdbconfig);


        //////////////////// add/update clients /////////////
        // fetch HRMS projects
        let [clients] = await orgdbcon.promise().query(` SELECT c.* FROM tm_clients c `);
        
        // console.log("clients", clients);

        if(clients && clients.length){

          for(var i = 0; i < clients.length; i++){

            let clientRow = clients[i];
            let {
              placement_client_id = null,
              client_name = null,
              dba = null,
              is_placement_client = false,
              qb_customer_name = null,
              qb_customer_id = null,
              qb_vendor_name = null,
              qb_vendor_id = null,
              is_active = null,
              createdby = 1,
              updatedby = 1,
            } = clientRow;
  
            let record_type_status = is_active == 1 ? "Active" : "Inactive";
            let customer_id = null;

            // insert/update customers
            let customer_exists = await con.query(`SELECT * FROM timesheets.get_customer_by_placement_client_id($1, $2)`,[org_id, placement_client_id]);
            customer_exists = (customer_exists && customer_exists.rows[0].j && customer_exists.rows[0].j[0]) || null;
            customer_id = (customer_exists && customer_exists.id) || 0;
            if(!customer_id){
              customer_exists = await con.query(`SELECT * FROM timesheets.get_customer_by_client_name($1, $2)`,[org_id, client_name]);
              customer_exists = (customer_exists && customer_exists.rows[1].j && customer_exists.rows[1].j[0]) || null;
              customer_id = (customer_exists && customer_exists.id) || 0;
            }

            if (customer_id) {
              qb_customer_name = customer_exists.qb_customer_name;
              qb_customer_id = customer_exists.qb_customer_id;
              qb_vendor_name = customer_exists.qb_vendor_name;
              qb_vendor_id = customer_exists.qb_vendor_id;

              let customerData = [
                customer_id,
                org_id,
                client_name,
                dba,
                is_placement_client,
                placement_client_id,
                qb_customer_name,
                qb_customer_id,
                qb_vendor_name,
                qb_vendor_id,
                updatedby,
                record_type_status,
              ];

              let customer_result = await con.query(`SELECT timesheets.update_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, customerData);
              syncClients.push(customer_result);

            } else {
              let customerData = [
                org_id,
                client_name,
                dba,
                is_placement_client,
                placement_client_id,
                qb_customer_name,
                qb_customer_id,
                qb_vendor_name,
                qb_vendor_id,
                createdby,
                record_type_status,
              ];

              let customer_result = await con.query(`SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`, customerData );

              syncClients.push(customer_result);

            }
          }
        }
        //////////////////// add/update clients ends here /////////////

        // fetch HRMS projects
        let [projects] = await orgdbcon.promise().query(`
        SELECT 
        p.*,
        jt.jobtitlename as job_title,
        tbl_countries.country_name as work_country, 
        tbl_states.state_name as work_state, 
        tbl_cities.city_name as work_city, 
        c.client_name,
        pv.client_name as prime_vendor_name, 
        v2.client_name as vendor2_name, 
        v1.client_name as vendor1_name, 
        ec.client_name as end_customer_name
        FROM tm_projects p
        LEFT JOIN main_jobtitles jt ON jt.id = p.jobtitle_id
        LEFT JOIN tbl_countries tbl_countries ON (tbl_countries.id = p.perm_country)
        LEFT JOIN tbl_states tbl_states ON (tbl_states.id = p.perm_state)
        LEFT JOIN tbl_cities tbl_cities ON (tbl_cities.id = p.perm_city)
        LEFT JOIN tm_clients c ON c.id = p.client_id
        LEFT JOIN tm_clients pv ON pv.id = p.prime_vendor
        LEFT JOIN tm_clients v2 ON v2.id = p.vendor_2
        LEFT JOIN tm_clients v1 ON v1.id = p.vendor_1
        LEFT JOIN tm_clients ec ON ec.id = p.end_customer
        ORDER BY p.id ASC
        `
        );
        
        // console.log("projects", projects, projects.length);

        if(projects && projects.length){
          
          // insert/update projects data
          for (var i = 0; i < projects.length; i++) {

            let projectRow = projects[i] || null;
            let hrms_project_id = projectRow.id;
            let end_customer = null;
            let project_status = projectStatusMap[projectRow.project_status] || "IN_PROGRESS";

            let {
              user_id: hrms_user_id = null,
              start_date = null,
              end_date = null,
              client_id = null,
              client_manager_name = null,
              client_manager_email = null,
              job_title = null,
              is_placement_project = false,
              placement_type = null,
              placement_project_id = null,
              placement_code = null,
              bill_rate = null,
              pay_rate = null,
              bill_rate_currency = null,
              ot_bill_rate = null,
              ot_pay_rate = null,
              ot_bill_rate_currency = null,
              is_primary_project = null,
              direct_customer_engagement = false,
              qb_customer_name = null,
              qb_customer_id = null,
              qb_project_name = null,
              qb_project_id = null,
              qb_product_id = null,
              qb_product_name = null,
              status = null,
              work_country = null,
              work_email = null,
              work_phone = null,
              work_state = null,
              work_city = null,
              is_updated = false,
              cancel_date = null,
              reason = null,
              reason_id = null,
              qb_status = null,
              createdby = 1,
              updatedby = 1,
              prime_vendor_name = null,
              vendor1_name = null,
              vendor2_name = null,
              end_customer_name = null,
              is_active = false,
              
            } = projectRow;


            // fetch HRMS projects
            let [history] = await orgdbcon.promise().query(`
            SELECT * FROM 
            tm_project_bill_rates 
            WHERE project_id = '${hrms_project_id}'
            ORDER BY effective_date DESC
            `
            );

            // console.log("history", history);
            //// set bill rate / pay rate
            if (history && history.length) {
              bill_rate = (history[0] && history[0].bill_rate) || null;
              pay_rate = (history[0] && history[0].agreed_pay_rate) || null;
              bill_rate_currency = (history[0] && history[0].bill_rate_currency) || null;

              ot_bill_rate = (history[0] && history[0].otBillRate) || null;
              ot_pay_rate = (history[0] && history[0].otAgreedPayRate) || null;
              ot_bill_rate_currency = (history[0] && history[0].ot_bill_rate_currency) || null;
            }

            end_customer = end_customer_name;

            user_details = await con.query(`SELECT timesheets.get_user_by_hrms_user_id($1, $2)`, [org_id, hrms_user_id]);
            user_details = (user_details && user_details.rows[0].get_user_by_hrms_user_id && user_details.rows[0].get_user_by_hrms_user_id[0]) || null;
            
            let user_id = (user_details && user_details.id) || 0;
            let candidateName = (user_details && user_details.full_name) || 0;
            
            if(vendor1_name){
              project_name = candidateName + "-" + vendor1_name;
            }
            else{
              project_name = candidateName + "-" + end_customer_name;
            }

            let end_customer_details = await con.query( `SELECT timesheets.get_customer_by_client_name($1, $2)`,  [org_id, end_customer_name]);
            end_customer_details = (end_customer_details && end_customer_details.rows[1].j && end_customer_details.rows[1].j[0]) || null;
            let end_customer_id = (end_customer_details && end_customer_details.id) || 0;

            let record_type_status = is_active == 1 ? "Active" : "Inactive";

            // insert/update customers

            let project_exists = null;
            let project_id = null;
            if(placement_project_id){
              project_exists = await con.query(`SELECT timesheets.get_project_by_placement_project_id($1, $2)`, [org_id, placement_project_id]);
              project_exists = (project_exists && project_exists.rows[0].get_project_by_placement_project_id && project_exists.rows[0].get_project_by_placement_project_id[0]) || null;
              project_id = (project_exists && project_exists.id) || 0;
            }
            else{
              project_exists = await con.query(`SELECT timesheets.get_project_by_hrms_project_id($1, $2)`, [org_id, hrms_project_id]);
              project_exists = (project_exists && project_exists.rows[0].get_project_by_hrms_project_id && project_exists.rows[0].get_project_by_hrms_project_id[0]) || null;
              project_id = (project_exists && project_exists.id) || 0;
            }

            let new_project_id = null;

              
              if (user_id) {

                // console.log(i, "user_id", org_id, user_id, placement_project_id, hrms_project_id)
                if (project_id) {
                  // record_type_status = project_exists.record_type_status;
                  qb_customer_name = project_exists.qb_customer_name;
                  qb_customer_id = project_exists.qb_customer_id;
                  qb_project_name = project_exists.qb_project_name;
                  qb_project_id = project_exists.qb_project_id;
                  qb_product_id = project_exists.qb_product_id;
                  qb_product_name = project_exists.qb_product_name;
                  
                  work_country = work_country || project_exists.work_country || null;
                  client_manager_name = client_manager_name || project_exists.client_manager_name || null;
                  client_manager_email = client_manager_email || project_exists.client_manager_email || null;
                  job_title = job_title || project_exists.job_title || null;

                  let projectData = [
                    project_id,
                    org_id,
                    user_id,
                    project_name,
                    project_status,
                    start_date,
                    end_date,
                    client_manager_name,
                    client_manager_email,
                    job_title,
                    is_placement_project,
                    placement_type,
                    placement_project_id,
                    placement_code,
                    bill_rate,
                    pay_rate,
                    bill_rate_currency,
                    ot_bill_rate,
                    ot_pay_rate,
                    ot_bill_rate_currency,
                    is_primary_project,
                    direct_customer_engagement,
                    end_customer_id,
                    qb_customer_name,
                    qb_customer_id,
                    qb_project_name,
                    qb_project_id,
                    qb_product_id,
                    qb_product_name,
                    work_country,
                    work_email,
                    work_phone,
                    work_state,
                    work_city,
                    is_updated,
                    cancel_date,
                    reason,
                    reason_id,
                    qb_status,
                    createdby,
                    record_type_status,
                    hrms_project_id
                  ];

                  let result = await con.query(
                    `SELECT timesheets.update_hrms_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42)`,
                    projectData
                  );
                  result = (result.rows && result.rows[1] && result.rows[1].update_hrms_projects && result.rows[1].update_hrms_projects[0]) || null;
                  new_project_id = result.id || null;
                  syncProjects.push(result);

                } else {
                  let projectData = [
                    org_id,
                    user_id,
                    project_name,
                    project_status,
                    start_date,
                    end_date,
                    client_manager_name,
                    client_manager_email,
                    job_title,
                    is_placement_project,
                    placement_type,
                    placement_project_id,
                    placement_code,
                    bill_rate,
                    pay_rate,
                    bill_rate_currency,
                    ot_bill_rate,
                    ot_pay_rate,
                    ot_bill_rate_currency,
                    is_primary_project,
                    direct_customer_engagement,
                    end_customer_id,
                    qb_customer_name,
                    qb_customer_id,
                    qb_project_name,
                    qb_project_id,
                    qb_product_id,
                    qb_product_name,
                    work_country,
                    work_email,
                    work_phone,
                    work_state,
                    work_city,
                    is_updated,
                    cancel_date,
                    reason,
                    reason_id,
                    qb_status,
                    createdby,
                    record_type_status,
                    hrms_project_id
                  ];

                  let result = await con.query(
                    `SELECT timesheets.insert_hrms_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40, $41)`,
                    projectData
                  );
                  result = (result.rows && result.rows[1] && result.rows[1].insert_hrms_projects && result.rows[1].insert_hrms_projects[0]) || null;
                  new_project_id = result.id || null;
                  syncProjects.push(result);
                }

                if (new_project_id) {
                  let delete_project_vendors = await con.query(
                    `SELECT timesheets.delete_project_vendors_by_project_id($1, $2)`,
                    [org_id, new_project_id]
                  );
                  delete_project_vendors = (delete_project_vendors && delete_project_vendors.rows[0].get_project_by_placement_project_id && delete_project_vendors.rows[0].get_project_by_placement_project_id[0]) || null;

                  // Insert Project Vendors
                  let vendor_name = null;
                  if(prime_vendor_name){
                    vendor_name = prime_vendor_name;
                  }
                  else if(vendor2_name){
                    vendor_name = vendor2_name;
                  }
                  // else if(vendor1_name){
                  //   vendor_name = vendor1_name;
                  // }
                  
                  if(vendor_name){
                    
                    let vendor_details = await con.query(`SELECT timesheets.get_customer_by_client_name($1, $2)`, [org_id, vendor_name] );
                    vendor_details = (vendor_details && vendor_details.rows[1].j && vendor_details.rows[1].j[0]) || null;

                    let customer_id = (vendor_details && vendor_details.id) || 0;

                    let projectVendorData = [
                      org_id,
                      new_project_id,
                      customer_id,
                      false,
                      createdby,
                      record_type_status,
                    ];

                    let insertVendor = await con.query(`SELECT timesheets.insert_project_vendors($1,$2,$3,$4,$5,$6)`, projectVendorData );
                    insertVendor = (insertVendor && insertVendor.rows && insertVendor.rows[1] && insertVendor.rows[1].insert_project_vendors && insertVendor.rows[1].insert_project_vendors[0]) || null;
                  }

                  //////////////////

                  // Insert Project Bill Rates
                  let delete_project_bill_rates = await con.query( `SELECT timesheets.delete_project_bill_rates_by_project_id($1, $2)`, [org_id, new_project_id] );
                  delete_project_bill_rates = (delete_project_bill_rates && delete_project_bill_rates.rows[0].delete_project_bill_rates_by_project_id && delete_project_bill_rates.rows[0].delete_project_bill_rates_by_project_id[0]) || null;

                  if (history && history.length) {

                    for (var j = 0; j < history.length; j++) {
                      let billRatesRow = history[j] || null;
                      let {
                        effective_date = null,
                        bill_rate = null,
                        agreed_pay_rate = null,
                        bill_rate_currency = null,
                        ot_bill_rate = null,
                        ot_agreed_pay_rate = null,
                        ot_bill_rate_currency = null,
                        createdby = 1,
                        record_type_status = "Active",
                      } = billRatesRow;

                      // effective_date = (effective_date && new Date(effective_date)) || null;

                      let projectBillRateData = [
                        org_id,
                        new_project_id,
                        effective_date,
                        bill_rate,
                        agreed_pay_rate,
                        bill_rate_currency,
                        ot_bill_rate,
                        ot_agreed_pay_rate,
                        ot_bill_rate_currency,
                        createdby,
                        record_type_status,
                      ];

                      let insertBillRate = await con.query(
                        `SELECT timesheets.insert_project_bill_rates($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                        projectBillRateData
                      );
                      insertBillRate = (insertBillRate && insertBillRate.rows && insertBillRate.rows[1] && insertBillRate.rows[1].insert_project_bill_rates && insertBillRate.rows[1].insert_project_bill_rates[0]) || null;
                    }
                  }
                  //////////////////
                }
              }
          }
        }

        /////////////////////////

        returnMessage.isError = false;
        returnMessage.message = "HRMS Projects Synced Successfully";
        returnMessage.data = syncProjects;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_projects";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for migrate_timesheets
const migrate_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {
    let limit = req.query.limit || null;
    let offset = req.query.offset || null;

    let usersLimitStr = (limit && offset) ? `LIMIT ${limit} OFFSET ${offset}`:``;

    let migrate_till_date = `2023-06-30`;
    let tmp_migrate_till_date = moment(`2023-06-30T00:00:00Z`);
    migrate_date_tsp = tmp_migrate_till_date.unix() || null;
    // console.log("migrate_date_tsp", migrate_date_tsp);

    let syncTimesheets = [];
    let org_id = (req.query.org_id && parseInt(req.query.org_id)) || null;
    let tsStatusMap = {
      "no_entry": null,
      "saved": "SAVED",
      "submitted": "SUBMITTED",
      "approved": "APPROVED",
      "rejected": "REJECTED",
    };

    if(!org_id){
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "migrate_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      

      let [clientdbs] = await mysqlcon.promise().query(`SELECT * from clients WHERE ecdb_org_id = '${org_id}'`);
      clientdbs = (clientdbs && clientdbs.length && clientdbs[0]) || null;

      // console.log(clientdbs);

      // if org db setting found
      if(clientdbs && clientdbs.client_id){

        //// Connect to HRMS Org DB
        let { host, db_name:database, user_name: user, password } = clientdbs;
        // console.log(host, database, user, password);

        var orgdbconfig = {
          host: host,
          port: process.env.HRMS_DB_PORT,
          user: user,
          password: password,
          database: database,
          connectionLimit: 10
        };
        const orgdbcon = new mysql.createPool(orgdbconfig);

        // fetch HRMS users
        let [users] = await orgdbcon.promise().query(`
        SELECT u.*, me.prefix_id, me.date_of_joining, me.date_of_leaving, md.deptname, tbl_countries.country_name, tbl_states.state_name, tbl_cities.city_name, me.work_streetaddress, me.work_zipcode, main_gender.gendername  from main_users u
        LEFT JOIN main_employees me ON (me.user_id = u.id)
        LEFT JOIN main_emppersonaldetails mepd ON (mepd.user_id = u.id)
        LEFT JOIN main_departments md ON (md.id = me.department_id)
        LEFT JOIN tbl_countries tbl_countries ON (tbl_countries.id = me.perm_country)
        LEFT JOIN tbl_states tbl_states ON (tbl_states.id = me.perm_state)
        LEFT JOIN tbl_cities tbl_cities ON (tbl_cities.id = me.perm_city)
        LEFT JOIN main_gender main_gender ON (main_gender.id = mepd.genderid)
        ORDER BY u.id ASC
        ${usersLimitStr}
        `);
        
        // console.log("users", users);

        if(users){

          for(var i = 0; i < users.length; i++){
            
            let userRow = users[i];
            // console.log("userRow", userRow);
            let user_id = null;

            let {
              id: hrms_user_id,
            } = userRow;


            ////////// get hrms approver data //////
            let [hrms_approver] = await orgdbcon.promise().query(`
            SELECT a.* from main_timesheet_approvers a
            WHERE a.user_id = '${hrms_user_id}' AND is_active = 1
            ORDER BY a.id ASC LIMIT 1
            `);
            let hrms_approver_id = (hrms_approver && hrms_approver[0] && hrms_approver[0].approver_id) || null;
            let approver_id = null;
            if(hrms_approver_id){
              approver_details = await con.query(`SELECT timesheets.get_user_by_hrms_user_id($1, $2)`, [org_id, hrms_approver_id]);
              approver_details = (approver_details && approver_details.rows[0].get_user_by_hrms_user_id && approver_details.rows[0].get_user_by_hrms_user_id[0]) || null;

              approver_id = (approver_details && approver_details.id) || null

            }

            // check user exists in timesheets DB
            user_details = await con.query(`SELECT timesheets.get_user_by_hrms_user_id($1, $2)`, [org_id, hrms_user_id]);
            user_details = (user_details && user_details.rows[0].get_user_by_hrms_user_id && user_details.rows[0].get_user_by_hrms_user_id[0]) || null;

            if(user_details && user_details.id /* && user_details.id ==1058 */){

              let user_id = (user_details && user_details.id) || 0;

              // fetch all HRMS timesheets without date limit
              // let [timesheets] = await orgdbcon.promise().query(`
              // SELECT 
              // t.*,
              // ts.sun_status,
              // ts.mon_status,
              // ts.tue_status,
              // ts.wed_status,
              // ts.thu_status,
              // ts.fri_status,
              // ts.sat_status,
              // ts.week_status,
              // ts.sun_reject_note,
              // ts.mon_reject_note,
              // ts.tue_reject_note,
              // ts.wed_reject_note,
              // ts.thu_reject_note,
              // ts.fri_reject_note,
              // ts.sat_reject_note,
              // tn.week_note
              // FROM tm_emp_timesheets t
              // LEFT JOIN tm_ts_status ts ON (t.emp_id = ts.emp_id AND t.project_id = ts.project_id AND t.ts_year = ts.ts_year AND t.ts_month = ts.ts_month AND t.ts_week = ts.ts_week AND t.cal_week = ts.cal_week)
              // LEFT JOIN tm_emp_ts_notes tn ON (t.emp_id = tn.emp_id AND t.ts_year = tn.ts_year AND t.ts_month = tn.ts_month AND t.ts_week = tn.ts_week AND t.cal_week = tn.cal_week)
              // WHERE t.emp_id = '${user_details.hrms_user_id}'
              // ORDER BY t.id ASC
              // `);

              // fetch HRMS timesheets till 30th june 
              let [timesheets] = await orgdbcon.promise().query(`
              SELECT 
              t.*,
              ts.sun_status,
              ts.mon_status,
              ts.tue_status,
              ts.wed_status,
              ts.thu_status,
              ts.fri_status,
              ts.sat_status,
              ts.week_status,
              ts.sun_reject_note,
              ts.mon_reject_note,
              ts.tue_reject_note,
              ts.wed_reject_note,
              ts.thu_reject_note,
              ts.fri_reject_note,
              ts.sat_reject_note,
              tn.week_note
              FROM tm_emp_timesheets t
              LEFT JOIN tm_ts_status ts ON (t.emp_id = ts.emp_id AND t.project_id = ts.project_id AND t.ts_year = ts.ts_year AND t.ts_month = ts.ts_month AND t.ts_week = ts.ts_week AND t.cal_week = ts.cal_week)
              LEFT JOIN tm_emp_ts_notes tn ON (t.emp_id = tn.emp_id AND t.ts_year = tn.ts_year AND t.ts_month = tn.ts_month AND t.ts_week = tn.ts_week AND t.cal_week = tn.cal_week)
              WHERE t.emp_id = '${user_details.hrms_user_id}'
              AND (
                t.sun_date <= '${migrate_till_date}'
                OR t.mon_date <= '${migrate_till_date}'
                OR t.tue_date <= '${migrate_till_date}'
                OR t.wed_date <= '${migrate_till_date}'
                OR t.thu_date <= '${migrate_till_date}'
                OR t.fri_date <= '${migrate_till_date}'
                OR t.sat_date <= '${migrate_till_date}'
              )
              ORDER BY t.id ASC
              `);

              if(timesheets && timesheets.length){
                for(var j = 0; j < timesheets.length; j++){
                  
                  let timesheetRow = timesheets[j];
        
                  let hrms_project_id = timesheetRow.project_id;

                  // check user exists in timesheets DB
                  project_details = await con.query(`SELECT timesheets.get_project_by_hrms_project_id($1, $2)`, [org_id, hrms_project_id]);
                  project_details = (project_details && project_details.rows[0].get_project_by_hrms_project_id && project_details.rows[0].get_project_by_hrms_project_id[0]) || null;

                  // console.log("project_details", project_details);
                  let project_id = (project_details && project_details.id) || 0;
                  
                  let monthNo = 0;
                  let weekNo = 0;
                  let sun_date = (timesheetRow.sun_date && moment(timesheetRow.sun_date).format("YYYY-MM-DD")) || ``;

                  let tsYear = timesheetRow.ts_year;
                  let tsMonth = timesheetRow.ts_month;
                  let sunMonth = (sun_date && parseInt(sun_date.split("-")[1])) || null

                  if(tsMonth > sunMonth){
                    let tmpDate = moment(timesheetRow.sat_date, "YYYY-MM-DD");
                    weekNo = tmpDate.week() - tmpDate.clone().startOf("month").week() + 1;
                    // monthNo = tsMonth;
                  }
                  else if(tsMonth < sunMonth){
                    let tmpDate = moment(timesheetRow.sun_date, "YYYY-MM-DD");
                    weekNo = tmpDate.week() - tmpDate.clone().startOf("month").week() + 1;
                    // monthNo = tsMonth;
                  }
                  else{
                    let tmpDate = moment(timesheetRow.sun_date, "YYYY-MM-DD");
                    weekNo = tmpDate.week() - tmpDate.clone().startOf("month").week() + 1;
                    // monthNo = tsMonth;
                  }

                  // generate new week range 
                  // let firstDayOfMonth = moment(`${tsYear}-${(tsMonth > 9)?tsMonth:`0${tsMonth}`}-01`);
                  // let startDate = firstDayOfMonth.add(weekNo - 1, "weeks").startOf("isoWeek");
                  // let endDate = startDate.clone().endOf("isoWeek");

                  // startDate = startDate.format("YYYY-MM-DD");
                  // endDate = endDate.format("YYYY-MM-DD");

                  let weekDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
                  for(var k = 0; k < weekDays.length; k++){
                    // if(k==0){
                    //   console.log("===============");
                    // }
                    
                    let timesheet_date = (timesheetRow[`${weekDays[k]}_date`] && moment(timesheetRow[`${weekDays[k]}_date`]).format("YYYY-MM-DD")) || ``;

                    let tmp_timesheet_date = moment(`${timesheet_date}T00:00:00Z`);
                    timesheet_date_tsp = tmp_timesheet_date.unix() || null;
                    
                    let timesheet_date_month = (timesheet_date && parseInt(timesheet_date.split("-")[1])) || null;

                    // migrate till june 30th 2023
                    if(timesheet_date_tsp <= migrate_date_tsp){
                      if(timesheet_date_month == tsMonth){
                      
                        // console.log(timesheet_date_month, timesheet_date);
  
                        let tmpDate = moment(timesheet_date, "YYYY-MM-DD");
                        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
                        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");
  
                        let ts_documents = (timesheetRow.ts_document && JSON.parse(timesheetRow.ts_document)) || null;
                        let day_status = timesheetRow[`${weekDays[k]}_status`] || null;
                        let week_status = timesheetRow.week_status || null;
                        let week_note = timesheetRow.week_note || null;
                        // console.log("week_note", week_status, week_note);
  
  
                        ///////////////////////////////
  
                        let hrms_regular_hours = (timesheetRow[`${weekDays[k]}_duration`] && timesheetRow[`${weekDays[k]}_duration`].split(":")) || null;
  
                        let hrms_ot_hours = (timesheetRow[`${weekDays[k]}_ot_duration`] && timesheetRow[`${weekDays[k]}_ot_duration`].split(":")) || null;
                        
                        let regular_hours = (hrms_regular_hours && parseInt(hrms_regular_hours[0])) || null;
                        let regular_minutes = (hrms_regular_hours && parseInt(hrms_regular_hours[1])) || null;
  
                        let ot_hours = (hrms_ot_hours && parseInt(hrms_ot_hours[0])) || null;
                        let ot_minutes = (hrms_ot_hours && parseInt(hrms_ot_hours[1])) || null;
  
                        // console.log("regular_hours", timesheetRow.id, {regular_hours, regular_minutes, ot_hours, ot_minutes});
  
  
                        let absent_type = null;
                        let absent_hours = null;
                        let absent_minutes = null;
                        let user_notes = timesheetRow.week_note;
                        // let approver_id = null;
                        let approver_notes = timesheetRow.week_note;
                        let qb_timesheet_id = null;
                        let qb_status = null;
              
                        var tdate = `${timesheet_date}T00:00:00Z`;
                        var day_name = moment(tdate).format("dddd");
                        let status = tsStatusMap[day_status] || TIMESHEET_STATUS.SAVED;
  
                        createdby = user_id;
                        updatedby = approver_id;
                        record_type_status = "Active";
  
                        
                        // console.log("status", status);
  
                        let timesheet_exists = await con.query(`SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`, [org_id, project_id, timesheet_date]);
              
                        timesheet_exists = (timesheet_exists && timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id && timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id[0]) || null;
  
                        // console.log("timesheet_exists", timesheet_exists);
  
                        if (timesheet_exists && timesheet_exists.id) {
                          // update
                          let timesheet_id = timesheet_exists.id;
                         
                          var timesheetData = [
                            timesheet_id,
                            org_id,
                            user_id,
                            project_id,
                            week_start_date.split("-")[0], // year
                            parseInt(week_start_date.split("-")[1]), // month
                            week_start_date,
                            week_end_date,
                            timesheet_date,
                            day_name,
                            (regular_hours || 0),
                            (regular_minutes || 0),
                            (ot_hours || 0),
                            (ot_minutes || 0),
                            (absent_type || null),
                            (absent_hours || 0),
                            (absent_minutes || 0),
                            status,
                            user_notes,
                            approver_id,
                            approver_notes,
                            qb_timesheet_id,
                            qb_status,
                            updatedby,
                            record_type_status,
                          ];
              
                          let results = await con.query(
                            `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                            timesheetData
                          );
                          var update_data =
                            (results.rows &&
                              results.rows[1] &&
                              results.rows[1].update_timesheet &&
                              results.rows[1].update_timesheet[0]) ||
                            null;
              
                          await InsertTimesheetHistory(org_id, update_data.id);
                        } else {
                          // insert
                          var timesheetData = [
                            org_id,
                            user_id,
                            project_id,
                            week_start_date.split("-")[0], // year
                            parseInt(week_start_date.split("-")[1]), // month
                            week_start_date,
                            week_end_date,
                            timesheet_date,
                            day_name,
                            (regular_hours || 0),
                            (regular_minutes || 0),
                            (ot_hours || 0),
                            (ot_minutes || 0),
                            (absent_type || null),
                            (absent_hours || 0),
                            (absent_minutes || 0),
                            status,
                            user_notes,
                            approver_id,
                            approver_notes,
                            qb_timesheet_id,
                            qb_status,
                            createdby,
                            record_type_status,
                          ];
              
                          let results = await con.query(
                            `SELECT timesheets.insert_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
                            timesheetData
                          );
              
                          var insert_data =
                            (results.rows &&
                              results.rows[1] &&
                              results.rows[1].insert_timesheet &&
                              results.rows[1].insert_timesheet[0]) ||
                            null;
                          await InsertTimesheetHistory(org_id, insert_data.id);
                        }
  
                        let statusData = {
                          org_id: org_id,
                          user_id: user_id,
                          project_id: project_id,
                          year: week_start_date.split("-")[0], // year,
                          month: parseInt(week_start_date.split("-")[1]), // month
                          week_start_date: week_start_date,
                          week_end_date: week_end_date,
                          client_manager_email: timesheetRow.client_manager_email || null,
                          client_manager_name: timesheetRow.client_manager_name || null,
                          user_notes: user_notes,
                          approver_id: approver_id,
                          approver_notes: approver_notes,
                          createdby: approver_id || createdby,
                        };
                
                        let ts_status_data = await ResetTimesheetStatus(statusData);
  
                        // console.log("ts_status_data", ts_status_data);
  
                        //////// insert daily reject note /////////
                        if(ts_status_data && ts_status_data.id && status == TIMESHEET_STATUS.REJECTED && timesheetRow[`${weekDays[k]}_reject_note`]){
  
                          let check_timesheet_comment = await con.query(
                            `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
                            [
                              org_id,
                              project_id,
                              week_start_date,
                              week_end_date,
                              TS_COMMENT_TYPE.DAILY,
                              TS_COMMENT_USER_TYPE.APPROVER,
                            ]
                          );
                      
                          check_timesheet_comment =
                            (check_timesheet_comment &&
                              check_timesheet_comment.rows[0].get_last_timesheet_comment &&
                              check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
                            null;
                      
                          let last_comment = (check_timesheet_comment && check_timesheet_comment.id && check_timesheet_comment.comments) || null;
  
                          if(!last_comment){
                            let comment_type = TS_COMMENT_TYPE.DAILY;
                            let user_type = TS_COMMENT_USER_TYPE.APPROVER;
    
                            let tsCommentData = [
                              org_id,
                              comment_type,
                              timesheet_date,
                              user_type,
                              approver_id,
                              timesheetRow[`${weekDays[k]}_reject_note`],
                              ts_status_data.id,
                              project_id,
                              week_start_date,
                              week_end_date,
                              createdby,
                              record_type_status,
                            ];
                            await con.query( `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, tsCommentData );
                          }
                          
                        }
                        ////////////////insert daily reject note ends///////////////////
                        
                        let last_documents = await con.query(`SELECT * from timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4);`, 
                        [
                          org_id,
                          week_start_date,
                          week_end_date,
                          project_id,
                        ]);
  
                        last_documents = (last_documents && last_documents.rows[0].j && last_documents.rows[0].j[0]) || null;
                        last_documents = (last_documents && last_documents.id && last_documents.original_name) || null;
  
                        // Insert timesheet documents
                        if (ts_status_data && ts_status_data.id && ts_documents && !last_documents) {
                          for(var docI = 0; docI < ts_documents.length; docI++){
                            await con.query(
                              `SELECT timesheets.insert_hrms_timesheet_documents($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
                              [
                                org_id,
                                user_id,
                                project_id,
                                ts_status_data.id,
                                ts_documents[docI],
                                ts_documents[docI],
                                week_start_date,
                                week_end_date,
                                createdby,
                                record_type_status,
                              ]
                            );
                          }
                        }
                        
                        // check last comment
                        let check_timesheet_comment = await con.query(
                          `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
                          [
                            org_id,
                            project_id,
                            week_start_date,
                            week_end_date,
                            TS_COMMENT_TYPE.WEEKLY,
                            TS_COMMENT_USER_TYPE.EMPLOYEE,
                          ]
                        );
  
                        check_timesheet_comment = (check_timesheet_comment && check_timesheet_comment.rows[0].get_last_timesheet_comment && check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) || null;
  
                        let last_comment = (check_timesheet_comment && check_timesheet_comment.id && check_timesheet_comment.comments) || null;
                        
                        // Insert note/comment
                        if (ts_status_data && ts_status_data.id && user_notes && !last_comment) {
  
                          let comment_type = TS_COMMENT_TYPE.WEEKLY;
                          let user_type = TS_COMMENT_USER_TYPE.EMPLOYEE;
  
                          let tsCommentData = [
                            org_id,
                            comment_type,
                            null,
                            user_type,
                            user_id,
                            user_notes,
                            ts_status_data.id,
                            project_id,
                            week_start_date,
                            week_end_date,
                            createdby,
                            record_type_status,
                          ];
                          var result = await con.query(
                            `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                            tsCommentData
                          );
                        }
                        //////////////////////////////
                      }
                    }
                    
                    
                  }
                }
              }
              
            }
            
          }
        }

        /////////////////////////

        returnMessage.isError = false;
        returnMessage.message = "HRMS Timesheets Synced Successfully";
        returnMessage.data = syncTimesheets;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// api for migrate_timesheets after june 30th
const migrate_timesheets_after_june = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {
    let limit = req.query.limit || null;
    let offset = req.query.offset || null;

    let usersLimitStr = (limit && offset) ? `LIMIT ${limit} OFFSET ${offset}`:``;

    let migrate_after_date = `2023-06-30`;
    let tmp_migrate_after_date = moment(`2023-06-30T00:00:00Z`);
    migrate_date_tsp = tmp_migrate_after_date.unix() || null;
    // console.log("migrate_date_tsp", migrate_date_tsp);

    let syncTimesheets = [];
    let org_id = (req.query.org_id && parseInt(req.query.org_id)) || null;
    let tsStatusMap = {
      "no_entry": null,
      "saved": "SAVED",
      "submitted": "SUBMITTED",
      "approved": "APPROVED",
      "rejected": "REJECTED",
    };

    if(!org_id){
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "migrate_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      

      let [clientdbs] = await mysqlcon.promise().query(`SELECT * from clients WHERE ecdb_org_id = '${org_id}'`);
      clientdbs = (clientdbs && clientdbs.length && clientdbs[0]) || null;

      // console.log(clientdbs);

      // if org db setting found
      if(clientdbs && clientdbs.client_id){

        //// Connect to HRMS Org DB
        let { host, db_name:database, user_name: user, password } = clientdbs;
        // console.log(host, database, user, password);

        var orgdbconfig = {
          host: host,
          port: process.env.HRMS_DB_PORT,
          user: user,
          password: password,
          database: database,
          connectionLimit: 10
        };
        const orgdbcon = new mysql.createPool(orgdbconfig);

        // fetch HRMS users
        let [users] = await orgdbcon.promise().query(`
        SELECT u.*, me.prefix_id, me.date_of_joining, me.date_of_leaving, md.deptname, tbl_countries.country_name, tbl_states.state_name, tbl_cities.city_name, me.work_streetaddress, me.work_zipcode, main_gender.gendername  from main_users u
        LEFT JOIN main_employees me ON (me.user_id = u.id)
        LEFT JOIN main_emppersonaldetails mepd ON (mepd.user_id = u.id)
        LEFT JOIN main_departments md ON (md.id = me.department_id)
        LEFT JOIN tbl_countries tbl_countries ON (tbl_countries.id = me.perm_country)
        LEFT JOIN tbl_states tbl_states ON (tbl_states.id = me.perm_state)
        LEFT JOIN tbl_cities tbl_cities ON (tbl_cities.id = me.perm_city)
        LEFT JOIN main_gender main_gender ON (main_gender.id = mepd.genderid)
        ORDER BY u.id ASC
        ${usersLimitStr}
        `);
        
        // console.log("users", users);

        if(users){

          for(var i = 0; i < users.length; i++){
            
            let userRow = users[i];
            // console.log("userRow", userRow);
            let user_id = null;

            let {
              id: hrms_user_id,
            } = userRow;


            ////////// get hrms approver data //////
            let [hrms_approver] = await orgdbcon.promise().query(`
            SELECT a.* from main_timesheet_approvers a
            WHERE a.user_id = '${hrms_user_id}' AND is_active = 1
            ORDER BY a.id ASC LIMIT 1
            `);
            let hrms_approver_id = (hrms_approver && hrms_approver[0] && hrms_approver[0].approver_id) || null;
            let approver_id = null;
            if(hrms_approver_id){
              approver_details = await con.query(`SELECT timesheets.get_user_by_hrms_user_id($1, $2)`, [org_id, hrms_approver_id]);
              approver_details = (approver_details && approver_details.rows[0].get_user_by_hrms_user_id && approver_details.rows[0].get_user_by_hrms_user_id[0]) || null;

              approver_id = (approver_details && approver_details.id) || null

            }

            // check user exists in timesheets DB
            user_details = await con.query(`SELECT timesheets.get_user_by_hrms_user_id($1, $2)`, [org_id, hrms_user_id]);
            user_details = (user_details && user_details.rows[0].get_user_by_hrms_user_id && user_details.rows[0].get_user_by_hrms_user_id[0]) || null;

            if(user_details && user_details.id /* && user_details.id ==1058 */){

              let user_id = (user_details && user_details.id) || 0;

              // fetch HRMS timesheets after 30th june 
              let [timesheets] = await orgdbcon.promise().query(`
              SELECT 
              t.*,
              ts.sun_status,
              ts.mon_status,
              ts.tue_status,
              ts.wed_status,
              ts.thu_status,
              ts.fri_status,
              ts.sat_status,
              ts.week_status,
              ts.sun_reject_note,
              ts.mon_reject_note,
              ts.tue_reject_note,
              ts.wed_reject_note,
              ts.thu_reject_note,
              ts.fri_reject_note,
              ts.sat_reject_note,
              tn.week_note
              FROM tm_emp_timesheets t
              LEFT JOIN tm_ts_status ts ON (t.emp_id = ts.emp_id AND t.project_id = ts.project_id AND t.ts_year = ts.ts_year AND t.ts_month = ts.ts_month AND t.ts_week = ts.ts_week AND t.cal_week = ts.cal_week)
              LEFT JOIN tm_emp_ts_notes tn ON (t.emp_id = tn.emp_id AND t.ts_year = tn.ts_year AND t.ts_month = tn.ts_month AND t.ts_week = tn.ts_week AND t.cal_week = tn.cal_week)
              WHERE t.emp_id = '${user_details.hrms_user_id}'
              AND (
                t.sun_date >= '${migrate_after_date}'
                OR t.mon_date >= '${migrate_after_date}'
                OR t.tue_date >= '${migrate_after_date}'
                OR t.wed_date >= '${migrate_after_date}'
                OR t.thu_date >= '${migrate_after_date}'
                OR t.fri_date >= '${migrate_after_date}'
                OR t.sat_date >= '${migrate_after_date}'
                OR DATE(t.created) >= '${migrate_after_date}'
				        OR DATE(t.modified) >= '${migrate_after_date}'
              )
              ORDER BY t.id ASC
              `);

              if(timesheets && timesheets.length){
                for(var j = 0; j < timesheets.length; j++){
                  
                  let timesheetRow = timesheets[j];
        
                  let hrms_project_id = timesheetRow.project_id;

                  // check user exists in timesheets DB
                  project_details = await con.query(`SELECT timesheets.get_project_by_hrms_project_id($1, $2)`, [org_id, hrms_project_id]);
                  project_details = (project_details && project_details.rows[0].get_project_by_hrms_project_id && project_details.rows[0].get_project_by_hrms_project_id[0]) || null;

                  // console.log("project_details", project_details);
                  let project_id = (project_details && project_details.id) || 0;
                  
                  let monthNo = 0;
                  let weekNo = 0;
                  let sun_date = (timesheetRow.sun_date && moment(timesheetRow.sun_date).format("YYYY-MM-DD")) || ``;

                  let tsYear = timesheetRow.ts_year;
                  let tsMonth = timesheetRow.ts_month;
                  let sunMonth = (sun_date && parseInt(sun_date.split("-")[1])) || null

                  if(tsMonth > sunMonth){
                    let tmpDate = moment(timesheetRow.sat_date, "YYYY-MM-DD");
                    weekNo = tmpDate.week() - tmpDate.clone().startOf("month").week() + 1;
                    // monthNo = tsMonth;
                  }
                  else if(tsMonth < sunMonth){
                    let tmpDate = moment(timesheetRow.sun_date, "YYYY-MM-DD");
                    weekNo = tmpDate.week() - tmpDate.clone().startOf("month").week() + 1;
                    // monthNo = tsMonth;
                  }
                  else{
                    let tmpDate = moment(timesheetRow.sun_date, "YYYY-MM-DD");
                    weekNo = tmpDate.week() - tmpDate.clone().startOf("month").week() + 1;
                    // monthNo = tsMonth;
                  }

                  // generate new week range 
                  // let firstDayOfMonth = moment(`${tsYear}-${(tsMonth > 9)?tsMonth:`0${tsMonth}`}-01`);
                  // let startDate = firstDayOfMonth.add(weekNo - 1, "weeks").startOf("isoWeek");
                  // let endDate = startDate.clone().endOf("isoWeek");

                  // startDate = startDate.format("YYYY-MM-DD");
                  // endDate = endDate.format("YYYY-MM-DD");

                  let weekDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
                  for(var k = 0; k < weekDays.length; k++){
                    // if(k==0){
                    //   console.log("===============");
                    // }
                    
                    let timesheet_date = (timesheetRow[`${weekDays[k]}_date`] && moment(timesheetRow[`${weekDays[k]}_date`]).format("YYYY-MM-DD")) || ``;

                    let tmp_timesheet_date = moment(`${timesheet_date}T00:00:00Z`);
                    timesheet_date_tsp = tmp_timesheet_date.unix() || null;
                    
                    let timesheet_date_month = (timesheet_date && parseInt(timesheet_date.split("-")[1])) || null;

                    if(timesheet_date_tsp){
                      if(timesheet_date_month == tsMonth){
                      
                        // console.log(timesheet_date_month, timesheet_date);
  
                        let tmpDate = moment(timesheet_date, "YYYY-MM-DD");
                        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
                        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");
  
                        let ts_documents = (timesheetRow.ts_document && JSON.parse(timesheetRow.ts_document)) || null;
                        let day_status = timesheetRow[`${weekDays[k]}_status`] || null;
                        let week_status = timesheetRow.week_status || null;
                        let week_note = timesheetRow.week_note || null;
                        // console.log("week_note", week_status, week_note);
  
  
                        ///////////////////////////////
  
                        let hrms_regular_hours = (timesheetRow[`${weekDays[k]}_duration`] && timesheetRow[`${weekDays[k]}_duration`].split(":")) || null;
  
                        let hrms_ot_hours = (timesheetRow[`${weekDays[k]}_ot_duration`] && timesheetRow[`${weekDays[k]}_ot_duration`].split(":")) || null;
                        
                        let regular_hours = (hrms_regular_hours && parseInt(hrms_regular_hours[0])) || null;
                        let regular_minutes = (hrms_regular_hours && parseInt(hrms_regular_hours[1])) || null;
  
                        let ot_hours = (hrms_ot_hours && parseInt(hrms_ot_hours[0])) || null;
                        let ot_minutes = (hrms_ot_hours && parseInt(hrms_ot_hours[1])) || null;
  
                        // console.log("regular_hours", timesheetRow.id, {regular_hours, regular_minutes, ot_hours, ot_minutes});
  
  
                        let absent_type = null;
                        let absent_hours = null;
                        let absent_minutes = null;
                        let user_notes = timesheetRow.week_note;
                        // let approver_id = null;
                        let approver_notes = timesheetRow.week_note;
                        let qb_timesheet_id = null;
                        let qb_status = null;
              
                        var tdate = `${timesheet_date}T00:00:00Z`;
                        var day_name = moment(tdate).format("dddd");
                        let status = tsStatusMap[day_status] || TIMESHEET_STATUS.SAVED;
  
                        createdby = user_id;
                        updatedby = approver_id;
                        record_type_status = "Active";
  
                        
                        // console.log("status", status);
  
                        let timesheet_exists = await con.query(`SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`, [org_id, project_id, timesheet_date]);
              
                        timesheet_exists = (timesheet_exists && timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id && timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id[0]) || null;
  
                        // console.log("timesheet_exists", timesheet_exists);
  
                        if (timesheet_exists && timesheet_exists.id) {
                          // update
                          let timesheet_id = timesheet_exists.id;
                         
                          var timesheetData = [
                            timesheet_id,
                            org_id,
                            user_id,
                            project_id,
                            week_start_date.split("-")[0], // year
                            parseInt(week_start_date.split("-")[1]), // month
                            week_start_date,
                            week_end_date,
                            timesheet_date,
                            day_name,
                            (regular_hours || 0),
                            (regular_minutes || 0),
                            (ot_hours || 0),
                            (ot_minutes || 0),
                            (absent_type || null),
                            (absent_hours || 0),
                            (absent_minutes || 0),
                            status,
                            user_notes,
                            approver_id,
                            approver_notes,
                            qb_timesheet_id,
                            qb_status,
                            updatedby,
                            record_type_status,
                          ];
              
                          let results = await con.query(
                            `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                            timesheetData
                          );
                          var update_data =
                            (results.rows &&
                              results.rows[1] &&
                              results.rows[1].update_timesheet &&
                              results.rows[1].update_timesheet[0]) ||
                            null;
              
                          await InsertTimesheetHistory(org_id, update_data.id);
                        } else {
                          // insert
                          var timesheetData = [
                            org_id,
                            user_id,
                            project_id,
                            week_start_date.split("-")[0], // year
                            parseInt(week_start_date.split("-")[1]), // month
                            week_start_date,
                            week_end_date,
                            timesheet_date,
                            day_name,
                            (regular_hours || 0),
                            (regular_minutes || 0),
                            (ot_hours || 0),
                            (ot_minutes || 0),
                            (absent_type || null),
                            (absent_hours || 0),
                            (absent_minutes || 0),
                            status,
                            user_notes,
                            approver_id,
                            approver_notes,
                            qb_timesheet_id,
                            qb_status,
                            createdby,
                            record_type_status,
                          ];
              
                          let results = await con.query(
                            `SELECT timesheets.insert_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
                            timesheetData
                          );
              
                          var insert_data =
                            (results.rows &&
                              results.rows[1] &&
                              results.rows[1].insert_timesheet &&
                              results.rows[1].insert_timesheet[0]) ||
                            null;
                          await InsertTimesheetHistory(org_id, insert_data.id);
                        }
  
                        let statusData = {
                          org_id: org_id,
                          user_id: user_id,
                          project_id: project_id,
                          year: week_start_date.split("-")[0], // year,
                          month: parseInt(week_start_date.split("-")[1]), // month
                          week_start_date: week_start_date,
                          week_end_date: week_end_date,
                          client_manager_email: timesheetRow.client_manager_email || null,
                          client_manager_name: timesheetRow.client_manager_name || null,
                          user_notes: user_notes,
                          approver_id: approver_id,
                          approver_notes: approver_notes,
                          createdby: approver_id || createdby,
                        };
                
                        let ts_status_data = await ResetTimesheetStatus(statusData);
  
                        // console.log("ts_status_data", ts_status_data);
  
                        //////// insert daily reject note /////////
                        if(ts_status_data && ts_status_data.id && status == TIMESHEET_STATUS.REJECTED && timesheetRow[`${weekDays[k]}_reject_note`]){
  
                          let check_timesheet_comment = await con.query(
                            `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
                            [
                              org_id,
                              project_id,
                              week_start_date,
                              week_end_date,
                              TS_COMMENT_TYPE.DAILY,
                              TS_COMMENT_USER_TYPE.APPROVER,
                            ]
                          );
                      
                          check_timesheet_comment =
                            (check_timesheet_comment &&
                              check_timesheet_comment.rows[0].get_last_timesheet_comment &&
                              check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
                            null;
                      
                          let last_comment = (check_timesheet_comment && check_timesheet_comment.id && check_timesheet_comment.comments) || null;
  
                          if(!last_comment){
                            let comment_type = TS_COMMENT_TYPE.DAILY;
                            let user_type = TS_COMMENT_USER_TYPE.APPROVER;
    
                            let tsCommentData = [
                              org_id,
                              comment_type,
                              timesheet_date,
                              user_type,
                              approver_id,
                              timesheetRow[`${weekDays[k]}_reject_note`],
                              ts_status_data.id,
                              project_id,
                              week_start_date,
                              week_end_date,
                              createdby,
                              record_type_status,
                            ];
                            await con.query( `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, tsCommentData );
                          }
                          
                        }
                        ////////////////insert daily reject note ends///////////////////
                        
                        let last_documents = await con.query(`SELECT * from timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4);`, 
                        [
                          org_id,
                          week_start_date,
                          week_end_date,
                          project_id,
                        ]);
  
                        last_documents = (last_documents && last_documents.rows[0].j && last_documents.rows[0].j[0]) || null;
                        last_documents = (last_documents && last_documents.id && last_documents.original_name) || null;
  
                        // Insert timesheet documents
                        if (ts_status_data && ts_status_data.id && ts_documents && !last_documents) {
                          for(var docI = 0; docI < ts_documents.length; docI++){
                            await con.query(
                              `SELECT timesheets.insert_hrms_timesheet_documents($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
                              [
                                org_id,
                                user_id,
                                project_id,
                                ts_status_data.id,
                                ts_documents[docI],
                                ts_documents[docI],
                                week_start_date,
                                week_end_date,
                                createdby,
                                record_type_status,
                              ]
                            );
                          }
                        }
                        
                        // check last comment
                        let check_timesheet_comment = await con.query(
                          `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
                          [
                            org_id,
                            project_id,
                            week_start_date,
                            week_end_date,
                            TS_COMMENT_TYPE.WEEKLY,
                            TS_COMMENT_USER_TYPE.EMPLOYEE,
                          ]
                        );
  
                        check_timesheet_comment = (check_timesheet_comment && check_timesheet_comment.rows[0].get_last_timesheet_comment && check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) || null;
  
                        let last_comment = (check_timesheet_comment && check_timesheet_comment.id && check_timesheet_comment.comments) || null;
                        
                        // Insert note/comment
                        if (ts_status_data && ts_status_data.id && user_notes && !last_comment) {
  
                          let comment_type = TS_COMMENT_TYPE.WEEKLY;
                          let user_type = TS_COMMENT_USER_TYPE.EMPLOYEE;
  
                          let tsCommentData = [
                            org_id,
                            comment_type,
                            null,
                            user_type,
                            user_id,
                            user_notes,
                            ts_status_data.id,
                            project_id,
                            week_start_date,
                            week_end_date,
                            createdby,
                            record_type_status,
                          ];
                          var result = await con.query(
                            `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                            tsCommentData
                          );
                        }
                        //////////////////////////////
                      }
                    }
                    
                    
                  }
                }
              }
              
            }
            
          }
        }

        /////////////////////////

        returnMessage.isError = false;
        returnMessage.message = "HRMS Timesheets Synced Successfully";
        returnMessage.data = syncTimesheets;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// api for list_users
const list_users = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {

      let [users] = await mysqlcon.promise().query(`SELECT * from users`);
      console.log("users", users)

      if(users && users.length){
      returnMessage.isError = false;
      returnMessage.message = "Data fetched Successfully";
      returnMessage.data = users;
      res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
      
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_users";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for employee_document_types
const migrate_employee_document_types = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {

    let syncDocTypes = [];
    
    let org_id = (req.query.org_id && parseInt(req.query.org_id)) || null;
    
    if(!org_id){
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "migrate_employee_document_types";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      

      let [clientdbs] = await mysqlcon.promise().query(`SELECT * from clients WHERE ecdb_org_id = '${org_id}'`);
      clientdbs = (clientdbs && clientdbs.length && clientdbs[0]) || null;

      // console.log(clientdbs);

      // if org db setting found
      if(clientdbs && clientdbs.client_id){

        //// Connect to HRMS Org DB
        let { host, db_name:database, user_name: user, password } = clientdbs;
        // console.log(host, database, user, password);

        var orgdbconfig = {
          host: host,
          port: process.env.HRMS_DB_PORT,
          user: user,
          password: password,
          database: database,
          connectionLimit: 10
        };
        const orgdbcon = new mysql.createPool(orgdbconfig);

        // fetch HRMS employee_document_types
        let [employee_document_types] = await orgdbcon.promise().query(`
          SELECT doc_type.*, c.country_name FROM main_identitydocuments doc_type
          LEFT JOIN tbl_countries c ON (c.id = doc_type.perm_country)
          ORDER BY doc_type.id ASC;
        `);
        

        if(employee_document_types){

          for(var i = 0; i < employee_document_types.length; i++){
            
            let docTypeRow = employee_document_types[i];

            let user_id = null;

            let record_type_status = (docTypeRow.isactive == 1)? "Active":"Inactive";

            let {
              id: hrms_doc_id,
              country_name: country_name,
              document_name: document_type_name = null,
              mandatory: is_mandatory,
              expiry: has_expiry,
              description: description,
            } = docTypeRow;

            is_mandatory = is_mandatory? true: false;
            has_expiry = has_expiry? true: false;
            // check if exists in timesheets DB
            doc_type_exists = await con.query(`SELECT * FROM timesheets.get_employee_document_types_by_hrms_doc_id($1, $2)`, [org_id, hrms_doc_id]);
            doc_type_exists = (doc_type_exists && doc_type_exists.rows[0].j && doc_type_exists.rows[0].j[0]) || null;

            if(document_type_name){

              if(doc_type_exists && doc_type_exists.id){
                doc_type_id = doc_type_exists.id;
                // update doc type
                let docTypeData = [
                  doc_type_id,
                  org_id,
                  country_name,
                  document_type_name,
                  is_mandatory,
                  has_expiry,
                  description,
                  hrms_doc_id,        
                  1,
                  record_type_status
                ];
                let updateDocType = await con.query(
                  `SELECT timesheets.update_hrms_employee_document_types($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
                  docTypeData
                );
                updateDocType = (updateDocType.rows && updateDocType.rows[1] && updateDocType.rows[1].update_hrms_employee_document_types && updateDocType.rows[1].update_hrms_employee_document_types[0]) || null;

                syncDocTypes.push(updateDocType);
              }
              else{

                // insert doc type

                let docTypeData = [
                  org_id,
                  country_name,
                  document_type_name,
                  is_mandatory,
                  has_expiry,
                  description,
                  hrms_doc_id,
                  1,
                  record_type_status
                ];
                
                let insertDocType = await con.query(`SELECT timesheets.insert_hrms_employee_document_types($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
                  docTypeData
                );
                insertDocType = (insertDocType.rows && insertDocType.rows[1] && insertDocType.rows[1].insert_hrms_employee_document_types && insertDocType.rows[1].insert_hrms_employee_document_types[0]) || null;
                
                syncDocTypes.push(insertDocType);
              }
            }
            
          }
        }

        /////////////////////////

        returnMessage.isError = false;
        returnMessage.message = "HRMS Employee Document Types Synced Successfully";
        returnMessage.data = syncDocTypes;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_employee_document_types";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// api for migrate_employee_documents
const migrate_employee_documents = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {

    let syncDocs = [];
    
    let org_id = (req.query.org_id && parseInt(req.query.org_id)) || null;
    let limit = req.query.limit || null;
    let offset = req.query.offset || null;

    let limitStr = (limit && offset) ? `LIMIT ${limit} OFFSET ${offset}`:``;
    
    if(!org_id){
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "migrate_employee_documents";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      

      let [clientdbs] = await mysqlcon.promise().query(`SELECT * from clients WHERE ecdb_org_id = '${org_id}'`);
      clientdbs = (clientdbs && clientdbs.length && clientdbs[0]) || null;

      // console.log(clientdbs);

      // if org db setting found
      if(clientdbs && clientdbs.client_id){

        //// Connect to HRMS Org DB
        let { host, db_name:database, user_name: user, password } = clientdbs;
        // console.log(host, database, user, password);

        var orgdbconfig = {
          host: host,
          port: process.env.HRMS_DB_PORT,
          user: user,
          password: password,
          database: database,
          connectionLimit: 10
        };
        const orgdbcon = new mysql.createPool(orgdbconfig);

        // fetch HRMS employee_documents
        let [employee_documents] = await orgdbcon.promise().query(`
          SELECT 
          employee_doc.*,
          u.id as hrms_user_id,
          u.emailaddress,
          doc_type.id as document_type_id, 
          doc_type.document_name as document_type_name, 
          c.country_name 
          FROM 
          main_employeedocuments employee_doc
          LEFT JOIN main_users u  ON (u.id = employee_doc.user_id)
          LEFT JOIN main_identitydocuments doc_type  ON (doc_type.id = employee_doc.document_name)
          LEFT JOIN tbl_countries c ON (c.id = doc_type.perm_country)
          ORDER BY doc_type.id ASC
          ${limitStr};
        `);
        
        // console.log("employee_documents", employee_documents);

        if(employee_documents){

          for(var i = 0; i < employee_documents.length; i++){
            
            let docRow = employee_documents[i];
            // console.log("docRow", docRow);
            let user_id = null;

            let record_type_status = (docRow.isactive == 1)? "Active":"Inactive";

            let {
              id: hrms_doc_id,
              emailaddress: email,
              document_type_id: hrms_document_type_id,
              document_type_name = null,
              attachments:document_file = null,
            } = docRow;

            
            let user_data = await con.query(`SELECT * FROM timesheets.get_user_by_email($1, $2)`, [org_id, email]);
            user_data = (user_data && user_data.rows[0].j && user_data.rows[0].j[0]) || null;
            user_id = (user_data && user_data.id) || null;

            let doc_type_exists = await con.query(`SELECT * FROM timesheets.get_employee_document_types_by_hrms_doc_id($1, $2)`, [org_id, hrms_document_type_id]);

            doc_type_exists = (doc_type_exists && doc_type_exists.rows[0].j && doc_type_exists.rows[0].j[0]) || null;
            let employee_document_type_id = (doc_type_exists && doc_type_exists.id) || null;

            // check if exists in timesheets DB
            doc_exists = await con.query(`SELECT * FROM timesheets.get_employee_documents_by_hrms_doc_id($1, $2)`, [org_id, hrms_doc_id]);
            doc_exists = (doc_exists && doc_exists.rows[0].j && doc_exists.rows[0].j[0]) || null;

            if(user_id){
              
              // console.log("doc_type_exists", doc_type_exists);
              if(doc_exists && doc_exists.id){
                doc_id = doc_exists.id;
                // update doc type
                let docData = [
                  doc_id,
                  org_id,
                  employee_document_type_id,
                  user_id,
                  document_file,
                  hrms_doc_id,
                  1,
                  record_type_status
                ];
                let updateDoc = await con.query(
                  `SELECT timesheets.update_hrms_employee_documents($1,$2,$3,$4,$5,$6,$7,$8)`,
                  docData
                );
                updateDoc = (updateDoc.rows && updateDoc.rows[1] && updateDoc.rows[1].update_hrms_employee_documents && updateDoc.rows[1].update_hrms_employee_documents[0]) || null;

                syncDocs.push(updateDoc);
                // console.log("updateDoc", updateDoc);
              }
              else{

                // insert doc

                let docData = [
                  org_id,
                  employee_document_type_id,
                  user_id,
                  document_file,
                  hrms_doc_id,
                  1,
                  record_type_status
                ];
                
                // console.log("docData", docData);
                let insertDoc = await con.query(`SELECT timesheets.insert_hrms_employee_documents($1,$2,$3,$4,$5,$6,$7)`,
                docData
                );
                insertDoc = (insertDoc.rows && insertDoc.rows[1] && insertDoc.rows[1].insert_hrms_employee_document_types && insertDoc.rows[1].insert_hrms_employee_document_types[0]) || null;
                
                // console.log("insertDoc", insertDoc);
                syncDocs.push(insertDoc);
              }
            }
            
          }
        }

        /////////////////////////

        returnMessage.isError = false;
        returnMessage.message = "HRMS Employee Documents Synced Successfully";
        returnMessage.data = syncDocs;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        returnMessage.data = null;
        res.status(200).json(returnMessage);
      }
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "migrate_employee_documents";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  migrate_users,
  migrate_projects,
  migrate_timesheets,
  migrate_timesheets_after_june,
  list_users,
  migrate_employee_document_types,
  migrate_employee_documents
};
