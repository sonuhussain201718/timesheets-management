const express = require("express");
const router = express.Router();

const {
  migrate_users,
  migrate_projects,
  migrate_timesheets,
  migrate_timesheets_after_june,
  list_users,
  migrate_employee_document_types,
  migrate_employee_documents
} = require("../../controllers/migrationController");

// @route POST api/v1/migration/migrate_users
// @desc  Route to migrate users
// @accesss public
// router.get("/list_users", list_users);

// @route POST api/v1/migration/migrate_users
// @desc  Route to migrate users
// @accesss public
router.get("/migrate_users", migrate_users);

// @route POST api/v1/migration/migrate_projects
// @desc  Route to migrate projects
// @accesss public
router.get("/migrate_projects", migrate_projects);

// @route POST api/v1/migration/migrate_timesheets
// @desc  Route to migrate timesheets
// @accesss public
router.get("/migrate_timesheets", migrate_timesheets);

// @route POST api/v1/migration/migrate_timesheets_after_june
// @desc  Route to migrate timesheets
// @accesss public
router.get("/migrate_timesheets_after_june", migrate_timesheets_after_june);

// @route POST api/v1/migration/migrate_employee_document_types
// @desc  Route to migrate_employee_document_types
// @accesss public
router.get("/migrate_employee_document_types", migrate_employee_document_types);

// @route POST api/v1/migration/migrate_employee_documents
// @desc  Route to migrate_employee_documents
// @accesss public
router.get("/migrate_employee_documents", migrate_employee_documents);

module.exports = router;
