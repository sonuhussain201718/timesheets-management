const express = require("express");
const router = express.Router();

const {
  get_all_roles,
  get_role_by_id,
  get_role_by_name,
} = require("../../controllers/rolesController");

// @route GET api/v1/roles/get_all_roles
// @desc  Route to get all roles
// @accesss public
router.get("/get_all_roles", get_all_roles);

// @route GET api/v1/roles/get_role_by_id
// @desc  Route to get role by id
// @accesss public
router.get("/get_role_by_id", get_role_by_id);

// @route GET api/v1/roles/get_role_by_name
// @desc  Route to get role by name
// @accesss public
router.get("/get_role_by_name", get_role_by_name);

module.exports = router;
