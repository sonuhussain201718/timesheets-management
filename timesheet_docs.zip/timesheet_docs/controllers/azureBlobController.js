const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createOrganizationValidator = require("../validation/createOrganizationValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const { getBlobUrl } = require("../utils/helpers");

// con.connect();

// api for getbloburl
const getbloburl = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {

    const { blobName, org_id } = req.body;
    if (!blobName) {
      returnMessage.isError = true;
      returnMessage.message = "Please provide blobName";
      returnMessage.errors = {};
      returnMessage.label = "getbloburl";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{

        const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
        const sasUrl = getBlobUrl(containerName, blobName);

        returnMessage.isError = false;
        returnMessage.response = sasUrl;
        returnMessage.data = sasUrl;
        returnMessage.message = "Blob URL Generated Successfully";
        res.status(200).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getbloburl";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getbloburl,
};
