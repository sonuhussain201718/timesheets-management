const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getalluser,
  insertuser,
  edituser,
  getuserbyid,
  get_user_by_prospective_user_id,
  get_user_by_prospective_user_id_excluding_id,
  get_user_by_ecdb_user_id,
  get_user_by_ecdb_user_id_excluding_id,
  searchusers,
  // filterusers,
  export_all_users,

  getallemployees,
  searchemployees,
  // filteremployees,
  insertemployee,
  editemployee,
  get_employees_list,
  getuserbyemail,
  getuserbyemailexcludingid,
  get_new_employee_id,
  export_all_employees,
  get_adpworkerid_details,
  // reset_employee_id,
  get_user_by_adp_associate_id,
  get_user_by_adp_associate_id_excluding_id,
  update_email_notification_setting,
  get_users_list,
} = require("../../controllers/user2Controller");

// @route GET api/v1/user/getalluser
// @desc  Route to get all users
// @accesss public
router.get("/getalluser", getalluser);

// @route GET api/v1/user/getuserbyid
// @desc  Route to get users by id
// @accesss public
router.get("/getuserbyid", getuserbyid);

// @route GET api/v1/user/get_user_by_prospective_user_id
// @desc  Route to get users by prospective_user_id
// @accesss public
router.get("/get_user_by_prospective_user_id", get_user_by_prospective_user_id);

// @route GET api/v1/user/get_user_by_prospective_user_id_excluding_id
// @desc  Route to get users by prospective_user_id excluding id
// @accesss public
router.get("/get_user_by_prospective_user_id_excluding_id", get_user_by_prospective_user_id_excluding_id);


// @route GET api/v1/user/get_user_by_ecdb_user_id
// @desc  Route to get users by ecdb_user_id
// @accesss public
router.get("/get_user_by_ecdb_user_id", get_user_by_ecdb_user_id);

// @route GET api/v1/user/get_user_by_ecdb_user_id_excluding_id
// @desc  Route to get users by ecdb_user_id excluding id
// @accesss public
router.get("/get_user_by_ecdb_user_id_excluding_id", get_user_by_ecdb_user_id_excluding_id);


// @route POST api/v1/user/insertuser
// @desc  Route to post users
// @accesss public
router.post("/insertuser", insertuser);

// @route PUT api/v1/user/edituser
// @desc  Route to edit users
// @accesss public
router.put("/edituser", edituser);

// @route GET api/v1/user/searchusers
// @desc  Route to get users by search
// @accesss public
router.get("/searchusers", searchusers);

// // @route GET api/v1/user/filterusers
// // @desc  Route to get users by filter
// // @accesss public
// router.get("/filterusers", filterusers);

// @route GET api/v1/user/getallemployees
// @desc  Route to get all employees
// @accesss public
router.get("/getallemployees", getallemployees);

// @route GET api/v1/user/searchemployees
// @desc  Route to get employee by search
// @accesss public
router.get("/searchemployees", searchemployees);

// // @route GET api/v1/user/filteremployees
// // @desc  Route to get employees by filter
// // @accesss public
// router.get("/filteremployees", filteremployees);

// @route POST api/v1/user/insertemployee
// @desc  Route to post employee
// @accesss public
router.post("/insertemployee", insertemployee);

// @route PUT api/v1/user/edituser
// @desc  Route to edit users
// @accesss public
router.put("/editemployee", editemployee);

// @route GET api/v1/user/get_employees_list
// @desc  Route to get employees list
// @accesss public
router.get("/get_employees_list", get_employees_list);

// @route GET api/v1/user/getuserbyemail
// @desc  Route to get user by email
// @accesss public
router.get("/getuserbyemail", getuserbyemail);

// @route GET api/v1/user/getuserbyemailexcludingid
// @desc  Route to getuserbyemailexcludingid
// @accesss public
router.get("/getuserbyemailexcludingid", getuserbyemailexcludingid);

// @route GET api/v1/empoyees/get_new_employee_id
// @desc  Route to get new employee id
// @accesss public
router.get("/get_new_employee_id", get_new_employee_id);

// @route GET api/v1/timesheets/export_all_users
// @desc  Route to get export_all_users
// @accesss public
router.get("/export_all_users", export_all_users);

// @route GET api/v1/timesheets/export_all_employees
// @desc  Route to get export_all_employees
// @accesss public
router.get("/export_all_employees", export_all_employees);

// @route GET api/v1/user/get_adpworkerid_details
// @desc  Route to get users by id
// @accesss public
router.get("/get_adpworkerid_details", get_adpworkerid_details);

// @route PUT api/v1/user/get_adpworkerid_details
// @desc  Route to get users by id
// @accesss public
// router.put("/reset_employee_id", reset_employee_id);

// @route GET api/v1/user/get_user_by_adp_associate_id_excluding_id
// @desc  Route to get_user_by_adp_associate_id_excluding_id
// @accesss public
router.get("/get_user_by_adp_associate_id_excluding_id", get_user_by_adp_associate_id_excluding_id);

// @route GET api/v1/user/get_user_by_adp_associate_id
// @desc  Route to get_user_by_adp_associate_id
// @accesss public
router.get("/get_user_by_adp_associate_id", get_user_by_adp_associate_id);

// @route PUT api/v1/user/update_email_notification_setting
// @desc  Route to edit email_notification_setting
// @accesss public
router.put("/update_email_notification_setting", update_email_notification_setting);

// @route GET api/v1/user/get_users_list
// @desc  Route to get_users_list
// @accesss public
router.get("/get_users_list", get_users_list);

module.exports = router;
