const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const moment = require("moment");
const createMobileForceUpdateValidator = require("../validation/createMobileForceUpdateValidator");
const createMobileDeviceValidator = require("../validation/createMobileDeviceValidator");
const con = require("../utils/db");
const logger = require("../utils/logger");

// GET api for get_all_mobile_force_update
const get_all_mobile_force_update = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.os == undefined || req.query.os == "") {
    req.query.os = null;
  }
  if (req.query.app_version == undefined || req.query.app_version == "") {
    req.query.app_version = null;
  }
  if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
    req.query.record_type_status = null;
  }

  try {
    await con.query(
      `SELECT * from timesheets.get_all_mobile_force_update($1,$2,$3,$4,$5,$6);`,
      [
        req.query.keyword,
        req.query.os,
        req.query.app_version,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "get_all_mobile_force_update";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {


          // don't pass qb details in API response
          let data = (results && results.rows && results.rows[1] && results.rows[1].j) || null;
          let count = (results && results.rows && results.rows[2] && results.rows[2].j) || null;
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = count;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_mobile_force_update";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for user by get_mobile_force_update_by_id

const get_mobile_force_update_by_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
   
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_mobile_force_update_by_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_mobile_force_update_by_id($1)`,
        [req.query.id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch details";
            returnMessage.error = error;
            returnMessage.label = "get_mobile_force_update_by_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            
            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;
            if (data) {

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.label = "get_mobile_force_update_by_id";
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_mobile_force_update_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for user by get_mobile_force_update_by_os_and_version
const get_mobile_force_update_by_os_and_version = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {
    if (!req.query.os) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "os can not be null or empty";
      returnMessage.label = "get_mobile_force_update_by_os_and_version";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } 
    else if (!req.query.app_version) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "app_version can not be null or empty";
      returnMessage.label = "get_mobile_force_update_by_os_and_version";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_mobile_force_update_by_os_and_version($1,$2)`,
        [req.query.os, req.query.app_version],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch details";
            returnMessage.error = error;
            returnMessage.label = "get_mobile_force_update_by_os_and_version";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            
            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;
            if (data) {

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.label = "get_mobile_force_update_by_os_and_version";
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_mobile_force_update_by_os_and_version";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// INSERT api for mobile_force_update
const insert_mobile_force_update = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {
    
    let org_id = req.user.org_id;  
    const { errors, isValid } = createMobileForceUpdateValidator({ ...req.body });

    let {
      os = null,
      app_version,
      force_update = false,
      description = null,
    } = req.body;

    let record_type_status =  "Active";
    let createdby = req.user.id;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "insert_mobile_force_update";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if adp associate id already exists
    // if(os && app_version) {
    //   setting_exists = await con.query(`SELECT timesheets.get_mobile_force_update_by_os_and_version($1,$2)`,
    //   [os,app_version]
    //   );
    //   setting_exists = (setting_exists && setting_exists.rows[0].get_mobile_force_update_by_os_and_version && 
    //     setting_exists.rows[0].get_mobile_force_update_by_os_and_version[0]) || null;
    // }

    // if (setting_exists && setting_exists.id) {
    //   returnMessage.isError = true;
    //   returnMessage.message = "setting already exists for given OS and app version";
    //   returnMessage.label = "insert_mobile_force_update";
    //   logger.log({
    //     level: "error",
    //     message: returnMessage,
    //   });
    //   res.status(400).json(returnMessage);
    // }  
    // else {
      await con.query(
        `SELECT timesheets.insert_mobile_force_update($1,$2,$3,$4,$5,$6)`,
        [
          os,
          app_version,
          force_update,
          description,
          createdby,
          record_type_status
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insert_mobile_force_update";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let data = (results && results.rows && results.rows[1] && results.rows[1].insert_mobile_force_update) || null;

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    // }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insert_mobile_force_update";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for mobile_force_update
const edit_mobile_force_update = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createMobileForceUpdateValidator({ ...req.body });

    

    let {
      id = null,
      os = null,
      app_version,
      force_update = false,
      description = null,
    } = req.body;

    let record_type_status =  "Active";
    let updatedby = req.user.id;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edit_mobile_force_update";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // if(os && app_version) {
    //   setting_exists = await con.query(`SELECT timesheets.get_mobile_force_update_by_os_and_version($1,$2)`,
    //   [os,app_version]
    //   );
    //   setting_exists = (setting_exists && setting_exists.rows[0].get_mobile_force_update_by_os_and_version && 
    //     setting_exists.rows[0].get_mobile_force_update_by_os_and_version[0]) || null;
    // }

    // if (setting_exists && setting_exists.id && setting_exists.id != id) {
    //   returnMessage.isError = true;
    //   returnMessage.message = "setting already exists for given OS and app version";
    //   returnMessage.label = "edit_mobile_force_update";
    //   logger.log({
    //     level: "error",
    //     message: returnMessage,
    //   });
    //   res.status(400).json(returnMessage);
    // }
    //  else {
      await con.query(
        `SELECT timesheets.update_mobile_force_update($1,$2,$3,$4,$5,$6,$7)`,
        [
          id,
          os,
          app_version,
          force_update,
          description,
          updatedby,
          record_type_status
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "edit_mobile_force_update";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let data = (results && results.rows && results.rows[1] && results.rows[1].update_mobile_force_update) || null;
            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    // }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "edit_mobile_force_update";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for update_mobile_device
const update_mobile_device = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  
  try {
    
    let org_id = req.user.org_id;
    let user_id = req.user.id;  
    const { errors, isValid } = createMobileDeviceValidator({ ...req.body, org_id, user_id });

    let {
      // user_id = null,
      os = null,
      device_token = null,
      is_active = true,
    } = req.body;

    let record_type_status =  "Active";
    let createdby = req.user.id;
    let updatedby = req.user.id;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "update_mobile_device";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    device_exists = await con.query(`SELECT * FROM timesheets.get_mobile_device_by_user_and_token($1,$2,$3)`,
    [org_id, user_id, device_token]
    );
    device_exists = (device_exists && device_exists.rows[0].j &&  device_exists.rows[0].j[0]) || null;
    
    if(device_exists && device_exists.id){
      // update 
      await con.query(
        `SELECT timesheets.update_mobile_device($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          device_exists.id,
          org_id,
          user_id,
          os,
          device_token,
          is_active,
          updatedby,
          record_type_status
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_mobile_device";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let data = (results && results.rows && results.rows[1] && results.rows[1].update_mobile_device && results.rows[1].update_mobile_device[0]) || null;

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    else{
      await con.query(
        `SELECT timesheets.insert_mobile_device($1,$2,$3,$4,$5,$6,$7)`,
        [
          org_id,
          user_id,
          os,
          device_token,
          is_active,
          createdby,
          record_type_status
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "update_mobile_device";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let data = (results && results.rows && results.rows[1] && results.rows[1].insert_mobile_device[0]) || null;

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "update_mobile_device";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for mobile_force_update_access
const insert_mobile_force_update_access = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    // let org_id = req.user.org_id;
    let email_exists = false;

    let { email = null } = req.body;

    let record_type_status = "Active";
    let createdby = req.user.id;

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_mobile_force_update_access_by_email($1)`,
        [email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_mobile_force_update_access_by_email &&
          email_exists.rows[0].get_mobile_force_update_access_by_email[0]) ||
        null;
    }

    if (!req.body.email) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid input: The email field cannot be left empty.";
      returnMessage.error = "email can not be null or empty";
      returnMessage.label = "get_mobile_force_update_access_by_email";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (email_exists && email_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "The email you provided is already exists. Please use a different email." };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.insert_mobile_force_update_access($1,$2,$3)`,
        [email, createdby, record_type_status],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insert_mobile_force_update_access";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let data =
              (results &&
                results.rows &&
                results.rows[1] &&
                results.rows[1].insert_mobile_force_update_access) ||
              null;

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insert_mobile_force_update_access";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for mobile_force_update_access_by_email
const get_mobile_force_update_access_by_email = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
   
    if (!req.query.email) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "email can not be null or empty";
      returnMessage.label = "get_mobile_force_update_access_by_email";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_mobile_force_update_access_by_email($1)`,
        [req.query.email],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch details";
            returnMessage.error = error;
            returnMessage.label = "get_mobile_force_update_access_by_email";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;
            if (data) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.label = "get_mobile_force_update_access_by_email";
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_mobile_force_update_access_by_email";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// DELETE api for mobile_force_update
const delete_mobile_force_update = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_mobile_force_update($1);`,
      [req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete Mobile force data";
          returnMessage.error = error;
          returnMessage.label = "delete_mobile_force_update";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = results.rows[0].j[0];
          returnMessage.data = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_mobile_force_update";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// DELETE api for mobile_force_update_access
const delete_mobile_force_update_access = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_mobile_force_update_access($1);`,
      [req.body.email],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete Mobile force data";
          returnMessage.error = error;
          returnMessage.label = "delete_mobile_force_update_access";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = results.rows[0].j[0];
          // returnMessage.data = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_mobile_force_update_access";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for current time
const get_current_date_time = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
      
    let current_date_object = new moment();
    let current_date_time = moment().format("YYYY-MM-DD HH:mm:ss");
    let current_unix_timestamp = moment().unix() || null;

    let data = {
      current_date_object,
      current_date_time,
      current_unix_timestamp
    };
    returnMessage.isError = false;
    returnMessage.message = "Fetched Successfully";
    returnMessage.data = data;
    res.status(200).json(returnMessage);
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_current_date_time";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_all_mobile_force_update,
  get_mobile_force_update_by_id,
  get_mobile_force_update_by_os_and_version,
  insert_mobile_force_update,
  edit_mobile_force_update,
  update_mobile_device,
  insert_mobile_force_update_access,
  get_mobile_force_update_access_by_email,
  delete_mobile_force_update,
  delete_mobile_force_update_access,
  get_current_date_time
};