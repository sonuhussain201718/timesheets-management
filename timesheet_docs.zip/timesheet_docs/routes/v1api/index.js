const express = require("express");
var browser = require('browser-detect');
const router = express.Router();
const con = require("../../utils/db");
const axios = require("axios");
const {
  getMsgFormat,
  isEmpty,
  titleCase,
  titleCaseForHyphen,
} = require("../../utils/helpers");
const jwt = require("jsonwebtoken");
const { lookup } = require("lookup-dns-cache");
const Tokens = require("csrf");
const csrf = new Tokens();
const request = require("request");
const { exec } = require("child_process");
const CronJob = require("cron").CronJob;
const restartCommand = "pm2 restart all";
const listCommand = "pm2 list";
const moment = require("moment");
const logger = require("../../utils/logger");
const { authMiddleware } = require("../../middlewares/auth"); // load auth middlware
const NodeCache = require("node-cache");
const myCache = new NodeCache();
const { firebaseAdmin } = require("../../utils/firebase");
const { SyncProjectsByUserId } = require("../../utils/timesheet_helpers");

const {
  PLACEMENT_STATUS_MAPPING,
  ALLOWED_PAST_ENTRY_DAYS,
  FCM_SETTINGS,
  PROJECTS_STATUS,
} = require("../../constants");

const {
  OrganizationsSyncEmail,
  UsersSyncEmail,
  ProjectsSyncEmail,
} = require("../../Email/email");
// a variable to save a session
var session;

const errMiddleware = (req, res, next) => {
  if (!req.user) {
    return res.status(400).json({ error: "User information not found!" });
  }
  next();
};

// cron job
new CronJob(
  "*/59 *  * * *",
  function () {
    refreshToken();
  },
  null,
  true,
  "Asia/Kolkata"
);

// cron job for organizations sync
new CronJob(
"05 0 * * *", // daily at 12:05 AM
  async function () {
    // console.log("Cron Started");
    await getOrganizationsData();
  },
  null,
  true,
  "Asia/Kolkata"
);

// cron job for users sync
new CronJob(
  "10 0 * * *", // daily at 12:10 AM
    async function () {

      let current_date = moment().format("YYYY-MM-DD");
      let yesterday_date = moment(current_date).subtract(1, 'days').format("YYYY-MM-DD");
      
      // console.log("Cron Started");
      await getUserData(yesterday_date);
    },
    null,
    true,
    "Asia/Kolkata"
);

// cron job for projects sync
new CronJob(
  "20 0 * * *", // daily at 12:20 AM
    async function () {
      
      let current_date = moment().format("YYYY-MM-DD");
      let yesterday_date = moment(current_date).subtract(1, 'days').format("YYYY-MM-DD");

      // console.log("Cron Started");
      await getProjectsData(yesterday_date);
    },
    null,
    true,
    "Asia/Kolkata"
);

// cron job for weekly timesheet reminder
new CronJob(
"59 0 * * *", // daily at 12:59 AM
  async function () {
    await getWeeklyTimesheetReminder();
  },
  null,
  true,
  "Asia/Kolkata"
);

async function refreshToken() {
  const token = myCache.get("token");
  if (token == undefined) {
  } else {
    var data = await axios.get(`${process.env.url}/api/v1/token/refreshToken`, {
      headers: {
        Authorization: token,
      },
    });
  }
}

async function getUserData(sync_date = ``) {
  let organizations_list = await con.query(
    `SELECT timesheets.get_organizations_list()`,
    []
  );
  organizations_list =
    (organizations_list &&
      organizations_list.rows[1] &&
      organizations_list.rows[1].get_organizations_list &&
      organizations_list.rows[1].get_organizations_list) ||
    null;

  if (organizations_list && organizations_list.length) {
    for (var i = 0; i < organizations_list.length; i++) {
      let { org_id = null } = organizations_list[i];
      if (org_id) {
        var data = await axios.get(
          `${process.env.url}/api/v1/index/getUserData?date=${sync_date}&org_id=${org_id}`
        );
      }
    }
  }
}


async function getOrganizationsData() {
  var data = await axios.get(
    `${process.env.url}/api/v1/index/getOrganizationsData`
  );
}

async function getProjectsData(sync_date = ``) {
  let organizations_list = await con.query(
    `SELECT timesheets.get_organizations_list()`,
    []
  );
  organizations_list =
    (organizations_list &&
      organizations_list.rows[1] &&
      organizations_list.rows[1].get_organizations_list &&
      organizations_list.rows[1].get_organizations_list) ||
    null;

  if (organizations_list && organizations_list.length) {
    for (var i = 0; i < organizations_list.length; i++) {
      let { org_id = null } = organizations_list[i];

      if (org_id) {
        var data = await axios.get(
          `${process.env.url}/api/v1/index/getProjectsData?date=${sync_date}&org_id=${org_id}`
        );
      }
    }
  }
}

//restart app every 1 hour
const restartApp = function () {
  exec(restartCommand, (err, stdout, stderr) => {
    if (!err && !stderr) {
      // listApps();
    } else if (err || stderr) {
      console.log(
        new Date(),
        `Error in executing ${restartCommand}`,
        err || stderr
      );
    }
  });
};

router.get("/check_user_by_email", async (req, res) => {
  const returnMessage = getMsgFormat();
  var email = req.query.email;

  try {
    if (!req.query.email) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "email can not be null or empty";
      returnMessage.label = "check_user_by_email";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_email_without_org_id($1);`,
        [email],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user by email";
            returnMessage.error = error;
            returnMessage.label = "check_user_by_email";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Email Exists";
            returnMessage.data = results.rows[0].j;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "check_user_by_email";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
});

router.post("/token", async (req, res) => {
  const returnMessage = getMsgFormat();
  var email = req.body.email;
  var org_id = req.body.organizationId;
  
  try {

    let user_data = await con.query(
      `SELECT timesheets.get_user_by_email($1, $2)`,
      [org_id, email]
    );
    user_data =
      (user_data &&
        user_data.rows[0].get_user_by_email &&
        user_data.rows[0].get_user_by_email[0]) ||
      null;

    if(user_data && user_data.id && (user_data.record_type_status.toUpperCase() == "ACTIVE")){

      // insert logs data for users 
      let user_id = user_data.id;
      let ip_address = (req.socket.remoteAddress && req.socket.remoteAddress.replace("::ffff:", "")) || null;
      let browser_details = browser(req.headers['user-agent']);

      let createdby = user_data.id;

      await con.query(`SELECT timesheets.insert_user_logs($1,$2,$3,$4,$5,$6)`, [
        org_id,
        user_id,
        ip_address,
        browser_details,
        createdby,
        "Active",
      ]);
      
      var today = new Date()
      var current_tsp = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0, 0, 0).getTime();
      var joining_tsp = user_data.joining_date?moment(user_data.joining_date).valueOf():null;
  
      // console.log("current_tsp", current_tsp, joining_tsp, user_data);
      if(!joining_tsp || (current_tsp >= joining_tsp)){
        var secret = process.env.SECRET_OR_KEY;
        var payload = {
          id: user_data.id,
          role_id: user_data.role_id,
          ecdb_user_id: user_data.ecdb_user_id,
          email,
          org_id,
          secret,
          expiry: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000),
        };
        jwt.sign(payload, secret, async function (err, token) {
          if (err) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to Generate Token";
            res.status(400).send(returnMessage);
          } else {
            var BearerToken = `Bearer ${token}`;
            //Setting localStorage Item
            myCache.set("token", BearerToken);

            // sync user projects
            let sync_result = await SyncProjectsByUserId(org_id, user_data.id);

            returnMessage.isError = false;
            returnMessage.message = "Token Generated Successfully";
            returnMessage.data = BearerToken;
            returnMessage.user_data = user_data;
            res.status(200).send(returnMessage);
          }
        });
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "Joining date is greater than current date";
        // returnMessage.error = "Joining date is greater than current date";
        returnMessage.label = "token";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      }


    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "User not found!";
      // returnMessage.error = "User not found!";
      returnMessage.label = "token";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = error;
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).send(returnMessage);
  }
});

router.post("/verifytoken", async (req, res) => {
  const returnMessage = getMsgFormat();
  var secret = process.env.SECRET_OR_KEY;
  var authorizationToken = req.headers["authorization"];
  var result = {};
  try {
    if (authorizationToken) {
      var authToken = authorizationToken.split("Bearer ")[1];
      result = jwt.verify(authToken, secret);
      returnMessage.isError = false;
      returnMessage.message = "Token Verified Successfully";
      returnMessage.data = result;
      res.status(200).send(returnMessage);
    } else {
      result = {
        error: "Authentication error .Token required",
        status: "401",
      };
      returnMessage.isError = true;
      returnMessage.message = result;
      res.status(400).send(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = error;
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).send(returnMessage);
  }
});

router.get("/logout", authMiddleware, async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  let user_id = req.user.id;
  try {
    // user logs last data fetching
    var last_user_logs = await con.query(
      `SELECT * from timesheets.get_last_user_logs_by_user_id($1,$2);`,
      [org_id, user_id]
    );
    last_user_logs =
      (last_user_logs &&
        last_user_logs.rows[0].j &&
        last_user_logs.rows[0].j[0]) ||
      null;

      let ip_address = (req.socket.remoteAddress && req.socket.remoteAddress.replace("::ffff:", "")) || null;
      let browser_details = browser(req.headers['user-agent']);
    //  update user logs last data
    await con.query(
      `SELECT * from timesheets.update_user_logs($1,$2,$3,$4,$5,$6,$7);`,
      [
        last_user_logs.id,
        last_user_logs.org_id,
        last_user_logs.user_id,
        ip_address,
        browser_details,
        last_user_logs.user_id,
        "Active",
      ]
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_last_user_logs_by_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
  req.session.qbauth = null;
  res.send("Session loggedout");
});

//quickbook authorization
router.get("/authUri", async (req, res) => {
  var org_id = req.query.org_id;
  var result = await con.query(
    `SELECT * from timesheets.get_qb_auth_by_orgid($1);`,
    [org_id]
  );
  var databaseData = result.rows[0].j[0];
  session = req.session;
  session.org_id = org_id;
  session.client_id = databaseData.client_id;
  session.client_secret = databaseData.client_secret;
  var redirecturl =
    "https://appcenter.intuit.com/connect/oauth2" +
    "?client_id=" +
    session.client_id +
    "&redirect_uri=" +
    encodeURIComponent(`${process.env.url}/api/v1/index/callback`) +
    "&response_type=code" +
    "&scope=com.intuit.quickbooks.accounting" +
    "&state=intuit-test";
  res.redirect(redirecturl);
});

//quickbook authorization callback
router.get("/callback", async (req, res) => {
  const returnMessage = getMsgFormat();
  var org_id = req.session.org_id;
  var result = await con.query(
    `SELECT * from timesheets.get_qb_auth_by_orgid($1);`,
    [org_id]
  );
  var dbdata = result.rows[0].j[0];
  const parseRedirect = req.url;
  session.realm_id = req.query.realmId;
  var auth = Buffer.from(
    session.client_id + ":" + session.client_secret
  ).toString("base64");

  var postBody = {
    url: "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: "Basic " + auth,
    },
    form: {
      grant_type: "authorization_code",
      code: req.query.code,
      redirect_uri: `${process.env.url}/api/v1/index/callback`, //Make sure this path matches entry in application dashboard
    },
    lookup: lookup,
  };
  request.post(postBody, async function (err, result, data) {
    if (err) {
      returnMessage.isError = true;
      returnMessage.message = "Failed to generate token";
      res.status(400).json(returnMessage);
    }
    var authdetails = JSON.parse(data);
    session.token = authdetails;
    await con.query(
      `SELECT timesheets.update_qb_authentication($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [
        dbdata.id,
        session.token.access_token,
        session.client_id,
        session.client_secret,
        "sandbox",
        session.token.expires_in,
        session.org_id,
        session.token.refresh_token,
        "ACTIVE",
        req.query.realmId,
      ],
      (error, results) => {
        if (error) {
          console.log(error);
        } else {
          console.log(results);
        }
      }
    );
    // save the access token somewhere on behalf of the logged in user
    returnMessage.isError = false;
    returnMessage.message = "Token Generated Successfully";
    returnMessage.data = authdetails;
    res.status(200).json(returnMessage);
    // restartApp();
  });
});

router.get("/getOrganizationsData", async function (req, res) {
  const returnMessage = getMsgFormat();
  var users = null;

  try {
    var data = await axios.get(
      `${process.env.ECDB_API_URL}api/organization/listOrganization`
    );
    data = (data && data.data) || null;
    var sync_results = [];

    if (data && data.statusCode == 200 && data.organizations) {
      organizations = data.organizations;
      if (organizations && organizations.length) {
        for (var i = 0; i < organizations.length; i++) {
          row = organizations[i];

          let {
            allow_placement = true,
            createdby = null,
            updatedby = null,
            domain = null,
            toolName: ecdb_tool_name = `Timesheet Tracker`,
            orgId: org_id = null,
            orgName: org_name = null,
            orgPrefix: org_prefix = null,
            orgHeadId: prospective_admin_id = null,
            logo = null,
            email_reminder_1 = null,
            email_reminder_2 = null,
            allowed_past_entry_days = null,
            orgStatus = null,
            fromEmail = null,
            max_regular_hours = 8,
            notify_to_email = null,
            notification_enabled = true
          } = row;

          let result = null;
          // if(org_id && email){
          //get existing organization details
          let org_details = await con.query(
            `SELECT timesheets.get_organizations_by_orgid($1)`,
            [org_id]
          );
          org_details =
            (org_details &&
              org_details.rows[0].get_organizations_by_orgid &&
              org_details.rows[0].get_organizations_by_orgid[0]) ||
            null;
          let local_org_id = (org_details && org_details.id) || null;

          let record_type_status =
            orgStatus == "ACTIVE" ? "Active" : "Inactive";

          if (local_org_id) {
            email_reminder_1 = org_details.email_reminder_1;
            email_reminder_2 = org_details.email_reminder_2;
            allowed_past_entry_days = org_details.allowed_past_entry_days;
            ecdb_tool_name = ecdb_tool_name || org_details.ecdb_tool_name;
            max_regular_hours = max_regular_hours || org_details.max_regular_hours;
            notify_to_email = notify_to_email || org_details.notify_to_email;
            notification_enabled = notification_enabled || org_details.notification_enabled;
            

            let orgData = [
              local_org_id,
              allow_placement,
              domain,
              ecdb_tool_name,
              org_id,
              org_name,
              org_prefix,
              prospective_admin_id,
              logo,
              record_type_status,
              updatedby,
              email_reminder_1,
              email_reminder_2,
              allowed_past_entry_days,
              max_regular_hours,
              notify_to_email,
              notification_enabled
            ];
            result = await con.query(
              `SELECT timesheets.update_organizations($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,
              orgData
            );
            result =
              (result.rows &&
                result.rows[1] &&
                result.rows[1].update_organizations &&
                result.rows[1].update_organizations[0]) ||
              null;
            sync_results.push(result);
          } else {
            let allowed_past_entry_days = ALLOWED_PAST_ENTRY_DAYS;
            ecdb_tool_name = ecdb_tool_name || `Timesheet Tracker`;
            let orgData = [
              allow_placement,
              createdby,
              domain,
              ecdb_tool_name,
              org_id,
              org_name,
              org_prefix,
              prospective_admin_id,
              logo,
              record_type_status,
              email_reminder_1,
              email_reminder_2,
              allowed_past_entry_days,
              max_regular_hours,
              notify_to_email,
              notification_enabled
            ];

            result = await con.query(
              `SELECT timesheets.insert_organizations($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
              orgData
            );
            result =
              (result.rows &&
                result.rows[1] &&
                result.rows[1].insert_organizations &&
                result.rows[1].insert_organizations[0]) ||
              null;
            sync_results.push(result);
          }

          /// add from email in email_config
          if (result) {
            let email_config_data = await con.query(
              `SELECT timesheets.get_email_config_by_org_id($1)`,
              [org_id]
            );

            email_config_data =
              (email_config_data &&
                email_config_data.rows[0].get_email_config_by_org_id &&
                email_config_data.rows[0].get_email_config_by_org_id[0]) ||
              null;

            let email_config_id =
              (email_config_data && email_config_data.id) || null;
            let new_from_email =
              fromEmail ||
              (email_config_data && email_config_data.from_email) ||
              null;

            if (email_config_id) {
              email_config_result = await con.query(
                `SELECT timesheets.update_email_config($1,$2,$3,$4,$5)`,
                [
                  email_config_id,
                  org_id,
                  new_from_email,
                  null,
                  email_config_data.record_type_status || "Active",
                ]
              );
            } else {
              email_config_result = await con.query(
                `SELECT timesheets.insert_email_config($1,$2,$3,$4)`,
                [org_id, new_from_email, null, "Active"]
              );
            }
          }

          // }
        }
      }
    }

    // Send Organization Synced Email
    if (sync_results && sync_results.length > 0) {
    await OrganizationsSyncEmail({
      org_id: null,
      username: process.env.ADMIN_NAME,
      count: (sync_results && sync_results.length) || 0,
    });
  };

    // Insert Organization Sync Log
    await con.query(`SELECT timesheets.insert_sync_logs($1,$2,$3,$4,$5)`, [
      (req.user && req.user.org_id) || null,
      "organizations",
      (sync_results && sync_results.length) || 0,
      (req.user && req.user.id) || null,
      "Active",
    ]);

    returnMessage.isError = false;
    returnMessage.message = "Data Synced Successfully";
    returnMessage.data = sync_results;
    res.status(200).json(returnMessage);
  } catch (error) {
    // console.log(error);
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.message = "Data Sync Failed";
    returnMessage.label = "getOrganizationsData";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).send(returnMessage);
  }
});

router.get("/getUserData", async function (req, res) {
  const returnMessage = getMsgFormat();
  var users = null;

  let org_id = req.query.org_id ? req.query.org_id : null;
  var datenow = req.query.date ? req.query.date : ``;

  if (!org_id) {
    returnMessage.isError = true;
    returnMessage.message = "Invalid Parameters";
    returnMessage.error = "org_id can not be null or empty";
    returnMessage.label = "getUserData";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(400).json(returnMessage);
  } else {
    try {
      const returnMessage = getMsgFormat();
      var data = await axios.get(
        `${process.env.ECDB_API_URL}api/userECDB/fetchByToolName/Timesheet Tracker?fromDate=${datenow}&orgId=${org_id}`
      );
      data = (data && data.data) || null;

      var sync_results = [];

      let org_ids = [];
      let organizations_list = await con.query(
        `SELECT timesheets.get_organizations_list()`,
        []
      );
      organizations_list =
        (organizations_list &&
          organizations_list.rows[1] &&
          organizations_list.rows[1].get_organizations_list &&
          organizations_list.rows[1].get_organizations_list) ||
        null;

      if (organizations_list && organizations_list.length) {
        for (var i = 0; i < organizations_list.length; i++) {
          orgRow = organizations_list[i];
          let { org_id = null } = orgRow;
          org_ids.push(org_id);
        }
      }

      if (data && data.statusCode == 200 && data.users) {
        users = data.users;
        if (users && users.length) {
          for (var i = 0; i < users.length; i++) {
            row = users[i];

            let {
              orgId: org_id = null,
              orgName,
              employeeType: employee_type,
              roleId,
              roleName,
              prefix = null,
              firstName: first_name,
              middleName: middle_name,
              lastName: last_name,
              fullName: full_name,
              email,
              gender = null,
              adpAssociateID: adp_associate_id = null,
              phoneNumber: phone_number,
              branch: branch_id = null,
              branchName: branch_name = null,
              department: department_id = null,
              departmentName: department_name = null,
              employeeID: employee_id = null,
              id: ecdb_user_id = null,
              prospectiveRefId: prospective_user_id = null,
              joiningDate: joining_date = null,
              leaving_date = null,
              qb_employee_name = "",
              qb_employee_id = null,
              userStatus: user_status,
              workLocation: work_location,
              countryName: work_country,
              stateName: work_state,
              workCity: work_city,
              workStreetAddress: work_street_address,
              permanent_address = null,
              work_address = null,
              zipcode,
              email_notifications = true,
              push_notifications = true,
              visa_status = null,
              adp_validated = false
            } = row;

            // if(org_id && email){
            //get role id from local db by role name
            let role_data = await con.query(
              `SELECT timesheets.get_role_by_name($1)`,
              [roleName]
            );
            role_data =
              (role_data &&
                role_data.rows[0].get_role_by_name &&
                role_data.rows[0].get_role_by_name[0]) ||
              null;
            let role_id = (role_data && role_data.id) || null;
            // console.log("prospective_user_id", prospective_user_id);
            //get prospective_user_id if prospectiveRefId does not exists
            if (!prospective_user_id && email && org_id) {
              let prospective_data = await axios.get(
                `${process.env.PROSPECTIVE_API_URL}prospective/candidate/search/orgId/${org_id}?name=${email}`
              );
              prospective_data =
                (prospective_data.data &&
                  prospective_data.data.statusCode == 200 &&
                  prospective_data.data.profileResponse &&
                  prospective_data.data.profileResponse[0]) ||
                null;
              prospective_user_id =
                (prospective_data && prospective_data.id) || null;
            }

            // check if email already exists
            let email_exists = await con.query(
              `SELECT timesheets.get_user_by_email($1, $2)`,
              [org_id, email]
            );

            email_exists =
              (email_exists &&
                email_exists.rows[0].get_user_by_email &&
                email_exists.rows[0].get_user_by_email[0]) ||
              null;

            let user_id = (email_exists && email_exists.id) || 0;
            let record_type_status =
              user_status == "ACTIVE" ? "Active" : "Inactive";

            if (org_ids.includes(org_id)) {
              // console.log("gender", gender)
              if (user_id) {
                employee_id = employee_id || email_exists.employee_id || null;

                qb_employee_id = email_exists.qb_employee_id;
                qb_employee_name = email_exists.qb_employee_name;
                permanent_address = email_exists.permanent_address;
                prefix = email_exists.prefix;
                work_country = email_exists.work_country;
                adp_associate_id = email_exists.adp_associate_id;
                visa_status = email_exists.visa_status;
                email_notifications = email_exists.email_notifications;
                push_notifications = email_exists.push_notifications;
                gender = gender || email_exists.gender || null;

                let userData = [
                  user_id,
                  org_id,
                  employee_type,
                  role_id,
                  prefix,
                  first_name,
                  middle_name,
                  last_name,
                  full_name,
                  email,
                  gender,
                  adp_associate_id,
                  phone_number,
                  branch_id,
                  branch_name,
                  department_id,
                  department_name,
                  work_country, // country_name
                  work_state, // state_name
                  employee_id,
                  ecdb_user_id,
                  prospective_user_id,
                  joining_date,
                  leaving_date,
                  qb_employee_name,
                  qb_employee_id,
                  user_status,
                  work_location,
                  work_country,
                  work_state,
                  work_city,
                  work_street_address,
                  "", // work_status
                  permanent_address,
                  work_address,
                  zipcode,
                  email_notifications,
                  push_notifications,
                  1,
                  record_type_status,
                  visa_status,
                  adp_validated,
                ];
                let result = await con.query(
                  `SELECT timesheets.update_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42)`,
                  userData
                );
                result =
                  (result.rows &&
                    result.rows[1] &&
                    result.rows[1].update_users &&
                    result.rows[1].update_users[0]) ||
                  null;
                sync_results.push(result);
              } else {
                let new_employee_id = await con.query(
                  `SELECT timesheets.get_new_employee_id($1)`,
                  [org_id]
                );
                new_employee_id =
                  (new_employee_id &&
                    new_employee_id.rows[0].get_new_employee_id &&
                    new_employee_id.rows[0].get_new_employee_id[0]) ||
                  null;
                employee_id = employee_id || new_employee_id.employee_id || null;

                let userData = [
                  org_id,
                  employee_type,
                  role_id,
                  prefix,
                  first_name,
                  middle_name,
                  last_name,
                  full_name,
                  email,
                  gender,
                  adp_associate_id,
                  phone_number,
                  branch_id,
                  branch_name,
                  department_id,
                  department_name,
                  work_country, // country_name
                  work_state, // state_name
                  employee_id,
                  ecdb_user_id,
                  prospective_user_id,
                  joining_date,
                  leaving_date,
                  qb_employee_name,
                  qb_employee_id,
                  user_status,
                  work_location,
                  work_country,
                  work_state,
                  work_city,
                  work_street_address,
                  "", // work_status
                  permanent_address,
                  work_address,
                  zipcode,
                  email_notifications,
                  push_notifications,
                  1,
                  record_type_status,
                  visa_status,
                  adp_validated,
                ];

                let result = await con.query(
                  `SELECT timesheets.insert_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
                  userData
                );
                result =
                  (result.rows &&
                    result.rows[1] &&
                    result.rows[1].insert_users &&
                    result.rows[1].insert_users[0]) ||
                  null;
                sync_results.push(result);
              }
            }

            // }
          }
        }
      }

      // Send User Synced Email
      if (sync_results && sync_results.length > 0) {
        await UsersSyncEmail({
          org_id: org_id,
          username: process.env.ADMIN_NAME,
          count: (sync_results && sync_results.length) || 0,
        });
      };

      // Insert User Sync Log
      await con.query(`SELECT timesheets.insert_sync_logs($1,$2,$3,$4,$5)`, [
        (req.user && req.user.org_id) || null,
        "users",
        (sync_results && sync_results.length) || 0,
        (req.user && req.user.id) || null,
        "Active",
      ]);

      returnMessage.isError = false;
      returnMessage.message = "Data Synced Successfully";
      returnMessage.data = sync_results;
      res.status(200).json(returnMessage);
    } catch (error) {
      // console.log(error);

      returnMessage.isError = true;
      returnMessage.error = error;
      returnMessage.message = "Data Sync Failed";
      returnMessage.label = "getUserData";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).send(returnMessage);
    }
  }
});

//////////////////////////////////
router.get("/getProjectsData", async function (req, res) {

  const returnMessage = getMsgFormat();
  var data = null;

  let org_id = req.query.org_id ? req.query.org_id : null;
  // var datenow = req.query.date ? req.query.date : moment().subtract(1, "d").format("YYYY-MM-DD");
  var datenow = req.query.date ? req.query.date : ``;

  if (!org_id) {
    returnMessage.isError = true;
    returnMessage.message = "Invalid Parameters";
    returnMessage.error = "org_id can not be null or empty";
    returnMessage.label = "getProjectsData";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(400).json(returnMessage);
  } else {
    try {
      var response = await axios.get(
        `${process.env.PLACEMENT_API_URL}placements/placements/getAllPlacementsFromDate?fromDate=${datenow}&orgId=${org_id}`
      );

      // to sync all projects
      // var response = await axios.get(`${process.env.PLACEMENT_API_URL}placements/placements/getAllPlacementsFromDate?fromDate=&orgId=${org_id}`);

      let org_ids = [];
      let organizations_list = await con.query(
        `SELECT timesheets.get_organizations_list()`,
        []
      );
      organizations_list =
        (organizations_list &&
          organizations_list.rows[1] &&
          organizations_list.rows[1].get_organizations_list &&
          organizations_list.rows[1].get_organizations_list) ||
        null;

      if (organizations_list && organizations_list.length) {
        for (var i = 0; i < organizations_list.length; i++) {
          orgRow = organizations_list[i];
          let { org_id = null } = orgRow;
          org_ids.push(org_id);
        }
      }

      data = (response && response.data) || null;
      var output = [];
      var sync_results = [];

      if (data && data.statusCode == 200 && data.allPlacements) {
        var jsondata = data.allPlacements;

        // insert customers and vendors as customers before adding projects data
        for (var i = 0; i < jsondata.length; i++) {
          let projectRow = jsondata[i] || null;

          let {
            orgId: org_id = null,
            customerId: placement_client_id = null,
            customerName: client_name = null,
            dba = null,
            is_placement_client = true,
            qb_customer_name = null,
            qb_customer_id = null,
            qb_vendor_name = null,
            qb_vendor_id = null,
            status = null,
            createdby = 1,
            updatedby = 1,
            vendors = null,
          } = projectRow;

          let record_type_status = status == "ACTIVE" ? "Active" : "Inactive";

          // insert/update customers
          if (placement_client_id && client_name && org_ids.includes(org_id)) {
            let customer_exists = await con.query(
              `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
              [org_id, placement_client_id]
            );
            customer_exists =
              (customer_exists &&
                customer_exists.rows[0].get_customer_by_placement_client_id &&
                customer_exists.rows[0]
                  .get_customer_by_placement_client_id[0]) ||
              null;
            let customer_id = (customer_exists && customer_exists.id) || 0;

            if (customer_id) {
              qb_customer_name = customer_exists.qb_customer_name;
              qb_customer_id = customer_exists.qb_customer_id;
              qb_vendor_name = customer_exists.qb_vendor_name;
              qb_vendor_id = customer_exists.qb_vendor_id;

              let customerData = [
                customer_id,
                org_id,
                client_name,
                dba,
                is_placement_client,
                placement_client_id,
                qb_customer_name,
                qb_customer_id,
                qb_vendor_name,
                qb_vendor_id,
                updatedby,
                "Active",
              ];

              let customer_result = await con.query(
                `SELECT timesheets.update_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                customerData
              );
            } else {
              let customerData = [
                org_id,
                client_name,
                dba,
                is_placement_client,
                placement_client_id,
                qb_customer_name,
                qb_customer_id,
                qb_vendor_name,
                qb_vendor_id,
                createdby,
                "Active",
              ];

              let customer_result = await con.query(
                `SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                customerData
              );
            }
          }

          // insert/update venors as customers

          if (vendors && vendors.length && org_ids.includes(org_id)) {
            for (var j = 0; j < vendors.length; j++) {
              let vendorRow = vendors[j] || null;

              let {
                id: placement_client_id = null,
                name: client_name = null,
                dba = null,
                is_placement_client = true,
                qb_customer_name = null,
                qb_customer_id = null,
                qb_vendor_name = null,
                qb_vendor_id = null,
                status = null,
                createdby = 1,
              } = vendorRow;

              let record_type_status =
                status == "ACTIVE" ? "Active" : "Inactive";

              let customer_exists = await con.query(
                `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
                [org_id, placement_client_id]
              );
              customer_exists =
                (customer_exists &&
                  customer_exists.rows[0].get_customer_by_placement_client_id &&
                  customer_exists.rows[0]
                    .get_customer_by_placement_client_id[0]) ||
                null;
              let customer_id = (customer_exists && customer_exists.id) || 0;

              if (customer_id) {
                qb_customer_name = customer_exists.qb_customer_name;
                qb_customer_id = customer_exists.qb_customer_id;
                qb_vendor_name = customer_exists.qb_vendor_name;
                qb_vendor_id = customer_exists.qb_vendor_id;

                let customerData = [
                  customer_id,
                  org_id,
                  client_name,
                  dba,
                  is_placement_client,
                  placement_client_id,
                  qb_customer_name,
                  qb_customer_id,
                  qb_vendor_name,
                  qb_vendor_id,
                  updatedby,
                  "Active",
                ];

                let customer_result = await con.query(
                  `SELECT timesheets.update_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                  customerData
                );
              } else {
                let customerData = [
                  org_id,
                  client_name,
                  dba,
                  is_placement_client,
                  placement_client_id,
                  qb_customer_name,
                  qb_customer_id,
                  qb_vendor_name,
                  qb_vendor_id,
                  createdby,
                  "Active",
                ];

                let customer_result = await con.query(
                  `SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                  customerData
                );
              }
            }
          }
        }

        // insert/update projects data
        for (var i = 0; i < jsondata.length; i++) {
          let projectRow = jsondata[i] || null;
          let end_customer = null;
          let {
            orgId: org_id = null,
            placementStatusName: project_status = null,
            candidateId: prospective_user_id = null,
            candidateType = null,
            candidateName = null,
            estStartDate: start_date = null,
            placementEndDate: end_date = null,
            customerId: placement_client_id = null,
            customerName = null,
            client_manager_name = null,
            client_manager_email = null,
            jobTitle: job_title = null,
            is_placement_project = true,
            placementTypeName: placement_type = null,
            placementId: placement_project_id = null,
            placementCode: placement_code = null,
            bill_rate = null,
            pay_rate = null,
            bill_rate_currency = null,
            ot_bill_rate = null,
            ot_pay_rate = null,
            ot_bill_rate_currency = null,
            is_primary_project = null,
            directCustomerEngagement: direct_customer_engagement = false,
            qb_customer_name = null,
            qb_customer_id = null,
            qb_project_name = null,
            qb_project_id = null,
            qb_product_id = null,
            qb_product_name = null,
            status = null,
            workCountry: work_country = null,
            work_email = null,
            work_phone = null,
            work_state = null,
            work_city = null,
            is_updated = false,
            terminateDate: cancel_date = null,
            terminateReasonName: reason = null,
            terminateReasonId: reason_id = null,
            qb_status = null,
            createdby = 1,
            updatedby = 1,
            vendors = null,
            history = null,
          } = projectRow;

          //mm-dd-yyyy
          end_date_split = (end_date && end_date.split("-")) || null;
          end_date = (end_date_split && (`${end_date_split[2]}-${end_date_split[0]}-${end_date_split[1]}`)) || null;

          //// set bill rate / pay rate
          if (history && history.length) {
            bill_rate = (history[0] && history[0].billRate) || null;
            pay_rate = (history[0] && history[0].agreedPayRate) || null;

            ot_bill_rate = (history[0] && history[0].otBillRate) || null;
            ot_pay_rate = (history[0] && history[0].otPayRate) || null;

          }

          if (org_ids.includes(org_id) && placement_type!="PERMANENT") {

            if(candidateType == "EXISTING"){
              user_details = await con.query(
                `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
                [org_id, prospective_user_id]
              );
              user_details =
                (user_details &&
                  user_details.rows[0].get_user_by_ecdb_user_id &&
                  user_details.rows[0].get_user_by_ecdb_user_id[0]) ||
                null;
            }
            else{
              user_details = await con.query(
                `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
                [org_id, prospective_user_id]
              );
              user_details =
                (user_details &&
                  user_details.rows[0].get_user_by_prospective_user_id &&
                  user_details.rows[0].get_user_by_prospective_user_id[0]) ||
                null;
            }
            let user_id = (user_details && user_details.id) || 0;
            candidateName = (user_details && user_details.full_name) || candidateName;
            
            let primeVendorId = null;
            let primeVendorName = null;
            end_customer = placement_client_id;
            let project_name = candidateName + "-" + customerName;

            //// set project name and end customer
            if(direct_customer_engagement){
              // end_customer = placement_client_id;
              project_name = candidateName + "-" + customerName;
            }
            else{
              // console.log(placement_project_id, direct_customer_engagement, "vendors", vendors)
              if (vendors && vendors.length) {
                for (var vendorI = 0; vendorI < vendors.length; vendorI++) {
                  tmpVendor = vendors[vendorI];
                  if(tmpVendor.isPrime){
                    primeVendorId = tmpVendor.id;
                    primeVendorName = tmpVendor.name;
                    // end_customer = tmpVendor.id;
                  }
                }

                if(primeVendorId){
                  // end_customer = primeVendorId;
                  project_name = candidateName + "-" + primeVendorName;
                }
                else{
                  // end_customer = vendors[0].id;
                  project_name = candidateName + "-" + vendors[0].name;
                }

              }
            }
            // project_name(camelCase)
            project_name = project_name ? titleCaseForHyphen(project_name) : "";

            let end_customer_details = await con.query(
              `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
              [org_id, end_customer]
            );
            end_customer_details =
              (end_customer_details &&
                end_customer_details.rows[0]
                  .get_customer_by_placement_client_id &&
                end_customer_details.rows[0]
                  .get_customer_by_placement_client_id[0]) ||
              null;
            let end_customer_id =
              (end_customer_details && end_customer_details.id) || 0;

            let record_type_status = "Active";
            project_status =
              PLACEMENT_STATUS_MAPPING[project_status] || "IN_PROGRESS";

            // project status is rejected
            if (project_status === PROJECTS_STATUS.REJECTED) {
              end_date = null;
              cancel_date = null;
            }
            // console.log('status---',project_status, end_date, cancel_date)

            // insert/update customers
            if (placement_project_id) {
              let project_exists = await con.query(
                `SELECT timesheets.get_project_by_placement_project_id($1, $2)`,
                [org_id, placement_project_id]
              );
              project_exists =
                (project_exists &&
                  project_exists.rows[0].get_project_by_placement_project_id &&
                  project_exists.rows[0]
                    .get_project_by_placement_project_id[0]) ||
                null;
              let project_id = (project_exists && project_exists.id) || 0;

              

              let new_project_id = null;

              if (user_id) {
                if (project_id) {
                  record_type_status = project_exists.record_type_status;
                  qb_customer_name = project_exists.qb_customer_name;
                  qb_customer_id = project_exists.qb_customer_id;
                  qb_project_name = project_exists.qb_project_name;
                  qb_project_id = project_exists.qb_project_id;
                  qb_product_id = project_exists.qb_product_id;
                  qb_product_name = project_exists.qb_product_name;
                  
                  work_country = work_country || project_exists.work_country;
                  client_manager_name = project_exists.client_manager_name;
                  client_manager_email = project_exists.client_manager_email;
                  job_title = project_exists.job_title;

                  let projectData = [
                    project_id,
                    org_id,
                    user_id,
                    project_name,
                    project_status,
                    start_date,
                    end_date,
                    client_manager_name,
                    client_manager_email,
                    job_title,
                    is_placement_project,
                    placement_type,
                    placement_project_id,
                    placement_code,
                    bill_rate,
                    pay_rate,
                    bill_rate_currency,
                    ot_bill_rate,
                    ot_pay_rate,
                    ot_bill_rate_currency,
                    is_primary_project,
                    direct_customer_engagement,
                    end_customer_id,
                    qb_customer_name,
                    qb_customer_id,
                    qb_project_name,
                    qb_project_id,
                    qb_product_id,
                    qb_product_name,
                    work_country,
                    work_email,
                    work_phone,
                    work_state,
                    work_city,
                    is_updated,
                    cancel_date,
                    reason,
                    reason_id,
                    qb_status,
                    createdby,
                    record_type_status,
                  ];

                  let result = await con.query(
                    `SELECT timesheets.update_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
                    projectData
                  );
                  result =
                    (result.rows &&
                      result.rows[1] &&
                      result.rows[1].update_projects &&
                      result.rows[1].update_projects[0]) ||
                    null;
                  new_project_id = result.id || null;
                  sync_results.push(result);
                } else {
                  let projectData = [
                    org_id,
                    user_id,
                    project_name,
                    project_status,
                    start_date,
                    end_date,
                    client_manager_name,
                    client_manager_email,
                    job_title,
                    is_placement_project,
                    placement_type,
                    placement_project_id,
                    placement_code,
                    bill_rate,
                    pay_rate,
                    bill_rate_currency,
                    ot_bill_rate,
                    ot_pay_rate,
                    ot_bill_rate_currency,
                    is_primary_project,
                    direct_customer_engagement,
                    end_customer_id,
                    qb_customer_name,
                    qb_customer_id,
                    qb_project_name,
                    qb_project_id,
                    qb_product_id,
                    qb_product_name,
                    work_country,
                    work_email,
                    work_phone,
                    work_state,
                    work_city,
                    is_updated,
                    cancel_date,
                    reason,
                    reason_id,
                    qb_status,
                    createdby,
                    record_type_status,
                  ];

                  let result = await con.query(
                    `SELECT timesheets.insert_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40)`,
                    projectData
                  );
                  result =
                    (result.rows &&
                      result.rows[1] &&
                      result.rows[1].insert_projects &&
                      result.rows[1].insert_projects[0]) ||
                    null;
                  new_project_id = result.id || null;
                  sync_results.push(result);
                }

                if (new_project_id) {
                  let delete_project_vendors = await con.query(
                    `SELECT timesheets.delete_project_vendors_by_project_id($1, $2)`,
                    [org_id, new_project_id]
                  );
                  delete_project_vendors =
                    (delete_project_vendors &&
                      delete_project_vendors.rows[0]
                        .get_project_by_placement_project_id &&
                      delete_project_vendors.rows[0]
                        .get_project_by_placement_project_id[0]) ||
                    null;

                  // Insert Project Vendors
                  if (vendors && vendors.length && !direct_customer_engagement) {

                    if(primeVendorId){
                      tmpProjectVendorId = primeVendorId;
                    }
                    else{
                      tmpProjectVendorId = vendors[0].id;
                    }
                    
                    
                    for (var j = 0; j < vendors.length; j++) {
                      
                      let vendorRow = vendors[j] || null;
                      if (vendorRow.id == tmpProjectVendorId) {
                        
                        let {
                          id: placement_client_id = null,
                          isPrime = false,
                          createdby = 1,
                          record_type_status = "Active",
                        } = vendorRow;
                        let vendor_details = await con.query(
                          `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
                          [org_id, placement_client_id]
                        );
                        vendor_details =
                          (vendor_details &&
                            vendor_details.rows[0]
                              .get_customer_by_placement_client_id &&
                            vendor_details.rows[0]
                              .get_customer_by_placement_client_id[0]) ||
                          null;
                        let customer_id =
                          (vendor_details && vendor_details.id) || 0;

                        let projectVendorData = [
                          org_id,
                          new_project_id,
                          customer_id,
                          isPrime,
                          createdby,
                          record_type_status,
                        ];

                        let result = await con.query(
                          `SELECT timesheets.insert_project_vendors($1,$2,$3,$4,$5,$6)`,
                          projectVendorData
                        );
                        result =
                          (result &&
                            result.rows &&
                            result.rows[1] &&
                            result.rows[1].insert_project_vendors &&
                            result.rows[1].insert_project_vendors[0]) ||
                          null;
                      }
                    }
                  }
                  //////////////////

                  // Insert Project Bill Rates
                  let delete_project_bill_rates = await con.query(
                    `SELECT timesheets.delete_project_bill_rates_by_project_id($1, $2)`,
                    [org_id, new_project_id]
                  );
                  delete_project_bill_rates =
                    (delete_project_bill_rates &&
                      delete_project_bill_rates.rows[0]
                        .delete_project_bill_rates_by_project_id &&
                      delete_project_bill_rates.rows[0]
                        .delete_project_bill_rates_by_project_id[0]) ||
                    null;

                  if (history && history.length) {
                    for (var j = 0; j < history.length; j++) {
                      let billRatesRow = history[j] || null;
                      let {
                        effectiveBillRateStart = null,
                        billRate: bill_rate = null,
                        agreedPayRate: agreed_pay_rate = null,
                        bill_rate_currency = null,
                        otBillRate: ot_bill_rate = null,
                        otPayRate: ot_agreed_pay_rate = null,
                        ot_bill_rate_currency = null,
                        createdby = 1,
                        record_type_status = "Active",
                      } = billRatesRow;

                      let effective_date =
                        (effectiveBillRateStart &&
                          new Date(effectiveBillRateStart)) ||
                        null;
                      let projectBillRateData = [
                        org_id,
                        new_project_id,
                        effective_date,
                        bill_rate,
                        agreed_pay_rate,
                        bill_rate_currency,
                        ot_bill_rate,
                        ot_agreed_pay_rate,
                        ot_bill_rate_currency,
                        createdby,
                        record_type_status,
                      ];

                      let result = await con.query(
                        `SELECT timesheets.insert_project_bill_rates($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                        projectBillRateData
                      );
                      result =
                        (result &&
                          result.rows &&
                          result.rows[1] &&
                          result.rows[1].insert_project_bill_rates &&
                          result.rows[1].insert_project_bill_rates[0]) ||
                        null;
                    }
                  }
                  //////////////////
                }
              }
            }
          }
        }
      }

      // Send Project Synced Email
      if (sync_results && sync_results.length > 0){
        await ProjectsSyncEmail({
          org_id: org_id,
          username: process.env.ADMIN_NAME,
          count: (sync_results && sync_results.length) || 0,
        });
      };

      // Insert Organization Sync Log
      await con.query(`SELECT timesheets.insert_sync_logs($1,$2,$3,$4,$5)`, [
        (req.user && req.user.org_id) || null,
        "projects",
        (sync_results && sync_results.length) || 0,
        (req.user && req.user.id) || null,
        "Active",
      ]);

      if (sync_results && sync_results.length) {
        for (var i = 0; i < sync_results.length; i++) {
          delete sync_results[i].bill_rate;
          delete sync_results[i].pay_rate;
          delete sync_results[i].bill_rate_currency;
          delete sync_results[i].ot_bill_rate;
          delete sync_results[i].ot_pay_rate;
          delete sync_results[i].ot_bill_rate_currency;
        }
      }

      returnMessage.isError = false;
      returnMessage.message = "Data Synced Successfully";
      returnMessage.data = sync_results;
      res.status(200).json(returnMessage);
    } catch (error) {
      returnMessage.isError = true;
      returnMessage.errors = error;
      returnMessage.message = "Data Sync Failed";
      returnMessage.label = "getProjectsData";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).send(returnMessage);
    }
  }
});

//////////////////////////////////

async function getWeeklyTimesheetReminder() {
  var data = await axios.get(`${process.env.url}/api/v1/cronjob/weekly_timesheet_reminder`);
}


router.get("/getTimesheetdata", async function (req, res) {
  const returnMessage = getMsgFormat();
  try {
    var data = req.body;
    var jsondata = JSON.stringify(data);
    const result = await con.query(
      `SELECT timesheets.sync_timesheet_data($1,$2)`,
      [1, jsondata]
    );
    returnMessage.isError = false;
    returnMessage.message = "Data Synced Successfully";
    returnMessage.data = result.rows[0];
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Data Sync Failed";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).send(returnMessage);
  }
});

router.post("/savetoken", async function (req, res) {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT timesheets.insert_qb_authentications($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [
        req.body.access_token,
        req.body.client_id,
        req.body.client_secret,
        req.body.environment,
        parseInt(req.body.expires_in),
        parseInt(req.body.org_id),
        req.body.realm_id,
        req.body.refresh_token,
        "Active",
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to save";
          res.status(400).send(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Token details added successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(500).send(returnMessage);
  }
});

router.put("/updatetoken", async function (req, res) {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT timesheets.update_qb_authentication($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [
        req.body.id,
        req.body.access_token,
        req.body.client_id,
        req.body.client_secret,
        req.body.environment,
        req.body.expires_in,
        req.body.org_id,
        req.body.realm_id,
        req.body.refresh_token,
        req.body.record_type_status,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to save";
          res.status(400).send(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Token details updated successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(500).send(returnMessage);
  }
});

router.get("/listtokens", async function (req, res) {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT timesheets.get_all_qb_authentications()`,
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch";
          res.status(400).send(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.data = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(500).send(returnMessage);
  }
});

router.get("/weeks", function (req, res) {
  // moment.updateLocale("en", {
  //   week: {
  //     dow: 1, // Monday is the first day of the week.
  //   },
  // });
  // var weeknumber = parseInt(req.query.week)
  //   ? parseInt(req.query.week)
  //   : parseInt(moment().utc().subtract(1, "week").week());
  var weeknumber = parseInt(req.query.week)
    ? parseInt(req.query.week)
    : moment().week();
  var year = moment().format("YYYY");
  function getWeekDaysByWeekNumber(weeknumber) {
    var date = moment().utc().isoWeek(weeknumber).startOf("week").add(1, "d"),
      weeklength = 7,
      result = [];
    while (weeklength--) {
      result.push(date.format());
      date.add(1, "day");
    }
    return result;
  }
  var preWeek = weeknumber - 1;
  var nextWeek = weeknumber + 1;
  var output = {
    currWeek: weeknumber,
    preWeek: preWeek,
    nextWeek: nextWeek,
    dates: getWeekDaysByWeekNumber(weeknumber),
  };
  res.send(output);
});
router.get("/monthnames", async function (req, res) {
  const month = req.query.month ? req.query.month : moment().format("MMMM");
  const prevMonth = moment().subtract(1, "M").format("MMMM")
    ? moment().month(month).subtract(1, "M").format("MMMM")
    : moment().month(month).subtract(1, "M").format("MMMM");
  const nextMonth = moment().add(1, "M").format("MMMM")
    ? moment().month(month).add(1, "M").format("MMMM")
    : moment().month(month).add(1, "M").format("MMMM");
  const Year = req.query.year ? req.query.year : moment().format("YYYY");
  var output = {
    currMonth: month,
    preMonth: prevMonth,
    nextMonth: nextMonth,
    year: Year,
  };
  res.send(output);
});
router.get("/month", async function (req, res) {
  var date = req.query.date;
  const month = moment(date, "YYYY-MM");
  const range = moment().range(
    moment(month).startOf("month").startOf("week"),
    moment(month).endOf("month").endOf("week")
  );
  const days = range.by("days");

  var dates = [...days].map((date) => date.format("DD-MM-YYYY"));
  res.send(dates);
});

router.get("/weekdates", function (req, res) {
  var date = `${req.query.date}T00:00:00Z`;
  var year = date.slice(0, 4);
  var startdate = moment(date).utc().year(year).weekday(1).format();
  var enddate = moment(date).utc().year(year).weekday(7).year(date).format();
  var weeknumber = moment(date).utc().year(year).isoWeek(weeknumber);
  function getWeekDaysByWeekNumber(weeknumber) {
    var date1 = moment()
        .utc()
        .isoWeek(weeknumber)
        .year(year)
        .startOf("week")
        .add(1, "d"),
      weeklength = 7,
      result = [];
    while (weeklength--) {
      result.push(date1.format());
      date1.add(1, "day");
    }
    return result;
  }
  var preWeek = weeknumber - 1;
  var nextWeek = weeknumber + 1;
  var output = {
    currWeek: weeknumber,
    preWeek: preWeek,
    nextWeek: nextWeek,
    dates: getWeekDaysByWeekNumber(weeknumber),
  };
  res.send(output);
});

// GET api for verify email
router.get("/checkemail", async function (req, res) {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.check_email($1);`,
      [req.query.email],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Error occured while fetching email";
          returnMessage.error = error;
          returnMessage.api = "checkemail";
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "Email Does Not Exist";
          res.status(200).json(returnMessage);
        } else {
          var arr = results.rows[0].j;
          var result = arr.reduce((unique, o) => {
            if (!unique.some((obj) => obj.email === o.email)) {
              unique.push(o);
            }
            return unique;
          }, []);
          returnMessage.isError = false;
          returnMessage.message = "Email Exists";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.api = "checkemail";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
});



router.post("/pushnotification", (req, res) => {
  
  const returnMessage = getMsgFormat();
  const registrationToken = req.body.registrationToken;
  const title = req.body.title;
  const message = req.body.message;
  const options = {
    priority: "high",
    timeToLive: 60 * 60 * 24,
  };

  const payload = { 
    notification : {
        title : title,
        body : message,
        // content_available : "true",
        // image:"https://timesheets.msrcosmos.com/media/logos/msrlogoicon.svg"
    },
    data: {
      user_id: "1"
    }
  }

  firebaseAdmin
    .messaging()
    .sendToDevice(registrationToken, payload, options)
    .then((response) => {
      returnMessage.isError = false;
      returnMessage.message = "Notification sent successfully";
      returnMessage.FCM_SETTINGS = FCM_SETTINGS;
      res.status(200).json(returnMessage);
    })
    .catch((error) => {
      returnMessage.isError = true;
      returnMessage.message = "Error Occured! please try again";
      returnMessage.error = error;
      returnMessage.FCM_SETTINGS = FCM_SETTINGS;
      return res.status(500).json(returnMessage);
    });
});


// router.get("/list_env_vars", async function (req, res) {

//   const returnMessage = getMsgFormat();
  
//   try{
//     var env_vars = process.env;
//     returnMessage.isError = false;
//     returnMessage.message = "Fetched Successfully";
//     returnMessage.data = env_vars;
//     res.status(200).json(returnMessage);
//   }
//   catch (error) {
//     console.log("error", error);
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.api = "list_env_vars";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
  
// });

module.exports = router;
