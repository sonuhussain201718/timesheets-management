const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createTimesheetValidator = require("../validation/createTimesheetValidator");
const submitAllTimesheetsValidator = require("../validation/submitAllTimesheetsValidator");
const unsubmitTimesheetValidator = require("../validation/unsubmitTimesheetValidator");
const approveTimesheetValidator = require("../validation/approveTimesheetValidator");
const approveSingleDayTimesheetValidator = require("../validation/approveSingleDayTimesheetValidator");
const approveAllTimesheetsValidator = require("../validation/approveAllTimesheetsValidator");

const revertSingleDayTimesheetValidator = require("../validation/revertSingleDayTimesheetValidator");
const revertTimesheetValidator = require("../validation/revertTimesheetValidator");
const revertAllTimesheetsValidator = require("../validation/revertAllTimesheetsValidator");

const rejectTimesheetValidator = require("../validation/rejectTimesheetValidator");
const rejectSingleDayTimesheetValidator = require("../validation/rejectSingleDayTimesheetValidator");
const rejectAllTimesheetsValidator = require("../validation/rejectAllTimesheetsValidator");
const quickBooksTimesheetValidator = require("../validation/quickBooksTimesheetValidator");

const approveMonthlyTimesheetValidator = require("../validation/approveMonthlyTimesheetValidator");
const approveProjectWiseMonthlyTimesheetValidator = require("../validation/approveProjectWiseMonthlyTimesheetValidator");
const approveMonthlyTimesheetsDataValidator = require("../validation/approveMonthlyTimesheetsDataValidator");


const rejectMonthlyTimesheetsValidator = require("../validation/rejectMonthlyTimesheetsValidator");
const rejectProjectWiseMonthlyTimesheetValidator = require("../validation/rejectProjectWiseMonthlyTimesheetValidator");
const rejectMonthlyTimesheetsDataValidator = require("../validation/rejectMonthlyTimesheetsDataValidator");

const revertMonthlyTimesheetsValidator = require("../validation/revertMonthlyTimesheetsValidator");
const revertProjectWiseMonthlyTimesheetsValidator = require("../validation/revertProjectWiseMonthlyTimesheetsValidator");
const revertMonthlyTimesheetsDataValidator = require("../validation/revertMonthlyTimesheetsDataValidator");


const con = require("../utils/db");
const logger = require("../utils/logger");
const { getBlobUrl } = require("../utils/helpers");
const {
  secondsToHm,
  InsertTimesheetHistory,
  ResetTimesheetStatus,
  InsertQuickBooksLog,
  UpdateProjectClientManagerDetails,
  isQBEnabled, 
  isEmailReminderOn,
  isQBTransactionOn,
  isAdpEnabled,
  isValidateAdpEmployee,
  isValidateAdpApprover,
  isUserAdpValidated,
  getEmployeeType
} = require("../utils/timesheet_helpers");
const {
  ROLES,
  TIMESHEET_STATUS,
  TS_COMMENT_TYPE,
  TS_COMMENT_USER_TYPE,
  EMPLOYEE_TYPE
} = require("../constants");

const axios = require("axios");
const qbodata = require("../utils/qb");
const moment = require("moment");
const {
  ApprovedEmailToEmployee,
  ApprovedSingleDayEmailToEmployee,
  RejectedEmailToEmployee,
  ApprovedMonthlyEmailToEmployee,
  RejectedMonthlyEmailToEmployee,
  RejectedSingleDayEmailToEmployee,
  SubmittedEmailToApprovers,
  PendingEmail,
} = require("../Email/email");

const {
  ApprovedPushNotificationToEmployee,
  ApprovedSingleDayPushNotificationToEmployee,
  ApprovedMonthlyPushNotificationToEmployee,
  RejectedPushNotificationToEmployee,
  RejectedSingleDayPushNotificationToEmployee,
  RejectedMonthlyPushNotificationToEmployee,
  RevertedPushNotificationToEmployee,
  RevertedSingleDayPushNotificationToEmployee,
  RevertedMonthlyPushNotificationToEmployee
} = require("../utils/push_notifications");

// GET api for all timesheet by user and week dates

const get_all_timesheets_by_user = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_all_timesheets_by_user";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      if (req.query.year == undefined || req.query.year == "") {
        req.query.year = null;
      }

      if (req.query.month == undefined || req.query.month == "") {
        req.query.month = null;
      }

      req.query.month = req.query.month?parseInt(req.query.month):null;
      req.query.month = req.query.month?((req.query.month > 9)?req.query.month:`0${req.query.month}`):null;

      await con.query(
        `SELECT * from timesheets.get_all_timesheets_by_user($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          org_id,
          req.query.user_id,
          req.query.year,
          req.query.month,
          req.query.client_manager_name,
          req.query.status,
          req.query.pagenumber,
          req.query.pagesize,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_all_timesheets_by_user";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_timesheets_by_user";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for single week timesheet by user and week dates

const get_single_week_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_single_week_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_single_week_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_single_week_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_single_week_timesheet($1,$2,$3,$4)`,
        [
          org_id,
          req.query.user_id,
          req.query.week_start_date,
          req.query.week_end_date,
        ],
        async (error, results) => {
          if (error) {
            
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_single_week_timesheet";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);

          } else {
            
            results = (results.rows && results.rows[0] && results.rows[0].j) || null;

            ///////////////
            if(results && results.length){
              
              let regular_hours = 0;
              let regular_minutes = 0;
              let ot_hours = 0;
              let ot_minutes = 0;
              let absent_hours = 0;
              let absent_minutes = 0;
              
              let total_sec = 0;
              let total_saved_sec = 0;
              let total_submitted_sec = 0;
              let total_approved_sec = 0;
              let total_rejected_sec = 0;

              let total_hours_minutes = 0;
              let total_saved_hours_minutes = 0;
              let total_submitted_hours_minutes = 0;
              let total_approved_hours_minutes = 0;
              let total_rejected_hours_minutes = 0;

              for (var i = 0; i < results.length; i++) {
                
                tsRow = results[i];
                let {timesheet_data = null} = tsRow;

                let project_total_sec = 0;
                let project_total_regular_sec = 0;
                let project_total_ot_sec = 0;
                let project_total_absent_sec = 0;
                
                let project_total_hours_minutes = 0;
                let project_total_absent_hours_minutes = 0;
                let project_total_regular_hours_minutes = 0;
                let project_total_ot_hours_minutes = 0;

                if(timesheet_data && timesheet_data.length){
                                    
                  for(j = 0; j < timesheet_data.length; j++){
                    
                    let tdRow = timesheet_data[j];

                    regular_hours = (tdRow.regular_hours && tdRow.regular_hours * 60 * 60) || 0;
                    regular_minutes = (tdRow.regular_minutes && tdRow.regular_minutes * 60) || 0; 
                    
                    ot_hours = (tdRow.ot_hours && tdRow.ot_hours * 60 * 60) || 0;
                    ot_minutes = (tdRow.ot_minutes && tdRow.ot_minutes * 60) || 0;

                    absent_hours = (tdRow.absent_hours && tdRow.absent_hours * 60 * 60) || 0;
                    absent_minutes = (tdRow.absent_minutes && tdRow.absent_minutes * 60) || 0;
                    
                    total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;

                    project_total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    project_total_regular_sec+= regular_hours + regular_minutes;
                    project_total_ot_sec+= ot_hours + ot_minutes;
                    project_total_absent_sec+= absent_hours + absent_minutes;

                    if (tdRow.status == TIMESHEET_STATUS.SAVED) {
                      total_saved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.SUBMITTED) {
                      total_submitted_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.APPROVED) {
                      total_approved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.REJECTED) {
                      total_rejected_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }

                    let is_qb_enabled = await isQBEnabled(req.user.org_id);

                    // don't pass qb details in API response
                    if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                      delete results[i].timesheet_data[j].qb_timesheet_id;
                      delete results[i].timesheet_data[j].qb_status;
                    }
                  }

                  project_total_hours_minutes = secondsToHm(project_total_sec);
                  project_total_regular_hours_minutes = secondsToHm(project_total_regular_sec);
                  project_total_ot_hours_minutes = secondsToHm(project_total_ot_sec);
                  project_total_absent_hours_minutes = secondsToHm(project_total_absent_sec);

                  results[i].project_total_hours_minutes = project_total_hours_minutes;
                  results[i].project_total_regular_hours_minutes = project_total_regular_hours_minutes;
                  results[i].project_total_ot_hours_minutes = project_total_ot_hours_minutes;
                  results[i].project_total_absent_hours_minutes = project_total_absent_hours_minutes;

                }

                let is_qb_enabled = await isQBEnabled(req.user.org_id);

                // don't pass qb details in API response
                if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                  delete results[i].qb_customer_id;
                  delete results[i].qb_customer_name;
                  delete results[i].qb_project_id;
                  delete results[i].qb_project_name;
                  delete results[i].qb_product_id;
                  delete results[i].qb_product_name;
                  delete results[i].qb_status;
                  
                }
                
                // don't pass bill rate / pay rate details in response
                delete results[i].bill_rate;
                delete results[i].pay_rate;
                delete results[i].bill_rate_currency;
                delete results[i].ot_bill_rate;
                delete results[i].ot_pay_rate;
                delete results[i].ot_bill_rate_currency;
              }

    
              total_hours_minutes = secondsToHm(total_sec);
              total_saved_hours_minutes = secondsToHm(total_saved_sec);
              total_submitted_hours_minutes = secondsToHm(total_submitted_sec);
              total_approved_hours_minutes = secondsToHm(total_approved_sec);
              total_rejected_hours_minutes = secondsToHm(total_rejected_sec);
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.hours_data = {
                total_hours_minutes,
                total_saved_hours_minutes,
                total_submitted_hours_minutes,
                total_approved_hours_minutes,
                total_rejected_hours_minutes
              };
              
              res.status(200).json(returnMessage);
              
            }
            else{
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_single_week_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for monthly timesheet by user

const get_monthly_timesheet_by_user = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_monthly_timesheet_by_user";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      ////////////////////////
      let month = req.query.month?((req.query.month > 0)?(req.query.month - 1) : req.query.month): null;
      let year = req.query.year || null;      
      let month2d = req.query.month ? moment().month(month).format("MM") : moment().format("MM");

      year = year
        ? moment().year(year).format("YYYY")
        : moment().format("YYYY");
      let date = `${year}-${month2d}`;
      let months = moment(date, "YYYY-MM");
      let range = moment().range(
        moment(months).startOf("month").startOf("isoweek"),
        moment(months).endOf("month").endOf("isoweek")
      );

      // console.log("range", month, range);
     

      let final_regular_sec = 0;
      let final_regular_hm = 0;
      let final_ot_sec = 0;
      let final_ot_hm = 0;
      let final_total_sec = 0;
      let final_total_hm = 0;
      
      let final_absent_sec = 0;
      let final_absent_hm = 0;

      let status_wise_hours_data = {
        SAVED: {},
        SUBMITTED: {},
        APPROVED: {},
        REJECTED: {},
      };

      for(i=0; i < Object.keys(status_wise_hours_data).length;i++){
        let statusKey = Object.keys(status_wise_hours_data)[i];
        status_wise_hours_data[statusKey] = {
          regular_hours: 0,
          regular_minutes: 0,
          ot_hours: 0,
          ot_minutes: 0,
          absent_hours: 0,
          absent_minutes: 0,

          total_regular_hours: 0,
          total_regular_minutes: 0,
          total_regular_sec: 0,
          total_regular_hm: 0,

          total_ot_hours: 0,
          total_ot_minutes: 0,
          total_ot_sec: 0,
          total_ot_hm: 0,

          total_absent_hours: 0,
          total_absent_minutes: 0,
          total_absent_sec: 0,
          total_absent_hm: 0,

          total_hours: 0,
          total_minutes: 0,
          total_sec: 0,
          total_hm: 0,
        }
      }
      

      let days = range.by("days");
      var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

      let data = [];
      if (dates && dates.length) {
        for (var i = 0; i < dates.length; i++) {
          let project_wise_data = [];
          let timesheet_date = dates[i];
          let result = await con.query(
            `SELECT * from timesheets.get_timesheet_by_user_id_and_date($1,$2,$3)`,
            [org_id, req.query.user_id, timesheet_date]
          );

          result = (result.rows && result.rows[0] && result.rows[0].j) || null;

          // console.log(result);
        
          let ts_days_length = (result && result.length) || 0;
          let regular_hours = 0;
          let regular_minutes = 0;
          let ot_hours = 0;
          let ot_minutes = 0;
          let absent_hours = 0;
          let absent_minutes = 0;
          let total_saved = 0;
          let total_submitted = 0;
          let total_approved = 0;
          let total_rejected = 0;
          let final_status = null;
          let full_name = (result && result[0].full_name);
          let employee_type = (result && result[0].employee_type);
          let adp_validated = (result && result[0].adp_validated);

          let tmpDate = moment(timesheet_date, "YYYY-MM-DD");
          let week_start_date = moment(tmpDate)
            .startOf("isoweek")
            .format("YYYY-MM-DD");
          let week_end_date = moment(tmpDate)
            .endOf("isoweek")
            .format("YYYY-MM-DD");

          if (result && result.length) {

            for (var j = 0; j < result.length; j++) {
              tsRow = result[j];

              project_wise_data.push({
                project_id: tsRow.project_id,
                project_name: tsRow.project_name,
                placement_code: tsRow.placement_code,
                regular_hours: tsRow.regular_hours,
                regular_minutes: tsRow.regular_minutes,
                ot_hours: tsRow.ot_hours,
                ot_minutes: tsRow.ot_minutes,
                absent_type: tsRow.absent_type,
                absent_hours: tsRow.absent_hours,
                absent_minutes: tsRow.absent_minutes,
                status: tsRow.status,
                
              });

              // console.log(project_wise_data);

              regular_hours += (tsRow.regular_hours && tsRow.regular_hours * 60 * 60) || 0;
              regular_minutes += (tsRow.regular_minutes && tsRow.regular_minutes * 60) || 0;

              ot_hours += (tsRow.ot_hours && tsRow.ot_hours * 60 * 60) || 0;
              ot_minutes += (tsRow.ot_minutes && tsRow.ot_minutes * 60) || 0;

              absent_hours += (tsRow.absent_hours && tsRow.absent_hours * 60 * 60) || 0;
              absent_minutes += (tsRow.absent_minutes && tsRow.absent_minutes * 60) || 0;

              if([
                TIMESHEET_STATUS.SAVED,
                TIMESHEET_STATUS.SUBMITTED,
                TIMESHEET_STATUS.APPROVED,
                TIMESHEET_STATUS.REJECTED,
              ].includes(tsRow.status)){
                status_wise_hours_data[tsRow.status].regular_hours += (tsRow.regular_hours && tsRow.regular_hours * 60 * 60) || 0;
                status_wise_hours_data[tsRow.status].regular_minutes += (tsRow.regular_minutes && tsRow.regular_minutes * 60) || 0;

                status_wise_hours_data[tsRow.status].ot_hours += (tsRow.ot_hours && tsRow.ot_hours * 60 * 60) || 0;
                status_wise_hours_data[tsRow.status].ot_minutes += (tsRow.ot_minutes && tsRow.ot_minutes * 60) || 0;

                status_wise_hours_data[tsRow.status].absent_hours += (tsRow.absent_hours && tsRow.absent_hours * 60 * 60) || 0;
                status_wise_hours_data[tsRow.status].absent_minutes += (tsRow.absent_minutes && tsRow.absent_minutes * 60) || 0;

              }


              if (tsRow.status == TIMESHEET_STATUS.SAVED) {
                total_saved++;
              }
              if (tsRow.status == TIMESHEET_STATUS.SUBMITTED) {
                total_submitted++;
              }
              if (tsRow.status == TIMESHEET_STATUS.APPROVED) {
                total_approved++;
              }
              if (tsRow.status == TIMESHEET_STATUS.REJECTED) {
                total_rejected++;
              }
            }
          }

          if (total_rejected > 0) {
            final_status = TIMESHEET_STATUS.REJECTED;
          } else if (total_submitted > 0) {
            final_status = TIMESHEET_STATUS.SUBMITTED;
          } else if (
            total_approved > 0 &&
            total_approved == ts_days_length - total_saved
          ) {
            final_status = TIMESHEET_STATUS.APPROVED;
          } else if (total_saved > 0) {
            final_status = TIMESHEET_STATUS.SAVED;
          } else {
            final_status = null;
          }

          total_sec = regular_hours + regular_minutes + ot_hours + ot_minutes;
          let total_hm = secondsToHm(total_sec);

          total_regular_sec = regular_hours + regular_minutes;
          let total_regular_hm = secondsToHm(total_regular_sec);
          
          final_regular_sec+= total_regular_sec;

          total_ot_sec = ot_hours + ot_minutes;
          let total_ot_hm = secondsToHm(total_ot_sec);
          final_ot_sec+= total_ot_sec;

          total_absent_sec = absent_hours + absent_minutes;
          let total_absent_hm = secondsToHm(total_absent_sec);
          final_absent_sec+= total_absent_sec;

          final_total_sec+= total_regular_sec+total_ot_sec;

          // for status wise hours
          for(k=0; k < Object.keys(status_wise_hours_data).length;k++){
            let statusKey = Object.keys(status_wise_hours_data)[k];
            status_wise_hours_data[statusKey].total_regular_sec= status_wise_hours_data[statusKey].regular_hours + status_wise_hours_data[statusKey].regular_minutes;
            
            status_wise_hours_data[statusKey].total_ot_sec= status_wise_hours_data[statusKey].ot_hours + status_wise_hours_data[statusKey].ot_minutes;

            status_wise_hours_data[statusKey].total_absent_sec= status_wise_hours_data[statusKey].absent_hours + status_wise_hours_data[statusKey].absent_minutes;

            status_wise_hours_data[statusKey].total_sec= status_wise_hours_data[statusKey].regular_hours + status_wise_hours_data[statusKey].regular_minutes + status_wise_hours_data[statusKey].ot_hours + status_wise_hours_data[statusKey].ot_minutes;
          }

          data.push({
            timesheet_date: dates[i],
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            regular_hours_minutes: total_regular_hm,
            ot_hours_minutes: total_ot_hm,
            absent_hours_minutes: total_absent_hm,
            total_hours_minutes: total_hm,
            ts_status: final_status,
            full_name:full_name,
            employee_type:employee_type,
            adp_validated:adp_validated,
            project_wise_data: project_wise_data,
          });
        }

        final_regular_hm = secondsToHm(final_regular_sec);
        final_ot_hm = secondsToHm(final_ot_sec);
        final_total_hm = secondsToHm(final_total_sec);
        final_absent_hm = secondsToHm(final_absent_sec);

        for(i=0; i < Object.keys(status_wise_hours_data).length;i++){
          
          let statusKey = Object.keys(status_wise_hours_data)[i];
          
          status_wise_hours_data[statusKey].total_regular_hm= secondsToHm(status_wise_hours_data[statusKey].total_regular_sec);
          
          status_wise_hours_data[statusKey].total_ot_hm= secondsToHm(status_wise_hours_data[statusKey].total_ot_sec);

          status_wise_hours_data[statusKey].total_absent_hm= secondsToHm(status_wise_hours_data[statusKey].total_absent_sec);
          
          status_wise_hours_data[statusKey].total_hm= secondsToHm(status_wise_hours_data[statusKey].total_sec);

        }

        // recreate status wise hours object with minimum details
        for(i=0; i < Object.keys(status_wise_hours_data).length;i++){
          
          let statusKey = Object.keys(status_wise_hours_data)[i];
          
          status_wise_hours_data[statusKey] = {
            total_regular_hm: status_wise_hours_data[statusKey].total_regular_hm,
            total_ot_hm: status_wise_hours_data[statusKey].total_ot_hm,
            total_absent_hm: status_wise_hours_data[statusKey].total_absent_hm,
            total_hm: status_wise_hours_data[statusKey].total_hm,
          }
        }
      }

      returnMessage.isError = false;
      returnMessage.message = "Records Found";
      returnMessage.data = data;
      returnMessage.hours_data = {
        final_regular_hm,
        final_ot_hm,
        final_total_hm,
        final_absent_hm
      };
      returnMessage.status_wise_hours_data = status_wise_hours_data;

      res.status(200).json(returnMessage);
      ////////////////////////
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_monthly_timesheet_by_user";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

//============ Timesheet history API ================||

// GET api for timesheet history by week and project id
const get_timesheet_history = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.project_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "project_id can not be null or empty";
      returnMessage.label = "get_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      let {
        project_id = null,
        week_start_date = null,
        week_end_date = null,
      } = req.query;

      let timesheet_history = await con.query(
        `SELECT * from timesheets.get_timesheet_history_by_week_and_project($1,$2,$3,$4)`,
        [org_id, project_id, week_start_date, week_end_date]
      );
      timesheet_history =
        (timesheet_history.rows && timesheet_history.rows[0].j) || null;

      let timesheet_status_history = await con.query(
        `SELECT * from timesheets.get_timesheet_status_history_by_week_and_project($1,$2,$3,$4)`,
        [org_id, project_id, week_start_date, week_end_date]
      );
      timesheet_status_history =
        (timesheet_status_history.rows && timesheet_status_history.rows[0].j) ||
        null;

      returnMessage.isError = false;
      returnMessage.message = "Records Found";
      returnMessage.data = {
        timesheet_history: timesheet_history,
        timesheet_status_history: timesheet_status_history,
      };
      res.status(200).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_timesheet_history";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for per day timesheet history
const get_per_day_timesheet_history = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.project_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "project_id can not be null or empty";
      returnMessage.label = "get_per_day_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_per_day_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_per_day_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.timesheet_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "timesheet_date can not be null or empty";
      returnMessage.label = "get_per_day_timesheet_history";
      logger.log({
        level: "error",
        message: returnMessage,
      });
    } else {
      let {
        project_id = null,
        week_start_date = null,
        week_end_date = null,
        timesheet_date = null,
      } = req.query;

      let timesheet_history = await con.query(
        `SELECT * from timesheets.get_timesheet_history_by_date_and_project($1,$2,$3,$4,$5)`,
        [org_id, project_id, week_start_date, week_end_date, timesheet_date],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message =
              "Failed to fetch per day timesheet history details";
            returnMessage.error = error;
            returnMessage.label = "get_timesheet_history_by_date_and_project";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = results.rows[0].j;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_per_day_timesheet_history";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for save_project_wise_timesheet

const save_project_wise_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = createTimesheetValidator({
      ...req.body,
      org_id,
    });
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "save_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_data = null,
      user_notes: ts_user_notes = null,
      approver_id: ts_approver_id = null,
      approver_notes: ts_approver_notes = null,
      client_manager_email = null,
      client_manager_name = null,
      // qb_timesheet_id = null,
      // qb_status = null,
    } = req.body;

    if (timesheet_data && timesheet_data.length) {
      // check last comment
      let check_timesheet_comment = await con.query(
        `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
        [
          org_id,
          project_id,
          week_start_date,
          week_end_date,
          TS_COMMENT_TYPE.WEEKLY,
          TS_COMMENT_USER_TYPE.EMPLOYEE,
        ]
      );

      check_timesheet_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
        null;

      let last_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.id &&
          check_timesheet_comment.comments) ||
        null;

      let same_comment = false;
      if (last_comment && last_comment == ts_user_notes) {
        same_comment = true;
      }

      // insert / update timesheet data
      for (var i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let {
          timesheet_date = null,
          regular_hours = null,
          regular_minutes = null,
          ot_hours = null,
          ot_minutes = null,
          absent_type = null,
          absent_hours = null,
          absent_minutes = null,
          // status = "SAVED",
          user_notes = null,
          approver_id = null,
          approver_notes = null,
          qb_timesheet_id = null,
          qb_status = null,
        } = tdRow;

        var tdate = `${timesheet_date}T00:00:00Z`;
        var day_name = moment(tdate).format("dddd");
        status = TIMESHEET_STATUS.SAVED;

        let timesheet_exists = await con.query(
          `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
          [org_id, project_id, timesheet_date]
        );

        timesheet_exists =
          (timesheet_exists &&
            timesheet_exists.rows[0]
              .get_single_timesheet_by_date_and_project_id &&
            timesheet_exists.rows[0]
              .get_single_timesheet_by_date_and_project_id[0]) ||
          null;
          

        if (timesheet_exists && timesheet_exists.id) {
          // update
          let timesheet_id = timesheet_exists.id;
          qb_timesheet_id = timesheet_exists.qb_timesheet_id;
          qb_status = timesheet_exists.qb_status;
          if (
            [
              TIMESHEET_STATUS.SUBMITTED,
              TIMESHEET_STATUS.APPROVED,
              TIMESHEET_STATUS.REJECTED,
            ].includes(timesheet_exists.status)
          ) {
            status = timesheet_exists.status;
          }

          var timesheetData = [
            timesheet_id,
            org_id,
            user_id,
            project_id,
            year,
            parseInt(month),
            week_start_date,
            week_end_date,
            timesheet_date,
            day_name,
            (regular_hours || 0),
            (regular_minutes || 0),
            (ot_hours || 0),
            (ot_minutes || 0),
            (absent_type || null),
            (absent_hours || 0),
            (absent_minutes || 0),
            status,
            user_notes,
            approver_id,
            approver_notes,
            qb_timesheet_id,
            qb_status,
            updatedby,
            record_type_status,
          ];

          let results = await con.query(
            `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
            timesheetData
          );
          var update_data =
            (results.rows &&
              results.rows[1] &&
              results.rows[1].update_timesheet &&
              results.rows[1].update_timesheet[0]) ||
            null;

          await InsertTimesheetHistory(org_id, update_data.id);
          await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

        } else {
          // insert
          var timesheetData = [
            org_id,
            user_id,
            project_id,
            year,
            parseInt(month),
            week_start_date,
            week_end_date,
            timesheet_date,
            day_name,
            (regular_hours || 0),
            (regular_minutes || 0),
            (ot_hours || 0),
            (ot_minutes || 0),
            (absent_type || null),
            (absent_hours || 0),
            (absent_minutes || 0),
            status,
            user_notes,
            approver_id,
            approver_notes,
            qb_timesheet_id,
            qb_status,
            createdby,
            record_type_status,
          ];

          let results = await con.query(
            `SELECT timesheets.insert_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
            timesheetData
          );

          var insert_data =
            (results.rows &&
              results.rows[1] &&
              results.rows[1].insert_timesheet &&
              results.rows[1].insert_timesheet[0]) ||
            null;
          await InsertTimesheetHistory(org_id, insert_data.id);
        }
      }

      let statusData = {
        org_id: org_id,
        user_id: user_id,
        project_id: project_id,
        year: year,
        month: parseInt(month),
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        client_manager_email: client_manager_email,
        client_manager_name: client_manager_name,
        user_notes: ts_user_notes,
        approver_id: ts_approver_id,
        approver_notes: ts_approver_notes,
        createdby: createdby,
      };

      let ts_status_data = await ResetTimesheetStatus(statusData);

      // update client manager name/email
      await UpdateProjectClientManagerDetails({
        id: project_id,
        org_id,
        client_manager_name,
        client_manager_email,
        updatedby

      });

      // Insert note/comment
      if (
        ts_status_data &&
        ts_status_data.id &&
        ts_user_notes &&
        !same_comment
      ) {
        let comment_type = TS_COMMENT_TYPE.WEEKLY;
        let user_type = TS_COMMENT_USER_TYPE.EMPLOYEE;

        let tsCommentData = [
          org_id,
          comment_type,
          null,
          user_type,
          user_id,
          ts_user_notes,
          ts_status_data.id,
          project_id,
          week_start_date,
          week_end_date,
          createdby,
          record_type_status,
        ];
        var result = await con.query(
          `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
          tsCommentData
        );
      }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Saved Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet data" };
      returnMessage.label = "save_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "save_project_wise_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for submit_project_wise_timesheet

const submit_project_wise_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = createTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "submit_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_data = null,
      user_notes: ts_user_notes = null,
      approver_id: ts_approver_id = null,
      approver_notes: ts_approver_notes = null,
      client_manager_email = null,
      client_manager_name = null,
    } = req.body;

    if (timesheet_data && timesheet_data.length) {
      // check last comment
      let check_timesheet_docs = await con.query(
        `SELECT timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4)`,
        [org_id, week_start_date, week_end_date, project_id]
      );
      check_timesheet_docs =
        (check_timesheet_docs.rows &&
          check_timesheet_docs.rows[0] &&
          check_timesheet_docs.rows[0]
            .get_timesheet_docs_by_week_and_project) ||
        null;

      // check last comment
      let check_timesheet_comment = await con.query(
        `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
        [
          org_id,
          project_id,
          week_start_date,
          week_end_date,
          TS_COMMENT_TYPE.WEEKLY,
          TS_COMMENT_USER_TYPE.EMPLOYEE,
        ]
      );

      check_timesheet_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
        null;

      let last_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.id &&
          check_timesheet_comment.comments) ||
        null;

      if (!check_timesheet_docs || !check_timesheet_docs.length > 0) {
        returnMessage.isError = true;
        returnMessage.message = "Documents not added";
        returnMessage.error = "timesheet_documents are requied";
        returnMessage.label = "submit_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      } else if (!ts_user_notes) {
        returnMessage.isError = true;
        returnMessage.message = "Comment not added";
        returnMessage.error = "timesheet_comments are requied";
        returnMessage.label = "submit_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      } else {
        let same_comment = false;
        if (last_comment && last_comment == ts_user_notes) {
          same_comment = true;
        }

        // insert / update timesheet data
        for (var i = 0; i < timesheet_data.length; i++) {
          let tdRow = timesheet_data[i];
          let {
            timesheet_date = null,
            regular_hours = null,
            regular_minutes = null,
            ot_hours = null,
            ot_minutes = null,
            absent_type = null,
            absent_hours = null,
            absent_minutes = null,
            // status = "SAVED",
            user_notes = null,
            approver_id = null,
            approver_notes = null,
            qb_timesheet_id = null,
            qb_status = null,
          } = tdRow;

          var tdate = `${timesheet_date}T00:00:00Z`;
          var day_name = moment(tdate).format("dddd");
          let status = TIMESHEET_STATUS.SUBMITTED;

          let timesheet_exists = await con.query(
            `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
            [org_id, project_id, timesheet_date]
          );

          timesheet_exists =
            (timesheet_exists &&
              timesheet_exists.rows[0]
                .get_single_timesheet_by_date_and_project_id &&
              timesheet_exists.rows[0]
                .get_single_timesheet_by_date_and_project_id[0]) ||
            null;

          if (timesheet_exists && timesheet_exists.id) {
            // update
            let timesheet_id = timesheet_exists.id;
            qb_timesheet_id = timesheet_exists.qb_timesheet_id;
            qb_status = timesheet_exists.qb_status;
            if (timesheet_exists.status == TIMESHEET_STATUS.APPROVED) {
              status = TIMESHEET_STATUS.APPROVED;
            }

            var timesheetData = [
              timesheet_id,
              org_id,
              user_id,
              project_id,
              year,
              parseInt(month),
              week_start_date,
              week_end_date,
              timesheet_date,
              day_name,
              (regular_hours || 0),
              (regular_minutes || 0),
              (ot_hours || 0),
              (ot_minutes || 0),
              (absent_type || null),
              (absent_hours || 0),
              (absent_minutes || 0),
              status,
              user_notes,
              approver_id,
              approver_notes,
              qb_timesheet_id,
              qb_status,
              updatedby,
              record_type_status,
            ];

            let results = await con.query(
              `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
              timesheetData
            );
            var update_data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].update_timesheet &&
                results.rows[1].update_timesheet[0]) ||
              null;

            await InsertTimesheetHistory(org_id, update_data.id);
            await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
            
          } else {
            // insert
            var timesheetData = [
              org_id,
              user_id,
              project_id,
              year,
              parseInt(month),
              week_start_date,
              week_end_date,
              timesheet_date,
              day_name,
              (regular_hours || 0),
              (regular_minutes || 0),
              (ot_hours || 0),
              (ot_minutes || 0),
              (absent_type || null),
              (absent_hours || 0),
              (absent_minutes || 0),
              status,
              user_notes,
              approver_id,
              approver_notes,
              qb_timesheet_id,
              qb_status,
              createdby,
              record_type_status,
            ];

            let results = await con.query(
              `SELECT timesheets.insert_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
              timesheetData
            );

            var insert_data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].insert_timesheet &&
                results.rows[1].insert_timesheet[0]) ||
              null;
            await InsertTimesheetHistory(org_id, insert_data.id);
          }
        }

        let statusData = {
          org_id: org_id,
          user_id: user_id,
          project_id: project_id,
          year: year,
          month: parseInt(month),
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          client_manager_email: client_manager_email,
          client_manager_name: client_manager_name,
          user_notes: ts_user_notes,
          approver_id: ts_approver_id,
          approver_notes: ts_approver_notes,
          createdby: createdby,
        };

        let ts_status_data = await ResetTimesheetStatus(statusData);

        // update client manager name/email
        await UpdateProjectClientManagerDetails({
          id: project_id,
          org_id,
          client_manager_name,
          client_manager_email,
          updatedby
        });

        // Insert note/comment
        if (
          ts_status_data &&
          ts_status_data.id &&
          ts_user_notes &&
          !same_comment
        ) {
          let comment_type = TS_COMMENT_TYPE.WEEKLY;
          let user_type = TS_COMMENT_USER_TYPE.EMPLOYEE;

          let tsCommentData = [
            org_id,
            comment_type,
            null,
            user_type,
            user_id,
            ts_user_notes,
            ts_status_data.id,
            project_id,
            week_start_date,
            week_end_date,
            createdby,
            record_type_status,
          ];
          var result = await con.query(
            `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
            tsCommentData
          );
        }

        // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.SUBMITTED){

        // Send Timesheet Submitted Email to approver
        let consultant_data = await con.query(
          `SELECT * from timesheets.get_user_by_id($1,$2)`,
          [user_id, org_id]
        );
        consultant_data =
          (consultant_data &&
            consultant_data.rows &&
            consultant_data.rows[0] &&
            consultant_data.rows[0].j &&
            consultant_data.rows[0].j[0]) ||
          null;

        let employee_name =
          (consultant_data && consultant_data.full_name) || null;
        let week_range = `${week_start_date}-${week_end_date}`;

        let approvers = await con.query(
          `SELECT * from timesheets.get_approvers_list($1);`,
          [org_id]
        );
        approvers =
          (approvers &&
            approvers.rows &&
            approvers.rows[0] &&
            approvers.rows[0].j) ||
          null;

        if (approvers && approvers.length) {
          for (let i = 0; i < approvers.length; i++) {
            let approverRow = approvers[i];
            let approver_name = approverRow.full_name || null;
            let approver_email = approverRow.email || null;
            // let approver_email = "masood.m@msr-it.com";

            if (approver_email) {
              let emailData = {
                org_id: org_id,
                week_start_date: week_start_date,
                week_end_date: week_end_date,
                approver_name: approver_name,
                approver_email: approver_email,
                employee_name: employee_name,
              };

              let user_id = approverRow.id;
              let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

              // send email to approvers only when user is submitting timesheet for himself 
              if(is_email_reminder && (consultant_data.id == req.user.id)){
                  await SubmittedEmailToApprovers(emailData);
              }
            }
          }
        }

        // }

        returnMessage.isError = false;
        returnMessage.data = null;
        returnMessage.message = "Timesheet Submitted Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet data" };
      returnMessage.label = "submit_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "submit_project_wise_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for submit_project_wise_timesheet

const submit_all_project_timesheets = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    let { errors, isValid } = submitAllTimesheetsValidator({
      ...req.body,
      org_id,
    });
    let submitted_response = 0;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "submit_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheets = null,
    } = req.body;

    if (timesheets && timesheets.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let { errors, isValid } = createTimesheetValidator({
          ...timesheetsRow,
          org_id,
          week_start_date,
          week_end_date,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "save_project_wise_timesheet";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      // check docs and comments
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let {
          project_id = null,
          user_notes: ts_user_notes = null,
          approver_id: ts_approver_id = null,
        } = timesheetsRow;

        let check_timesheet_docs = await con.query(
          `SELECT timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4)`,
          [org_id, week_start_date, week_end_date, project_id]
        );
        check_timesheet_docs =
          (check_timesheet_docs.rows &&
            check_timesheet_docs.rows[0] &&
            check_timesheet_docs.rows[0]
              .get_timesheet_docs_by_week_and_project) ||
          null;

        // check last comment
        let check_timesheet_comment = await con.query(
          `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
          [
            org_id,
            project_id,
            week_start_date,
            week_end_date,
            TS_COMMENT_TYPE.WEEKLY,
            TS_COMMENT_USER_TYPE.EMPLOYEE,
          ]
        );

        check_timesheet_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
          null;

        let last_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.id &&
            check_timesheet_comment.comments) ||
          null;

        if (!check_timesheet_docs || !check_timesheet_docs.length > 0) {
          returnMessage.isError = true;
          returnMessage.message = "Documents not added";
          returnMessage.error = "timesheet_documents are requied";
          returnMessage.label = "submit_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        } else if (!ts_user_notes) {
          returnMessage.isError = true;
          returnMessage.message = "Comment not added";
          returnMessage.error = "timesheet_comments are requied";
          returnMessage.label = "submit_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];

        let {
          user_id = null,
          project_id = null,
          timesheet_data = null,
          user_notes: ts_user_notes = null,
          approver_id: ts_approver_id = null,
          approver_notes: ts_approver_notes = null,
          client_manager_email = null,
          client_manager_name = null,
        } = timesheetsRow;

        if (timesheet_data && timesheet_data.length) {
          // check last comment
          let check_timesheet_docs = await con.query(
            `SELECT timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4)`,
            [org_id, week_start_date, week_end_date, project_id]
          );
          check_timesheet_docs =
            (check_timesheet_docs.rows &&
              check_timesheet_docs.rows[0] &&
              check_timesheet_docs.rows[0]
                .get_timesheet_docs_by_week_and_project) ||
            null;

          // check last comment
          let check_timesheet_comment = await con.query(
            `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
            [
              org_id,
              project_id,
              week_start_date,
              week_end_date,
              TS_COMMENT_TYPE.WEEKLY,
              TS_COMMENT_USER_TYPE.EMPLOYEE,
            ]
          );

          check_timesheet_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
            null;

          let last_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.id &&
              check_timesheet_comment.comments) ||
            null;

          let same_comment = false;
          if (last_comment && last_comment == ts_user_notes) {
            same_comment = true;
          }

          // insert / update timesheet data
          for (var j = 0; j < timesheet_data.length; j++) {
            let tdRow = timesheet_data[j];
            let {
              timesheet_date = null,
              regular_hours = null,
              regular_minutes = null,
              ot_hours = null,
              ot_minutes = null,
              absent_type = null,
              absent_hours = null,
              absent_minutes = null,
              // status = "SAVED",
              user_notes = null,
              approver_id = null,
              approver_notes = null,
              qb_timesheet_id = null,
              qb_status = null,
            } = tdRow;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.SUBMITTED;

            let timesheet_exists = await con.query(
              `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
              [org_id, project_id, timesheet_date]
            );

            timesheet_exists =
              (timesheet_exists &&
                timesheet_exists.rows[0]
                  .get_single_timesheet_by_date_and_project_id &&
                timesheet_exists.rows[0]
                  .get_single_timesheet_by_date_and_project_id[0]) ||
              null;

            if (timesheet_exists && timesheet_exists.id) {
              // update
              let timesheet_id = timesheet_exists.id;
              qb_timesheet_id = timesheet_exists.qb_timesheet_id;
              qb_status = timesheet_exists.qb_status;
              if (timesheet_exists.status == TIMESHEET_STATUS.APPROVED) {
                status = TIMESHEET_STATUS.APPROVED;
              }

              var timesheetData = [
                timesheet_id,
                org_id,
                user_id,
                project_id,
                year,
                parseInt(month),
                week_start_date,
                week_end_date,
                timesheet_date,
                day_name,
                (regular_hours || 0),
                (regular_minutes || 0),
                (ot_hours || 0),
                (ot_minutes || 0),
                (absent_type || null),
                (absent_hours || 0),
                (absent_minutes || 0),
                status,
                user_notes,
                approver_id,
                approver_notes,
                qb_timesheet_id,
                qb_status,
                updatedby,
                record_type_status,
              ];

              let results = await con.query(
                `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                timesheetData
              );
              var update_data =
                (results.rows &&
                  results.rows[1] &&
                  results.rows[1].update_timesheet &&
                  results.rows[1].update_timesheet[0]) ||
                null;

              await InsertTimesheetHistory(org_id, update_data.id);
              await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

            } else {
              // insert
              var timesheetData = [
                org_id,
                user_id,
                project_id,
                year,
                parseInt(month),
                week_start_date,
                week_end_date,
                timesheet_date,
                day_name,
                (regular_hours || 0),
                (regular_minutes || 0),
                (ot_hours || 0),
                (ot_minutes || 0),
                (absent_type || null),
                (absent_hours || 0),
                (absent_minutes || 0),
                status,
                user_notes,
                approver_id,
                approver_notes,
                qb_timesheet_id,
                qb_status,
                createdby,
                record_type_status,
              ];

              let results = await con.query(
                `SELECT timesheets.insert_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
                timesheetData
              );

              var insert_data =
                (results.rows &&
                  results.rows[1] &&
                  results.rows[1].insert_timesheet &&
                  results.rows[1].insert_timesheet[0]) ||
                null;
              await InsertTimesheetHistory(org_id, insert_data.id);
            }
          }

          let statusData = {
            org_id: org_id,
            user_id: user_id,
            project_id: project_id,
            year: year,
            month: parseInt(month),
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            client_manager_email: client_manager_email,
            client_manager_name: client_manager_name,
            user_notes: ts_user_notes,
            approver_id: ts_approver_id,
            approver_notes: ts_approver_notes,
            createdby: createdby,
          };

          let ts_status_data = await ResetTimesheetStatus(statusData);

          // update client manager name/email
          await UpdateProjectClientManagerDetails({
            id: project_id,
            org_id,
            client_manager_name,
            client_manager_email,
            updatedby
          });

          // Insert note/comment
          if (
            ts_status_data &&
            ts_status_data.id &&
            ts_user_notes &&
            !same_comment
          ) {
            let comment_type = TS_COMMENT_TYPE.WEEKLY;
            let user_type = TS_COMMENT_USER_TYPE.EMPLOYEE;

            let tsCommentData = [
              org_id,
              comment_type,
              null,
              user_type,
              user_id,
              ts_user_notes,
              ts_status_data.id,
              project_id,
              week_start_date,
              week_end_date,
              createdby,
              record_type_status,
            ];
            var result = await con.query(
              `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
              tsCommentData
            );
          }

          submitted_response++;
        }
      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.SUBMITTED){

      let user_id =
        (timesheets && timesheets.length && timesheets[0].user_id) || null;
      // Send Timesheet Submitted Email to approver
      let consultant_data = await con.query(
        `SELECT * from timesheets.get_user_by_id($1,$2)`,
        [user_id, org_id]
      );
      consultant_data =
        (consultant_data &&
          consultant_data.rows &&
          consultant_data.rows[0] &&
          consultant_data.rows[0].j &&
          consultant_data.rows[0].j[0]) ||
        null;

      let employee_name =
        (consultant_data && consultant_data.full_name) || null;
      let week_range = `${week_start_date}-${week_end_date}`;

      let approvers = await con.query(
        `SELECT * from timesheets.get_approvers_list($1);`,
        [org_id]
      );
      approvers =
        (approvers &&
          approvers.rows &&
          approvers.rows[0] &&
          approvers.rows[0].j) ||
        null;

      if (approvers && approvers.length) {
        for (let i = 0; i < approvers.length; i++) {
          let approverRow = approvers[i];
          let approver_name = approverRow.full_name || null;
          let approver_email = approverRow.email || null;
          // let approver_email = "masood.m@msr-it.com";

          if (approver_email) {
            let emailData = {
              org_id: org_id,
              week_start_date: week_start_date,
              week_end_date: week_end_date,
              approver_name: approver_name,
              approver_email: approver_email,
              employee_name: employee_name,
            };

            let user_id = approverRow.id;
            let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

            // send email to approvers only when user is submitting timesheet for himself 
            if(is_email_reminder && (consultant_data.id == req.user.id)){
              await SubmittedEmailToApprovers(emailData);
            }
          }
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "All Timesheets Submitted Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheets" };
      returnMessage.label = "submit_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "submit_all_project_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// POST api for unsubmit project wise timesheet

const unsubmit_project_wise_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = unsubmitTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "unsubmit_project_wise_timesheet2";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;

    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
    } = req.body;

    let tmp_start_date = `${week_start_date}T00:00:00Z`;
    let tmp_end_date = `${week_end_date}T00:00:00Z`;

    let range = moment().range(moment(tmp_start_date), moment(tmp_end_date));

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        let timesheet_date = dates[i];
        status = TIMESHEET_STATUS.SAVED;

        let timesheet_exists = await con.query(
          `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
          [org_id, project_id, timesheet_date]
        );

        timesheet_exists =
          (timesheet_exists &&
            timesheet_exists.rows[0]
              .get_single_timesheet_by_date_and_project_id &&
            timesheet_exists.rows[0]
              .get_single_timesheet_by_date_and_project_id[0]) ||
          null;

        if (timesheet_exists && timesheet_exists.id) {
          
          // update
          let timesheet_id = timesheet_exists.id;
          if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
            status = TIMESHEET_STATUS.SAVED;
          } else {
            status = timesheet_exists.status;
          }

          var timesheetData = [
            timesheet_id,
            timesheet_exists.org_id,
            timesheet_exists.user_id,
            timesheet_exists.project_id,
            timesheet_exists.year,
            timesheet_exists.month,
            timesheet_exists.week_start_date,
            timesheet_exists.week_end_date,
            timesheet_exists.timesheet_date,
            timesheet_exists.day_name,
            timesheet_exists.regular_hours,
            timesheet_exists.regular_minutes,
            timesheet_exists.ot_hours,
            timesheet_exists.ot_minutes,
            timesheet_exists.absent_type,
            timesheet_exists.absent_hours,
            timesheet_exists.absent_minutes,
            status,
            timesheet_exists.user_notes,
            timesheet_exists.approver_id,
            timesheet_exists.approver_notes,
            timesheet_exists.qb_timesheet_id,
            timesheet_exists.qb_status,
            updatedby,
            timesheet_exists.record_type_status,
          ];

          let results = await con.query(
            `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
            timesheetData
          );
          var update_data =
            (results.rows &&
              results.rows[1] &&
              results.rows[1].update_timesheet &&
              results.rows[1].update_timesheet[0]) ||
            null;

          await InsertTimesheetHistory(org_id, update_data.id);
          await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

        }
      }

      let old_status_data = await con.query(
        `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
        [org_id, week_start_date, week_end_date, project_id]
      );

      old_status_data =
        (old_status_data &&
          old_status_data.rows[0].get_timesheet_status_by_week_and_project_id &&
          old_status_data.rows[0]
            .get_timesheet_status_by_week_and_project_id[0]) ||
        null;

      if (old_status_data && old_status_data.id) {
        let statusData = {
          org_id: old_status_data.org_id,
          user_id: old_status_data.user_id,
          project_id: old_status_data.project_id,
          year: old_status_data.year,
          month: old_status_data.month,
          week_start_date: old_status_data.week_start_date,
          week_end_date: old_status_data.week_end_date,
          client_manager_email: old_status_data.client_manager_email,
          client_manager_name: old_status_data.client_manager_name,
          user_notes: old_status_data.user_notes,
          approver_id: old_status_data.approver_id,
          approver_notes: old_status_data.approver_notes,
          createdby: createdby,
        };

        let ts_status_data = await ResetTimesheetStatus(statusData);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error =
        "Please provide correct week_start_date and week_end_date";
      returnMessage.label = "unsubmit_project_wise_timesheet2";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    returnMessage.isError = false;
    returnMessage.data = null;
    returnMessage.message = "Timesheet UnSubmited Successfully";
    returnMessage.statuscode = 200;
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "unsubmit_project_wise_timesheet2";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// POST api for unsubmit all project timesheet

const unsubmit_all_project_timesheets = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;
    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";

    let {
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheets = null,
    } = req.body;

    if (timesheets && timesheets.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let { errors, isValid } = unsubmitTimesheetValidator({
          ...timesheetsRow,
          org_id,
          year,
          month,
          week_start_date,
          week_end_date,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "unsubmit_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }
    }

    let tmp_start_date = `${week_start_date}T00:00:00Z`;
    let tmp_end_date = `${week_end_date}T00:00:00Z`;

    let range = moment().range(moment(tmp_start_date), moment(tmp_end_date));

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    if (timesheets && timesheets.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let { user_id = null, project_id = null } = timesheetsRow;

        if (dates && dates.length) {
          for (var j = 0; j < dates.length; j++) {
            let timesheet_date = dates[j];
            status = TIMESHEET_STATUS.SAVED;

            let timesheet_exists = await con.query(
              `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
              [org_id, project_id, timesheet_date]
            );

            timesheet_exists =
              (timesheet_exists &&
                timesheet_exists.rows[0]
                  .get_single_timesheet_by_date_and_project_id &&
                timesheet_exists.rows[0]
                  .get_single_timesheet_by_date_and_project_id[0]) ||
              null;

            if (timesheet_exists && timesheet_exists.id) {
              // update
              let timesheet_id = timesheet_exists.id;
              if (
                [TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)
              ) {
                status = TIMESHEET_STATUS.SAVED;
              } else {
                status = timesheet_exists.status;
              }

              var timesheetData = [
                timesheet_id,
                timesheet_exists.org_id,
                timesheet_exists.user_id,
                timesheet_exists.project_id,
                timesheet_exists.year,
                timesheet_exists.month,
                timesheet_exists.week_start_date,
                timesheet_exists.week_end_date,
                timesheet_exists.timesheet_date,
                timesheet_exists.day_name,
                timesheet_exists.regular_hours,
                timesheet_exists.regular_minutes,
                timesheet_exists.ot_hours,
                timesheet_exists.ot_minutes,
                timesheet_exists.absent_type,
                timesheet_exists.absent_hours,
                timesheet_exists.absent_minutes,
                status,
                timesheet_exists.user_notes,
                timesheet_exists.approver_id,
                timesheet_exists.approver_notes,
                timesheet_exists.qb_timesheet_id,
                timesheet_exists.qb_status,
                updatedby,
                timesheet_exists.record_type_status,
              ];

              let results = await con.query(
                `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                timesheetData
              );
              var update_data =
                (results.rows &&
                  results.rows[1] &&
                  results.rows[1].update_timesheet &&
                  results.rows[1].update_timesheet[0]) ||
                null;

              await InsertTimesheetHistory(org_id, update_data.id);
              await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
            }
          }

          let old_status_data = await con.query(
            `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
            [org_id, week_start_date, week_end_date, project_id]
          );

          old_status_data =
            (old_status_data &&
              old_status_data.rows[0]
                .get_timesheet_status_by_week_and_project_id &&
              old_status_data.rows[0]
                .get_timesheet_status_by_week_and_project_id[0]) ||
            null;

          if (old_status_data && old_status_data.id) {
            let statusData = {
              org_id: old_status_data.org_id,
              user_id: old_status_data.user_id,
              project_id: old_status_data.project_id,
              year: old_status_data.year,
              month: old_status_data.month,
              week_start_date: old_status_data.week_start_date,
              week_end_date: old_status_data.week_end_date,
              client_manager_email: old_status_data.client_manager_email,
              client_manager_name: old_status_data.client_manager_name,
              user_notes: old_status_data.user_notes,
              approver_id: old_status_data.approver_id,
              approver_notes: old_status_data.approver_notes,
              createdby: createdby,
            };

            let ts_status_data = await ResetTimesheetStatus(statusData);
          }
        } else {
          returnMessage.isError = true;
          returnMessage.message = "Invalid Data";
          returnMessage.error =
            "Please provide correct week_start_date and week_end_date";
          returnMessage.label = "unsubmit_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }
    }

    returnMessage.isError = false;
    returnMessage.data = null;
    returnMessage.message = "Timesheet UnSubmited Successfully";
    returnMessage.statuscode = 200;
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "unsubmit_all_project_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for status wise total hours by month

const get_status_wise_total_hours_by_month = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    //////////////////////
    let month = req.query.month?((req.query.month > 0)?(req.query.month - 1) : req.query.month): null;
    let year = req.query.year || null;      
    let month2d = req.query.month ? moment().month(month).format("MM") : moment().format("MM");
    year = year ? moment().year(year).format("YYYY") : moment().format("YYYY");
    let date = `${year}-${month2d}`;
    let months = moment(date, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").format("YYYY-MM-DD");

    let data = {};

    // get total saved hours
    let result_saved = await con.query(
      `SELECT * from timesheets.get_total_hours_by_month_and_status($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        year,
        month2d,
        month_start_date,
        month_end_date,
        TIMESHEET_STATUS.SAVED,
      ]
    );
    result_saved =
      (result_saved &&
        result_saved.rows &&
        result_saved.rows[0] &&
        result_saved.rows[0].j &&
        result_saved.rows[0].j[0]) ||
      null;

    // get total submitted hours
    let result_submitted = await con.query(
      `SELECT * from timesheets.get_total_hours_by_month_and_status($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        year,
        month2d,
        month_start_date,
        month_end_date,
        TIMESHEET_STATUS.SUBMITTED,
      ]
    );
    result_submitted =
      (result_submitted &&
        result_submitted.rows &&
        result_submitted.rows[0] &&
        result_submitted.rows[0].j &&
        result_submitted.rows[0].j[0]) ||
      null;

    // get total approved hours
    let result_approved = await con.query(
      `SELECT * from timesheets.get_total_hours_by_month_and_status($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        year,
        month2d,
        month_start_date,
        month_end_date,
        TIMESHEET_STATUS.APPROVED,
      ]
    );
    result_approved =
      (result_approved &&
        result_approved.rows &&
        result_approved.rows[0] &&
        result_approved.rows[0].j &&
        result_approved.rows[0].j[0]) ||
      null;

    // get total rejected hours
    let result_rejected = await con.query(
      `SELECT * from timesheets.get_total_hours_by_month_and_status($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        year,
        month2d,
        month_start_date,
        month_end_date,
        TIMESHEET_STATUS.REJECTED,
      ]
    );
    result_rejected =
      (result_rejected &&
        result_rejected.rows &&
        result_rejected.rows[0] &&
        result_rejected.rows[0].j &&
        result_rejected.rows[0].j[0]) ||
      null;

    data[TIMESHEET_STATUS.SAVED] = result_saved;
    data[TIMESHEET_STATUS.SUBMITTED] = result_submitted;
    data[TIMESHEET_STATUS.APPROVED] = result_approved;
    data[TIMESHEET_STATUS.REJECTED] = result_rejected;

    returnMessage.isError = false;
    returnMessage.message = "Data fetched successfully";
    returnMessage.data = data;
    res.status(200).json(returnMessage);
    ////////////////////////
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_status_wise_total_hours_by_month";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for single week approver timesheet by user and week dates

const get_single_week_approver_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_single_week_approver_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_single_week_approver_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_single_week_approver_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_single_week_approver_timesheet($1,$2,$3,$4)`,
        [
          org_id,
          req.query.user_id,
          req.query.week_start_date,
          req.query.week_end_date,
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_single_week_approver_timesheet";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            results = (results.rows && results.rows[0] && results.rows[0].j) || null;
          
            ///////////////
            if(results && results.length){
                        
              let regular_hours = 0;
              let regular_minutes = 0;
              let ot_hours = 0;
              let ot_minutes = 0;
              let absent_hours = 0;
              let absent_minutes = 0;
              
              let total_sec = 0;
              let total_saved_sec = 0;
              let total_submitted_sec = 0;
              let total_approved_sec = 0;
              let total_rejected_sec = 0;
          
              let total_hours_minutes = 0;
              let total_saved_hours_minutes = 0;
              let total_submitted_hours_minutes = 0;
              let total_approved_hours_minutes = 0;
              let total_rejected_hours_minutes = 0;
          
              for (var i = 0; i < results.length; i++) {
              
              tsRow = results[i];
              let {timesheet_data = null} = tsRow;
          
              let project_total_sec = 0;
              let project_total_regular_sec = 0;
              let project_total_ot_sec = 0;
              let project_total_absent_sec = 0;
              
              let project_total_hours_minutes = 0;
              let project_total_absent_hours_minutes = 0;
              let project_total_regular_hours_minutes = 0;
              let project_total_ot_hours_minutes = 0;
          
              if(timesheet_data && timesheet_data.length){
                        
                for(j = 0; j < timesheet_data.length; j++){
                
                let tdRow = timesheet_data[j];
          
                regular_hours = (tdRow.regular_hours && tdRow.regular_hours * 60 * 60) || 0;
                regular_minutes = (tdRow.regular_minutes && tdRow.regular_minutes * 60) || 0; 
                
                ot_hours = (tdRow.ot_hours && tdRow.ot_hours * 60 * 60) || 0;
                ot_minutes = (tdRow.ot_minutes && tdRow.ot_minutes * 60) || 0;
          
                absent_hours = (tdRow.absent_hours && tdRow.absent_hours * 60 * 60) || 0;
                absent_minutes = (tdRow.absent_minutes && tdRow.absent_minutes * 60) || 0;
                
                total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
          
                project_total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                project_total_regular_sec+= regular_hours + regular_minutes;
                project_total_ot_sec+= ot_hours + ot_minutes;
                project_total_absent_sec+= absent_hours + absent_minutes;
          
                if (tdRow.status == TIMESHEET_STATUS.SAVED) {
                  total_saved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                }
                if (tdRow.status == TIMESHEET_STATUS.SUBMITTED) {
                  total_submitted_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                }
                if (tdRow.status == TIMESHEET_STATUS.APPROVED) {
                  total_approved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                }
                if (tdRow.status == TIMESHEET_STATUS.REJECTED) {
                  total_rejected_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                }

                let is_qb_enabled = await isQBEnabled(req.user.org_id);

                  // don't pass qb details in API response
                  if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                    delete results[i].timesheet_data[j].qb_timesheet_id;
                    delete results[i].timesheet_data[j].qb_status;
                  }
                }
          
                project_total_hours_minutes = secondsToHm(project_total_sec);
                project_total_regular_hours_minutes = secondsToHm(project_total_regular_sec);
                project_total_ot_hours_minutes = secondsToHm(project_total_ot_sec);
                project_total_absent_hours_minutes = secondsToHm(project_total_absent_sec);
          
                results[i].project_total_hours_minutes = project_total_hours_minutes;
                results[i].project_total_regular_hours_minutes = project_total_regular_hours_minutes;
                results[i].project_total_ot_hours_minutes = project_total_ot_hours_minutes;
                results[i].project_total_absent_hours_minutes = project_total_absent_hours_minutes;
          
              }

              let is_qb_enabled = await isQBEnabled(req.user.org_id);
              // don't pass qb details in API response
              if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                delete results[i].qb_customer_id;
                delete results[i].qb_customer_name;
                delete results[i].qb_project_id;
                delete results[i].qb_project_name;
                delete results[i].qb_product_id;
                delete results[i].qb_product_name;
                delete results[i].qb_status;
              }
              // don't pass bill rate / pay rate details in response
              delete results[i].bill_rate;
              delete results[i].pay_rate;
              delete results[i].bill_rate_currency;
              delete results[i].ot_bill_rate;
              delete results[i].ot_pay_rate;
              delete results[i].ot_bill_rate_currency;

              }
          
          
              total_hours_minutes = secondsToHm(total_sec);
              total_saved_hours_minutes = secondsToHm(total_saved_sec);
              total_submitted_hours_minutes = secondsToHm(total_submitted_sec);
              total_approved_hours_minutes = secondsToHm(total_approved_sec);
              total_rejected_hours_minutes = secondsToHm(total_rejected_sec);
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.hours_data = {
                total_hours_minutes,
                total_saved_hours_minutes,
                total_submitted_hours_minutes,
                total_approved_hours_minutes,
                total_rejected_hours_minutes
              };
              
              res.status(200).json(returnMessage);
              
            }
            else{
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_single_week_approver_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for approve_project_wise_timesheet

const approve_project_wise_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = approveTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "approve_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_data = null,
      approver_notes: ts_approver_notes = null,
    } = req.body;

    let ts_approver_id = req.user.id;

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "approve_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
      
    }

    if (timesheet_data && timesheet_data.length) {
      // check last comment
      let check_timesheet_comment = await con.query(
        `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
        [
          org_id,
          project_id,
          week_start_date,
          week_end_date,
          TS_COMMENT_TYPE.WEEKLY,
          TS_COMMENT_USER_TYPE.APPROVER,
        ]
      );

      check_timesheet_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
        null;

      let last_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.id &&
          check_timesheet_comment.comments) ||
        null;

      if (!ts_approver_notes) {
        returnMessage.isError = true;
        returnMessage.message = "Comment not added";
        returnMessage.error = "approver_notes are requied";
        returnMessage.label = "approve_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      } else {
        let same_comment = false;
        if (last_comment && last_comment == ts_approver_notes) {
          same_comment = true;
        }

        // insert / update timesheet data
        for (var i = 0; i < timesheet_data.length; i++) {
          let tdRow = timesheet_data[i];
          let {
            timesheet_date = null,
            approver_notes = null,
            approver_id = ts_approver_id,
          } = tdRow;

          var tdate = `${timesheet_date}T00:00:00Z`;
          var day_name = moment(tdate).format("dddd");
          let status = TIMESHEET_STATUS.APPROVED;

          let timesheet_exists = await con.query(
            `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
            [org_id, project_id, timesheet_date]
          );

          timesheet_exists =
            (timesheet_exists &&
              timesheet_exists.rows[0]
                .get_single_timesheet_by_date_and_project_id &&
              timesheet_exists.rows[0]
                .get_single_timesheet_by_date_and_project_id[0]) ||
            null;

          if (timesheet_exists && timesheet_exists.id) {
            // update
            let timesheet_id = timesheet_exists.id;
            if (
              [TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)
            ) {
              status = TIMESHEET_STATUS.APPROVED;
            } else {
              status = timesheet_exists.status;
            }

            var timesheetData = [
              timesheet_id,
              org_id,
              user_id,
              project_id,
              year,
              parseInt(month),
              week_start_date,
              week_end_date,
              timesheet_date,
              day_name,
              timesheet_exists.regular_hours,
              timesheet_exists.regular_minutes,
              timesheet_exists.ot_hours,
              timesheet_exists.ot_minutes,
              timesheet_exists.absent_type,
              timesheet_exists.absent_hours,
              timesheet_exists.absent_minutes,
              status,
              timesheet_exists.user_notes,
              ts_approver_id,
              ts_approver_notes,
              timesheet_exists.qb_timesheet_id,
              timesheet_exists.qb_status,
              updatedby,
              record_type_status,
            ];

            let results = await con.query(
              `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
              timesheetData
            );
            var update_data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].update_timesheet &&
                results.rows[1].update_timesheet[0]) ||
              null;

            await InsertTimesheetHistory(org_id, update_data.id);
            await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
          }
        }

        let ts_status_data = null;
        let old_status_data = await con.query(
          `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
          [org_id, week_start_date, week_end_date, project_id]
        );

        old_status_data =
          (old_status_data &&
            old_status_data.rows[0]
              .get_timesheet_status_by_week_and_project_id &&
            old_status_data.rows[0]
              .get_timesheet_status_by_week_and_project_id[0]) ||
          null;

        if (old_status_data && old_status_data.id) {
          let statusData = {
            org_id: org_id,
            user_id: user_id,
            project_id: project_id,
            year: year,
            month: parseInt(month),
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            client_manager_email: old_status_data.client_manager_email,
            client_manager_name: old_status_data.client_manager_name,
            user_notes: old_status_data.user_notes,
            approver_id: ts_approver_id,
            approver_notes: ts_approver_notes,
            createdby: createdby,
          };

          ts_status_data = await ResetTimesheetStatus(statusData);
        }

        // Insert approver note/comment
        if (
          ts_status_data &&
          ts_status_data.id &&
          ts_approver_notes &&
          !same_comment
        ) {
          let comment_type = TS_COMMENT_TYPE.WEEKLY;
          let user_type = TS_COMMENT_USER_TYPE.APPROVER;

          let tsCommentData = [
            org_id,
            comment_type,
            null,
            user_type,
            ts_approver_id,
            ts_approver_notes,
            ts_status_data.id,
            project_id,
            week_start_date,
            week_end_date,
            createdby,
            record_type_status,
          ];
          var result = await con.query(
            `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
            tsCommentData
          );
        }

        // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.APPROVED){

        // Send Timesheet Approved Email to employee
        let consultant_data = await con.query(
          `SELECT * from timesheets.get_user_by_id($1,$2)`,
          [user_id, org_id]
        );
        consultant_data =
          (consultant_data &&
            consultant_data.rows &&
            consultant_data.rows[0] &&
            consultant_data.rows[0].j &&
            consultant_data.rows[0].j[0]) ||
          null;

        let employee_name =
          (consultant_data && consultant_data.full_name) || null;
        let employee_email = (consultant_data && consultant_data.email) || null;
        // let employee_email = "sonu.hussain@msr-it.com";
        let week_range = `${week_start_date}-${week_end_date}`;

        if(consultant_data.id){
          
          // send push notification 
          let notificationData = {
            action: "approve_project_wise_timesheet",
            org_id: org_id,
            user_id: consultant_data.id, 
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            employee_name: employee_name,
            employee_email: employee_email,
          };
          await ApprovedPushNotificationToEmployee(notificationData);
        }

        if (employee_email) {
          let emailData = {
            org_id: org_id,
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            employee_name: employee_name,
            employee_email: employee_email,
          };

          let user_id= consultant_data.id;
          let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);


          // send email
          if(is_email_reminder){
            await ApprovedEmailToEmployee(emailData);
          }
        }

        // }

        returnMessage.isError = false;
        returnMessage.data = null;
        returnMessage.message = "Timesheet Approved Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet data" };
      returnMessage.label = "approve_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "approve_project_wise_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for approve_project_wise_single_day_timesheet

const approve_project_wise_single_day_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = approveSingleDayTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "approve_project_wise_single_day_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_date = null,
      approver_notes: ts_approver_notes = null,
    } = req.body;

    let ts_approver_id = req.user.id;

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "approve_project_wise_single_day_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
      
    }

    // check last comment
    let check_timesheet_comment = await con.query(
      `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        project_id,
        week_start_date,
        week_end_date,
        TS_COMMENT_TYPE.WEEKLY,
        TS_COMMENT_USER_TYPE.APPROVER,
      ]
    );

    check_timesheet_comment =
      (check_timesheet_comment &&
        check_timesheet_comment.rows[0].get_last_timesheet_comment &&
        check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
      null;

    let last_comment =
      (check_timesheet_comment &&
        check_timesheet_comment.id &&
        check_timesheet_comment.comments) ||
      null;

    let same_comment = false;
    if (last_comment && last_comment == ts_approver_notes) {
      same_comment = true;
    }

    // insert / update timesheet data

    var tdate = `${timesheet_date}T00:00:00Z`;
    var day_name = moment(tdate).format("dddd");
    let status = TIMESHEET_STATUS.APPROVED;

    let timesheet_exists = await con.query(
      `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
      [org_id, project_id, timesheet_date]
    );

    timesheet_exists =
      (timesheet_exists &&
        timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id &&
        timesheet_exists.rows[0]
          .get_single_timesheet_by_date_and_project_id[0]) ||
      null;

    if (timesheet_exists && timesheet_exists.id) {
      // update
      let timesheet_id = timesheet_exists.id;
      if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
        status = TIMESHEET_STATUS.APPROVED;
      } else {
        status = timesheet_exists.status;
      }

      var timesheetData = [
        timesheet_id,
        org_id,
        user_id,
        project_id,
        year,
        parseInt(month),
        week_start_date,
        week_end_date,
        timesheet_date,
        day_name,
        timesheet_exists.regular_hours,
        timesheet_exists.regular_minutes,
        timesheet_exists.ot_hours,
        timesheet_exists.ot_minutes,
        timesheet_exists.absent_type,
        timesheet_exists.absent_hours,
        timesheet_exists.absent_minutes,
        status,
        timesheet_exists.user_notes,
        ts_approver_id,
        ts_approver_notes,
        timesheet_exists.qb_timesheet_id,
        timesheet_exists.qb_status,
        updatedby,
        record_type_status,
      ];

      let results = await con.query(
        `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
        timesheetData
      );
      var update_data =
        (results.rows &&
          results.rows[1] &&
          results.rows[1].update_timesheet &&
          results.rows[1].update_timesheet[0]) ||
        null;

      await InsertTimesheetHistory(org_id, update_data.id);
      await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
    }

    let ts_status_data = null;
    let old_status_data = await con.query(
      `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
      [org_id, week_start_date, week_end_date, project_id]
    );

    old_status_data =
      (old_status_data &&
        old_status_data.rows[0].get_timesheet_status_by_week_and_project_id &&
        old_status_data.rows[0]
          .get_timesheet_status_by_week_and_project_id[0]) ||
      null;

    if (old_status_data && old_status_data.id) {
      let statusData = {
        org_id: org_id,
        user_id: user_id,
        project_id: project_id,
        year: year,
        month: parseInt(month),
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        client_manager_email: old_status_data.client_manager_email,
        client_manager_name: old_status_data.client_manager_name,
        user_notes: old_status_data.user_notes,
        approver_id: ts_approver_id,
        approver_notes: old_status_data.approver_notes,
        createdby: createdby,
      };

      ts_status_data = await ResetTimesheetStatus(statusData);
    }

    // Insert approver note/comment
    if (
      ts_status_data &&
      ts_status_data.id &&
      ts_approver_notes &&
      !same_comment
    ) {
      let comment_type = TS_COMMENT_TYPE.DAILY;
      let user_type = TS_COMMENT_USER_TYPE.APPROVER;

      let tsCommentData = [
        org_id,
        comment_type,
        timesheet_date,
        user_type,
        ts_approver_id,
        ts_approver_notes,
        ts_status_data.id,
        project_id,
        week_start_date,
        week_end_date,
        createdby,
        record_type_status,
      ];
      var result = await con.query(
        `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        tsCommentData
      );
    }

    // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.APPROVED){

    // Send Timesheet Approved Email to employee
    let consultant_data = await con.query(
      `SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]
    );
    consultant_data =
      (consultant_data &&
        consultant_data.rows &&
        consultant_data.rows[0] &&
        consultant_data.rows[0].j &&
        consultant_data.rows[0].j[0]) ||
      null;

    let employee_name = (consultant_data && consultant_data.full_name) || null;
    let employee_email = (consultant_data && consultant_data.email) || null;
    // let employee_email = "masood.m@msr-it.com";
    let week_range = `${week_start_date}-${week_end_date}`;

    if(consultant_data.id){
          
      // send push notification 
      let notificationData = {
        action: "approve_project_wise_single_day_timesheet",
        org_id: org_id,
        user_id: consultant_data.id, 
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        timesheet_date: timesheet_date,
        employee_name: employee_name,
        employee_email: employee_email,
      };
      await ApprovedSingleDayPushNotificationToEmployee(notificationData);
    }

    if (employee_email) {
      let emailData = {
        org_id: org_id,
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        timesheet_date: timesheet_date,
        employee_name: employee_name,
        employee_email: employee_email,
      };

      let user_id = consultant_data.id;
      let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

      if(is_email_reminder){
        await ApprovedSingleDayEmailToEmployee(emailData);
      }
    }

    // }

    returnMessage.isError = false;
    returnMessage.data = null;
    returnMessage.message = "Timesheet Approved Successfully";
    returnMessage.statuscode = 200;
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "approve_project_wise_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for approve_all_project_timesheets

const approve_all_project_timesheets = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = approveAllTimesheetsValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "approve_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheets = null,
    } = req.body;

    let ts_approver_id = req.user.id;
    let approved_response = 0;

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, ((timesheets && timesheets.length && timesheets[0].user_id) || null));
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let user_id =
        (timesheets && timesheets.length && timesheets[0].user_id) || null;

      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "approve_all_project_timesheets";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }

    if (timesheets && timesheets.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let { errors, isValid } = approveTimesheetValidator({
          ...timesheetsRow,
          org_id,
          week_start_date,
          week_end_date,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "approve_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      // check approver comments
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let {
          user_id = null,
          project_id = null,
          approver_notes: ts_approver_notes = null,
        } = timesheetsRow;

        // check last comment
        let check_timesheet_comment = await con.query(
          `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
          [
            org_id,
            project_id,
            week_start_date,
            week_end_date,
            TS_COMMENT_TYPE.WEEKLY,
            TS_COMMENT_USER_TYPE.APPROVER,
          ]
        );

        check_timesheet_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
          null;

        let last_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.id &&
            check_timesheet_comment.comments) ||
          null;

        if (!ts_approver_notes) {
          returnMessage.isError = true;
          returnMessage.message = "Comment not added";
          returnMessage.error = "approver_notes are requied";
          returnMessage.label = "approve_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];

        let {
          user_id = null,
          project_id = null,
          timesheet_data = null,
          approver_notes: ts_approver_notes = null,
        } = timesheetsRow;

        if (timesheet_data && timesheet_data.length) {
          // check last comment
          let check_timesheet_comment = await con.query(
            `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
            [
              org_id,
              project_id,
              week_start_date,
              week_end_date,
              TS_COMMENT_TYPE.WEEKLY,
              TS_COMMENT_USER_TYPE.APPROVER,
            ]
          );

          check_timesheet_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
            null;

          let last_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.id &&
              check_timesheet_comment.comments) ||
            null;

          if (!ts_approver_notes) {
            returnMessage.isError = true;
            returnMessage.message = "Comment not added";
            returnMessage.error = "approver_notes are requied";
            returnMessage.label = "approve_all_project_timesheets";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            return res.status(400).json(returnMessage);
          } else {
            let same_comment = false;
            if (last_comment && last_comment == ts_approver_notes) {
              same_comment = true;
            }

            // insert / update timesheet data
            for (var j = 0; j < timesheet_data.length; j++) {
              let tdRow = timesheet_data[j];
              let { timesheet_date = null } = tdRow;

              var tdate = `${timesheet_date}T00:00:00Z`;
              var day_name = moment(tdate).format("dddd");
              let status = TIMESHEET_STATUS.APPROVED;

              let timesheet_exists = await con.query(
                `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
                [org_id, project_id, timesheet_date]
              );

              timesheet_exists =
                (timesheet_exists &&
                  timesheet_exists.rows[0]
                    .get_single_timesheet_by_date_and_project_id &&
                  timesheet_exists.rows[0]
                    .get_single_timesheet_by_date_and_project_id[0]) ||
                null;

              if (timesheet_exists && timesheet_exists.id) {
                // update
                let timesheet_id = timesheet_exists.id;
                if (
                  [TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)
                ) {
                  status = TIMESHEET_STATUS.APPROVED;
                } else {
                  status = timesheet_exists.status;
                }

                var timesheetData = [
                  timesheet_id,
                  org_id,
                  user_id,
                  project_id,
                  year,
                  parseInt(month),
                  week_start_date,
                  week_end_date,
                  timesheet_date,
                  day_name,
                  timesheet_exists.regular_hours,
                  timesheet_exists.regular_minutes,
                  timesheet_exists.ot_hours,
                  timesheet_exists.ot_minutes,
                  timesheet_exists.absent_type,
                  timesheet_exists.absent_hours,
                  timesheet_exists.absent_minutes,
                  status,
                  timesheet_exists.user_notes,
                  ts_approver_id,
                  ts_approver_notes,
                  timesheet_exists.qb_timesheet_id,
                  timesheet_exists.qb_status,
                  updatedby,
                  record_type_status,
                ];

                let results = await con.query(
                  `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                  timesheetData
                );
                var update_data =
                  (results.rows &&
                    results.rows[1] &&
                    results.rows[1].update_timesheet &&
                    results.rows[1].update_timesheet[0]) ||
                  null;

                await InsertTimesheetHistory(org_id, update_data.id);
                await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

              }
            }

            let ts_status_data = null;
            let old_status_data = await con.query(
              `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
              [org_id, week_start_date, week_end_date, project_id]
            );

            old_status_data =
              (old_status_data &&
                old_status_data.rows[0]
                  .get_timesheet_status_by_week_and_project_id &&
                old_status_data.rows[0]
                  .get_timesheet_status_by_week_and_project_id[0]) ||
              null;

            if (old_status_data && old_status_data.id) {
              let statusData = {
                org_id: org_id,
                user_id: user_id,
                project_id: project_id,
                year: year,
                month: parseInt(month),
                week_start_date: week_start_date,
                week_end_date: week_end_date,
                client_manager_email: old_status_data.client_manager_email,
                client_manager_name: old_status_data.client_manager_name,
                user_notes: old_status_data.user_notes,
                approver_id: ts_approver_id,
                approver_notes: ts_approver_notes,
                createdby: createdby,
              };

              ts_status_data = await ResetTimesheetStatus(statusData);
            }

            // Insert approver note/comment
            if (
              ts_status_data &&
              ts_status_data.id &&
              ts_approver_notes &&
              !same_comment
            ) {
              let comment_type = TS_COMMENT_TYPE.WEEKLY;
              let user_type = TS_COMMENT_USER_TYPE.APPROVER;

              let tsCommentData = [
                org_id,
                comment_type,
                null,
                user_type,
                ts_approver_id,
                ts_approver_notes,
                ts_status_data.id,
                project_id,
                week_start_date,
                week_end_date,
                createdby,
                record_type_status,
              ];
              var result = await con.query(
                `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                tsCommentData
              );
            }

            approved_response++;
          }
        }
      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.APPROVED){

      let user_id =
        (timesheets && timesheets.length && timesheets[0].user_id) || null;
      // Send Timesheet Approved Email to employee
      let consultant_data = await con.query(
        `SELECT * from timesheets.get_user_by_id($1,$2)`,
        [user_id, org_id]
      );
      consultant_data =
        (consultant_data &&
          consultant_data.rows &&
          consultant_data.rows[0] &&
          consultant_data.rows[0].j &&
          consultant_data.rows[0].j[0]) ||
        null;

      let employee_name =
        (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";
      let week_range = `${week_start_date}-${week_end_date}`;

      if(consultant_data.id){
          
        // send push notification 
        let notificationData = {
          action: "approve_all_project_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
        };
        await ApprovedPushNotificationToEmployee(notificationData);
      }

      if (employee_email) {
        let emailData = {
          org_id: org_id,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
        };

        let user_id = consultant_data.id;
        let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

        if(is_email_reminder){
          await ApprovedEmailToEmployee(emailData);
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Approved Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheets" };
      returnMessage.label = "approve_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "approve_all_project_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_status_wise_emp_timesheet_by_month
const get_status_wise_emp_timesheet_by_month = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (req.query.status == undefined || req.query.status == "") {
      req.query.status = null;
    }

    let month = req.query.month?((req.query.month > 0)?(req.query.month - 1) : req.query.month): null;
    let year = req.query.year || null;      
    let month2d = req.query.month ? moment().month(month).format("MM") : moment().format("MM");
    year = year ? moment().year(year).format("YYYY") : moment().format("YYYY");
    let date = `${year}-${month2d}`;
    let months = moment(date, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").format("YYYY-MM-DD");

    let tmpMDate = moment(`${year}-${month2d}-01`, "YYYY-MM-DD");
    let monthName = tmpMDate.format("MMMM");

    await con.query(
      `SELECT * from timesheets.get_status_wise_emp_timesheet_by_month($1,$2,$3,$4)`,
      [req.user.org_id, year, month2d, req.query.status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_status_wise_emp_timesheet_by_month";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {

          results = (results.rows && results.rows[0] && results.rows[0].j) || null;
          
          // console.log("results", results)

          if (results && results.length) {

          for(var i = 0; i < results.length; i++){
            let row = results[i];
            let total_match = 0;
            let { user_id, week_start_date, week_end_date, ts_status } = row;

            let total_null = 0;
            let total_saved = 0;
            let total_submitted = 0;
            let total_approved = 0;
            let total_rejected = 0;
            let statusArr = [];
            let final_status = null;

            let total_reg_sec = 0;
            let total_ot_sec = 0;
            let total_sec = 0;
            for(var j = 0; j < results.length; j++){

              let jRow = results[j];

              if(jRow.user_id == user_id && jRow.week_start_date == week_start_date && jRow.week_end_date == week_end_date){
                total_match++;
                if(!jRow.ts_status){
                  total_null++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.SAVED){
                  total_saved++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.SUBMITTED){
                  total_submitted++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.APPROVED){
                  total_approved++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.REJECTED){
                  total_rejected++;
                }
              }

              if(jRow.user_id == user_id && jRow.week_start_date == week_start_date && jRow.week_end_date == week_end_date && jRow.total_hours_minutes && jRow.total_hours_minutes != '00:00:00'){
                
                regh_split = jRow.regular_hours_minutes.split(":") || null;
                oth_split = jRow.ot_hours_minutes.split(":") || null;
                th_split = jRow.total_hours_minutes.split(":") || null;
                
                let tmp_reg_hours = regh_split[0] || null;
                let tmp_reg_minutes = regh_split[1] || null;

                let tmp_ot_hours = oth_split[0] || null;
                let tmp_ot_minutes = oth_split[1] || null;

                let tmp_hours = th_split[0] || null;
                let tmp_minutes = th_split[1] || null;
                
                let reg_hours_sec = (tmp_reg_hours && tmp_reg_hours * 60 * 60) || 0;
                let reg_minutes_sec = (tmp_reg_minutes && tmp_reg_minutes * 60) || 0;

                let ot_hours_sec = (tmp_ot_hours && tmp_ot_hours * 60 * 60) || 0;
                let ot_minutes_sec = (tmp_ot_minutes && tmp_ot_minutes * 60) || 0;

                let total_hours_sec = (tmp_hours && tmp_hours * 60 * 60) || 0;
                let total_minutes_sec = (tmp_minutes && tmp_minutes * 60) || 0;

                total_reg_sec+= reg_hours_sec + reg_minutes_sec;
                total_ot_sec+= ot_hours_sec + ot_minutes_sec;
                total_sec+= total_hours_sec + total_minutes_sec;

              }
            }

            regular_hours_minutes = secondsToHm(total_reg_sec);
            ot_hours_minutes = secondsToHm(total_ot_sec);
            total_hours_minutes = secondsToHm(total_sec);

            results[i].regular_hours_minutes = regular_hours_minutes;
            results[i].ot_hours_minutes = ot_hours_minutes;
            results[i].total_hours_minutes = total_hours_minutes;

            if(total_rejected > 0){
              final_status = TIMESHEET_STATUS.REJECTED;
            }
            else if(total_submitted > 0){
              final_status = TIMESHEET_STATUS.SUBMITTED;
            }
            else if(total_approved > 0 && total_approved == ((total_match - total_saved) - (total_null))){
              final_status = TIMESHEET_STATUS.APPROVED;
            }
            else{
              final_status = TIMESHEET_STATUS.SAVED;
            }

            results[i].final_status = final_status;
          }

          for(var i = 0; i < results.length; i++){
            delete results[i].ts_status;
          }
          
            // console.log("results", results);
          seen = Object.create(null),
          unique_results = results.filter(o => {
            var key = ['user_id', 'week_start_date', 'week_end_date'].map(k => o[k]).join('|');
            if (!seen[key]) {
                seen[key] = true;
                return true;
            }
          });
          
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.monthName = monthName;
            returnMessage.year = year;
            returnMessage.data = unique_results;

            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_status_wise_emp_timesheet_by_month";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_status_wise_project_timesheet_by_month
const get_status_wise_project_timesheet_by_month = async (req, res) => {
  if (req.query.status == undefined || req.query.status == "") {
    req.query.status = null;
  }

  let month = req.query.month?((req.query.month > 0)?(req.query.month - 1) : req.query.month): null;
  let year = req.query.year || null;      
  let month2d = req.query.month ? moment().month(month).format("MM") : moment().format("MM");
  year = year ? moment().year(year).format("YYYY") : moment().format("YYYY");
  let date = `${year}-${month2d}`;
  let months = moment(date, "YYYY-MM");
  let month_start_date = moment(months).startOf("month").format("YYYY-MM-DD");
  let month_end_date = moment(months).endOf("month").format("YYYY-MM-DD");


  let tmpMDate = moment(`${year}-${month2d}-01`, "YYYY-MM-DD");
  let monthName = tmpMDate.format("MMMM");

  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_status_wise_project_timesheet_by_month($1,$2,$3,$4)`,
      [req.user.org_id, year, month2d, req.query.status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_status_wise_project_timesheet_by_month";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;
          if (results) {

            seen = Object.create(null),
            unique_results = results.filter(o => {
              var key = ['project_id', 'week_start_date', 'week_end_date'].map(k => o[k]).join('|');
              if (!seen[key]) {
                  seen[key] = true;
                  return true;
              }
            });
            
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.monthName = monthName;
            returnMessage.year = year;
            returnMessage.data = unique_results;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_status_wise_project_timesheet_by_month";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for reject_project_wise_timesheet

const reject_project_wise_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = rejectTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "reject_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_data = null,
      approver_notes: ts_approver_notes = null,
    } = req.body;

    let ts_approver_id = req.user.id;


    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "reject_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }

    if (timesheet_data && timesheet_data.length) {
      // check last comment
      let check_timesheet_comment = await con.query(
        `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
        [
          org_id,
          project_id,
          week_start_date,
          week_end_date,
          TS_COMMENT_TYPE.WEEKLY,
          TS_COMMENT_USER_TYPE.APPROVER,
        ]
      );

      check_timesheet_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
        null;

      let last_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.id &&
          check_timesheet_comment.comments) ||
        null;

      if (!ts_approver_notes) {
        returnMessage.isError = true;
        returnMessage.message = "Comment not added";
        returnMessage.error = "approver_notes are requied";
        returnMessage.label = "reject_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      } else {
        let same_comment = false;
        if (last_comment && last_comment == ts_approver_notes) {
          same_comment = true;
        }

        // insert / update timesheet data
        for (var i = 0; i < timesheet_data.length; i++) {
          let tdRow = timesheet_data[i];
          let {
            timesheet_date = null,
            approver_notes = null,
            approver_id = ts_approver_id,
          } = tdRow;

          if (timesheet_date) {
            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.REJECTED;

            let timesheet_exists = await con.query(
              `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
              [org_id, project_id, timesheet_date]
            );

            timesheet_exists =
              (timesheet_exists &&
                timesheet_exists.rows[0]
                  .get_single_timesheet_by_date_and_project_id &&
                timesheet_exists.rows[0]
                  .get_single_timesheet_by_date_and_project_id[0]) ||
              null;

            if (timesheet_exists && timesheet_exists.id) {
              // update
              let timesheet_id = timesheet_exists.id;
              if (
                [TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)
              ) {
                status = TIMESHEET_STATUS.REJECTED;
              } else {
                status = timesheet_exists.status;
              }

              var timesheetData = [
                timesheet_id,
                org_id,
                user_id,
                project_id,
                year,
                parseInt(month),
                week_start_date,
                week_end_date,
                timesheet_date,
                day_name,
                timesheet_exists.regular_hours,
                timesheet_exists.regular_minutes,
                timesheet_exists.ot_hours,
                timesheet_exists.ot_minutes,
                timesheet_exists.absent_type,
                timesheet_exists.absent_hours,
                timesheet_exists.absent_minutes,
                status,
                timesheet_exists.user_notes,
                ts_approver_id,
                ts_approver_notes,
                timesheet_exists.qb_timesheet_id,
                timesheet_exists.qb_status,
                updatedby,
                record_type_status,
              ];

              let results = await con.query(
                `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                timesheetData
              );
              var update_data =
                (results.rows &&
                  results.rows[1] &&
                  results.rows[1].update_timesheet &&
                  results.rows[1].update_timesheet[0]) ||
                null;

              await InsertTimesheetHistory(org_id, update_data.id);
              await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
            }
          }
        }

        let ts_status_data = null;
        let old_status_data = await con.query(
          `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
          [org_id, week_start_date, week_end_date, project_id]
        );

        old_status_data =
          (old_status_data &&
            old_status_data.rows[0]
              .get_timesheet_status_by_week_and_project_id &&
            old_status_data.rows[0]
              .get_timesheet_status_by_week_and_project_id[0]) ||
          null;

        if (old_status_data && old_status_data.id) {
          let statusData = {
            org_id: org_id,
            user_id: user_id,
            project_id: project_id,
            year: year,
            month: parseInt(month),
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            client_manager_email: old_status_data.client_manager_email,
            client_manager_name: old_status_data.client_manager_name,
            user_notes: old_status_data.user_notes,
            approver_id: ts_approver_id,
            approver_notes: ts_approver_notes,
            createdby: createdby,
          };

          ts_status_data = await ResetTimesheetStatus(statusData);
        }

        // Insert approver note/comment
        if (
          ts_status_data &&
          ts_status_data.id &&
          ts_approver_notes &&
          !same_comment
        ) {
          let comment_type = TS_COMMENT_TYPE.WEEKLY;
          let user_type = TS_COMMENT_USER_TYPE.APPROVER;

          let tsCommentData = [
            org_id,
            comment_type,
            null,
            user_type,
            ts_approver_id,
            ts_approver_notes,
            ts_status_data.id,
            project_id,
            week_start_date,
            week_end_date,
            createdby,
            record_type_status,
          ];
          var result = await con.query(
            `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
            tsCommentData
          );
        }

        // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.APPROVED){

        // Send Timesheet Approved Email to employee
        let consultant_data = await con.query(
          `SELECT * from timesheets.get_user_by_id($1,$2)`,
          [user_id, org_id]
        );
        consultant_data =
          (consultant_data &&
            consultant_data.rows &&
            consultant_data.rows[0] &&
            consultant_data.rows[0].j &&
            consultant_data.rows[0].j[0]) ||
          null;

        let employee_name =
          (consultant_data && consultant_data.full_name) || null;
        let employee_email = (consultant_data && consultant_data.email) || null;
        // let employee_email = "masood.m@msr-it.com";
        let week_range = `${week_start_date}-${week_end_date}`;

        if(consultant_data.id){
          
          // send push notification 
          let notificationData = {
            action: "reject_project_wise_timesheet",
            org_id: org_id,
            user_id: consultant_data.id, 
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            employee_name: employee_name,
            employee_email: employee_email,
          };
          await RejectedPushNotificationToEmployee(notificationData);
        }

        if (employee_email) {
          let emailData = {
            org_id: org_id,
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            employee_name: employee_name,
            employee_email: employee_email,
            approver_notes: ts_approver_notes,
          };

          let user_id = consultant_data.id;
          let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

          if(is_email_reminder){
            await RejectedEmailToEmployee(emailData);
          }
        }

        // }

        returnMessage.isError = false;
        returnMessage.data = null;
        returnMessage.message = "Timesheet Rejected Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet data" };
      returnMessage.label = "reject_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "reject_project_wise_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for reject_project_wise_single_day_timesheet

const reject_project_wise_single_day_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = rejectSingleDayTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "reject_project_wise_single_day_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_date = null,
      approver_notes: ts_approver_notes = null,
    } = req.body;

    let ts_approver_id = req.user.id;

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "reject_project_wise_single_day_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }

    // check last comment
    let check_timesheet_comment = await con.query(
      `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        project_id,
        week_start_date,
        week_end_date,
        TS_COMMENT_TYPE.WEEKLY,
        TS_COMMENT_USER_TYPE.APPROVER,
      ]
    );

    check_timesheet_comment =
      (check_timesheet_comment &&
        check_timesheet_comment.rows[0].get_last_timesheet_comment &&
        check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
      null;

    let last_comment =
      (check_timesheet_comment &&
        check_timesheet_comment.id &&
        check_timesheet_comment.comments) ||
      null;

    let same_comment = false;
    if (last_comment && last_comment == ts_approver_notes) {
      same_comment = true;
    }

    // insert / update timesheet data

    var tdate = `${timesheet_date}T00:00:00Z`;
    var day_name = moment(tdate).format("dddd");
    let status = TIMESHEET_STATUS.APPROVED;

    let timesheet_exists = await con.query(
      `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
      [org_id, project_id, timesheet_date]
    );

    timesheet_exists =
      (timesheet_exists &&
        timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id &&
        timesheet_exists.rows[0]
          .get_single_timesheet_by_date_and_project_id[0]) ||
      null;

    if (timesheet_exists && timesheet_exists.id) {
      // update
      let timesheet_id = timesheet_exists.id;
      if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
        status = TIMESHEET_STATUS.REJECTED;
      } else {
        status = timesheet_exists.status;
      }

      var timesheetData = [
        timesheet_id,
        org_id,
        user_id,
        project_id,
        year,
        parseInt(month),
        week_start_date,
        week_end_date,
        timesheet_date,
        day_name,
        timesheet_exists.regular_hours,
        timesheet_exists.regular_minutes,
        timesheet_exists.ot_hours,
        timesheet_exists.ot_minutes,
        timesheet_exists.absent_type,
        timesheet_exists.absent_hours,
        timesheet_exists.absent_minutes,
        status,
        timesheet_exists.user_notes,
        ts_approver_id,
        ts_approver_notes,
        timesheet_exists.qb_timesheet_id,
        timesheet_exists.qb_status,
        updatedby,
        record_type_status,
      ];

      let results = await con.query(
        `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
        timesheetData
      );
      var update_data =
        (results.rows &&
          results.rows[1] &&
          results.rows[1].update_timesheet &&
          results.rows[1].update_timesheet[0]) ||
        null;

      await InsertTimesheetHistory(org_id, update_data.id);
      await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

    }

    let ts_status_data = null;
    let old_status_data = await con.query(
      `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
      [org_id, week_start_date, week_end_date, project_id]
    );

    old_status_data =
      (old_status_data &&
        old_status_data.rows[0].get_timesheet_status_by_week_and_project_id &&
        old_status_data.rows[0]
          .get_timesheet_status_by_week_and_project_id[0]) ||
      null;

    if (old_status_data && old_status_data.id) {
      let statusData = {
        org_id: org_id,
        user_id: user_id,
        project_id: project_id,
        year: year,
        month: parseInt(month),
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        client_manager_email: old_status_data.client_manager_email,
        client_manager_name: old_status_data.client_manager_name,
        user_notes: old_status_data.user_notes,
        approver_id: ts_approver_id,
        approver_notes: old_status_data.approver_notes,
        createdby: createdby,
      };

      ts_status_data = await ResetTimesheetStatus(statusData);
    }

    // Insert approver note/comment
    if (
      ts_status_data &&
      ts_status_data.id &&
      ts_approver_notes &&
      !same_comment
    ) {
      let comment_type = TS_COMMENT_TYPE.DAILY;
      let user_type = TS_COMMENT_USER_TYPE.APPROVER;

      let tsCommentData = [
        org_id,
        comment_type,
        timesheet_date,
        user_type,
        ts_approver_id,
        ts_approver_notes,
        ts_status_data.id,
        project_id,
        week_start_date,
        week_end_date,
        createdby,
        record_type_status,
      ];
      var result = await con.query(
        `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        tsCommentData
      );
    }

    // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.REJECTED){

    // Send Timesheet Rejected Email to employee
    let consultant_data = await con.query(
      `SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]
    );
    consultant_data =
      (consultant_data &&
        consultant_data.rows &&
        consultant_data.rows[0] &&
        consultant_data.rows[0].j &&
        consultant_data.rows[0].j[0]) ||
      null;

    let employee_name = (consultant_data && consultant_data.full_name) || null;
    let employee_email = (consultant_data && consultant_data.email) || null;
    // let employee_email = "masood.m@msr-it.com";
    let week_range = `${week_start_date}-${week_end_date}`;

    if(consultant_data.id){
          
      // send push notification 
      let notificationData = {
        action: "reject_project_wise_single_day_timesheet",
        org_id: org_id,
        user_id: consultant_data.id, 
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        timesheet_date: timesheet_date,
        employee_name: employee_name,
        employee_email: employee_email,
      };
      await RejectedSingleDayPushNotificationToEmployee(notificationData);
    }
    
    if (employee_email) {
      let emailData = {
        org_id: org_id,
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        timesheet_date: timesheet_date,
        employee_name: employee_name,
        employee_email: employee_email,
        approver_notes: ts_approver_notes,
      };

      let user_id = consultant_data.id;
      let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

      if(is_email_reminder){
        await RejectedSingleDayEmailToEmployee(emailData);
      }
    }

    // }

    returnMessage.isError = false;
    returnMessage.data = null;
    returnMessage.message = "Timesheet Rejected Successfully";
    returnMessage.statuscode = 200;
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "reject_project_wise_single_day_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for reject_all_project_timesheets

const reject_all_project_timesheets = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = rejectAllTimesheetsValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "reject_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheets = null,
    } = req.body;

    let ts_approver_id = req.user.id;
    let rejected_response = 0;

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, ((timesheets && timesheets.length && timesheets[0].user_id) || null));
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let user_id =
        (timesheets && timesheets.length && timesheets[0].user_id) || null;

      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "reject_all_project_timesheets";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }
    
    if (timesheets && timesheets.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let { errors, isValid } = rejectTimesheetValidator({
          ...timesheetsRow,
          org_id,
          week_start_date,
          week_end_date,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "reject_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      // check approver comments
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let {
          user_id = null,
          project_id = null,
          approver_notes: ts_approver_notes = null,
        } = timesheetsRow;

        // check last comment
        let check_timesheet_comment = await con.query(
          `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
          [
            org_id,
            project_id,
            week_start_date,
            week_end_date,
            TS_COMMENT_TYPE.WEEKLY,
            TS_COMMENT_USER_TYPE.APPROVER,
          ]
        );

        check_timesheet_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
          null;

        let last_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.id &&
            check_timesheet_comment.comments) ||
          null;

        if (!ts_approver_notes) {
          returnMessage.isError = true;
          returnMessage.message = "Comment not added";
          returnMessage.error = "approver_notes are requied";
          returnMessage.label = "reject_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];

        let {
          user_id = null,
          project_id = null,
          timesheet_data = null,
          approver_notes: ts_approver_notes = null,
        } = timesheetsRow;

        if (timesheet_data && timesheet_data.length) {
          // check last comment
          let check_timesheet_comment = await con.query(
            `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
            [
              org_id,
              project_id,
              week_start_date,
              week_end_date,
              TS_COMMENT_TYPE.WEEKLY,
              TS_COMMENT_USER_TYPE.APPROVER,
            ]
          );

          check_timesheet_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
            null;

          let last_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.id &&
              check_timesheet_comment.comments) ||
            null;

          if (!ts_approver_notes) {
            returnMessage.isError = true;
            returnMessage.message = "Comment not added";
            returnMessage.error = "approver_notes are requied";
            returnMessage.label = "reject_all_project_timesheets";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            return res.status(400).json(returnMessage);
          } else {
            let same_comment = false;
            if (last_comment && last_comment == ts_approver_notes) {
              same_comment = true;
            }

            // insert / update timesheet data
            for (var j = 0; j < timesheet_data.length; j++) {
              let tdRow = timesheet_data[j];
              let { timesheet_date = null } = tdRow;

              if (timesheet_date) {
                var tdate = `${timesheet_date}T00:00:00Z`;
                var day_name = moment(tdate).format("dddd");
                let status = TIMESHEET_STATUS.REJECTED;

                let timesheet_exists = await con.query(
                  `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
                  [org_id, project_id, timesheet_date]
                );

                timesheet_exists =
                  (timesheet_exists &&
                    timesheet_exists.rows[0]
                      .get_single_timesheet_by_date_and_project_id &&
                    timesheet_exists.rows[0]
                      .get_single_timesheet_by_date_and_project_id[0]) ||
                  null;

                if (timesheet_exists && timesheet_exists.id) {
                  // update
                  let timesheet_id = timesheet_exists.id;
                  if (
                    [TIMESHEET_STATUS.SUBMITTED].includes(
                      timesheet_exists.status
                    )
                  ) {
                    status = TIMESHEET_STATUS.REJECTED;
                  } else {
                    status = timesheet_exists.status;
                  }

                  var timesheetData = [
                    timesheet_id,
                    org_id,
                    user_id,
                    project_id,
                    year,
                    parseInt(month),
                    week_start_date,
                    week_end_date,
                    timesheet_date,
                    day_name,
                    timesheet_exists.regular_hours,
                    timesheet_exists.regular_minutes,
                    timesheet_exists.ot_hours,
                    timesheet_exists.ot_minutes,
                    timesheet_exists.absent_type,
                    timesheet_exists.absent_hours,
                    timesheet_exists.absent_minutes,
                    status,
                    timesheet_exists.user_notes,
                    ts_approver_id,
                    ts_approver_notes,
                    timesheet_exists.qb_timesheet_id,
                    timesheet_exists.qb_status,
                    updatedby,
                    record_type_status,
                  ];

                  let results = await con.query(
                    `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                    timesheetData
                  );
                  var update_data =
                    (results.rows &&
                      results.rows[1] &&
                      results.rows[1].update_timesheet &&
                      results.rows[1].update_timesheet[0]) ||
                    null;

                  await InsertTimesheetHistory(org_id, update_data.id);
                  await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
                }
              }
            }

            let ts_status_data = null;
            let old_status_data = await con.query(
              `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
              [org_id, week_start_date, week_end_date, project_id]
            );

            old_status_data =
              (old_status_data &&
                old_status_data.rows[0]
                  .get_timesheet_status_by_week_and_project_id &&
                old_status_data.rows[0]
                  .get_timesheet_status_by_week_and_project_id[0]) ||
              null;

            if (old_status_data && old_status_data.id) {
              let statusData = {
                org_id: org_id,
                user_id: user_id,
                project_id: project_id,
                year: year,
                month: parseInt(month),
                week_start_date: week_start_date,
                week_end_date: week_end_date,
                client_manager_email: old_status_data.client_manager_email,
                client_manager_name: old_status_data.client_manager_name,
                user_notes: old_status_data.user_notes,
                approver_id: ts_approver_id,
                approver_notes: ts_approver_notes,
                createdby: createdby,
              };

              ts_status_data = await ResetTimesheetStatus(statusData);
            }

            // Insert approver note/comment
            if (
              ts_status_data &&
              ts_status_data.id &&
              ts_approver_notes &&
              !same_comment
            ) {
              let comment_type = TS_COMMENT_TYPE.WEEKLY;
              let user_type = TS_COMMENT_USER_TYPE.APPROVER;

              let tsCommentData = [
                org_id,
                comment_type,
                null,
                user_type,
                ts_approver_id,
                ts_approver_notes,
                ts_status_data.id,
                project_id,
                week_start_date,
                week_end_date,
                createdby,
                record_type_status,
              ];
              var result = await con.query(
                `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                tsCommentData
              );
            }

            rejected_response++;
          }
        }
      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.REJECTED){

      let user_id =
        (timesheets && timesheets.length && timesheets[0].user_id) || null;
      // Send Timesheet Rejected Email to employee
      let consultant_data = await con.query(
        `SELECT * from timesheets.get_user_by_id($1,$2)`,
        [user_id, org_id]
      );
      consultant_data =
        (consultant_data &&
          consultant_data.rows &&
          consultant_data.rows[0] &&
          consultant_data.rows[0].j &&
          consultant_data.rows[0].j[0]) ||
        null;

      let employee_name =
        (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";
      let week_range = `${week_start_date}-${week_end_date}`;

      if(consultant_data.id){
          
        // send push notification 
        let notificationData = {
          action: "reject_all_project_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
        };
        await RejectedPushNotificationToEmployee(notificationData);
      }

      if (employee_email) {
        let emailData = {
          org_id: org_id,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes:
            (timesheets && timesheets.length && timesheets[0].approver_notes) ||
            ``,
        };

        let user_id = consultant_data.id;
        let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

        if(is_email_reminder){
          await RejectedEmailToEmployee(emailData);
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Rejected Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheets" };
      returnMessage.label = "reject_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "reject_all_project_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// ||=================== REVERT APIs ===================||

// api for revert_project_wise_single_day_timesheet
const revert_project_wise_single_day_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = revertSingleDayTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "revert_project_wise_single_day_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_date = null,
      approver_notes: ts_approver_notes = null,
    } = req.body;

    let ts_approver_id = req.user.id;

    // check last comment
    let check_timesheet_comment = await con.query(
      `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        project_id,
        week_start_date,
        week_end_date,
        TS_COMMENT_TYPE.WEEKLY,
        TS_COMMENT_USER_TYPE.APPROVER,
      ]
    );

    check_timesheet_comment =
      (check_timesheet_comment &&
        check_timesheet_comment.rows[0].get_last_timesheet_comment &&
        check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
      null;

    let last_comment =
      (check_timesheet_comment &&
        check_timesheet_comment.id &&
        check_timesheet_comment.comments) ||
      null;

    let same_comment = false;
    if (last_comment && last_comment == ts_approver_notes) {
      same_comment = true;
    }

    // insert / update timesheet data

    var tdate = `${timesheet_date}T00:00:00Z`;
    var day_name = moment(tdate).format("dddd");
    let status = TIMESHEET_STATUS.SUBMITTED;

    let timesheet_exists = await con.query(
      `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
      [org_id, project_id, timesheet_date]
    );

    timesheet_exists =
      (timesheet_exists &&
        timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id &&
        timesheet_exists.rows[0]
          .get_single_timesheet_by_date_and_project_id[0]) ||
      null;

    if (timesheet_exists && timesheet_exists.id) {
      // update
      let timesheet_id = timesheet_exists.id;
      if (
        [TIMESHEET_STATUS.APPROVED, TIMESHEET_STATUS.REJECTED].includes(
          timesheet_exists.status
        )
      ) {
        status = TIMESHEET_STATUS.SUBMITTED;
      } else {
        status = timesheet_exists.status;
      }

      var timesheetData = [
        timesheet_id,
        org_id,
        user_id,
        project_id,
        year,
        parseInt(month),
        week_start_date,
        week_end_date,
        timesheet_date,
        day_name,
        timesheet_exists.regular_hours,
        timesheet_exists.regular_minutes,
        timesheet_exists.ot_hours,
        timesheet_exists.ot_minutes,
        timesheet_exists.absent_type,
        timesheet_exists.absent_hours,
        timesheet_exists.absent_minutes,
        status,
        timesheet_exists.user_notes,
        ts_approver_id,
        ts_approver_notes,
        timesheet_exists.qb_timesheet_id,
        timesheet_exists.qb_status,
        updatedby,
        record_type_status,
      ];

      let results = await con.query(
        `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
        timesheetData
      );
      var update_data =
        (results.rows &&
          results.rows[1] &&
          results.rows[1].update_timesheet &&
          results.rows[1].update_timesheet[0]) ||
        null;

      await InsertTimesheetHistory(org_id, update_data.id, true);
      await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
    }

    let ts_status_data = null;
    let old_status_data = await con.query(
      `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
      [org_id, week_start_date, week_end_date, project_id]
    );

    old_status_data =
      (old_status_data &&
        old_status_data.rows[0].get_timesheet_status_by_week_and_project_id &&
        old_status_data.rows[0]
          .get_timesheet_status_by_week_and_project_id[0]) ||
      null;

    if (old_status_data && old_status_data.id) {
      let statusData = {
        org_id: org_id,
        user_id: user_id,
        project_id: project_id,
        year: year,
        month: parseInt(month),
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        client_manager_email: old_status_data.client_manager_email,
        client_manager_name: old_status_data.client_manager_name,
        user_notes: old_status_data.user_notes,
        approver_id: ts_approver_id,
        approver_notes: old_status_data.approver_notes,
        createdby: createdby,
      };

      ts_status_data = await ResetTimesheetStatus(statusData, true);
    }

    // Insert approver note/comment
    if (
      ts_status_data &&
      ts_status_data.id &&
      ts_approver_notes &&
      !same_comment
    ) {
      let comment_type = TS_COMMENT_TYPE.DAILY;
      let user_type = TS_COMMENT_USER_TYPE.APPROVER;

      let tsCommentData = [
        org_id,
        comment_type,
        timesheet_date,
        user_type,
        ts_approver_id,
        ts_approver_notes,
        ts_status_data.id,
        project_id,
        week_start_date,
        week_end_date,
        createdby,
        record_type_status,
      ];
      var result = await con.query(
        `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        tsCommentData
      );
    }

    let consultant_data = await con.query(
      `SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]
    );
    consultant_data =
      (consultant_data &&
        consultant_data.rows &&
        consultant_data.rows[0] &&
        consultant_data.rows[0].j &&
        consultant_data.rows[0].j[0]) ||
      null;

    let employee_name = (consultant_data && consultant_data.full_name) || null;
    let employee_email = (consultant_data && consultant_data.email) || null;
    // let employee_email = "masood.m@msr-it.com";
    let week_range = `${week_start_date}-${week_end_date}`;

    if(consultant_data.id){
          
      // send push notification 
      let notificationData = {
        action: "revert_project_wise_single_day_timesheet",
        org_id: org_id,
        user_id: consultant_data.id, 
        week_start_date: week_start_date,
        week_end_date: week_end_date,
        timesheet_date: timesheet_date,
        employee_name: employee_name,
        employee_email: employee_email,
      };
      await RevertedSingleDayPushNotificationToEmployee(notificationData);
    }

    returnMessage.isError = false;
    returnMessage.data = null;
    returnMessage.message = "Timesheet Reverted Successfully";
    returnMessage.statuscode = 200;
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "revert_project_wise_single_day_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for revert_project_wise_timesheet
const revert_project_wise_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = revertTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "revert_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_data = null,
      approver_notes: ts_approver_notes = null,
    } = req.body;

    let ts_approver_id = req.user.id;

    if (timesheet_data && timesheet_data.length) {
      // check last comment
      let check_timesheet_comment = await con.query(
        `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
        [
          org_id,
          project_id,
          week_start_date,
          week_end_date,
          TS_COMMENT_TYPE.WEEKLY,
          TS_COMMENT_USER_TYPE.APPROVER,
        ]
      );

      check_timesheet_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment &&
          check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
        null;

      let last_comment =
        (check_timesheet_comment &&
          check_timesheet_comment.id &&
          check_timesheet_comment.comments) ||
        null;

      if (!ts_approver_notes) {
        returnMessage.isError = true;
        returnMessage.message = "Comment not added";
        returnMessage.error = "approver_notes are requied";
        returnMessage.label = "revert_project_wise_timesheet";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      } else {
        let same_comment = false;
        if (last_comment && last_comment == ts_approver_notes) {
          same_comment = true;
        }

        // insert / update timesheet data
        for (var i = 0; i < timesheet_data.length; i++) {
          let tdRow = timesheet_data[i];
          let {
            timesheet_date = null,
            approver_notes = null,
            approver_id = ts_approver_id,
          } = tdRow;

          var tdate = `${timesheet_date}T00:00:00Z`;
          var day_name = moment(tdate).format("dddd");
          let status = TIMESHEET_STATUS.SUBMITTED;

          let timesheet_exists = await con.query(
            `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
            [org_id, project_id, timesheet_date]
          );

          timesheet_exists =
            (timesheet_exists &&
              timesheet_exists.rows[0]
                .get_single_timesheet_by_date_and_project_id &&
              timesheet_exists.rows[0]
                .get_single_timesheet_by_date_and_project_id[0]) ||
            null;

          if (timesheet_exists && timesheet_exists.id) {
            // update
            let timesheet_id = timesheet_exists.id;
            if (
              [TIMESHEET_STATUS.APPROVED, TIMESHEET_STATUS.REJECTED].includes(
                timesheet_exists.status
              )
            ) {
              status = TIMESHEET_STATUS.SUBMITTED;
            } else {
              status = timesheet_exists.status;
            }
            var timesheetData = [
              timesheet_id,
              org_id,
              user_id,
              project_id,
              year,
              parseInt(month),
              week_start_date,
              week_end_date,
              timesheet_date,
              day_name,
              timesheet_exists.regular_hours,
              timesheet_exists.regular_minutes,
              timesheet_exists.ot_hours,
              timesheet_exists.ot_minutes,
              timesheet_exists.absent_type,
              timesheet_exists.absent_hours,
              timesheet_exists.absent_minutes,
              status,
              timesheet_exists.user_notes,
              ts_approver_id,
              ts_approver_notes,
              timesheet_exists.qb_timesheet_id,
              timesheet_exists.qb_status,
              updatedby,
              record_type_status,
            ];

            let results = await con.query(
              `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
              timesheetData
            );
            var update_data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].update_timesheet &&
                results.rows[1].update_timesheet[0]) ||
              null;

            await InsertTimesheetHistory(org_id, update_data.id, true);
            await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

          }
        }

        let ts_status_data = null;
        let old_status_data = await con.query(
          `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
          [org_id, week_start_date, week_end_date, project_id]
        );

        old_status_data =
          (old_status_data &&
            old_status_data.rows[0]
              .get_timesheet_status_by_week_and_project_id &&
            old_status_data.rows[0]
              .get_timesheet_status_by_week_and_project_id[0]) ||
          null;

        if (old_status_data && old_status_data.id) {
          let statusData = {
            org_id: org_id,
            user_id: user_id,
            project_id: project_id,
            year: year,
            month: parseInt(month),
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            client_manager_email: old_status_data.client_manager_email,
            client_manager_name: old_status_data.client_manager_name,
            user_notes: old_status_data.user_notes,
            approver_id: ts_approver_id,
            approver_notes: ts_approver_notes,
            createdby: createdby,
          };

          ts_status_data = await ResetTimesheetStatus(statusData, true);
        }

        // Insert approver note/comment
        if (
          ts_status_data &&
          ts_status_data.id &&
          ts_approver_notes &&
          !same_comment
        ) {
          let comment_type = TS_COMMENT_TYPE.WEEKLY;
          let user_type = TS_COMMENT_USER_TYPE.APPROVER;

          let tsCommentData = [
            org_id,
            comment_type,
            null,
            user_type,
            ts_approver_id,
            ts_approver_notes,
            ts_status_data.id,
            project_id,
            week_start_date,
            week_end_date,
            createdby,
            record_type_status,
          ];
          var result = await con.query(
            `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
            tsCommentData
          );
        }

        ///////////////Send Push Notifications ////////////////
        let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`, [user_id, org_id]);
        consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

        let employee_name = (consultant_data && consultant_data.full_name) || null;
        let employee_email = (consultant_data && consultant_data.email) || null;
        let week_range = `${week_start_date}-${week_end_date}`;

        if(consultant_data.id){
          
          // send push notification 
          let notificationData = {
            action: "revert_project_wise_timesheet",
            org_id: org_id,
            user_id: consultant_data.id, 
            week_start_date: week_start_date,
            week_end_date: week_end_date,
            employee_name: employee_name,
            employee_email: employee_email,
          };
          await RevertedPushNotificationToEmployee(notificationData);
        }
        //////////////////////////////////////////

        returnMessage.isError = false;
        returnMessage.data = null;
        returnMessage.message = "Timesheet Reverted Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet data" };
      returnMessage.label = "revert_project_wise_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "revert_project_wise_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for revert_all_project_timesheets

const revert_all_project_timesheets = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;

    const { errors, isValid } = revertAllTimesheetsValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "revert_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheets = null,
    } = req.body;

    let ts_approver_id = req.user.id;
    let approved_response = 0;

    if (timesheets && timesheets.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let { errors, isValid } = approveTimesheetValidator({
          ...timesheetsRow,
          org_id,
          week_start_date,
          week_end_date,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "revert_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      // check approver comments
      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];
        let {
          user_id = null,
          project_id = null,
          approver_notes: ts_approver_notes = null,
        } = timesheetsRow;

        // check last comment
        let check_timesheet_comment = await con.query(
          `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
          [
            org_id,
            project_id,
            week_start_date,
            week_end_date,
            TS_COMMENT_TYPE.WEEKLY,
            TS_COMMENT_USER_TYPE.APPROVER,
          ]
        );

        check_timesheet_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment &&
            check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
          null;

        let last_comment =
          (check_timesheet_comment &&
            check_timesheet_comment.id &&
            check_timesheet_comment.comments) ||
          null;

        if (!ts_approver_notes) {
          returnMessage.isError = true;
          returnMessage.message = "Comment not added";
          returnMessage.error = "approver_notes are requied";
          returnMessage.label = "revert_all_project_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      for (let i = 0; i < timesheets.length; i++) {
        let timesheetsRow = timesheets[i];

        let {
          user_id = null,
          project_id = null,
          timesheet_data = null,
          approver_notes: ts_approver_notes = null,
        } = timesheetsRow;

        if (timesheet_data && timesheet_data.length) {
          // check last comment
          let check_timesheet_comment = await con.query(
            `SELECT timesheets.get_last_timesheet_comment($1,$2,$3,$4,$5,$6)`,
            [
              org_id,
              project_id,
              week_start_date,
              week_end_date,
              TS_COMMENT_TYPE.WEEKLY,
              TS_COMMENT_USER_TYPE.APPROVER,
            ]
          );

          check_timesheet_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment &&
              check_timesheet_comment.rows[0].get_last_timesheet_comment[0]) ||
            null;

          let last_comment =
            (check_timesheet_comment &&
              check_timesheet_comment.id &&
              check_timesheet_comment.comments) ||
            null;

          if (!ts_approver_notes) {
            returnMessage.isError = true;
            returnMessage.message = "Comment not added";
            returnMessage.error = "approver_notes are requied";
            returnMessage.label = "revert_all_project_timesheets";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            return res.status(400).json(returnMessage);
          } else {
            let same_comment = false;
            if (last_comment && last_comment == ts_approver_notes) {
              same_comment = true;
            }

            // insert / update timesheet data
            for (var j = 0; j < timesheet_data.length; j++) {
              let tdRow = timesheet_data[j];
              let { timesheet_date = null } = tdRow;

              var tdate = `${timesheet_date}T00:00:00Z`;
              var day_name = moment(tdate).format("dddd");
              let status = TIMESHEET_STATUS.SUBMITTED;

              let timesheet_exists = await con.query(
                `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
                [org_id, project_id, timesheet_date]
              );

              timesheet_exists =
                (timesheet_exists &&
                  timesheet_exists.rows[0]
                    .get_single_timesheet_by_date_and_project_id &&
                  timesheet_exists.rows[0]
                    .get_single_timesheet_by_date_and_project_id[0]) ||
                null;

              if (timesheet_exists && timesheet_exists.id) {
                // update
                let timesheet_id = timesheet_exists.id;
                if (
                  [
                    TIMESHEET_STATUS.APPROVED,
                    TIMESHEET_STATUS.REJECTED,
                  ].includes(timesheet_exists.status)
                ) {
                  status = TIMESHEET_STATUS.SUBMITTED;
                } else {
                  status = timesheet_exists.status;
                }

                var timesheetData = [
                  timesheet_id,
                  org_id,
                  user_id,
                  project_id,
                  year,
                  parseInt(month),
                  week_start_date,
                  week_end_date,
                  timesheet_date,
                  day_name,
                  timesheet_exists.regular_hours,
                  timesheet_exists.regular_minutes,
                  timesheet_exists.ot_hours,
                  timesheet_exists.ot_minutes,
                  timesheet_exists.absent_type,
                  timesheet_exists.absent_hours,
                  timesheet_exists.absent_minutes,
                  status,
                  timesheet_exists.user_notes,
                  ts_approver_id,
                  ts_approver_notes,
                  timesheet_exists.qb_timesheet_id,
                  timesheet_exists.qb_status,
                  updatedby,
                  record_type_status,
                ];

                let results = await con.query(
                  `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                  timesheetData
                );
                var update_data =
                  (results.rows &&
                    results.rows[1] &&
                    results.rows[1].update_timesheet &&
                    results.rows[1].update_timesheet[0]) ||
                  null;

                await InsertTimesheetHistory(org_id, update_data.id, true);
                await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);

              }
            }

            let ts_status_data = null;
            let old_status_data = await con.query(
              `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
              [org_id, week_start_date, week_end_date, project_id]
            );

            old_status_data =
              (old_status_data &&
                old_status_data.rows[0]
                  .get_timesheet_status_by_week_and_project_id &&
                old_status_data.rows[0]
                  .get_timesheet_status_by_week_and_project_id[0]) ||
              null;

            if (old_status_data && old_status_data.id) {
              let statusData = {
                org_id: org_id,
                user_id: user_id,
                project_id: project_id,
                year: year,
                month: parseInt(month),
                week_start_date: week_start_date,
                week_end_date: week_end_date,
                client_manager_email: old_status_data.client_manager_email,
                client_manager_name: old_status_data.client_manager_name,
                user_notes: old_status_data.user_notes,
                approver_id: ts_approver_id,
                approver_notes: ts_approver_notes,
                createdby: createdby,
              };

              ts_status_data = await ResetTimesheetStatus(statusData, true);
            }

            // Insert approver note/comment
            if (
              ts_status_data &&
              ts_status_data.id &&
              ts_approver_notes &&
              !same_comment
            ) {
              let comment_type = TS_COMMENT_TYPE.WEEKLY;
              let user_type = TS_COMMENT_USER_TYPE.APPROVER;

              let tsCommentData = [
                org_id,
                comment_type,
                null,
                user_type,
                ts_approver_id,
                ts_approver_notes,
                ts_status_data.id,
                project_id,
                week_start_date,
                week_end_date,
                createdby,
                record_type_status,
              ];
              var result = await con.query(
                `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                tsCommentData
              );
            }

            approved_response++;
          }
        }
      }

      ///////////////Send Push Notifications ////////////////
      
      let user_id = (timesheets && timesheets.length && timesheets[0].user_id) || null;
      
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`, [user_id, org_id]);
      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      let week_range = `${week_start_date}-${week_end_date}`;

      if(consultant_data.id){
        
        // send push notification 
        let notificationData = {
          action: "revert_all_project_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
        };
        await RevertedPushNotificationToEmployee(notificationData);
      }
      //////////////////////////////////////////

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Reverted Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheets" };
      returnMessage.label = "revert_all_project_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "revert_all_project_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_day_and_dates_by_week

const get_day_and_dates_by_week = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;
    let week_start_date = req.query.week_start_date;
    let week_end_date = req.query.week_end_date;

    let tmp_start_date = `${week_start_date}T00:00:00Z`;
    let tmp_end_date = `${week_end_date}T00:00:00Z`;

    let range = moment().range(moment(tmp_start_date), moment(tmp_end_date));

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    if (dates && dates.length) {
      let dates_data = {};
      for (var i = 0; i < dates.length; i++) {
        let timesheet_date = dates[i];
        var tdate = `${timesheet_date}T00:00:00Z`;
        var day_name = moment(tdate).format("dddd");
        dates_data[`${timesheet_date}`] = day_name
      }

      returnMessage.isError = false;
      returnMessage.data = dates_data;
      returnMessage.message = "Timesheet Dates Fetched Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
      
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error =
        "Please provide correct week_start_date and week_end_date";
      returnMessage.label = "get_day_and_dates_by_week";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_day_and_dates_by_week";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for send_project_wise_timesheet_to_qb

const send_project_wise_timesheet_to_qb = async (req, res) => {

  const returnMessage = getMsgFormat();

  try {
    
    let org_id = req.user.org_id;

    let is_qb_transaction_on = await isQBTransactionOn(org_id, "send_project_wise_timesheet_to_qb");
    if(is_qb_transaction_on) {

    var qbo = await qbodata(org_id);
    const { errors, isValid } = quickBooksTimesheetValidator({ ...req.body, org_id, });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "send_project_wise_timesheet_to_qb";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      year = null,
      month = null,
      week_start_date = null,
      week_end_date = null,
      timesheet_data = null,
      user_notes: ts_user_notes = null,
      approver_id: ts_approver_id = null,
      approver_notes: ts_approver_notes = null,
      client_manager_email = null,
      client_manager_name = null,
    } = req.body;

    if (timesheet_data && timesheet_data.length) {
      
        // insert / update timesheet data
        for (var i = 0; i < timesheet_data.length; i++) {
          let tdRow = timesheet_data[i];
          let {
            timesheet_date = null,
            // status = "SAVED",
            qb_timesheet_id = null,
            qb_status = null,
            bill_rate = 0, 
            pay_rate = 0
          } = tdRow;


          var tdate = `${timesheet_date}T00:00:00Z`;
          var day_name = moment(tdate).format("dddd");

          pay_rate = (pay_rate && parseFloat(pay_rate).toFixed(2)) || 0.00;

          let timesheet_exists = await con.query(
            `SELECT timesheets.get_single_timesheet_by_date_and_project_id($1,$2,$3)`,
            [org_id, project_id, timesheet_date]
          );

          timesheet_exists = (timesheet_exists && timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id && timesheet_exists.rows[0].get_single_timesheet_by_date_and_project_id[0]) || null;

          if (timesheet_exists && timesheet_exists.id) {

            let timesheet_id = timesheet_exists.id;
            let total_sec = 0;
            regular_hours = (timesheet_exists.regular_hours && timesheet_exists.regular_hours * 60 * 60) || 0;
            regular_minutes = (timesheet_exists.regular_minutes && timesheet_exists.regular_minutes * 60) || 0; 
            ot_hours = (timesheet_exists.ot_hours && timesheet_exists.ot_hours * 60 * 60) || 0;
            ot_minutes = (timesheet_exists.ot_minutes && timesheet_exists.ot_minutes * 60) || 0;
                        
            total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
            total_hours_minutes = secondsToHm(total_sec);
            total_hours_minutes_split = total_hours_minutes.split(":");
            total_hours = (total_hours_minutes_split && total_hours_minutes_split[0])?total_hours_minutes_split[0]: 0;
            total_minutes = (total_hours_minutes_split && total_hours_minutes_split[1])?total_hours_minutes_split[1]: 0;
            
            let quickbooks_info = await con.query(
              `SELECT timesheets.get_quickbooks_info_by_project_id($1,$2)`,
              [org_id, project_id]
            );
            quickbooks_info = (quickbooks_info && quickbooks_info.rows[0].get_quickbooks_info_by_project_id && quickbooks_info.rows[0].get_quickbooks_info_by_project_id[0]) || null;

            if(quickbooks_info.qb_employee_id && quickbooks_info.qb_customer_id){

              let data = {
                TxnDate: timesheet_exists.timesheet_date,
                NameOf: "Employee",
                EmployeeRef: {
                  value: parseInt(quickbooks_info.qb_employee_id) || null,
                  name: quickbooks_info.qb_employee_name,
                },
                CustomerRef: {
                  value: parseInt(quickbooks_info.qb_customer_id) || null,
                  name: quickbooks_info.qb_customer_name,
                },
                ItemRef: {
                  value: parseInt(quickbooks_info.qb_product_id) || null,
                  name: quickbooks_info.qb_product_name,
                },
                // ItemRef: {
                //   value: parseInt(total_hours) || 0,
                //   name: "Hours",
                // },
                // BillableStatus: "Billable", // HourlyRate will be 0 if BillableStatus is not set as 'Billable'
                HourlyRate: pay_rate,
                Hours: parseInt(total_hours) || 0,
                Minutes: parseInt(total_minutes) || 0,
                Description: ts_approver_notes,
              };
              
              let timeactivity = null;
              if(qb_timesheet_id){
  
                data.Id = qb_timesheet_id.toString();
                data.SyncToken = 0;
  
                let old_timeactivity = await new Promise((resolve, reject) => {
                  qbo.findTimeActivities({ id: data.Id }, async (e, timeactivity) => {
                      if (e) {
                        
                        let api_name = 'findTimeActivities';
                        let request_data = JSON.stringify({ id: data.Id });
                        let response_data = JSON.stringify(e);
                        let request_status = "FAILED";
                        let qbData = { api_name, request_data, response_data, request_status, createdby };
                        await InsertQuickBooksLog(org_id, qbData);
  
                        return reject(e);
                      }
                      else{
  
                        let api_name = 'findTimeActivities';
                        let request_data = JSON.stringify({ id: data.Id });
                        let response_data = JSON.stringify(timeactivity);
                        let request_status = "SUCCESS";
                        let qbData = { api_name, request_data, response_data, request_status, createdby };
                        await InsertQuickBooksLog(org_id, qbData);
  
                        resolve(timeactivity);
                      }
                  });
                });

                
                                
                data.SyncToken = (old_timeactivity && old_timeactivity.QueryResponse && old_timeactivity.QueryResponse.TimeActivity && old_timeactivity.QueryResponse.TimeActivity[0] && old_timeactivity.QueryResponse.TimeActivity[0].SyncToken) || 0;
  
                timeactivity = await new Promise((resolve, reject) => {
                  
                  qbo.updateTimeActivity(data, async (e, timeactivity) => {
                      if (e) {
  
                        let api_name = 'updateTimeActivity';
                        let request_data = JSON.stringify(data);
                        let response_data = JSON.stringify(e);
                        let request_status = "FAILED";
                        let qbData = { api_name, request_data, response_data, request_status, createdby };
                        await InsertQuickBooksLog(org_id, qbData);
  
                        return reject(e);
                      }
                      else{
  
                        let api_name = 'updateTimeActivity';
                        let request_data = JSON.stringify(data);
                        let response_data = JSON.stringify(timeactivity);
                        let request_status = "SUCCESS";
                        let qbData = { api_name, request_data, response_data, request_status, createdby };
                        await InsertQuickBooksLog(org_id, qbData);
  
                        console.log("response_dataresponse_data", response_data)

                        resolve(timeactivity);
                      }
                  });
                });
                
              }
              else{
                timeactivity = await new Promise((resolve, reject) => {
                  qbo.createTimeActivity(data, async (e, timeactivity) => {
                      if (e) {
  
                        let api_name = 'createTimeActivity';
                        let request_data = JSON.stringify(data);
                        let response_data = JSON.stringify(e);
                        let request_status = "FAILED";
                        let qbData = { api_name, request_data, response_data, request_status, createdby };
                        await InsertQuickBooksLog(org_id, qbData);
  
                        return reject(e);
                      }
                      else{
  
                        let api_name = 'createTimeActivity';
                        let request_data = JSON.stringify(data);
                        let response_data = JSON.stringify(timeactivity);
                        let request_status = "SUCCESS";
                        let qbData = { api_name, request_data, response_data, request_status, createdby };
                        await InsertQuickBooksLog(org_id, qbData);
  
                        resolve(timeactivity);
                      }
                  });
                });
              }
  
              ////////////////////////////////////////////////
              
              qb_timesheet_id = (timeactivity && timeactivity.Id) || null;
  
              if(qb_timesheet_id){
                // update timesheet
                var timesheetData = [
                 timesheet_id,
                 org_id,
                 timesheet_exists.user_id,
                 timesheet_exists.project_id,
                 timesheet_exists.year,
                 parseInt(timesheet_exists.month),
                 timesheet_exists.week_start_date,
                 timesheet_exists.week_end_date,
                 timesheet_exists.timesheet_date,
                 timesheet_exists.day_name,
                 timesheet_exists.regular_hours,
                 timesheet_exists.regular_minutes,
                 timesheet_exists.ot_hours,
                 timesheet_exists.ot_minutes,
                 timesheet_exists.absent_type,
                 timesheet_exists.absent_hours,
                 timesheet_exists.absent_minutes,
                 timesheet_exists.status,
                 timesheet_exists.user_notes,
                 timesheet_exists.approver_id,
                 timesheet_exists.approver_notes,
                 qb_timesheet_id,
                 timesheet_exists.qb_status,
                 updatedby,
                 record_type_status,
               ];
   
               let results = await con.query(
                 `SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                 timesheetData
               );
               var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;
  
               // await InsertTimesheetHistory(org_id, update_data.id);
  
             }
  
              ///////////////////////////////////////////////
            }
            else{
              returnMessage.isError = true;
              returnMessage.message = "QB Consultant ID or QB Customer ID is not configured";
              returnMessage.label = "send_project_wise_timesheet_to_qb";
              logger.log({
                level: "error",
                message: returnMessage,
              });
              return res.status(400).json(returnMessage);
            }

          }
        }

        returnMessage.isError = false;
        returnMessage.data = null;
        returnMessage.message = "Timesheet has been sent to QuickBooks";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);

    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet data" };
      returnMessage.label = "send_project_wise_timesheet_to_qb";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } else{
    returnMessage.isError = true;
    returnMessage.message = "QB Transaction not enabled!";
    returnMessage.error = "QB Transaction not enabled!";
    returnMessage.label = "send_project_wise_timesheet_to_qb";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).json(returnMessage);
  }
  }catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "send_project_wise_timesheet_to_qb";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// ====================Approve Monthly Timesheet data ==================

// api for approve_monthly_timesheets
const approve_monthly_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;

    const { errors, isValid } = approveMonthlyTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "approve_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      approver_notes: ts_approver_notes = null,
      // timesheet_data = null,
      year: ts_year = null,
      month: ts_month = null,
    } = req.body;

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "approve_monthly_timesheets";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
      
    }
    
    let ts_approver_id = req.user.id;
    let approved_response = 0;

    let month = ts_month?((ts_month > 0)?(ts_month - 1) : ts_month): null;
    let month2d = ts_month ? moment().month(month).format("MM") : moment().format("MM");
    year = ts_year ? moment().year(ts_year).format("YYYY") : moment().format("YYYY");
    let ymdate = `${year}-${month2d}`;
    let months = moment(ymdate, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").startOf("isoweek").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").endOf("isoweek").format("YYYY-MM-DD");
    let range = moment().range(
      moment(months).startOf("month").startOf("isoweek"),
      moment(months).endOf("month").endOf("isoweek")
    );

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    let timesheet_data = [];

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        
        let tmpDate = dates[i];

        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");

        timesheet_data.push({
          timesheet_date: tmpDate,
          week_start_date: week_start_date,
          week_end_date: week_end_date,

        });
      }
    }


    if (timesheet_data && timesheet_data.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let { errors, isValid } = approveMonthlyTimesheetsDataValidator({
          ...tdRow,
          org_id,
          user_id,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "approve_monthly_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }


      if (timesheet_data && timesheet_data.length) {

        for (var i = 0; i < timesheet_data.length; i++) {

          let tdRow = timesheet_data[i];
          let { timesheet_date = null, week_start_date = null, week_end_date = null } = tdRow;

          if (timesheet_date) {

            let year = (week_start_date && week_start_date.split("-")[0]) || null;
            let month = (week_start_date && parseInt(week_start_date.split("-")[1])) || null;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.APPROVED;

            let p_timesheets_exists = await con.query(
              `SELECT timesheets.get_timesheet_by_user_id_and_date($1,$2,$3)`,
              [org_id, user_id, timesheet_date]
            );

            p_timesheets_exists = (p_timesheets_exists && p_timesheets_exists.rows[0].get_timesheet_by_user_id_and_date && p_timesheets_exists.rows[0].get_timesheet_by_user_id_and_date) || null;
            
            if(p_timesheets_exists && p_timesheets_exists.length){

              for (var j = 0; j < p_timesheets_exists.length; j++) {
                
                timesheet_exists = p_timesheets_exists[j];

                if (timesheet_exists && timesheet_exists.id) {
                  // update
                  let timesheet_id = timesheet_exists.id;
                  if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
                    status = TIMESHEET_STATUS.APPROVED;
                  } else {
                    status = timesheet_exists.status;
                  }
    
                  var timesheetData = [
                    timesheet_id,
                    org_id,
                    user_id,
                    timesheet_exists.project_id,
                    year,
                    month,
                    week_start_date,
                    week_end_date,
                    timesheet_date,
                    day_name,
                    timesheet_exists.regular_hours,
                    timesheet_exists.regular_minutes,
                    timesheet_exists.ot_hours,
                    timesheet_exists.ot_minutes,
                    timesheet_exists.absent_type,
                    timesheet_exists.absent_hours,
                    timesheet_exists.absent_minutes,
                    status,
                    timesheet_exists.user_notes,
                    ts_approver_id,
                    timesheet_exists.approver_notes,
                    timesheet_exists.qb_timesheet_id,
                    timesheet_exists.qb_status,
                    updatedby,
                    record_type_status,
                  ];
    
                  let results = await con.query(`SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                    timesheetData
                  );
                  var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;
    
                  await InsertTimesheetHistory(org_id, update_data.id);
                  await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
                  /////////////

                  let ts_status_data = null;
                  let old_status_data = await con.query(`SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
                  [org_id, week_start_date, week_end_date, timesheet_exists.project_id]);

                  old_status_data = (old_status_data && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

                  if (old_status_data && old_status_data.id) {
                    
                    let statusData = {
                      org_id: org_id,
                      user_id: user_id,
                      project_id: timesheet_exists.project_id,
                      year: year,
                      month: month,
                      week_start_date: week_start_date,
                      week_end_date: week_end_date,
                      client_manager_email: old_status_data.client_manager_email,
                      client_manager_name: old_status_data.client_manager_name,
                      user_notes: old_status_data.user_notes,
                      approver_id: ts_approver_id,
                      approver_notes: old_status_data.approver_notes,
                      createdby: createdby,
                    };

                    ts_status_data = await ResetTimesheetStatus(statusData);
                  }

                  approved_response++;
                  ////////////
                }
              }

            }

          }
        }

      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.APPROVED){
      
      // Send Timesheet Approved Email to employee
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]);

      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";

      if(consultant_data.id){
          
        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let week_start_date = tmpDate.startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = tmpDate.endOf("isoweek").format("YYYY-MM-DD");

        let monthName = tmpDate.format("MMMM");
        // send push notification 
        let notificationData = {
          action: "approve_monthly_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };
        await ApprovedMonthlyPushNotificationToEmployee(notificationData);
      }
      
      if (employee_email) {

        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
  
        let emailData = {
          org_id: org_id,
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };

        let user_id = consultant_data.id;
        let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

        if(is_email_reminder){
          await ApprovedMonthlyEmailToEmployee(emailData);
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Approved Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet_data" };
      returnMessage.label = "approve_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "approve_monthly_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};



// api for reject_monthly_timesheets

const reject_monthly_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;

    const { errors, isValid } = rejectMonthlyTimesheetsValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "reject_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      approver_notes: ts_approver_notes = null,
      // timesheet_data = null,
      year: ts_year = null,
      month: ts_month = null,
    } = req.body;
    

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "reject_monthly_timesheets";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }

    let ts_approver_id = req.user.id;
    let rejected_response = 0;

    let month = ts_month?((ts_month > 0)?(ts_month - 1) : ts_month): null;
    let month2d = ts_month ? moment().month(month).format("MM") : moment().format("MM");
    year = ts_year ? moment().year(ts_year).format("YYYY") : moment().format("YYYY");
    let ymdate = `${year}-${month2d}`;
    let months = moment(ymdate, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").startOf("isoweek").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").endOf("isoweek").format("YYYY-MM-DD");
    let range = moment().range(
      moment(months).startOf("month").startOf("isoweek"),
      moment(months).endOf("month").endOf("isoweek")
    );

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    let timesheet_data = [];

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        
        let tmpDate = dates[i];

        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");

        timesheet_data.push({
          timesheet_date: tmpDate,
          week_start_date: week_start_date,
          week_end_date: week_end_date,

        });
      }
    }

    if (timesheet_data && timesheet_data.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let { errors, isValid } = rejectMonthlyTimesheetsDataValidator({
          ...tdRow,
          org_id,
          user_id,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "reject_monthly_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }


      if (timesheet_data && timesheet_data.length) {

        for (var i = 0; i < timesheet_data.length; i++) {

          let tdRow = timesheet_data[i];
          let { timesheet_date = null, week_start_date = null, week_end_date = null } = tdRow;

          if (timesheet_date) {


            let year = (week_start_date && week_start_date.split("-")[0]) || null;
            let month = (week_start_date && parseInt(week_start_date.split("-")[1])) || null;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.REJECTED;

            let p_timesheets_exists = await con.query(
              `SELECT timesheets.get_timesheet_by_user_id_and_date($1,$2,$3)`,
              [org_id, user_id, timesheet_date]
            );

            p_timesheets_exists = (p_timesheets_exists && p_timesheets_exists.rows[0].get_timesheet_by_user_id_and_date && p_timesheets_exists.rows[0].get_timesheet_by_user_id_and_date) || null;
            
            if(p_timesheets_exists && p_timesheets_exists.length){

              for (var j = 0; j < p_timesheets_exists.length; j++) {
                
                timesheet_exists = p_timesheets_exists[j];

                if (timesheet_exists && timesheet_exists.id) {
                  // update
                  let timesheet_id = timesheet_exists.id;
                  if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
                    status = TIMESHEET_STATUS.REJECTED;
                  } else {
                    status = timesheet_exists.status;
                  }
    
                  var timesheetData = [
                    timesheet_id,
                    org_id,
                    user_id,
                    timesheet_exists.project_id,
                    year,
                    month,
                    week_start_date,
                    week_end_date,
                    timesheet_date,
                    day_name,
                    timesheet_exists.regular_hours,
                    timesheet_exists.regular_minutes,
                    timesheet_exists.ot_hours,
                    timesheet_exists.ot_minutes,
                    timesheet_exists.absent_type,
                    timesheet_exists.absent_hours,
                    timesheet_exists.absent_minutes,
                    status,
                    timesheet_exists.user_notes,
                    ts_approver_id,
                    timesheet_exists.approver_notes,
                    timesheet_exists.qb_timesheet_id,
                    timesheet_exists.qb_status,
                    updatedby,
                    record_type_status,
                  ];
    
                  let results = await con.query(`SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                    timesheetData
                  );
                  var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;
    
                  await InsertTimesheetHistory(org_id, update_data.id);
                  await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
                  /////////////

                  let ts_status_data = null;
                  let old_status_data = await con.query(`SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
                  [org_id, week_start_date, week_end_date, timesheet_exists.project_id]);

                  old_status_data = (old_status_data && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

                  if (old_status_data && old_status_data.id) {
                    
                    let statusData = {
                      org_id: org_id,
                      user_id: user_id,
                      project_id: timesheet_exists.project_id,
                      year: year,
                      month: month,
                      week_start_date: week_start_date,
                      week_end_date: week_end_date,
                      client_manager_email: old_status_data.client_manager_email,
                      client_manager_name: old_status_data.client_manager_name,
                      user_notes: old_status_data.user_notes,
                      approver_id: ts_approver_id,
                      approver_notes: old_status_data.approver_notes,
                      createdby: createdby,
                    };

                    ts_status_data = await ResetTimesheetStatus(statusData);
                  }

                  rejected_response++;
                  ////////////
                
                }
              }
            }
          }
        }

      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.REJECTED){
      
      // Send Timesheet Rejected Email to employee
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]);

      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";

      if(consultant_data.id){
          
        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let week_start_date = tmpDate.startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = tmpDate.endOf("isoweek").format("YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
        // send push notification 
        let notificationData = {
          action: "reject_monthly_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };
        await RejectedMonthlyPushNotificationToEmployee(notificationData);
      }

      if (employee_email) {

        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
  
        let emailData = {
          org_id: org_id,
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };

        let user_id = consultant_data.id;
        let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

        if(is_email_reminder){
          await RejectedMonthlyEmailToEmployee(emailData);
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Rejected Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet_data" };
      returnMessage.label = "reject_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "reject_monthly_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// api for revert_monthly_timesheets

const revert_monthly_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;

    const { errors, isValid } = revertMonthlyTimesheetsValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "revert_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      approver_notes: ts_approver_notes = null,
      // timesheet_data = null,
      year: ts_year = null,
      month: ts_month = null,
    } = req.body;
    
    let ts_approver_id = req.user.id;
    let reverted_response = 0;

    let month = ts_month?((ts_month > 0)?(ts_month - 1) : ts_month): null;
    let month2d = ts_month ? moment().month(month).format("MM") : moment().format("MM");
    year = ts_year ? moment().year(ts_year).format("YYYY") : moment().format("YYYY");
    let ymdate = `${year}-${month2d}`;
    let months = moment(ymdate, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").startOf("isoweek").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").endOf("isoweek").format("YYYY-MM-DD");
    let range = moment().range(
      moment(months).startOf("month").startOf("isoweek"),
      moment(months).endOf("month").endOf("isoweek")
    );

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    let timesheet_data = [];

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        
        let tmpDate = dates[i];

        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");

        timesheet_data.push({
          timesheet_date: tmpDate,
          week_start_date: week_start_date,
          week_end_date: week_end_date,

        });
      }
    }

    if (timesheet_data && timesheet_data.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let { errors, isValid } = revertMonthlyTimesheetsDataValidator({
          ...tdRow,
          org_id,
          user_id,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "revert_monthly_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }


      if (timesheet_data && timesheet_data.length) {

        for (var i = 0; i < timesheet_data.length; i++) {

          let tdRow = timesheet_data[i];
          let { timesheet_date = null, week_start_date = null, week_end_date = null } = tdRow;

          if (timesheet_date) {

            let year = (week_start_date && week_start_date.split("-")[0]) || null;
            let month = (week_start_date && parseInt(week_start_date.split("-")[1])) || null;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.SUBMITTED;

            let p_timesheets_exists = await con.query(
              `SELECT timesheets.get_timesheet_by_user_id_and_date($1,$2,$3)`,
              [org_id, user_id, timesheet_date]
            );

            p_timesheets_exists = (p_timesheets_exists && p_timesheets_exists.rows[0].get_timesheet_by_user_id_and_date && p_timesheets_exists.rows[0].get_timesheet_by_user_id_and_date) || null;
            
            if(p_timesheets_exists && p_timesheets_exists.length){

              for (var j = 0; j < p_timesheets_exists.length; j++) {
                
                timesheet_exists = p_timesheets_exists[j];

                if (timesheet_exists && timesheet_exists.id) {
                  // update
                  let timesheet_id = timesheet_exists.id;
                  if ([
                    TIMESHEET_STATUS.APPROVED,
                    TIMESHEET_STATUS.REJECTED,
                  ].includes(timesheet_exists.status)) {
                    status = TIMESHEET_STATUS.SUBMITTED;
                  } else {
                    status = timesheet_exists.status;
                  }
    
                  var timesheetData = [
                    timesheet_id,
                    org_id,
                    user_id,
                    timesheet_exists.project_id,
                    year,
                    month,
                    week_start_date,
                    week_end_date,
                    timesheet_date,
                    day_name,
                    timesheet_exists.regular_hours,
                    timesheet_exists.regular_minutes,
                    timesheet_exists.ot_hours,
                    timesheet_exists.ot_minutes,
                    timesheet_exists.absent_type,
                    timesheet_exists.absent_hours,
                    timesheet_exists.absent_minutes,
                    status,
                    timesheet_exists.user_notes,
                    ts_approver_id,
                    timesheet_exists.approver_notes,
                    timesheet_exists.qb_timesheet_id,
                    timesheet_exists.qb_status,
                    updatedby,
                    record_type_status,
                  ];
    
                  let results = await con.query(`SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                    timesheetData
                  );
                  var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;
    
                  await InsertTimesheetHistory(org_id, update_data.id, true);
                  await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
                  /////////////

                  let ts_status_data = null;
                  let old_status_data = await con.query(`SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
                  [org_id, week_start_date, week_end_date, timesheet_exists.project_id]);

                  old_status_data = (old_status_data && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

                  if (old_status_data && old_status_data.id) {
                    
                    let statusData = {
                      org_id: org_id,
                      user_id: user_id,
                      project_id: timesheet_exists.project_id,
                      year: year,
                      month: month,
                      week_start_date: week_start_date,
                      week_end_date: week_end_date,
                      client_manager_email: old_status_data.client_manager_email,
                      client_manager_name: old_status_data.client_manager_name,
                      user_notes: old_status_data.user_notes,
                      approver_id: ts_approver_id,
                      approver_notes: old_status_data.approver_notes,
                      createdby: createdby,
                    };

                    ts_status_data = await ResetTimesheetStatus(statusData, true);
                  }

                  reverted_response++;
                  ////////////
                }
              }
            }
          }
        }

      }

      // Send Timesheet reverted notification to employee
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]);

      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";

      if(consultant_data.id){
          
        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let week_start_date = tmpDate.startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = tmpDate.endOf("isoweek").format("YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
        // send push notification 
        let notificationData = {
          action: "revert_monthly_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };
        await RevertedMonthlyPushNotificationToEmployee(notificationData);
      }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Reverted Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet_data" };
      returnMessage.label = "revert_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "revert_monthly_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// api for approve_project_wise_monthly_timesheets
const approve_project_wise_monthly_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;

    const { errors, isValid } = approveProjectWiseMonthlyTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "approve_project_wise_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      approver_notes: ts_approver_notes = null,
      // timesheet_data = null,
      year: ts_year = null,
      month: ts_month = null,
    } = req.body;
    

    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "approve_project_wise_monthly_timesheets";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }

    let ts_approver_id = req.user.id;
    let approved_response = 0;

    let month = ts_month?((ts_month > 0)?(ts_month - 1) : ts_month): null;
    let month2d = ts_month ? moment().month(month).format("MM") : moment().format("MM");
    
    year = ts_year ? moment().year(ts_year).format("YYYY") : moment().format("YYYY");
    let ymdate = `${year}-${month2d}`;
    let months = moment(ymdate, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").startOf("isoweek").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").endOf("isoweek").format("YYYY-MM-DD");
    let range = moment().range(
      moment(months).startOf("month").startOf("isoweek"),
      moment(months).endOf("month").endOf("isoweek")
    );

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    let timesheet_data = [];

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        
        let tmpDate = dates[i];

        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");

        timesheet_data.push({
          timesheet_date: tmpDate,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
        });
      }
    }

    if (timesheet_data && timesheet_data.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let { errors, isValid } = approveMonthlyTimesheetsDataValidator({
          ...tdRow,
          org_id,
          user_id,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "approve_project_wise_monthly_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }

      if (timesheet_data && timesheet_data.length) {

        for (var i = 0; i < timesheet_data.length; i++) {

          let tdRow = timesheet_data[i];
          let { timesheet_date = null, week_start_date = null, week_end_date = null } = tdRow;

          if (timesheet_date) {

            let year = (week_start_date && week_start_date.split("-")[0]) || null;
            let month = (week_start_date && parseInt(week_start_date.split("-")[1])) || null;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.APPROVED;

            let timesheet_exists = await con.query(
              `SELECT * FROM timesheets.get_timesheet_by_project_id_and_date($1,$2,$3)`,
              [org_id, project_id, timesheet_date]
            );

            timesheet_exists = (timesheet_exists && timesheet_exists.rows[0] && timesheet_exists.rows[0].j && timesheet_exists.rows[0].j[0]) || null;
            
            if (timesheet_exists && timesheet_exists.id) {
              // update
              let timesheet_id = timesheet_exists.id;
              if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
                status = TIMESHEET_STATUS.APPROVED;
              } else {
                status = timesheet_exists.status;
              }

              var timesheetData = [
                timesheet_id,
                org_id,
                user_id,
                timesheet_exists.project_id,
                year,
                month,
                week_start_date,
                week_end_date,
                timesheet_date,
                day_name,
                timesheet_exists.regular_hours,
                timesheet_exists.regular_minutes,
                timesheet_exists.ot_hours,
                timesheet_exists.ot_minutes,
                timesheet_exists.absent_type,
                timesheet_exists.absent_hours,
                timesheet_exists.absent_minutes,
                status,
                timesheet_exists.user_notes,
                ts_approver_id,
                timesheet_exists.approver_notes,
                timesheet_exists.qb_timesheet_id,
                timesheet_exists.qb_status,
                updatedby,
                record_type_status,
              ];

              let results = await con.query(`SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                timesheetData
              );
              var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;

              await InsertTimesheetHistory(org_id, update_data.id);
              await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
              /////////////

              let ts_status_data = null;
              let old_status_data = await con.query(`SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
              [org_id, week_start_date, week_end_date, timesheet_exists.project_id]);

              old_status_data = (old_status_data && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

              if (old_status_data && old_status_data.id) {
                
                let statusData = {
                  org_id: org_id,
                  user_id: user_id,
                  project_id: timesheet_exists.project_id,
                  year: year,
                  month: month,
                  week_start_date: week_start_date,
                  week_end_date: week_end_date,
                  client_manager_email: old_status_data.client_manager_email,
                  client_manager_name: old_status_data.client_manager_name,
                  user_notes: old_status_data.user_notes,
                  approver_id: ts_approver_id,
                  approver_notes: old_status_data.approver_notes,
                  createdby: createdby,
                };

                ts_status_data = await ResetTimesheetStatus(statusData);
              }

              approved_response++;
              ////////////
            }

          }
        }

      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.APPROVED){
      
      // Send Timesheet Approved Email to employee
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]);

      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";

      if(consultant_data.id){
          
        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let week_start_date = tmpDate.startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = tmpDate.endOf("isoweek").format("YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
        // send push notification 
        let notificationData = {
          action: "approve_project_wise_monthly_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };
        await ApprovedMonthlyPushNotificationToEmployee(notificationData);
      }

      if (employee_email) {

        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
  
        let emailData = {
          org_id: org_id,
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };

        let user_id = consultant_data.id;
        let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

        if(is_email_reminder){
          await ApprovedMonthlyEmailToEmployee(emailData);
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Approved Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet_data" };
      returnMessage.label = "approve_project_wise_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "approve_project_wise_monthly_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// api for reject_project_wise_monthly_timesheets

const reject_project_wise_monthly_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;

    const { errors, isValid } = rejectProjectWiseMonthlyTimesheetValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "reject_project_wise_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      approver_notes: ts_approver_notes = null,
      // timesheet_data = null,
      year: ts_year = null,
      month: ts_month = null,
    } = req.body;
    
    // don't allow this action id ADP not valdiated
    let is_adp_enabled = await isAdpEnabled(org_id);
    let is_validate_adp_approver = await isValidateAdpApprover(org_id);
    let tmp_employee_type = await getEmployeeType(org_id, user_id);
    if(is_adp_enabled && is_validate_adp_approver && tmp_employee_type.toUpperCase() == EMPLOYEE_TYPE.W2){
      
      let is_user_adp_validated = await isUserAdpValidated(org_id, user_id);
      if(!is_user_adp_validated){
        returnMessage.isError = true;
        returnMessage.message = "ADP is not validated";
        returnMessage.label = "reject_project_wise_monthly_timesheets";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return res.status(400).json(returnMessage);
      }
    }

    let ts_approver_id = req.user.id;
    let rejected_response = 0;

    let month = ts_month?((ts_month > 0)?(ts_month - 1) : ts_month): null;
    let month2d = ts_month ? moment().month(month).format("MM") : moment().format("MM");
    year = ts_year ? moment().year(ts_year).format("YYYY") : moment().format("YYYY");
    let ymdate = `${year}-${month2d}`;
    let months = moment(ymdate, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").startOf("isoweek").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").endOf("isoweek").format("YYYY-MM-DD");
    let range = moment().range(
      moment(months).startOf("month").startOf("isoweek"),
      moment(months).endOf("month").endOf("isoweek")
    );

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    let timesheet_data = [];

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        
        let tmpDate = dates[i];

        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");

        timesheet_data.push({
          timesheet_date: tmpDate,
          week_start_date: week_start_date,
          week_end_date: week_end_date,

        });
      }
    }

    if (timesheet_data && timesheet_data.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let { errors, isValid } = rejectMonthlyTimesheetsDataValidator({
          ...tdRow,
          org_id,
          user_id,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "reject_project_wise_monthly_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }


      if (timesheet_data && timesheet_data.length) {

        for (var i = 0; i < timesheet_data.length; i++) {

          let tdRow = timesheet_data[i];
          let { timesheet_date = null, week_start_date = null, week_end_date = null } = tdRow;

          if (timesheet_date) {


            let year = (week_start_date && week_start_date.split("-")[0]) || null;
            let month = (week_start_date && parseInt(week_start_date.split("-")[1])) || null;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.REJECTED;

            let timesheet_exists = await con.query(
              `SELECT * FROM timesheets.get_timesheet_by_project_id_and_date($1,$2,$3)`,
              [org_id, project_id, timesheet_date]
            );

            timesheet_exists = (timesheet_exists && timesheet_exists.rows[0] && timesheet_exists.rows[0].j && timesheet_exists.rows[0].j[0]) || null;

            if (timesheet_exists && timesheet_exists.id) {
              // update
              let timesheet_id = timesheet_exists.id;

              if ([TIMESHEET_STATUS.SUBMITTED].includes(timesheet_exists.status)) {
                status = TIMESHEET_STATUS.REJECTED;
              } else {
                status = timesheet_exists.status;
              }

              var timesheetData = [
                timesheet_id,
                org_id,
                user_id,
                timesheet_exists.project_id,
                year,
                month,
                week_start_date,
                week_end_date,
                timesheet_date,
                day_name,
                timesheet_exists.regular_hours,
                timesheet_exists.regular_minutes,
                timesheet_exists.ot_hours,
                timesheet_exists.ot_minutes,
                timesheet_exists.absent_type,
                timesheet_exists.absent_hours,
                timesheet_exists.absent_minutes,
                status,
                timesheet_exists.user_notes,
                ts_approver_id,
                timesheet_exists.approver_notes,
                timesheet_exists.qb_timesheet_id,
                timesheet_exists.qb_status,
                updatedby,
                record_type_status,
              ];

              let results = await con.query(`SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                timesheetData
              );
              var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;

              await InsertTimesheetHistory(org_id, update_data.id);
              await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
              /////////////

              let ts_status_data = null;
              let old_status_data = await con.query(`SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
              [org_id, week_start_date, week_end_date, timesheet_exists.project_id]);

              old_status_data = (old_status_data && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

              if (old_status_data && old_status_data.id) {
                
                let statusData = {
                  org_id: org_id,
                  user_id: user_id,
                  project_id: timesheet_exists.project_id,
                  year: year,
                  month: month,
                  week_start_date: week_start_date,
                  week_end_date: week_end_date,
                  client_manager_email: old_status_data.client_manager_email,
                  client_manager_name: old_status_data.client_manager_name,
                  user_notes: old_status_data.user_notes,
                  approver_id: ts_approver_id,
                  approver_notes: old_status_data.approver_notes,
                  createdby: createdby,
                };

                ts_status_data = await ResetTimesheetStatus(statusData);
              }

              rejected_response++;
              ////////////
            }
          }
        }

      }

      // if(ts_status_data && ts_status_data.status == TIMESHEET_STATUS.REJECTED){
      
      // Send Timesheet Rejected Email to employee
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]);

      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";

      if(consultant_data.id){
          
        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let week_start_date = tmpDate.startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = tmpDate.endOf("isoweek").format("YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
        // send push notification 
        let notificationData = {
          action: "reject_project_wise_monthly_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };
        await RejectedMonthlyPushNotificationToEmployee(notificationData);
      }
      
      if (employee_email) {

        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
  
        let emailData = {
          org_id: org_id,
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };

        let user_id = consultant_data.id;
        let is_email_reminder = await isEmailReminderOn(req.user.org_id, user_id);

        if(is_email_reminder){
          await RejectedMonthlyEmailToEmployee(emailData);
        }
      }

      // }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Rejected Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet_data" };
      returnMessage.label = "reject_project_wise_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "reject_project_wise_monthly_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

const revert_project_wise_monthly_timesheets = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;

    const { errors, isValid } = revertProjectWiseMonthlyTimesheetsValidator({
      ...req.body,
      org_id,
    });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "revert_project_wise_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;
    let record_type_status = "Active";
    let {
      user_id = null,
      project_id = null,
      approver_notes: ts_approver_notes = null,
      // timesheet_data = null,
      year: ts_year = null,
      month: ts_month = null,
    } = req.body;
    
    let ts_approver_id = req.user.id;
    let reverted_response = 0;

    let month = ts_month?((ts_month > 0)?(ts_month - 1) : ts_month): null;
    let month2d = ts_month ? moment().month(month).format("MM") : moment().format("MM");
    year = ts_year ? moment().year(ts_year).format("YYYY") : moment().format("YYYY");
    let ymdate = `${year}-${month2d}`;
    let months = moment(ymdate, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").startOf("isoweek").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").endOf("isoweek").format("YYYY-MM-DD");
    let range = moment().range(
      moment(months).startOf("month").startOf("isoweek"),
      moment(months).endOf("month").endOf("isoweek")
    );

    let days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

    let timesheet_data = [];

    if (dates && dates.length) {
      for (var i = 0; i < dates.length; i++) {
        
        let tmpDate = dates[i];

        let week_start_date = moment(tmpDate).startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = moment(tmpDate).endOf("isoweek").format("YYYY-MM-DD");

        timesheet_data.push({
          timesheet_date: tmpDate,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
        });
      }
    }

    if (timesheet_data && timesheet_data.length) {
      // validate timesheet_data
      for (let i = 0; i < timesheet_data.length; i++) {
        let tdRow = timesheet_data[i];
        let { errors, isValid } = revertMonthlyTimesheetsDataValidator({
          ...tdRow,
          org_id,
          user_id,
        });

        if (!isValid) {
          returnMessage.isError = true;
          returnMessage.message = "Validation failed";
          returnMessage.errors = { ...errors };
          returnMessage.label = "revert_project_wise_monthly_timesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          return res.status(400).json(returnMessage);
        }
      }


      if (timesheet_data && timesheet_data.length) {

        for (var i = 0; i < timesheet_data.length; i++) {

          let tdRow = timesheet_data[i];
          let { timesheet_date = null, week_start_date = null, week_end_date = null } = tdRow;

          if (timesheet_date) {

            let year = (week_start_date && week_start_date.split("-")[0]) || null;
            let month = (week_start_date && parseInt(week_start_date.split("-")[1])) || null;

            var tdate = `${timesheet_date}T00:00:00Z`;
            var day_name = moment(tdate).format("dddd");
            let status = TIMESHEET_STATUS.SUBMITTED;

            let timesheet_exists = await con.query(`SELECT * FROM timesheets.get_timesheet_by_project_id_and_date($1,$2,$3)`,
            [org_id, project_id, timesheet_date]);

            timesheet_exists = (timesheet_exists && timesheet_exists.rows[0] && timesheet_exists.rows[0].j && timesheet_exists.rows[0].j[0]) || null;
              
            if (timesheet_exists && timesheet_exists.id) {
              // update
              let timesheet_id = timesheet_exists.id;
              if ([
                TIMESHEET_STATUS.APPROVED,
                TIMESHEET_STATUS.REJECTED,
              ].includes(timesheet_exists.status)) {
                status = TIMESHEET_STATUS.SUBMITTED;
              } else {
                status = timesheet_exists.status;
              }

              var timesheetData = [
                timesheet_id,
                org_id,
                user_id,
                timesheet_exists.project_id,
                year,
                month,
                week_start_date,
                week_end_date,
                timesheet_date,
                day_name,
                timesheet_exists.regular_hours,
                timesheet_exists.regular_minutes,
                timesheet_exists.ot_hours,
                timesheet_exists.ot_minutes,
                timesheet_exists.absent_type,
                timesheet_exists.absent_hours,
                timesheet_exists.absent_minutes,
                status,
                timesheet_exists.user_notes,
                ts_approver_id,
                timesheet_exists.approver_notes,
                timesheet_exists.qb_timesheet_id,
                timesheet_exists.qb_status,
                updatedby,
                record_type_status,
              ];

              let results = await con.query(`SELECT timesheets.update_timesheet($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)`,
                timesheetData
              );
              var update_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet && results.rows[1].update_timesheet[0]) || null;

              await InsertTimesheetHistory(org_id, update_data.id, true);
              await con.query(`SELECT * from timesheets.update_timesheet_mark_unsynced($1,$2)`,  [org_id, update_data.id]);
              /////////////

              let ts_status_data = null;
              let old_status_data = await con.query(`SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
              [org_id, week_start_date, week_end_date, timesheet_exists.project_id]);

              old_status_data = (old_status_data && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id && old_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

              if (old_status_data && old_status_data.id) {
                
                let statusData = {
                  org_id: org_id,
                  user_id: user_id,
                  project_id: timesheet_exists.project_id,
                  year: year,
                  month: month,
                  week_start_date: week_start_date,
                  week_end_date: week_end_date,
                  client_manager_email: old_status_data.client_manager_email,
                  client_manager_name: old_status_data.client_manager_name,
                  user_notes: old_status_data.user_notes,
                  approver_id: ts_approver_id,
                  approver_notes: old_status_data.approver_notes,
                  createdby: createdby,
                };

                ts_status_data = await ResetTimesheetStatus(statusData, true);
              }

              reverted_response++;
              ////////////
            }
          }
        }

      }


      // Send Timesheet reverted notification to employee
      let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
      [user_id, org_id]);

      consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

      let employee_name = (consultant_data && consultant_data.full_name) || null;
      let employee_email = (consultant_data && consultant_data.email) || null;
      // let employee_email = "masood.m@msr-it.com";

      if(consultant_data.id){
          
        let tmpDate = moment(`${ts_year}-${ts_month}-01`, "YYYY-MM-DD");
        let week_start_date = tmpDate.startOf("isoweek").format("YYYY-MM-DD");
        let week_end_date = tmpDate.endOf("isoweek").format("YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");
        // send push notification 
        let notificationData = {
          action: "revert_project_wise_monthly_timesheets",
          org_id: org_id,
          user_id: consultant_data.id, 
          year: ts_year,
          month: ts_month,
          monthName: monthName,
          week_start_date: week_start_date,
          week_end_date: week_end_date,
          employee_name: employee_name,
          employee_email: employee_email,
          approver_notes: ts_approver_notes || ``,
        };
        await RevertedMonthlyPushNotificationToEmployee(notificationData);
      }

      returnMessage.isError = false;
      returnMessage.data = null;
      returnMessage.message = "Timesheet Reverted Successfully";
      returnMessage.statuscode = 200;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Data";
      returnMessage.error = { timesheet_data: "Please provide timesheet_data" };
      returnMessage.label = "revert_project_wise_monthly_timesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "revert_project_wise_monthly_timesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for multiple week timesheet by user and week dates

const get_multiple_week_timesheet = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {

      let date_range_arr = [];
      
      moment.updateLocale("en", {
        week: {
          dow: 1, // Monday is the first day of the week.
        },
      });

      let week_start_date = req.query.week_start_date?req.query.week_start_date:moment().format("YYYY-MM-DD");
      week_start_date = moment(week_start_date).startOf("week").format("YYYY-MM-DD");
      week_start_date = `${week_start_date}T00:00:00Z`;
      
      var current_week_no = moment(week_start_date).week();
      var previous_weeks = req.query.previous_weeks?parseInt(req.query.previous_weeks):3;
      var next_weeks = req.query.next_weeks?parseInt(req.query.next_weeks):3;
      var total_weeks = (previous_weeks + next_weeks + 1);
      
      // for previous weeks date range
      for(var i = previous_weeks; i > 0; i--){

        let start_date = moment(week_start_date).subtract(i, "weeks").startOf("week").format("YYYY-MM-DD");
        let end_date = moment(week_start_date).subtract(i, "weeks").endOf("week").format("YYYY-MM-DD");

        date_range_arr.push({
          week_start_date : start_date,
          week_end_date : end_date,
        });
      }

      // for current week date range
      let start_date = moment(week_start_date).add(0, "weeks").startOf("week").format("YYYY-MM-DD");
      let end_date = moment(week_start_date).add(0, "weeks").endOf("week").format("YYYY-MM-DD");

      date_range_arr.push({
        week_start_date : start_date,
        week_end_date : end_date,
      });
      
      // for next weeks date range
      for(var i = 1; i <= next_weeks; i++){

        let start_date = moment(week_start_date).add(i, "weeks").startOf("week").format("YYYY-MM-DD");
        let end_date = moment(week_start_date).add(i, "weeks").endOf("week").format("YYYY-MM-DD");

        date_range_arr.push({
          week_start_date : start_date,
          week_end_date : end_date,
        });
      }
      

      let data = {};

      if(date_range_arr && date_range_arr.length){
        for(var di = 0; di < date_range_arr.length; di++){

          let { week_start_date, week_end_date } = date_range_arr[di];

          let results = await con.query(
          `SELECT * from timesheets.get_single_week_timesheet($1,$2,$3,$4)`,
          [
            org_id,
            req.query.user_id,
            week_start_date,
            week_end_date,
          ]);

          results = (results.rows && results.rows[0] && results.rows[0].j) || null;
          ///////////////
          if(results && results.length){
            
            let regular_hours = 0;
            let regular_minutes = 0;
            let ot_hours = 0;
            let ot_minutes = 0;
            let absent_hours = 0;
            let absent_minutes = 0;
            
            let total_sec = 0;
            let total_saved_sec = 0;
            let total_submitted_sec = 0;
            let total_approved_sec = 0;
            let total_rejected_sec = 0;

            let total_hours_minutes = 0;
            let total_saved_hours_minutes = 0;
            let total_submitted_hours_minutes = 0;
            let total_approved_hours_minutes = 0;
            let total_rejected_hours_minutes = 0;

            for (var i = 0; i < results.length; i++) {
              
              tsRow = results[i];
              let {timesheet_data = null} = tsRow;

              let project_total_sec = 0;
              let project_total_regular_sec = 0;
              let project_total_ot_sec = 0;
              let project_total_absent_sec = 0;
              
              let project_total_hours_minutes = 0;
              let project_total_absent_hours_minutes = 0;
              let project_total_regular_hours_minutes = 0;
              let project_total_ot_hours_minutes = 0;

              if(timesheet_data && timesheet_data.length){
                                  
                for(j = 0; j < timesheet_data.length; j++){
                  
                  let tdRow = timesheet_data[j];

                  regular_hours = (tdRow.regular_hours && tdRow.regular_hours * 60 * 60) || 0;
                  regular_minutes = (tdRow.regular_minutes && tdRow.regular_minutes * 60) || 0; 
                  
                  ot_hours = (tdRow.ot_hours && tdRow.ot_hours * 60 * 60) || 0;
                  ot_minutes = (tdRow.ot_minutes && tdRow.ot_minutes * 60) || 0;

                  absent_hours = (tdRow.absent_hours && tdRow.absent_hours * 60 * 60) || 0;
                  absent_minutes = (tdRow.absent_minutes && tdRow.absent_minutes * 60) || 0;
                  
                  total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;

                  project_total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  project_total_regular_sec+= regular_hours + regular_minutes;
                  project_total_ot_sec+= ot_hours + ot_minutes;
                  project_total_absent_sec+= absent_hours + absent_minutes;

                  if (tdRow.status == TIMESHEET_STATUS.SAVED) {
                    total_saved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }
                  if (tdRow.status == TIMESHEET_STATUS.SUBMITTED) {
                    total_submitted_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }
                  if (tdRow.status == TIMESHEET_STATUS.APPROVED) {
                    total_approved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }
                  if (tdRow.status == TIMESHEET_STATUS.REJECTED) {
                    total_rejected_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }

                  let is_qb_enabled = await isQBEnabled(req.user.org_id);

                  // don't pass qb details in API response
                  if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                    delete results[i].timesheet_data[j].qb_timesheet_id;
                    delete results[i].timesheet_data[j].qb_status;
                  }
                }

                project_total_hours_minutes = secondsToHm(project_total_sec);
                project_total_regular_hours_minutes = secondsToHm(project_total_regular_sec);
                project_total_ot_hours_minutes = secondsToHm(project_total_ot_sec);
                project_total_absent_hours_minutes = secondsToHm(project_total_absent_sec);

                results[i].project_total_hours_minutes = project_total_hours_minutes;
                results[i].project_total_regular_hours_minutes = project_total_regular_hours_minutes;
                results[i].project_total_ot_hours_minutes = project_total_ot_hours_minutes;
                results[i].project_total_absent_hours_minutes = project_total_absent_hours_minutes;

              }

              let is_qb_enabled = await isQBEnabled(req.user.org_id);

              // don't pass qb details in API response
              if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                delete results[i].qb_customer_id;
                delete results[i].qb_customer_name;
                delete results[i].qb_project_id;
                delete results[i].qb_project_name;
                delete results[i].qb_product_id;
                delete results[i].qb_product_name;
                delete results[i].qb_status;
                
              }

              // don't pass bill rate / pay rate details in response
                delete results[i].bill_rate;
                delete results[i].pay_rate;
                delete results[i].bill_rate_currency;
                delete results[i].ot_bill_rate;
                delete results[i].ot_pay_rate;
                delete results[i].ot_bill_rate_currency;
              
            }

  
            total_hours_minutes = secondsToHm(total_sec);
            total_saved_hours_minutes = secondsToHm(total_saved_sec);
            total_submitted_hours_minutes = secondsToHm(total_submitted_sec);
            total_approved_hours_minutes = secondsToHm(total_approved_sec);
            total_rejected_hours_minutes = secondsToHm(total_rejected_sec);

            let hours_data = {
              total_hours_minutes,
              total_saved_hours_minutes,
              total_submitted_hours_minutes,
              total_approved_hours_minutes,
              total_rejected_hours_minutes
            };
            

            data[`${week_start_date}-${week_end_date}`] = {
              data: results,
              hours_data: hours_data,
            };
                                      
          }

        }
      }

      returnMessage.isError = false;
      returnMessage.message = "Records Found";
      returnMessage.data = data;
      res.status(200).json(returnMessage);

    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_multiple_week_timesheet";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};



// GET api for single week timesheet by user, project and week dates

const get_single_week_timesheet_by_project = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_single_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } 
    else if (!req.query.project_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "project_id can not be null or empty";
      returnMessage.label = "get_single_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_single_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_single_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {

      await con.query(
        `SELECT * from timesheets.get_single_week_timesheet_by_project($1,$2,$3,$4,$5)`,
        [
          org_id,
          req.query.user_id,
          req.query.project_id,
          req.query.week_start_date,
          req.query.week_end_date,
        ],
        async (error, results) => {
          
          if (error) {
            
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_single_week_timesheet_by_project";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);

          } else {
            
            results = (results.rows && results.rows[0] && results.rows[0].j) || null;

            ///////////////
            if(results && results.length){
              
              let regular_hours = 0;
              let regular_minutes = 0;
              let ot_hours = 0;
              let ot_minutes = 0;
              let absent_hours = 0;
              let absent_minutes = 0;
              
              let total_sec = 0;
              let total_saved_sec = 0;
              let total_submitted_sec = 0;
              let total_approved_sec = 0;
              let total_rejected_sec = 0;

              let total_hours_minutes = 0;
              let total_saved_hours_minutes = 0;
              let total_submitted_hours_minutes = 0;
              let total_approved_hours_minutes = 0;
              let total_rejected_hours_minutes = 0;

              for (var i = 0; i < results.length; i++) {
                
                tsRow = results[i];
                let {timesheet_data = null} = tsRow;

                let project_total_sec = 0;
                let project_total_regular_sec = 0;
                let project_total_ot_sec = 0;
                let project_total_absent_sec = 0;
                
                let project_total_hours_minutes = 0;
                let project_total_absent_hours_minutes = 0;
                let project_total_regular_hours_minutes = 0;
                let project_total_ot_hours_minutes = 0;

                if(timesheet_data && timesheet_data.length){
                                    
                  for(j = 0; j < timesheet_data.length; j++){
                    
                    let tdRow = timesheet_data[j];

                    regular_hours = (tdRow.regular_hours && tdRow.regular_hours * 60 * 60) || 0;
                    regular_minutes = (tdRow.regular_minutes && tdRow.regular_minutes * 60) || 0; 
                    
                    ot_hours = (tdRow.ot_hours && tdRow.ot_hours * 60 * 60) || 0;
                    ot_minutes = (tdRow.ot_minutes && tdRow.ot_minutes * 60) || 0;

                    absent_hours = (tdRow.absent_hours && tdRow.absent_hours * 60 * 60) || 0;
                    absent_minutes = (tdRow.absent_minutes && tdRow.absent_minutes * 60) || 0;
                    
                    total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;

                    project_total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    project_total_regular_sec+= regular_hours + regular_minutes;
                    project_total_ot_sec+= ot_hours + ot_minutes;
                    project_total_absent_sec+= absent_hours + absent_minutes;

                    if (tdRow.status == TIMESHEET_STATUS.SAVED) {
                      total_saved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.SUBMITTED) {
                      total_submitted_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.APPROVED) {
                      total_approved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.REJECTED) {
                      total_rejected_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }

                    let is_qb_enabled = await isQBEnabled(req.user.org_id);

                    // don't pass qb details in API response
                    if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                      delete results[i].timesheet_data[j].qb_timesheet_id;
                      delete results[i].timesheet_data[j].qb_status;
                    }
                  }

                  project_total_hours_minutes = secondsToHm(project_total_sec);
                  project_total_regular_hours_minutes = secondsToHm(project_total_regular_sec);
                  project_total_ot_hours_minutes = secondsToHm(project_total_ot_sec);
                  project_total_absent_hours_minutes = secondsToHm(project_total_absent_sec);

                  results[i].project_total_hours_minutes = project_total_hours_minutes;
                  results[i].project_total_regular_hours_minutes = project_total_regular_hours_minutes;
                  results[i].project_total_ot_hours_minutes = project_total_ot_hours_minutes;
                  results[i].project_total_absent_hours_minutes = project_total_absent_hours_minutes;

                }

                let is_qb_enabled = await isQBEnabled(req.user.org_id);
                // don't pass qb details in API response
                if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                  delete results[i].qb_customer_id;
                  delete results[i].qb_customer_name;
                  delete results[i].qb_project_id;
                  delete results[i].qb_project_name;
                  delete results[i].qb_product_id;
                  delete results[i].qb_product_name;
                  delete results[i].qb_status;
                  
                }

                // don't pass bill rate / pay rate details in response
                  delete results[i].bill_rate;
                  delete results[i].pay_rate;
                  delete results[i].bill_rate_currency;
                  delete results[i].ot_bill_rate;
                  delete results[i].ot_pay_rate;
                  delete results[i].ot_bill_rate_currency;
              }

    
              total_hours_minutes = secondsToHm(total_sec);
              total_saved_hours_minutes = secondsToHm(total_saved_sec);
              total_submitted_hours_minutes = secondsToHm(total_submitted_sec);
              total_approved_hours_minutes = secondsToHm(total_approved_sec);
              total_rejected_hours_minutes = secondsToHm(total_rejected_sec);
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.hours_data = {
                total_hours_minutes,
                total_saved_hours_minutes,
                total_submitted_hours_minutes,
                total_approved_hours_minutes,
                total_rejected_hours_minutes
              };
              
              res.status(200).json(returnMessage);
              
            }
            else{
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_single_week_timesheet_by_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for multiple week timesheet by user, project and week dates

const get_multiple_week_timesheet_by_project = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else if (!req.query.project_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "project_id can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_multiple_week_timesheet_by_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {

      let date_range_arr = [];
      
      moment.updateLocale("en", {
        week: {
          dow: 1, // Monday is the first day of the week.
        },
      });

      let week_start_date = req.query.week_start_date?req.query.week_start_date:moment().format("YYYY-MM-DD");
      week_start_date = moment(week_start_date).startOf("week").format("YYYY-MM-DD");
      week_start_date = `${week_start_date}T00:00:00Z`;
      
      var current_week_no = moment(week_start_date).week();
      var previous_weeks = req.query.previous_weeks?parseInt(req.query.previous_weeks):3;
      var next_weeks = req.query.next_weeks?parseInt(req.query.next_weeks):3;
      var total_weeks = (previous_weeks + next_weeks + 1);
      
      // for previous weeks date range
      for(var i = previous_weeks; i > 0; i--){

        let start_date = moment(week_start_date).subtract(i, "weeks").startOf("week").format("YYYY-MM-DD");
        let end_date = moment(week_start_date).subtract(i, "weeks").endOf("week").format("YYYY-MM-DD");

        date_range_arr.push({
          week_start_date : start_date,
          week_end_date : end_date,
        });
      }

      // for current week date range
      let start_date = moment(week_start_date).add(0, "weeks").startOf("week").format("YYYY-MM-DD");
      let end_date = moment(week_start_date).add(0, "weeks").endOf("week").format("YYYY-MM-DD");

      date_range_arr.push({
        week_start_date : start_date,
        week_end_date : end_date,
      });
      
      // for next weeks date range
      for(var i = 1; i <= next_weeks; i++){

        let start_date = moment(week_start_date).add(i, "weeks").startOf("week").format("YYYY-MM-DD");
        let end_date = moment(week_start_date).add(i, "weeks").endOf("week").format("YYYY-MM-DD");

        date_range_arr.push({
          week_start_date : start_date,
          week_end_date : end_date,
        });
      }
      

      let data = {};

      if(date_range_arr && date_range_arr.length){
        for(var di = 0; di < date_range_arr.length; di++){

          let { week_start_date, week_end_date } = date_range_arr[di];

          let results = await con.query(
          `SELECT * from timesheets.get_single_week_timesheet_by_project($1,$2,$3,$4,$5)`,
          [
            org_id,
            req.query.user_id,
            req.query.project_id,
            week_start_date,
            week_end_date,
          ]);

          results = (results.rows && results.rows[0] && results.rows[0].j) || null;
          ///////////////
          if(results && results.length){
              

            let regular_hours = 0;
            let regular_minutes = 0;
            let ot_hours = 0;
            let ot_minutes = 0;
            let absent_hours = 0;
            let absent_minutes = 0;
            
            let total_sec = 0;
            let total_saved_sec = 0;
            let total_submitted_sec = 0;
            let total_approved_sec = 0;
            let total_rejected_sec = 0;

            let total_hours_minutes = 0;
            let total_saved_hours_minutes = 0;
            let total_submitted_hours_minutes = 0;
            let total_approved_hours_minutes = 0;
            let total_rejected_hours_minutes = 0;

            for (var i = 0; i < results.length; i++) {
              
              tsRow = results[i];
              let {timesheet_data = null} = tsRow;

              let project_total_sec = 0;
              let project_total_regular_sec = 0;
              let project_total_ot_sec = 0;
              let project_total_absent_sec = 0;
              
              let project_total_hours_minutes = 0;
              let project_total_absent_hours_minutes = 0;
              let project_total_regular_hours_minutes = 0;
              let project_total_ot_hours_minutes = 0;

              if(timesheet_data && timesheet_data.length){
                                  
                for(j = 0; j < timesheet_data.length; j++){
                  
                  let tdRow = timesheet_data[j];

                  regular_hours = (tdRow.regular_hours && tdRow.regular_hours * 60 * 60) || 0;
                  regular_minutes = (tdRow.regular_minutes && tdRow.regular_minutes * 60) || 0; 
                  
                  ot_hours = (tdRow.ot_hours && tdRow.ot_hours * 60 * 60) || 0;
                  ot_minutes = (tdRow.ot_minutes && tdRow.ot_minutes * 60) || 0;

                  absent_hours = (tdRow.absent_hours && tdRow.absent_hours * 60 * 60) || 0;
                  absent_minutes = (tdRow.absent_minutes && tdRow.absent_minutes * 60) || 0;
                  
                  total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;

                  project_total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  project_total_regular_sec+= regular_hours + regular_minutes;
                  project_total_ot_sec+= ot_hours + ot_minutes;
                  project_total_absent_sec+= absent_hours + absent_minutes;

                  if (tdRow.status == TIMESHEET_STATUS.SAVED) {
                    total_saved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }
                  if (tdRow.status == TIMESHEET_STATUS.SUBMITTED) {
                    total_submitted_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }
                  if (tdRow.status == TIMESHEET_STATUS.APPROVED) {
                    total_approved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }
                  if (tdRow.status == TIMESHEET_STATUS.REJECTED) {
                    total_rejected_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                  }

                  let is_qb_enabled = await isQBEnabled(req.user.org_id);

                  // don't pass qb details in API response
                  if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                    delete results[i].timesheet_data[j].qb_timesheet_id;
                    delete results[i].timesheet_data[j].qb_status;
                  }
                }

                project_total_hours_minutes = secondsToHm(project_total_sec);
                project_total_regular_hours_minutes = secondsToHm(project_total_regular_sec);
                project_total_ot_hours_minutes = secondsToHm(project_total_ot_sec);
                project_total_absent_hours_minutes = secondsToHm(project_total_absent_sec);

                results[i].project_total_hours_minutes = project_total_hours_minutes;
                results[i].project_total_regular_hours_minutes = project_total_regular_hours_minutes;
                results[i].project_total_ot_hours_minutes = project_total_ot_hours_minutes;
                results[i].project_total_absent_hours_minutes = project_total_absent_hours_minutes;

              }

              let is_qb_enabled = await isQBEnabled(req.user.org_id);
              // don't pass qb details in API response
              if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                delete results[i].qb_customer_id;
                delete results[i].qb_customer_name;
                delete results[i].qb_project_id;
                delete results[i].qb_project_name;
                delete results[i].qb_product_id;
                delete results[i].qb_product_name;
                delete results[i].qb_status;
                
              }

              // don't pass bill rate / pay rate details in response
                delete results[i].bill_rate;
                delete results[i].pay_rate;
                delete results[i].bill_rate_currency;
                delete results[i].ot_bill_rate;
                delete results[i].ot_pay_rate;
                delete results[i].ot_bill_rate_currency;
            }
  
            total_hours_minutes = secondsToHm(total_sec);
            total_saved_hours_minutes = secondsToHm(total_saved_sec);
            total_submitted_hours_minutes = secondsToHm(total_submitted_sec);
            total_approved_hours_minutes = secondsToHm(total_approved_sec);
            total_rejected_hours_minutes = secondsToHm(total_rejected_sec);

            let hours_data = {
              total_hours_minutes,
              total_saved_hours_minutes,
              total_submitted_hours_minutes,
              total_approved_hours_minutes,
              total_rejected_hours_minutes
            };
            

            data[`${week_start_date}-${week_end_date}`] = {
              data: results,
              hours_data: hours_data,
            };
                                      
          }

        }
      }

      returnMessage.isError = false;
      returnMessage.message = "Records Found";
      returnMessage.data = data;
      res.status(200).json(returnMessage);

    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_multiple_week_timesheet_by_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for get_status_wise_monthly_emp_timesheet_by_month
const get_status_wise_monthly_emp_timesheet_by_month = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (req.query.status == undefined || req.query.status == "") {
      req.query.status = null;
    }

    let month = req.query.month?((req.query.month > 0)?(req.query.month - 1) : req.query.month): null;
    let year = req.query.year || null;      
    let month2d = req.query.month ? moment().month(month).format("MM") : moment().format("MM");
    year = year ? moment().year(year).format("YYYY") : moment().format("YYYY");
    let date = `${year}-${month2d}`;
    let months = moment(date, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").format("YYYY-MM-DD");

    let tmpMDate = moment(`${year}-${month2d}-01`, "YYYY-MM-DD");
    let monthName = tmpMDate.format("MMMM");

    await con.query(
      `SELECT * from timesheets.get_status_wise_monthly_emp_timesheet_by_month($1,$2,$3,$4)`,
      [req.user.org_id, year, month2d, req.query.status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_status_wise_monthly_emp_timesheet_by_month";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {

          results = (results.rows && results.rows[0] && results.rows[0].j) || null;
          
          // console.log("results", results)

          if (results && results.length) {

          for(var i = 0; i < results.length; i++){
            let row = results[i];
            let total_match = 0;
            let { user_id, week_start_date, week_end_date, ts_status } = row;

            let total_null = 0;
            let total_saved = 0;
            let total_submitted = 0;
            let total_approved = 0;
            let total_rejected = 0;
            let statusArr = [];
            let final_status = null;

            let total_reg_sec = 0;
            let total_ot_sec = 0;
            let total_sec = 0;
            for(var j = 0; j < results.length; j++){

              let jRow = results[j];

              if(jRow.user_id == user_id){
                total_match++;
                if(!jRow.ts_status){
                  total_null++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.SAVED){
                  total_saved++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.SUBMITTED){
                  total_submitted++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.APPROVED){
                  total_approved++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.REJECTED){
                  total_rejected++;
                }
              }

              if(jRow.user_id == user_id && jRow.total_hours_minutes && jRow.total_hours_minutes != '00:00:00'){
                
                regh_split = jRow.regular_hours_minutes.split(":") || null;
                oth_split = jRow.ot_hours_minutes.split(":") || null;
                th_split = jRow.total_hours_minutes.split(":") || null;
                
                let tmp_reg_hours = regh_split[0] || null;
                let tmp_reg_minutes = regh_split[1] || null;

                let tmp_ot_hours = oth_split[0] || null;
                let tmp_ot_minutes = oth_split[1] || null;

                let tmp_hours = th_split[0] || null;
                let tmp_minutes = th_split[1] || null;
                
                let reg_hours_sec = (tmp_reg_hours && tmp_reg_hours * 60 * 60) || 0;
                let reg_minutes_sec = (tmp_reg_minutes && tmp_reg_minutes * 60) || 0;

                let ot_hours_sec = (tmp_ot_hours && tmp_ot_hours * 60 * 60) || 0;
                let ot_minutes_sec = (tmp_ot_minutes && tmp_ot_minutes * 60) || 0;

                let total_hours_sec = (tmp_hours && tmp_hours * 60 * 60) || 0;
                let total_minutes_sec = (tmp_minutes && tmp_minutes * 60) || 0;

                total_reg_sec+= reg_hours_sec + reg_minutes_sec;
                total_ot_sec+= ot_hours_sec + ot_minutes_sec;
                total_sec+= total_hours_sec + total_minutes_sec;

              }
            }

            regular_hours_minutes = secondsToHm(total_reg_sec);
            ot_hours_minutes = secondsToHm(total_ot_sec);
            total_hours_minutes = secondsToHm(total_sec);

            results[i].regular_hours_minutes = regular_hours_minutes;
            results[i].ot_hours_minutes = ot_hours_minutes;
            results[i].total_hours_minutes = total_hours_minutes;

            if(total_rejected > 0){
              final_status = TIMESHEET_STATUS.REJECTED;
            }
            else if(total_submitted > 0){
              final_status = TIMESHEET_STATUS.SUBMITTED;
            }
            else if(total_approved > 0 && total_approved == ((total_match - total_saved) - (total_null))){
              final_status = TIMESHEET_STATUS.APPROVED;
            }
            else{
              final_status = TIMESHEET_STATUS.SAVED;
            }

            results[i].final_status = final_status;
          }

          for(var i = 0; i < results.length; i++){
            delete results[i].ts_status;
            delete results[i].week_start_date;
            delete results[i].week_end_date;
          }
          
            // console.log("results", results);
          seen = Object.create(null),
          unique_results = results.filter(o => {
            var key = ['user_id'].map(k => o[k]).join('|');
            if (!seen[key]) {
                seen[key] = true;
                return true;
            }
          });
          
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.monthName = monthName;
            returnMessage.year = year;
            returnMessage.data = unique_results;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_status_wise_monthly_emp_timesheet_by_month";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_status_wise_monthly_project_timesheet_by_month
const get_status_wise_monthly_project_timesheet_by_month = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {
    if (req.query.status == undefined || req.query.status == "") {
      req.query.status = null;
    }

    let month = req.query.month?((req.query.month > 0)?(req.query.month - 1) : req.query.month): null;
    let year = req.query.year || null;      
    let month2d = req.query.month ? moment().month(month).format("MM") : moment().format("MM");
    year = year ? moment().year(year).format("YYYY") : moment().format("YYYY");
    let date = `${year}-${month2d}`;
    let months = moment(date, "YYYY-MM");
    let month_start_date = moment(months).startOf("month").format("YYYY-MM-DD");
    let month_end_date = moment(months).endOf("month").format("YYYY-MM-DD");

    let tmpMDate = moment(`${year}-${month2d}-01`, "YYYY-MM-DD");
    let monthName = tmpMDate.format("MMMM");

    await con.query(
      `SELECT * from timesheets.get_status_wise_monthly_project_timesheet_by_month($1,$2,$3,$4)`,
      [req.user.org_id, year, month2d, req.query.status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_status_wise_monthly_project_timesheet_by_month";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {

          results = (results.rows && results.rows[0] && results.rows[0].j) || null;
          
          // console.log("results", results)

          if (results && results.length) {

          for(var i = 0; i < results.length; i++){
            let row = results[i];
            let total_match = 0;
            let { user_id, project_id, week_start_date, week_end_date, ts_status } = row;

            let total_null = 0;
            let total_saved = 0;
            let total_submitted = 0;
            let total_approved = 0;
            let total_rejected = 0;
            let statusArr = [];
            let final_status = null;

            let total_reg_sec = 0;
            let total_ot_sec = 0;
            let total_sec = 0;
            for(var j = 0; j < results.length; j++){

              let jRow = results[j];

              if(jRow.project_id == project_id){
                total_match++;
                if(!jRow.ts_status){
                  total_null++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.SAVED){
                  total_saved++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.SUBMITTED){
                  total_submitted++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.APPROVED){
                  total_approved++;
                }
                if(jRow.ts_status == TIMESHEET_STATUS.REJECTED){
                  total_rejected++;
                }
              }

              if(jRow.project_id == project_id && jRow.total_hours_minutes && jRow.total_hours_minutes != '00:00:00'){
                
                regh_split = jRow.regular_hours_minutes.split(":") || null;
                oth_split = jRow.ot_hours_minutes.split(":") || null;
                th_split = jRow.total_hours_minutes.split(":") || null;
                
                let tmp_reg_hours = regh_split[0] || null;
                let tmp_reg_minutes = regh_split[1] || null;

                let tmp_ot_hours = oth_split[0] || null;
                let tmp_ot_minutes = oth_split[1] || null;

                let tmp_hours = th_split[0] || null;
                let tmp_minutes = th_split[1] || null;
                
                let reg_hours_sec = (tmp_reg_hours && tmp_reg_hours * 60 * 60) || 0;
                let reg_minutes_sec = (tmp_reg_minutes && tmp_reg_minutes * 60) || 0;

                let ot_hours_sec = (tmp_ot_hours && tmp_ot_hours * 60 * 60) || 0;
                let ot_minutes_sec = (tmp_ot_minutes && tmp_ot_minutes * 60) || 0;

                let total_hours_sec = (tmp_hours && tmp_hours * 60 * 60) || 0;
                let total_minutes_sec = (tmp_minutes && tmp_minutes * 60) || 0;

                total_reg_sec+= reg_hours_sec + reg_minutes_sec;
                total_ot_sec+= ot_hours_sec + ot_minutes_sec;
                total_sec+= total_hours_sec + total_minutes_sec;

              }
            }

            regular_hours_minutes = secondsToHm(total_reg_sec);
            ot_hours_minutes = secondsToHm(total_ot_sec);
            total_hours_minutes = secondsToHm(total_sec);

            results[i].regular_hours_minutes = regular_hours_minutes;
            results[i].ot_hours_minutes = ot_hours_minutes;
            results[i].total_hours_minutes = total_hours_minutes;

            if(total_rejected > 0){
              final_status = TIMESHEET_STATUS.REJECTED;
            }
            else if(total_submitted > 0){
              final_status = TIMESHEET_STATUS.SUBMITTED;
            }
            else if(total_approved > 0 && total_approved == ((total_match - total_saved) - (total_null))){
              final_status = TIMESHEET_STATUS.APPROVED;
            }
            else{
              final_status = TIMESHEET_STATUS.SAVED;
            }

            results[i].final_status = final_status;
          }

          for(var i = 0; i < results.length; i++){
            delete results[i].ts_status;
            delete results[i].week_start_date;
            delete results[i].week_end_date;
          }
          
            // console.log("results", results);
          seen = Object.create(null),
          unique_results = results.filter(o => {
            var key = ['project_id'].map(k => o[k]).join('|');
            if (!seen[key]) {
                seen[key] = true;
                return true;
            }
          });
          
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.monthName = monthName;
            returnMessage.year = year;
            returnMessage.data = unique_results;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_status_wise_monthly_project_timesheet_by_month";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for copy last week timesheet hours by user and week dates

const get_copy_last_week_hours_data = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_copy_last_week_hours_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_start_date can not be null or empty";
      returnMessage.label = "get_copy_last_week_hours_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.week_end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "week_end_date can not be null or empty";
      returnMessage.label = "get_copy_last_week_hours_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_copy_last_week_hours_data($1,$2,$3,$4)`,
        [
          org_id,
          req.query.user_id,
          req.query.week_start_date,
          req.query.week_end_date,
        ],
        async (error, results) => {
          if (error) {
            
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_copy_last_week_hours_data";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);

          } else {
            
            results = (results.rows && results.rows[0] && results.rows[0].j) || null;

            ///////////////
            if(results && results.length){
              
              let regular_hours = 0;
              let regular_minutes = 0;
              let ot_hours = 0;
              let ot_minutes = 0;
              let absent_hours = 0;
              let absent_minutes = 0;
              
              let total_sec = 0;
              let total_saved_sec = 0;
              let total_submitted_sec = 0;
              let total_approved_sec = 0;
              let total_rejected_sec = 0;

              let total_hours_minutes = 0;
              let total_saved_hours_minutes = 0;
              let total_submitted_hours_minutes = 0;
              let total_approved_hours_minutes = 0;
              let total_rejected_hours_minutes = 0;

              for (var i = 0; i < results.length; i++) {
                
                tsRow = results[i];
                let {timesheet_data = null} = tsRow;

                let project_total_sec = 0;
                let project_total_regular_sec = 0;
                let project_total_ot_sec = 0;
                let project_total_absent_sec = 0;
                
                let project_total_hours_minutes = 0;
                let project_total_absent_hours_minutes = 0;
                let project_total_regular_hours_minutes = 0;
                let project_total_ot_hours_minutes = 0;

                if(timesheet_data && timesheet_data.length){
                                    
                  for(j = 0; j < timesheet_data.length; j++){
                    
                    let tdRow = timesheet_data[j];

                    regular_hours = (tdRow.regular_hours && tdRow.regular_hours * 60 * 60) || 0;
                    regular_minutes = (tdRow.regular_minutes && tdRow.regular_minutes * 60) || 0; 
                    
                    ot_hours = (tdRow.ot_hours && tdRow.ot_hours * 60 * 60) || 0;
                    ot_minutes = (tdRow.ot_minutes && tdRow.ot_minutes * 60) || 0;

                    absent_hours = (tdRow.absent_hours && tdRow.absent_hours * 60 * 60) || 0;
                    absent_minutes = (tdRow.absent_minutes && tdRow.absent_minutes * 60) || 0;
                    
                    total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;

                    project_total_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    project_total_regular_sec+= regular_hours + regular_minutes;
                    project_total_ot_sec+= ot_hours + ot_minutes;
                    project_total_absent_sec+= absent_hours + absent_minutes;

                    if (tdRow.status == TIMESHEET_STATUS.SAVED) {
                      total_saved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.SUBMITTED) {
                      total_submitted_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.APPROVED) {
                      total_approved_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }
                    if (tdRow.status == TIMESHEET_STATUS.REJECTED) {
                      total_rejected_sec+= regular_hours + regular_minutes + ot_hours + ot_minutes;
                    }

                    let is_qb_enabled = await isQBEnabled(req.user.org_id);

                    // don't pass qb details in API response
                    if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                      delete results[i].timesheet_data[j].qb_timesheet_id;
                      delete results[i].timesheet_data[j].qb_status;
                    }
                  }

                  project_total_hours_minutes = secondsToHm(project_total_sec);
                  project_total_regular_hours_minutes = secondsToHm(project_total_regular_sec);
                  project_total_ot_hours_minutes = secondsToHm(project_total_ot_sec);
                  project_total_absent_hours_minutes = secondsToHm(project_total_absent_sec);

                  results[i].project_total_hours_minutes = project_total_hours_minutes;
                  results[i].project_total_regular_hours_minutes = project_total_regular_hours_minutes;
                  results[i].project_total_ot_hours_minutes = project_total_ot_hours_minutes;
                  results[i].project_total_absent_hours_minutes = project_total_absent_hours_minutes;

                }

                let is_qb_enabled = await isQBEnabled(req.user.org_id);

                // don't pass qb details in API response
                if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                  delete results[i].qb_customer_id;
                  delete results[i].qb_customer_name;
                  delete results[i].qb_project_id;
                  delete results[i].qb_project_name;
                  delete results[i].qb_product_id;
                  delete results[i].qb_product_name;
                  delete results[i].qb_status;
                  
                }
                
                // don't pass bill rate / pay rate details in response
                delete results[i].bill_rate;
                delete results[i].pay_rate;
                delete results[i].bill_rate_currency;
                delete results[i].ot_bill_rate;
                delete results[i].ot_pay_rate;
                delete results[i].ot_bill_rate_currency;
              }

    
              total_hours_minutes = secondsToHm(total_sec);
              total_saved_hours_minutes = secondsToHm(total_saved_sec);
              total_submitted_hours_minutes = secondsToHm(total_submitted_sec);
              total_approved_hours_minutes = secondsToHm(total_approved_sec);
              total_rejected_hours_minutes = secondsToHm(total_rejected_sec);
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.hours_data = {
                total_hours_minutes,
                total_saved_hours_minutes,
                total_submitted_hours_minutes,
                total_approved_hours_minutes,
                total_rejected_hours_minutes
              };
              
              res.status(200).json(returnMessage);
              
            }
            else{
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_copy_last_week_hours_data";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_all_timesheets_by_user,
  get_single_week_timesheet,
  get_monthly_timesheet_by_user,
  get_timesheet_history,
  get_per_day_timesheet_history,
  save_project_wise_timesheet,
  submit_project_wise_timesheet,
  submit_all_project_timesheets,
  unsubmit_project_wise_timesheet,
  unsubmit_all_project_timesheets,
  get_status_wise_total_hours_by_month,
  get_single_week_approver_timesheet,
  approve_project_wise_timesheet,
  approve_project_wise_single_day_timesheet,
  approve_all_project_timesheets,
  get_status_wise_emp_timesheet_by_month,
  get_status_wise_project_timesheet_by_month,
  reject_project_wise_timesheet,
  reject_project_wise_single_day_timesheet,
  reject_all_project_timesheets,
  revert_project_wise_single_day_timesheet,
  revert_project_wise_timesheet,
  revert_all_project_timesheets,
  get_day_and_dates_by_week,
  send_project_wise_timesheet_to_qb,
  approve_monthly_timesheets,
  reject_monthly_timesheets,
  revert_monthly_timesheets,
  get_multiple_week_timesheet,
  get_single_week_timesheet_by_project,
  get_multiple_week_timesheet_by_project,
  get_status_wise_monthly_emp_timesheet_by_month,
  get_status_wise_monthly_project_timesheet_by_month,
  approve_project_wise_monthly_timesheets,
  reject_project_wise_monthly_timesheets,
  revert_project_wise_monthly_timesheets,
  get_copy_last_week_hours_data
};
