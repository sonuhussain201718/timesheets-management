const express = require("express");
const router = express.Router();

const {
  getbloburl,
} = require("../../controllers/azureBlobController");


// @route POST api/v1/azureblob/getbloburl
// @desc  Route to fetch blob url
// @accesss public
router.post("/getbloburl", getbloburl);


module.exports = router;
