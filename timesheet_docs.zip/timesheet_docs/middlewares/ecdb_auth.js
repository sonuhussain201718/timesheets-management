const jwt = require("jsonwebtoken");
const axios = require("axios");
const logger = require("../utils/logger");

const ecdbAuth = async (req, res, next) => {

  let org_id = req.query.org_id;
  const bearerToken = req.header("Authorization");

  if (!bearerToken) {
    return res.status(401).send({
      error:
        "Not authorized to access this resource. Please provide access token",
    });
  }

  // const token = bearerToken.replace("Bearer ", "");
  let tokenData = null;

  // Verify token
  try {
    var data = await axios.get(`${process.env.ECDB_API_URL}/api/user/login/token/validate`, {
      headers: {
        Authorization: bearerToken,
      },
    });

    data = (data && data.data) || null;

    if(data && data.statusCode == 200){

      if(data.organizations && data.organizations.length){
        let allowed = data.organizations.filter((row) =>{
          return row.organizationId == org_id
        });

        if(allowed && allowed.length){
          next();
        }
        else{
          return res.status(401).send({
            error: "Not authorized to access this resource. Incorrect token",
          });
        }
      }
      else{
        return res.status(401).send({
          error: "Not authorized to access this resource. Incorrect token",
        });
      }
      
    }
    else{
      return res.status(401).send({
        error: "Not authorized to access this resource. Incorrect token",
      });
    }

  } catch (error) {
    // console.log("error", error);
    return res.status(401).send({
      error: "Not authorized to access this resource. Incorrect token",
    });
  }
};

module.exports = { ecdbAuthMiddleware: ecdbAuth };
