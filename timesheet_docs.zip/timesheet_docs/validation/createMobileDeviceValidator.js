const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createMobileDeviceValidator(data) {
  let errors = {};

  // if (data.hasOwnProperty("id") && !data.id) {
  //   errors.id = "id field is required";
  // }

  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }
  
  if (!data.user_id) {
    errors.user_id = "user_id field is required";
  }

  if (!data.os) {
    errors.os = "os field is required";
  }

  if (!data.device_token) {
    errors.device_token = "device_token field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
