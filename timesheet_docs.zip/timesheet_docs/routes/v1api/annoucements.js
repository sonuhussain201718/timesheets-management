const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getallannoucements,
  get_annoucement_by_id,
  insert_annoucement,
  update_annoucement,
  delete_annoucement,
  get_latest_announcement,
  // get_announcement_reads_by_user,
  mark_as_read,
} = require("../../controllers/annoucementsController");

// @route GET api/v1/annoucements/getallannoucements
// @desc  Route to get all annoucements
// @accesss public
router.get("/getallannoucements", getallannoucements);

// @route GET api/v1/annoucements/get_annoucement_by_id
// @desc  Route to get annoucements by id
// @accesss public
router.get("/get_annoucement_by_id", get_annoucement_by_id);

// @route post api/v1/annoucements/insert_annoucement
// @desc  Route to create annoucements data
// @accesss public
router.post("/insert_annoucement", insert_annoucement);

// @route put api/v1/annoucements/update_annoucement
// @desc  Route to update annoucements data
// @accesss public
router.put("/update_annoucement", update_annoucement);

// @route delete api/v1/annoucements/delete_annoucement
// @desc  Route to delete annoucements
// @accesss public
router.put("/delete_annoucement", delete_annoucement);

// @route get api/v1/annoucements/get_latest_announcement_by_org_id
// @desc  Route to delete annoucements
// @accesss public
router.get("/get_latest_announcement", get_latest_announcement);

// ============Announcement Read Api=============

// @route get api/v1/annoucements/get_announcement_reads_by_user
// @desc  Route to delete annoucements
// @accesss public
// router.get("/get_announcement_reads_by_user", get_announcement_reads_by_user);

// @route get api/v1/annoucements/mark_as_read
// @desc  Route to delete annoucements
// @accesss public
router.post("/mark_as_read", mark_as_read);

module.exports = router;
