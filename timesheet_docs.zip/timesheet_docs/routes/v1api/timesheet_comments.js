const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_comments_by_week_and_project,
  insert_comment,
  delete_comment,
  test_email
} = require("../../controllers/timesheetCommentsController");


// @route GET api/v1/timesheet_comments/test_email
// @desc  Route to sent test email
// @accesss public
router.get("/test_email", test_email);

// @route GET api/v1/timesheet_comments/get_comments_by_week_and_project
// @desc  Route to get comments by org_id,week and project
// @accesss public
router.get("/get_comments_by_week_and_project", get_comments_by_week_and_project);

// @route POST api/v1/timesheet_comments/insert_comment
// @desc  Route to post comment
// @accesss public
router.post("/insert_comment", insert_comment);

// @route PUT api/v1/timesheet_comments/delete_comment
// @desc  Route to delete comment by id
// @accesss public
router.put("/delete_comment", delete_comment);


module.exports = router;
