const { count } = require("console");
var express = require("express");
var router = express.Router();
var fs = require("fs");
var path = require("path");
const { getMsgFormat, isEmpty } = require("../utils/helpers");
const con = require("../utils/db");
const logger = require("../utils/logger");
const { BlobServiceClient } = require("@azure/storage-blob");
const { v1: uuidv1 } = require("uuid");
const createTimesheetDocValidator = require("../validation/createTimedocValidator");
require("dotenv").config();
const moment = require("moment");
const { getBlobUrl } = require("../utils/helpers");
var mime = require('mime-types')

// con.connect();

// GET api for timedoc List
const getalltimedoc = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_timesheet_documents($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timedoc details";
          returnMessage.error = error;
          returnMessage.label = "getalltimedoc";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimedoc";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timedoc by id
const gettimedocbyid = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_docs_by_id($1,$2)`,
      [req.query.id, req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timedoc details";
          returnMessage.error = error;
          returnMessage.label = "gettimedocbyid";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimedocbyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// Insert Timesheet Documents
const inserttimedoc = async function (req, res) {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  let createdby = req.user.id;

  try {
    const { errors, isValid } = createTimesheetDocValidator({
      ...req.body,
      org_id,
    });
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insert_timesheet_documents";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    var data = req.body;
    let {
      user_id = null,
      project_id = null,
      week_start_date = null,
      week_end_date = null,
      status = null,
      record_type_status = "Active",
    } = data;

    if (req.files && req.files.file) {
      var images = [];
      var insert_doc_results = [];
      var timesheet_status_id = null;

      req.files.file = !req.files.file.length
        ? [req.files.file]
        : req.files.file;

      const AZURE_STORAGE_CONNECTION_STRING =
        process.env.AZURE_STORAGE_CONNECTION_STRING;
      if (!AZURE_STORAGE_CONNECTION_STRING) {
        throw Error("Azure Storage Connection string not found");
      }

      const blobServiceClient = BlobServiceClient.fromConnectionString(
        AZURE_STORAGE_CONNECTION_STRING
      );
      const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
      const containerClient =
        blobServiceClient.getContainerClient(containerName);
      const createContainerResponse = await containerClient.createIfNotExists();

      // Create a unique name for the blob
      var files = req.files.file;
      for (i = 0; i < files.length; i++) {
        // Create a unique name for the blob
        var docFile = files[i];
        var original_name = docFile.name;
        var document_name = uuidv1() + (docFile.name.replace(/[^a-zA-Z0-9,_;\-.!? ]/g, ''));
        const blockBlobClient = containerClient.getBlockBlobClient(
          `${org_id}/${user_id}/${project_id}-timesheet/${week_start_date}-${week_end_date}/${document_name}`
        );

        let contentType = mime.lookup(document_name);
        // console.log("contentType", contentType);
        const blobOptions = { blobHTTPHeaders: { blobContentType: contentType } };

        const uploadBlobResponse = await blockBlobClient.upload(
          docFile.data,
          docFile.data.length, 
          blobOptions
        );

        // console.log("uploadBlobResponse", JSON.stringify(uploadBlobResponse));

        if (uploadBlobResponse && uploadBlobResponse.requestId) {
          images.push({
            document_name,
            original_name,
          });
        }
      }

      let status_data = await con.query(
        `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
        [org_id, week_start_date, week_end_date, project_id]
      );

      status_data =
        (status_data &&
          status_data.rows[0].get_timesheet_status_by_week_and_project_id &&
          status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) ||
        null;

      if (status_data) {
        timesheet_status_id = status_data.id;
      } else {
        status_data = await con.query(
          `SELECT timesheets.insert_timesheet_status($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
          [
            org_id,
            user_id,
            project_id,
            week_start_date.split("-")[0],
            parseInt(week_start_date.split("-")[1]),
            week_start_date,
            week_end_date,
            null,
            null,
            null,
            null,
            null,
            null,
            createdby,
            record_type_status,
          ]
        );

        status_data =
          (status_data &&
            status_data.rows[1].insert_timesheet_status &&
            status_data.rows[1].insert_timesheet_status[0]) ||
          null;
      }

      if (images && images.length) {
        for (i = 0; i < images.length; i++) {
          var result = await con.query(
            `SELECT timesheets.insert_timesheet_documents($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
            [
              req.user.org_id,
              user_id,
              project_id,
              status_data.id,
              images[i].original_name,
              images[i].document_name,
              week_start_date,
              week_end_date,
              createdby,
              record_type_status,
            ]
          );

          result =
            (result &&
              result.rows[1].insert_timesheet_documents &&
              result.rows[1].insert_timesheet_documents[0]) ||
            null;
          insert_doc_results.push(result);
        }
      }

      if (insert_doc_results && insert_doc_results.length) {
        returnMessage.isError = false;
        returnMessage.data = {
          timesheet_status_id: status_data.id,
          documents_result: insert_doc_results,
        };
        returnMessage.message = "Added Successfully";
        res.status(200).json(returnMessage);
      } else {
        returnMessage.isError = true;
        returnMessage.message = "Failed to add";
        returnMessage.error = error;
        returnMessage.label = "inserttimedoc";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(500).json(returnMessage);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Please select file(s)";
      returnMessage.label = "inserttimedoc";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (err) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured";
    returnMessage.error = err;
    returnMessage.label = "inserttimedoc";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).json(returnMessage);
  }
};

// GET api for timesheet docs list by week and project
const get_timesheet_docs_by_week_and_project = async (req, res) => {
  const returnMessage = getMsgFormat();
  const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;

  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.week_start_date,
        req.query.week_end_date,
        req.query.project_id,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timesheet documents";
          returnMessage.error = error;
          returnMessage.label = "get_timesheet_docs_by_week_and_project";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (
          results.rows &&
          results.rows[0] &&
          results.rows[0].j &&
          !isEmpty(results.rows[0].j)
        ) {
          results.rows[0].j.map((row, i) => {
            if (results.rows[0].j[i].document_name) {
              // console.log("row", row);

              if(results.rows[0].j[i].is_hrms == true){
                results.rows[0].j[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/hrms_timesheets/${row.document_name}`, true );
                results.rows[0].j[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/hrms_timesheets/${row.document_name}` );
              }
              else{
                results.rows[0].j[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/${row.project_id}-timesheet/${row.week_start_date}-${row.week_end_date}/${row.document_name}`, true );

                results.rows[0].j[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/${row.project_id}-timesheet/${row.week_start_date}-${row.week_end_date}/${row.document_name}` );
              }
              
            }
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j[0].count || null;
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_timesheet_docs_by_week_and_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timesheet docs list by week and project
const get_timesheet_documents_by_week = async (req, res) => {
  const returnMessage = getMsgFormat();
  const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;

  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_documents_by_week($1,$2,$3,$4);`,
      [req.user.org_id, req.query.user_id, req.query.week_start_date, req.query.week_end_date],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timesheet documents";
          returnMessage.error = error;
          returnMessage.label = "get_timesheet_documents_by_week";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (
          results.rows &&
          results.rows[0] &&
          results.rows[0].j &&
          !isEmpty(results.rows[0].j)
        ) {
          results.rows[0].j.map((row, i) => {
            if (results.rows[0].j[i].document_name) {
              // console.log("row", row);
              
              if(results.rows[0].j[i].is_hrms == true){
                results.rows[0].j[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/hrms_timesheets/${row.document_name}`, true );
                results.rows[0].j[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/hrms_timesheets/${row.document_name}` );
              }
              else{
                results.rows[0].j[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/${row.project_id}-timesheet/${row.week_start_date}-${row.week_end_date}/${row.document_name}`, true );

                results.rows[0].j[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/${row.project_id}-timesheet/${row.week_start_date}-${row.week_end_date}/${row.document_name}` );
              }
            }
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j[0].count || null;
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_timesheet_documents_by_week";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// PUT api for deleting timesheet doc by id
const delete_timesheet_document = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_timesheet_document($1,$2);`,
      [req.user.org_id, req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete timesheet document";
          returnMessage.error = error;
          returnMessage.label = "delete_timesheet_document";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_timesheet_document";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getalltimedoc,
  gettimedocbyid,
  inserttimedoc,
  get_timesheet_docs_by_week_and_project,
  get_timesheet_documents_by_week,
  delete_timesheet_document,
};
