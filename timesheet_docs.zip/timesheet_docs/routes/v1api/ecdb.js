const express = require("express");
const router = express.Router();
const authRouter = require("../../middlewares/auth");
const { ecdbAuthMiddleware } = require("../../middlewares/ecdb_auth"); // load auth middlware

const {
  insert_organization_data,
  insert_user_data,
  update_user_data,
  get_projects_by_ecdb_user_id,
} = require("../../controllers/ecdbController");

// @route POST api/v1/user/insert_organization_data
// @desc  Route to post users
// @accesss public
router.post("/insert_organization_data", insert_organization_data);

// @route POST api/v1/user/insert_user_data
// @desc  Route to post users
// @accesss public
router.post("/insert_user_data", insert_user_data);

// @route POST api/v1/user/update_user_data
// @desc Route to POST users
// @access public
router.post("/update_user_data", update_user_data);

// @route GET api/v1/user/get_projects_by_ecdb_user_id
// @desc Route to GET users
// @access public
router.get("/get_projects_by_ecdb_user_id", ecdbAuthMiddleware, get_projects_by_ecdb_user_id);

module.exports = router;
