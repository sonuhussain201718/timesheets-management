const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createGlobalConfigValidator = require("../validation/createGlobalConfigValidator");
const con = require("../utils/db");
const logger = require("../utils/logger");
const axios = require("axios");

// GET api for global config
const get_global_config = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_global_config()`,
      [],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch global config details";
          returnMessage.error = error;
          returnMessage.label = "get_global_config";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_global_config";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for users
const update_global_config = async (req, res) => {
  // console.log(req.body);
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    let createdby = req.user.id;
    const { errors, isValid } = createGlobalConfigValidator(req.body);

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "update_global_config";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let exists_data = await con.query(
      `SELECT timesheets.get_global_config()`,
      []
    );
    exists_data =
      (exists_data && exists_data.rows[0].get_global_config && exists_data.rows[0].get_global_config[0]) || null;
    let id = (exists_data && exists_data.id) || null;

    // console.log("exists_data", JSON.stringify(exists_data));
    let {
      notify_to_email = null,
      notification_enabled = true,
      record_type_status = "Active",
    } = req.body;

    if (exists_data && exists_data.id) {
      await con.query(
        `SELECT timesheets.update_global_config($1,$2,$3,$4,$5)`,
        [
          id,
          notify_to_email,
          notification_enabled,
          req.user.id,
          req.body.record_type_status,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_global_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].update_global_config &&
                results.rows[1].update_global_config[0]) ||
              null;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    } else {
      await con.query(
        `SELECT timesheets.insert_global_config($1,$2,$3,$4)`,
        [
          notify_to_email,
          notification_enabled,
          createdby, 
          req.body.record_type_status
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "update_global_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].insert_global_config &&
                results.rows[1].insert_global_config[0]) ||
              null;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "update_global_config";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_global_config,
  update_global_config,
};