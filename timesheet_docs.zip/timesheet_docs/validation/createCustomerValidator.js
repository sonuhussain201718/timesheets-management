const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createCustomerValidator(data) {
  let errors = {};

  if (validator.isEmpty(data.client_name)) {
    errors.client_name = "client_name is invalid";
  }

  if (validator.isEmpty(String(data.org_id))) {
    errors.org_id = "org_id field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
