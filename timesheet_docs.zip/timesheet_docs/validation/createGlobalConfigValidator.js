const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createGlobalConfigValidator(data) {
  let errors = {};


  if (validator.isEmpty(data.notify_to_email)) {
    errors.from_email = "notify_to_email field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
