const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createEmailConfigValidator = require("../validation/createEmailConfigValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const axios = require("axios");
// con.connect();

// GET api for annoucements details
const get_email_config_by_org_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_email_config_by_org_id($1)`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch email config details";
          returnMessage.error = error;
          returnMessage.label = "get_email_config_by_org_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    console.log("85", error);
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_email_config_by_org_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// API for update_email_config
const update_email_config = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    let createdby = req.user.id;
    const { errors, isValid } = createEmailConfigValidator({...req.body, org_id});

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "update_email_config";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let exists_data = await con.query(
      `SELECT timesheets.get_email_config_by_org_id($1)`,
      [org_id]
    );
    exists_data =
      (exists_data &&
        exists_data.rows[0].get_email_config_by_org_id &&
        exists_data.rows[0].get_email_config_by_org_id[0]) ||
      null;
    let id = (exists_data && exists_data.id) || null;

    // console.log("exists_data", JSON.stringify(exists_data));
    if (exists_data && exists_data.id) {
      await con.query(
        `SELECT timesheets.update_email_config($1,$2,$3,$4,$5)`,
        [
          id,
          org_id,
          req.body.from_email,
          req.user.id,
          req.body.record_type_status,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_email_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].update_email_config &&
                results.rows[1].update_email_config[0]) ||
              null;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    } else {
      await con.query(
        `SELECT timesheets.insert_email_config($1,$2,$3,$4)`,
        [org_id, req.body.from_email, createdby, req.body.record_type_status],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "update_email_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].insert_email_config &&
                results.rows[1].insert_email_config[0]) ||
              null;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "update_email_config";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_email_config_by_org_id,
  update_email_config,
};
