const errMiddleware = (req, res, next) => {
  if (!req.user) {
    return res.status(400).json({ error: "User information not found!" });
  }
  next();
};

module.exports = { errMiddleware: errMiddleware };
