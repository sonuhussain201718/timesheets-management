const { getMsgFormat, isEmpty } = require("../utils/helpers");
const employeeDocumentTypeValidator = require("../validation/employeeDocumentTypeValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const axios = require("axios");

// GET api for employee_document_types List
const get_all_employee_document_types = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_employee_document_types($1,$2);`,
      [req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch all employee document type details";
          returnMessage.error = error;
          returnMessage.label = "get_all_employee_document_types";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_employee_document_types";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_employee_document_types_by_id
const get_employee_document_types_by_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_employee_document_types_by_id($1)`,
      [req.query.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch annoucement details";
          returnMessage.error = error;
          returnMessage.label = "get_employee_document_types_by_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employee_document_types_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// // INSERT api for employee_document_types
const insert_employee_document_type = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = employeeDocumentTypeValidator(req.body);

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "employeeDocumentTypeValidator";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already document_type
    let document_type_exists = await con.query(
      `SELECT timesheets.get_employee_document_types_by_document_type_name($1)`,
      [req.body.document_type_name]
    );
    document_type_exists =
      (document_type_exists &&
        document_type_exists.rows[0]
          .get_employee_document_types_by_document_type_name &&
        document_type_exists.rows[0]
          .get_employee_document_types_by_document_type_name[0]) ||
      null;
    if (document_type_exists && document_type_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "document_type_name already exists";
      returnMessage.error = { email: "document_type_name already exists" };
      returnMessage.label = "insert_employee_document_type";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.insert_employee_document_types($1,$2,$3,$4)`,
        [
          req.body.document_type_name,
          req.body.description,
          req.body.createdby,
          req.body.record_type_status,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insert_employee_document_types";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message =
              results.rows[0].insert_employee_document_types[0].message;
            returnMessage.data = results.rows[1].insert_employee_document_types;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insert_employee_document_types";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for employee_document_types
const update_employee_document_types = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = employeeDocumentTypeValidator(req.body);

    let document_type_exists = false;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "editannoucements validation";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already document_type
    let document_type_name = req.body.document_type_name;
    if (document_type_name) {
      document_type_exists = await con.query(
        `SELECT timesheets.get_employee_document_types_by_document_type_name_excluding_id($1,$2)`,
        [req.body.id, document_type_name]
      );
      document_type_exists =
        (document_type_exists &&
          document_type_exists.rows[0]
            .get_employee_document_types_by_document_type_name_excluding_id &&
          document_type_exists.rows[0]
            .get_employee_document_types_by_document_type_name_excluding_id[0]) ||
        null;
    }

    if (
      document_type_exists &&
      document_type_exists.id &&
      document_type_exists.id != req.body.id
    ) {
      returnMessage.isError = true;
      returnMessage.message = "document_type_name already exists";
      returnMessage.error = {
        document_type_name: "document_type_name already exists",
      };
      returnMessage.label = "insert_employee_document_type";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.update_employee_document_types($1,$2,$3,$4,$5)`,
        [
          req.body.id,
          req.body.document_type_name,
          req.body.description,
          req.body.updatedby,
          req.body.record_type_status,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_employee_document_types";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.response =
              results.rows[0].update_employee_document_types;
            returnMessage.data = results.rows[1].update_employee_document_types;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "update_employee_document_types";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// DELETE api for employee_document_type
const delete_employee_document_type = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_employee_document_type($1);`,
      [req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete timesheet document";
          returnMessage.error = error;
          returnMessage.label = "delete_employee_document_type";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_employee_document_type";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_employee_document_types_list
const get_employee_document_types_list = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_employee_document_types_list();`,
      [],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch users list";
          returnMessage.error = error;
          returnMessage.label = "get_employee_document_types_list";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employee_document_types_list";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_all_employee_document_types,
  get_employee_document_types_by_id,
  insert_employee_document_type,
  update_employee_document_types,
  delete_employee_document_type,
  get_employee_document_types_list,
};
