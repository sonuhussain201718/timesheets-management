const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_email_config_by_org_id,
  update_email_config,
} = require("../../controllers/emailConfigController");

// @route GET api/v1/emailconfig/get_annoucement_by_id
// @desc  Route to get emailconfig by id
// @accesss public
router.get("/getemailconfig_by_orgid", get_email_config_by_org_id);

// @route GET api/v1/emailconfig/get_annoucement_by_id
// @desc  Route to get emailconfig by id
// @accesss public
router.post("/update_email_config", update_email_config);

module.exports = router;
