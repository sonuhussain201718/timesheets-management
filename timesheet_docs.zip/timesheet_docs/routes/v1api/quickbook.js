const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getcustomerdata,
  getcustomerdatabyname,
  updatecustomerdata,
  addcustomerdata,
  getvendordata,
  getvendordatabyname,
  addvendordata,
  getemployeedata,
  addemployeedata,
  updateemployeedata,
  getemployeedatabyname,
  gettimeactivitydata,
  createtimeactivity,
  gettimeactivitydatabyid,
  updatetimeactivity,
  deletetimeactivity,
  getitemdata,
  createitem,
  getitemdatabyname,
  updateitem,
  get_all_qb_logs,
  get_qb_logs_filter,
  get_quickbook_config,
  update_quickbook_config,
  get_qb_logs_api_names,
} = require("../../controllers/quickbookController");

// @route GET api/v1/quickbook/getcustomerdata
// @desc  Route to get all customers
// @accesss public
router.get("/getcustomerdata", getcustomerdata);

// @route GET api/v1/quickbook/getcustomerdatabyname
// @desc  Route to get customers by id
// @accesss public
router.get("/getcustomerdatabyname", getcustomerdatabyname);

// @route PUT api/v1/quickbook/updatecustomerdata
// @desc  Route to update customers
// @accesss public
router.put("/updatecustomerdata", updatecustomerdata);

// @route POST api/v1/quickbook/addcustomerdata
// @desc  Route to add customers
// @accesss public
router.post("/addcustomerdata", addcustomerdata);

// @route GET api/v1/quickbook/getvendordata
// @desc  Route to get all vendors
// @accesss public
router.get("/getvendordata", getvendordata);

// @route GET api/v1/quickbook/getvendordatabyname
// @desc  Route to get all vendors
// @accesss public
router.get("/getvendordatabyname", getvendordatabyname);

// @route POST api/v1/quickbook/addvendordata
// @desc  Route to add vendors
// @accesss public
router.post("/addvendordata", addvendordata);

// @route GET api/v1/quickbook/getemployeedata
// @desc  Route to get all employees
// @accesss public
router.get("/getemployeedata", getemployeedata);

// @route POST api/v1/quickbook/addemployeedata
// @desc  Route to add employee
// @accesss public
router.post("/addemployeedata", addemployeedata);

// @route PUT api/v1/quickbook/updateemployeedata
// @desc  Route to update employee
// @accesss public
router.put("/updateemployeedata", updateemployeedata);

// @route GET api/v1/quickbook/getemployeedatabyid
// @desc  Route to get all vendors
// @accesss public
router.post("/getemployeedatabyname", getemployeedatabyname);

// @route GET api/v1/quickbook/gettimeactivitydata
// @desc  Route to get all time activities
// @accesss public
router.get("/gettimeactivitydata", gettimeactivitydata);

// @route POST api/v1/quickbook/createtimeactivity
// @desc  Route to add timeactivity
// @accesss public
router.post("/createtimeactivity", createtimeactivity);

// @route GET api/v1/quickbook/gettimeactivitydatabyid
// @desc  Route to get all time activities
// @accesss public
router.get("/gettimeactivitydatabyid", gettimeactivitydatabyid);

// @route PUT api/v1/quickbook/updatetimeactivity
// @desc  Route to update time activity
// @accesss public
router.put("/updatetimeactivity", updatetimeactivity);

// @route DELETE api/v1/quickbook/deletetimeactivity
// @desc  Route to delete time activity
// @accesss public
router.delete("/deletetimeactivity", deletetimeactivity);

// @route GET api/v1/quickbook/getitemdata
// @desc  Route to get all item
// @accesss public
router.get("/getitemdata", getitemdata);

// @route POST api/v1/quickbook/createitem
// @desc  Route to add item
// @accesss public
router.post("/createitem", createitem);

// @route GET api/v1/quickbook/getitemdatabyname
// @desc  Route to get all item
// @accesss public
router.get("/getitemdatabyname", getitemdatabyname);

// @route PUT api/v1/quickbook/updateitem
// @desc  Route to update item
// @accesss public
router.put("/updateitem", updateitem);

// @route GET api/v1/quickbook/get_all_qb_logs
// @desc  Route to get_all_qb_logs item
// @accesss public
router.get("/get_all_qb_logs", get_all_qb_logs);

// @route GET api/v1/quickbook/get_qb_logs_filter
// @desc  Route to get_qb_logs_filter item
// @accesss public
router.get("/get_qb_logs_filter", get_qb_logs_filter);

//  @route GET api/vi/quickbook/get_quickbook_config
//  @desc Route to get_quickbook_config
//  @access public
router.get("/get_quickbook_config", get_quickbook_config);

// @route POST api/v1/quickbook/update_quickbook_config
// @desc  Route to update_quickbook_config
// @accesss public
router.post("/update_quickbook_config", update_quickbook_config);

// @route GET api/v1/quickbook/get_qb_logs_api_names
// @desc  Route to get_qb_logs_api_names item
// @accesss public
router.get("/get_qb_logs_api_names", get_qb_logs_api_names);

module.exports = router;
