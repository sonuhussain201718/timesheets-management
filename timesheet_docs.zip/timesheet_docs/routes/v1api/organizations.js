const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getallorganizations,
  get_organization_by_id,
  get_organization_by_org_id,
  insertorganization,
  editorganization,
  edit_organization_setting,
  update_organization_qb_setting,
  update_organization_adp_setting,
  update_organization_weekly_reminder_setting,
  get_qb_transaction_names,
  get_qb_transactions_setting,
  get_qb_transactions_setting_by_name,
  get_client_manager_mandatory,
  update_organization_hours_setting,
  update_organization_email_setting
} = require("../../controllers/organizationsController");

// @route GET api/v1/organizations/getallorganizations
// @desc  Route to get all organizations
// @accesss public
router.get("/getallorganizations", getallorganizations);

// @route GET api/v1/organizations/get_organization_by_id
// @desc  Route to get organization by id
// @accesss public
router.get("/get_organization_by_id", get_organization_by_id);

// @route GET api/v1/organizations/get_organization_by_org_id
// @desc  Route to get organization by org_id
// @accesss public
router.get("/get_organization_by_org_id", get_organization_by_org_id);

// @route POST api/v1/organizations/insertorganizations
// @desc  Route to post organizations
// @accesss public
router.post("/insertorganization", insertorganization);

// @route PUT api/v1/organizations/editorganization
// @desc  Route to edit organizations
// @accesss public
router.put("/editorganization", editorganization);

// @route PUT api/v1/organizations/edit_organization_setting
// @desc  Route to edit organizations
// @accesss public
router.put("/edit_organization_setting", edit_organization_setting);

// @route PUT api/v1/organizations/update_organization_qb_setting
// @desc  Route to edit organization qb setting
// @accesss public
router.put("/update_organization_qb_setting", update_organization_qb_setting);

// @route PUT api/v1/organizations/update_organization_adp_setting
// @desc  Route to edit organization adp setting
// @accesss public
router.put("/update_organization_adp_setting", update_organization_adp_setting);

// @route PUT api/v1/organizations/update_organization_weekly_reminder_setting
// @desc  Route to update organization weekly reminder setting
// @accesss public
router.put("/update_organization_weekly_reminder_setting", update_organization_weekly_reminder_setting);

// @route GET api/v1/organizations/get_qb_transaction_names
// @desc  Route to get qb transaction names
// @accesss public
router.get("/get_qb_transaction_names", get_qb_transaction_names);

// @route GET api/v1/organizations/get_qb_transactions_setting
// @desc  Route to get qb transactions setting
// @accesss public
router.get("/get_qb_transactions_setting", get_qb_transactions_setting);

// @route GET api/v1/organizations/get_qb_transactions_setting_by_name
// @desc  Route to get_qb_transactions_setting_by_name
// @accesss public
router.get("/get_qb_transactions_setting_by_name", get_qb_transactions_setting_by_name);

// @route GET api/v1/organizations/get_client_manager_mandatory
// @desc  Route to get_client_manager_mandatory
// @accesss public
router.get("/get_client_manager_mandatory", get_client_manager_mandatory);

// @route PUT api/v1/organizations/update_organization_hours_setting
// @desc  Route to update_organization_hours_setting
// @accesss public
router.put("/update_organization_hours_setting", update_organization_hours_setting);

// @route PUT api/v1/organizations/update_organization_email_setting
// @desc  Route to update_organization_email_setting
// @accesss public
router.put("/update_organization_email_setting", update_organization_email_setting);

module.exports = router;
