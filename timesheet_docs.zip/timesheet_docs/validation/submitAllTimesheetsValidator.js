const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function submitAllTimesheetsValidator(data) {
  let errors = {};

  if (validator.isEmpty(String(data.org_id))) {
    errors.org_id = "org_id field is required";
  }

  if (!data.year) {
    errors.year = "year field is required";
  }

  if (!data.month) {
    errors.month = "month field is required";
  }

  if (!data.week_start_date) {
    errors.week_start_date = "week_start_date field is required";
  }

  if (!data.week_end_date) {
    errors.week_end_date = "week_end_date field is required";
  }

  if (!data.timesheets) {
    errors.timesheets = "timesheets field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
