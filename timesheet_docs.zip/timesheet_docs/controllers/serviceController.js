const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createServiceValidator = require("../validation/createServiceValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
con.connect();

// GET api for services List
const getallservices = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_services($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch service details";
          returnMessage.error = error;
          returnMessage.label = "getallservices";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallservices";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for services List
const getservicebyid = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_service_by_id($1,$2)`,
      [req.user.org_id, req.query.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch service details";
          returnMessage.error = error;
          returnMessage.label = "getservicebyid";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getservicebyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for service
const insertService = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createServiceValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insertService";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    await con.query(
      `SELECT timesheets.insert_services($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)`,
      [
        req.body.createdby,
        req.body.modified_person_name,
        req.body.org_id,
        req.body.project_name,
        req.body.project_id,
        req.body.qb_id,
        req.body.qb_service_name,
        req.body.record_type_status,
        req.body.service_name,
        req.body.service_id,
        req.body.status,
        req.body.status_code,
        req.body.terminate_reason,
        req.body.terminate_reason_id,
        req.body.terminate_date,
        req.body.terminate_person_name,
        req.body.description,
        req.body.product_information,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to Add";
          returnMessage.error = error;
          returnMessage.label = "insertService";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.response = results.rows[0].insert_services;
          returnMessage.data = results.rows[1].insert_services;
          returnMessage.message = "Added Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insertService";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for services
const editservice = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createServiceValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "editservice";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    await con.query(
      `SELECT timesheets.update_services($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)`,
      [
        req.body.id,
        req.body.modified_person_name,
        req.body.org_id,
        req.body.project_name,
        req.body.project_id,
        req.body.qb_id,
        req.body.qb_service_name,
        req.body.record_type_status,
        req.body.service_name,
        req.body.service_id,
        req.body.status,
        req.body.status_code,
        req.body.terminate_reason,
        req.body.terminate_reason_id,
        req.body.terminate_date,
        req.body.terminate_person_name,
        req.body.updatedby,
        req.body.description,
        req.body.product_information,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to update";
          returnMessage.error = error;
          returnMessage.label = "editservice";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.data = results.rows[1].update_services;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "editservice";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// DELETE api for services
const deleteservice = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT timesheets.delete_service($1)`,
      [req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete";
          returnMessage.error = error;
          returnMessage.label = "deleteservice";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "deleteservice";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getallservices,
  insertService,
  editservice,
  deleteservice,
  getservicebyid,
};
