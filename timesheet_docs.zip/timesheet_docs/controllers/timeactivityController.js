const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createTimeActivityValidator = require("../validation/createTimeActivityValidator");
const createTimedocValidator = require("../validation/createTimedocValidator");
const con = require("../utils/db");
const logger = require("../utils/logger");
const { getBlobUrl } = require("../utils/helpers");

const axios = require("axios");
const qbodata = require("../utils/qb");
const moment = require("moment");
const {
  ApproveEmail,
  RejectEmail,
  SubmittedEmail,
  PendingEmail,
} = require("../Email/email");
con.connect();

// GET api for timeactivity List
const getalltimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_timesheets($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getalltimeactivity";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivity";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

function pad(d) {
  return d < 10 ? "0" + d.toString() : d.toString();
}

// GET api for timeactivity by week
const getalltimeactivitybyweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var week = req.query.week;
    await con.query(
      `SELECT * from timesheets.get_timesheet_by_week($1,$2,$3);`,
      [req.user.org_id, req.user.email, req.query.week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getalltimeactivitybyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          const grouped = Object.values(
            data.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivitybyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by status
const getalltimeactivitybystatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var data1 = [];
    var status = req.query.status;
    await con.query(
      `SELECT * from timesheets.get_timesheets_by_status($1,$2,$3);`,
      [req.user.org_id, req.user.email, req.query.status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by status details";
          returnMessage.error = error;
          returnMessage.label = "getalltimeactivitybystatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[1].j;
          data.forEach(function (item, index) {
            if (item.status == status) {
              data1.push(item.employee_name);
            } else if (item.status != status) {
              data1.push(item.employee_name);
            } else {
              data1 = [];
            }
          });
          var result = data1.reduce((unique, o) => {
            if (!unique.some((obj) => obj.employee_name === o.employee_name)) {
              unique.push(o);
            }
            return unique;
          }, []);
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivitybystatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity List
const getalltimeactivityweekwise = async (req, res) => {
  const returnMessage = getMsgFormat();
  const month = req.query.month ? req.query.month : moment().format("MMMM");
  const prevMonth = moment(req.query.month).subtract(1, "M").format("MMMM")
    ? moment(req.query.nextMonth).subtract(1, "M").format("MMMM")
    : moment().subtract(1, "M").format("MMMM");
  const nextMonth = moment(req.query.month).add(1, "M").format("MMMM")
    ? moment(req.query.nextMonth).add(1, "M").format("MMMM")
    : moment().add(1, "M").format("MMMM");
  const year = req.query.year ? req.query.year : moment().format("YYYY");
  try {
    var finalres = [];
    await con.query(
      `SELECT * from timesheets.get_all_vw_weekly_timesheet($1,$2,$3,$4,$5,$6)`,
      [
        req.user.org_id,
        req.user.email,
        month,
        year,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity weekly details";
          returnMessage.error = error;
          returnMessage.label = "getalltimeactivityweekwise";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          var arr = await con.query(
            `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
            [req.user.org_id, req.user.email]
          );
          var output = arr.rows[0].j;
          var data = [];
          output.forEach(function (item) {
            var data1 = {
              project_name: item.project_name,
              employee_name: item.employee_name,
              week: "",
              month: month,
              year: year,
              user_email: req.user.email,
              client_name: item.client_name,
              client_manager_name: item.client_manager_name,
              client_manager_email: item.client_manager_email,
              status: "No Entry",
              row_number: 0,
              year_week_number: `${moment(year).format("YYYY")}_${moment(
                month
              ).format("MM")}`,
              org_id: req.user.org_id,
              total_regular_hours: "00:00",
              total_ot_hours: "00:00",
              regular_and_ot_hours: "00:00",
              total_regular_minutes: "00:00",
              total_ot_minutes: "00:00",
              regular_and_ot_minutes: "00:00",
              total_hours_minutes: "00:00",
            };
            data.push(data1);
          });
          finalres.push(data);
        } else {
          finalres.push(results.rows[1].j);
        }
        returnMessage.isError = false;
        returnMessage.message = "Records Found";
        returnMessage.data = finalres[0];
        returnMessage.count = results.rows[2].j;
        res.status(200).json(returnMessage);
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivityweekwise";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity List Mobile API
const getalltimeactivityweekswise = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var month = req.query.startdate
      ? moment(req.query.startdate).format("MMMM")
      : moment().format("MM");
    var year = req.query.startdate
      ? moment(req.query.startdate).format("YYYY")
      : moment().format("YYYY");
    var startdate = req.query.startdate
      ? req.query.startdate
      : moment().utc().weekday(1);
    var enddate = req.query.enddate
      ? req.query.enddate
      : moment().utc().weekday(7);
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var prevCount = req.query.prevCount ? req.query.prevCount : 0;
    var nextCount = req.query.nextCount ? req.query.nextCount : 0;
    var weeknumber = moment(startdate).week();
    var prevWeekCount = parseInt(weeknumber) - parseInt(prevCount);
    var nextWeekCount = parseInt(weeknumber) + parseInt(nextCount);
    moment.updateLocale("en", {
      week: {
        dow: 1, // Monday is the first day of the week.
      },
    });
    var startweek = moment().week(prevWeekCount).startOf("week");
    var endweek = moment().week(nextWeekCount).endOf("week");
    function getTwoDatesBetweenDates(startweek, endweek) {
      var now = startweek;
      var getDates = [];

      while (now.isSameOrBefore(endweek)) {
        getDates.push(now.format("YYYY-MM-DD"));
        now.add(1, "days");
      }
      return getDates;
    }
    var dateList = getTwoDatesBetweenDates(startweek, endweek);
    var weekdates = [];
    var subarraylength = dateList.length / 7;
    var count = dateList.length / subarraylength;
    for (i = 0; i < dateList.length; i++) {
      var newsubarray = dateList.splice(0, count);
      weekdates.push(newsubarray);
    }
    var allweeks = weekdates;
    var weeks = [];
    for (i = 0; i < allweeks.length; i++) {
      var startweek = moment(allweeks[i][0]).format("YYYY-MM-DD");
      var endweek = moment(allweeks[i][6]).format("YYYY-MM-DD");
      var startweekdate = `${startweek}T00:00:00Z`;
      var endweekdate = `${endweek}T00:00:00Z`;
      var week = `${startweekdate}-${endweekdate}`;
      weeks.push(week);
    }
    var result = [];
    weeks.forEach(async function (week) {
      await con.query(
        `SELECT * from timesheets.get_timesheet_by_week($1,$2,$3);`,
        [req.user.org_id, req.user.email, week],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message =
              "Failed to fetch timeactivity weekly details";
            returnMessage.error = error;
            returnMessage.label = "getalltimeactivityweekswise";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            var arr = await con.query(
              `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
              [req.user.org_id, req.user.email]
            );
            var output = arr.rows[0].j;
            var data = [];
            output.forEach(function (item) {
              var data1 = [
                {
                  project_name: item.project_name,
                  employee_name: item.employee_name,
                  week: week,
                  user_email: req.user.email,
                  client_name: item.client_name,
                  client_manager_name: item.client_manager_name,
                  client_manager_email: item.client_manager_email,
                },
              ];
              data.push(data1);
            });
            result.push({ week: week, projects: data });
          } else {
            var data = results.rows[0].j;
            const grouped = Object.values(
              data.reduce((acc, item) => {
                acc[item.project_name] = [
                  ...(acc[item.project_name] || []),
                  item,
                ];
                return acc;
              }, {})
            );
            result.push({
              week: week,
              projects: grouped,
            });
          }
          if (result.length == weeks.length) {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = result;
            res.status(200).json(returnMessage);
          }
        }
      );
    });
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivityweekwise";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by given weeks Mobile API
const getalltimeactivitybyweeks = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var project = req.query.project_name;
    var startdate = req.query.startdate
      ? req.query.startdate
      : moment().utc().weekday(1);
    var enddate = req.query.enddate
      ? req.query.enddate
      : moment().utc().weekday(7);
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var prevCount = req.query.prevCount ? req.query.prevCount : 0;
    var nextCount = req.query.nextCount ? req.query.nextCount : 0;
    var weeknumber = moment(startdate).week();
    var prevWeekCount = parseInt(weeknumber) - parseInt(prevCount);
    var nextWeekCount = parseInt(weeknumber) + parseInt(nextCount);
    moment.updateLocale("en", {
      week: {
        dow: 1, // Monday is the first day of the week.
      },
    });
    var startweek = moment().week(prevWeekCount).startOf("week");
    var endweek = moment().week(nextWeekCount).endOf("week");
    function getTwoDatesBetweenDates(startweek, endweek) {
      var now = startweek;
      var getDates = [];

      while (now.isSameOrBefore(endweek)) {
        getDates.push(now.format("YYYY-MM-DD"));
        now.add(1, "days");
      }
      return getDates;
    }
    var dateList = getTwoDatesBetweenDates(startweek, endweek);
    var weekdates = [];
    var subarraylength = dateList.length / 7;
    var count = dateList.length / subarraylength;
    for (i = 0; i < dateList.length; i++) {
      var newsubarray = dateList.splice(0, count);
      weekdates.push(newsubarray);
    }
    var allweeks = weekdates;
    var weeks = [];
    for (i = 0; i < allweeks.length; i++) {
      var startweek = moment(allweeks[i][0]).format("YYYY-MM-DD");
      var endweek = moment(allweeks[i][6]).format("YYYY-MM-DD");
      var startweekdate = `${startweek}T00:00:00Z`;
      var endweekdate = `${endweek}T00:00:00Z`;
      var week = `${startweekdate}-${endweekdate}`;
      weeks.push(week);
    }
    // res.send(weeks);
    var result = [];
    weeks.forEach(async function (week) {
      await con.query(
        `SELECT * from timesheets.get_timesheet_by_weeks($1,$2,$3,$4);`,
        [req.user.org_id, req.user.email, week, project],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message =
              "Failed to fetch timeactivity by week details";
            returnMessage.error = error;
            returnMessage.label = "getalltimeactivitybyweek";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            result.push({
              week: week,
              days: [],
            });
          } else {
            var data = results.rows[0].j;
            data.forEach(function (item, index) {
              item.regular_hours < 10 && item.regular_hours != null
                ? (data[index].regular_hours = "0" + item.regular_hours)
                : item.regular_hours >= 10
                ? (data[index].regular_hours = item.regular_hours.toString())
                : item.regular_hours == null
                ? (data[index].regular_hours = 0)
                : item.ot_hours == 0
                ? (data[index].regular_hours = "00")
                : "00";
              item.regular_minutes < 10 && item.regular_minutes != null
                ? (data[index].regular_minutes = "0" + item.regular_minutes)
                : item.regular_minutes >= 10
                ? (data[index].regular_minutes = item.regular_minutes)
                : item.regular_minutes == null
                ? (data[index].regular_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].regular_minutes = "00")
                : "00";
              item.ot_hours < 10 && item.ot_hours != null
                ? (data[index].ot_hours = "0" + item.ot_hours)
                : item.ot_hours >= 10
                ? (data[index].ot_hours = item.ot_hours)
                : item.ot_hours == null
                ? (data[index].ot_hours = 0)
                : item.ot_hours == 0
                ? (data[index].absent_minutes = "00")
                : "00";
              item.ot_minutes < 10 && item.ot_minutes != null
                ? (data[index].ot_minutes = "0" + item.ot_minutes)
                : item.ot_minutes >= 10
                ? (data[index].ot_minutes = item.ot_minutes)
                : item.ot_minutes == null
                ? (data[index].ot_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].ot_minutes = "00")
                : "00";
              item.absent_hours < 10 && item.absent_hours != null
                ? (data[index].absent_hours = "0" + item.absent_hours)
                : item.absent_hours >= 10
                ? (data[index].absent_hours = item.absent_hours)
                : item.absent_hours == null
                ? (data[index].absent_hours = 0)
                : item.ot_hours == 0
                ? (data[index].absent_hours = "00")
                : "00";
              item.absent_minutes < 10 && item.absent_minutes != null
                ? (data[index].absent_minutes = "0" + item.absent_minutes)
                : item.absent_minutes >= 10
                ? (data[index].absent_minutes = item.absent_minutes)
                : item.absent_minutes == null
                ? (data[index].absent_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].absent_minutes = "00")
                : "00";
            });
            // const grouped = Object.values(
            //   data.reduce((acc, item) => {
            //     acc[item.project_name] = [
            //       ...(acc[item.project_name] || []),
            //       item,
            //     ];
            //     return acc;
            //   }, {})
            // );
            result.push({
              week: week,
              days: data,
            });
          }
          if (result.length == weeks.length) {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = result;
            res.status(200).json(returnMessage);
          }
        }
      );
    });
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivitybyweeks";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for employee projects List
const getemployeeprojects = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
      [req.user.org_id, req.user.email],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch employee project details";
          returnMessage.error = error;
          returnMessage.label = "getemployeeprojects";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var arr = results.rows[0].j;
          var result = arr.reduce((unique, o) => {
            if (!unique.some((obj) => obj.project_name === o.project_name)) {
              unique.push(o);
            }
            return unique;
          }, []);
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getemployeeprojects";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity List
const gettimeactivitybyid = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheets_by_id($1,$2,$3)`,
      [req.query.id, req.user.org_id, req.user.email],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimeactivitybyid";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimeactivitybyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT & update api for timeactivity
const insertupdatetimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var data = req.body;
    var jsondata = JSON.stringify(data);
    const result = await con.query(
      `SELECT timesheets.sync_timesheet_data($1,$2)`,
      [252, jsondata]
    );
    returnMessage.isError = false;
    returnMessage.message = "Data Inserted/Updated Successfully";
    returnMessage.data = result.rows[0];
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Data Inserted/Updated Failed";
    res.status(400).send(returnMessage);
  }
};

// INSERT api for timeactivity
const inserttimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var org_id = req.user.org_id;
    var qbo = await qbodata(org_id);
    var data = req.body;
    var employee_name = data[0].employee_name;
    var project_name = data[0].project_name;
    if (
      (project_name != null ||
        project_name != undefined ||
        project_name != "") &&
      (employee_name != null ||
        employee_name != undefined ||
        employee_name != "")
    ) {
      const qb_result = await con.query(
        `SELECT timesheets.get_vw_qb_id_and_name_by_emp_name2($1,$2,$3)`,
        [req.user.org_id, employee_name, project_name]
      );
      var qb_data = qb_result.rows[1].get_vw_qb_id_and_name_by_emp_name2;
      if (!isEmpty(qb_data)) {
        data.forEach((element, index) => {
          qb_data.find((item) => {
            if (element.project_name == item.project_name) {
              var data = {
                TxnDate: element.timesheet_date,
                NameOf: "Employee",
                EmployeeRef: {
                  value: parseInt(item.qb_employee_id),
                  name: item.qb_employee_name,
                },
                CustomerRef: {
                  value: parseInt(item.qb_customer_id),
                  name: item.qb_customer_name,
                },
                ItemRef: {
                  value: parseInt(item.qb_product_id),
                  name: item.qb_product_name,
                },
                HourlyRate: 8,
                Hours: parseInt(element.regular_hours),
                Minutes: parseInt(element.regular_minutes),
                Description: element.approver_comments,
              };
              qbo.createTimeActivity(data, function (e, timeactivity) {
                if (e) {
                } else {
                }
              });
            } else {
              returnMessage.isError = false;
              returnMessage.message = "Please provide valid quickBook Details";
              res.status(400).send(returnMessage);
            }
          });
        });
      } else {
        returnMessage.isError = false;
        returnMessage.message = "QuickBook details not found";
        res.status(400).send(returnMessage);
      }
    } else {
      returnMessage.isError = false;
      returnMessage.message = "Project name or Employee name not found";
      res.status(400).send(returnMessage);
    }
    returnMessage.isError = false;
    returnMessage.message = "Timesheet created successfully";
    res.status(200).send(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured !";
    res.status(500).send(returnMessage);
  }
};

// INSERT api for timeactivity
const insertalltimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var data1 = req.body;
    const data = [].concat(...data1);
    data.forEach(function (item, index) {
      data[index].approver_id = parseInt(item.approver_id);
      data[index].day_status_hours = parseInt(item.day_status_hours);
      data[index].org_id = parseInt(item.org_id);
      data[index].regular_hours = parseInt(item.regular_hours);
      data[index].regular_minutes = parseInt(item.regular_minutes);
      data[index].ot_hours = parseInt(item.ot_hours);
      data[index].ot_minutes = parseInt(item.ot_minutes);
      data[index].project_id = parseInt(item.project_id);
      data[index].qb_timesheet_id = parseInt(item.qb_timesheet_id);
      data[index].user_id = parseInt(item.user_id);
      data[index].absent_hours = parseInt(item.absent_hours);
      data[index].absent_minutes = parseInt(item.absent_minutes);
      data[index].absent_type = parseInt(item.absent_type);
    });
    var jsondata = JSON.stringify(data);
    const result = await con.query(
      `SELECT timesheets.sync_timesheet_data($1,$2)`,
      [req.user.org_id, jsondata],
      function (err, results) {
        if (err) {
          returnMessage.isError = false;
          returnMessage.message = "Data Synced Failed";
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Data Synced Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Data Sync Failed";
    res.status(400).send(returnMessage);
  }
};
//status email
const sendstatusemail = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var data = req.body;
    if (data.week_status == "Waiting For Approval") {
      console.log("Waiting For Approval");
      SubmittedEmail(data);
    } else if (data.week_status == "Approved") {
      console.log("Approved");
      ApproveEmail(data);
    } else if (data.week_status == "Rejected") {
      console.log("Rejected");
      RejectEmail(data);
    }
  } catch (e) {
    console.log(e);
    returnMessage.isError = false;
    returnMessage.message = "Error Occured!";
    res.status(200).json(returnMessage);
  }
};
//cron job for pending email
// const pendingemailfromapprover = async (req, res) => {
//   const returnMessage = getMsgFormat();
//   try {
//     // cron job
//     new CronJob(
//       "* *  * * *",
//       function () {
//         PendingEmail(maildata);
//       },
//       null,
//       true,
//       "Asia/Kolkata"
//     );
//   } catch (e) {
//     returnMessage.isError = false;
//     returnMessage.message = "Error Occured!";
//     res.status(200).json(returnMessage);
//   }
// };
// EDIT api for timeactivity
const edittimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createTimeActivityValidator(req.body);

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edittimeactivity";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
    await con.query(
      `SELECT timesheets.update_timesheet_history_and_status($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28)`,
      [
        req.body.id,
        req.body.approver_id,
        req.body.approver_notes,
        req.body.client_name,
        req.body.day_status,
        req.body.day_status_hours,
        req.body.employee_name,
        req.body.end_customer,
        req.body.history,
        req.body.notes,
        req.body.name_of_employee,
        req.body.org_id,
        req.body.ot_hours,
        req.body.ot_minutes,
        req.body.project_id,
        req.body.project_name,
        req.body.qb_timesheet_id,
        req.body.regular_hours,
        req.body.regular_minutes,
        req.body.record_type_status,
        req.body.status,
        req.body.service_name,
        req.body.timesheet_date,
        req.body.user_id,
        req.body.updatedby,
        req.body.client_manager_email,
        req.body.client_manager_name,
        req.body.createdby,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to update";
          returnMessage.error = error;
          returnMessage.label = "edittimeactivity";
          logger.log({
            level: "error",
            message: returnMessage,
          });
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "edittimeactivity";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for filter timeactivity
const filtertimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (req.query.client_name == undefined || req.query.client_name == "") {
      req.query.client_name = null;
    }
    if (req.query.status == undefined || req.query.status == "") {
      req.query.status = null;
    }
    if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
      req.query.pagenumber = null;
    }
    if (req.query.pagesize == undefined || req.query.pagesize == "") {
      req.query.pagenumber = null;
    }
    await con.query(
      `SELECT * from timesheets.get_timesheets_filter($1,$2,$3,$4,$5,$6)`,
      [
        req.query.client_name,
        req.query.status,
        req.user.org_id,
        req.user.email,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to filter timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "filtertimeactivity";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "filtertimeactivity";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timedoc List
const getalltimedoc = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_timesheet_documents($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timedoc details";
          returnMessage.error = error;
          returnMessage.label = "getalltimedoc";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimedoc";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timedoc by id
const gettimedocbyid = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_docs_by_id($1,$2)`,
      [req.query.id, req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timedoc details";
          returnMessage.error = error;
          returnMessage.label = "gettimedocbyid";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimedocbyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timehistory List
const getalltimehistory = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_timesheet_history($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.user.email,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timehistory details";
          returnMessage.error = error;
          returnMessage.label = "getalltimehistory";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimehistory";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timestatus List
const getalltimestatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_timesheet_status($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.user.email,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timestatus details";
          returnMessage.error = error;
          returnMessage.label = "getalltimestatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimestatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gethouroftimesheetstatus
const gethouroftimesheetstatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_vw_status_hour_of_timesheet($1,$2)`,
      [req.user.org_id, req.user.email],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gethouroftimesheetstatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var arr = results.rows[0].j;
          const output = (arr) => {
            const obj = {};
            for (let i = 0; i < arr.length; i++) {
              arr[i].regular_and_ot_hours < 10 &&
              arr[i].regular_and_ot_hours != null
                ? (arr[i].regular_and_ot_hours =
                    "0" + arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours >= 10
                ? (arr[i].regular_and_ot_hours = arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours == null ||
                  arr[i].regular_and_ot_hours == 0
                ? (arr[i].regular_and_ot_hours = 0)
                : "00";
              arr[i].regular_and_ot_minutes < 10 &&
              arr[i].regular_and_ot_minutes != null
                ? (arr[i].regular_and_ot_minutes =
                    "0" + arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes >= 10
                ? (arr[i].regular_and_ot_minutes =
                    arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes == null ||
                  arr[i].regular_and_ot_minutes == 0
                ? (arr[i].regular_and_ot_minutes = 0)
                : "00";
              const { status, regular_and_ot_hours, regular_and_ot_minutes } =
                arr[i];
              if (
                status == "submit" ||
                status == "approve" ||
                status == "reject"
              )
                obj[
                  status
                ] = `${regular_and_ot_hours}:${regular_and_ot_minutes}`;
            }
            return obj;
          };
          var data = output(arr);
          var submitkey = data.hasOwnProperty("submit");
          var approvekey = data.hasOwnProperty("approve");
          var rejectkey = data.hasOwnProperty("reject");
          if (submitkey == false) {
            data["submit"] = "00:00";
          }
          if (approvekey == false) {
            data["approve"] = "00:00";
          }
          if (rejectkey == false) {
            data["reject"] = "00:00";
          }
          const result = Object.keys(data)
            .sort()
            .reduce((obj, key) => {
              obj[key] = data[key];
              return obj;
            }, {});
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gethouroftimesheetstatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gethouroftimesheetstatusbyweek
const gethouroftimesheetstatusbyweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_vw_status_hour_of_timesheet_week($1,$2,$3)`,
      [req.user.org_id, req.user.email, req.query.week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gethouroftimesheetstatusbyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var arr = results.rows[0].j;
          const output = (arr) => {
            const obj = {};
            for (let i = 0; i < arr.length; i++) {
              arr[i].regular_and_ot_hours < 10 &&
              arr[i].regular_and_ot_hours != null
                ? (arr[i].regular_and_ot_hours =
                    "0" + arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours >= 10
                ? (arr[i].regular_and_ot_hours = arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours == null ||
                  arr[i].regular_and_ot_hours == 0
                ? (arr[i].regular_and_ot_hours = 0)
                : "00";
              arr[i].regular_and_ot_minutes < 10 &&
              arr[i].regular_and_ot_minutes != null
                ? (arr[i].regular_and_ot_minutes =
                    "0" + arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes >= 10
                ? (arr[i].regular_and_ot_minutes =
                    arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes == null ||
                  arr[i].regular_and_ot_minutes == 0
                ? (arr[i].regular_and_ot_minutes = 0)
                : "00";
              const { status, regular_and_ot_hours, regular_and_ot_minutes } =
                arr[i];
              if (
                status == "submit" ||
                status == "approve" ||
                status == "reject"
              )
                obj[
                  status
                ] = `${regular_and_ot_hours}:${regular_and_ot_minutes}`;
            }
            return obj;
          };
          var data = output(arr);
          var submitkey = data.hasOwnProperty("submit");
          var approvekey = data.hasOwnProperty("approve");
          var rejectkey = data.hasOwnProperty("reject");
          if (submitkey == false) {
            data["submit"] = "00:00";
          }
          if (approvekey == false) {
            data["approve"] = "00:00";
          }
          if (rejectkey == false) {
            data["reject"] = "00:00";
          }
          const result = Object.keys(data)
            .sort()
            .reduce((obj, key) => {
              obj[key] = data[key];
              return obj;
            }, {});
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gethouroftimesheetstatusbyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gettimesheetsbyempname
const gettimesheetsbyempname = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var startdate = moment().utc().weekday(1).format("YYYY-MM-DD");
    var enddate = moment().utc().weekday(7).format("YYYY-MM-DD");
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var week = req.query.week ? req.query.week : weekdays;
    await con.query(
      `SELECT * from timesheets.get_timesheets_by_emp_name($1,$2,$3,$4)`,
      [req.user.org_id, req.user.email, req.query.employee_name, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheetsbyempname";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          const grouped = Object.values(
            data.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheetsbyempname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gettimesheetsbyprojectname
const gettimesheetsbyprojectname = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var startdate = moment().utc().weekday(1).format("YYYY-MM-DD");
    var enddate = moment().utc().weekday(7).format("YYYY-MM-DD");
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var week = req.query.week ? req.query.week : weekdays;
    await con.query(
      `SELECT * from timesheets.get_timesheets_by_project_name($1,$2,$3,$4)`,
      [req.user.org_id, req.user.email, req.query.project_name, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheetsbyprojectname";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          const grouped = Object.values(
            data.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheetsbyprojectname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gettimesheetsbyyearandmonth
const gettimesheetsbyyearandmonth = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var month = req.query.month
      ? moment().month(req.query.month).format("MMMM")
      : moment().format("MMMM");
    var month1 = req.query.month
      ? moment().month(req.query.month).format("MM")
      : moment().format("MM");
    var year = req.query.year
      ? moment().year(req.query.year).format("YYYY")
      : moment().format("YYYY");
    var date = `${year}-${month1}`;
    const months = moment(date, "YYYY-MM");
    const range = moment().range(
      moment(months).startOf("month").startOf("week"),
      moment(months).endOf("month").endOf("week")
    );
    const days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));
    dates = dates.map((x) => {
      return { timesheet_date: x };
    });
    await con.query(
      `SELECT * from timesheets.get_timesheets_by_month_year($1,$2,$3,$4,$5,$6)`,
      [
        req.user.org_id,
        req.query.employee_name,
        month,
        year,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        var arr = [];
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheetsbyyearandmonths";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          var arr = await con.query(
            `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
            [req.user.org_id, req.user.email]
          );
          var output = arr.rows[0].j;
          var result = [];
          output.forEach(function (item) {
            dates.forEach(function (date, i) {
              var data1 = {
                timesheet_date: date.timesheet_date,
                project_name: item.project_name,
                regular_hours: "00",
                regular_minutes: "00",
                ot_hours: "00",
                ot_minutes: "00",
                absent_hours: "00",
                absent_minutes: "00",
                status: "No",
              };
              result.push(data1);
            });
          });
          const grouped = Object.values(
            result.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[1].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          var projects = await con.query(
            `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
            [req.user.org_id, req.user.email]
          );
          var output = projects.rows[0].j;
          dates.forEach(function (date, i) {
            output.forEach(function (project, k) {
              let counter = 0;
              data.forEach(function (value, j) {
                if (
                  date.timesheet_date == value.timesheet_date &&
                  project.project_name == value.project_name
                ) {
                  arr.push(value);
                  counter = 1;
                }
              });
              if (counter == 0) {
                arr.push({
                  timesheet_date: date.timesheet_date,
                  project_name: project.project_name,
                  regular_hours: "00",
                  regular_minutes: "00",
                  ot_hours: "00",
                  ot_minutes: "00",
                  absent_hours: "00",
                  absent_minutes: "00",
                  status: "No Entry",
                });
              }
            });
          });

          const grouped = Object.values(
            arr.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheetsbyyearandmonths";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by email and week
const gettimesheethistorybyemailandweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_by_email_and_week($1,$2,$3,$4);`,
      [req.user.org_id, req.user.email, req.query.week, req.query.project_name],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheethistorybyemailandweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheethistorybyemailandweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by email and week
const gettimesheethistorybystatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_by_status($1,$2,$3);`,
      [req.user.org_id, req.user.email, req.query.project_name],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheethistorybystatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheethistorybystatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by email and week
const gettimesheethistorybyhours = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_by_hours($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.user.email,
        req.query.project_name,
        req.query.regular_hours,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheethistorybyhours";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheethistorybyhours";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by date
const getalltimeactivitybydate = async (req, res) => {
  const returnMessage = getMsgFormat();
  var date = `${req.query.date}T00:00:00Z`;
  var startdate = moment(date).utc().weekday(1).format();
  var enddate = moment(date).utc().weekday(7).format();
  var weekdate = `${startdate}-${enddate}`;
  try {
    var week = weekdate;
    await con.query(
      `SELECT * from timesheets.get_timesheet_by_week($1,$2,$3);`,
      [req.user.org_id, req.user.email, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getalltimeactivitybyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          const grouped = Object.values(
            data.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalltimeactivitybyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// ================ APPROVER API ==========================
// GET api for getapprovertimesheetsbyempname
const getapprovertimesheetsbyempname = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var data1 = [];
    var status = req.query.status;
    var startdate = moment()
      .utc()
      .subtract(1, "week")
      .weekday(1)
      .format("YYYY-MM-DD");
    var enddate = moment()
      .utc()
      .subtract(1, "week")
      .weekday(7)
      .format("YYYY-MM-DD");
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var week = req.query.week ? req.query.week : weekdays;
    await con.query(
      `SELECT * from timesheets.get_approver_timesheets_by_emp_name($1,$2,$3)`,
      [req.user.org_id, req.query.employee_name, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheetsbyempname";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            if (item.status == status) {
              data1.push(item);
            } else if (status == "all") {
              data1.push(item);
            }
          });
          if (data1.length > 0) {
            const grouped = Object.values(
              data.reduce((acc, item) => {
                acc[item.project_name] = [
                  ...(acc[item.project_name] || []),
                  item,
                ];
                return acc;
              }, {})
            );

            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = grouped;
            returnMessage.count = data.length;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheetsbyempname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gettimesheetsbyprojectname
const getapprovertimesheetsbyprojectname = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var data1 = [];
    var status = req.query.status;
    var startdate = moment()
      .utc()
      .subtract(1, "week")
      .weekday(1)
      .format("YYYY-MM-DD");
    var enddate = moment()
      .utc()
      .subtract(1, "week")
      .weekday(7)
      .format("YYYY-MM-DD");
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var week = req.query.week ? req.query.week : weekdays;
    await con.query(
      `SELECT * from timesheets.get_approver_timesheets_by_project_name($1,$2,$3)`,
      [req.user.org_id, req.query.project_name, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheetsbyprojectname";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            if (item.status == status) {
              data1.push(item);
            } else if (status == "all") {
              data1.push(item);
            }
          });
          if (data1.length > 0) {
            const grouped = Object.values(
              data.reduce((acc, item) => {
                acc[item.employee_name] = [
                  ...(acc[item.employee_name] || []),
                  item,
                ];
                return acc;
              }, {})
            );
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = grouped;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheetsbyprojectname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for getapprovertimesheetsbyyearandmonth
const getapprovertimesheetsbyyearandmonth = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var month = req.query.month
      ? moment().month(req.query.month).format("MMMM")
      : moment().format("MMMM");
    var month1 = req.query.month
      ? moment().month(req.query.month).format("MM")
      : moment().format("MM");
    var year = req.query.year
      ? moment().year(req.query.year).format("YYYY")
      : moment().format("YYYY");
    var date = `${year}-${month1}`;
    const months = moment(date, "YYYY-MM");
    const range = moment().range(
      moment(months).startOf("month").startOf("week"),
      moment(months).endOf("month").endOf("week")
    );
    var employee_name = req.query.employee_name;
    const days = range.by("days");
    var dates = [...days].map((date) => date.format("YYYY-MM-DD"));
    dates = dates.map((x) => {
      return { timesheet_date: x };
    });
    await con.query(
      `SELECT * from timesheets.get_approver_timesheets_by_month_year($1,$2,$3,$4,$5,$6)`,
      [
        req.user.org_id,
        req.query.employee_name,
        month,
        year,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheetsbyyearandmonth";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          var arr = await con.query(
            `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
            [req.user.org_id, req.user.email]
          );
          var output = arr.rows[0].j;
          var result = [];
          output.forEach(function (item) {
            dates.forEach(function (date, i) {
              var data1 = {
                timesheet_date: date.timesheet_date,
                project_name: item.project_name,
                regular_hours: "00",
                regular_minutes: "00",
                ot_hours: "00",
                ot_minutes: "00",
                absent_hours: "00",
                absent_minutes: "00",
                status: "No",
              };
              result.push(data1);
            });
          });
          const grouped = Object.values(
            result.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[1].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours > 10
              ? (data[index].regular_hours = item.regular_hours)
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes > 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours > 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes > 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours > 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes > 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : "00";
          });
          var arr = [];
          var projects = await con.query(
            `SELECT * from timesheets.get_vw_emp_project_timesheet2($1,$2);`,
            [req.user.org_id, req.user.email]
          );
          var output = projects.rows[0].j;
          dates.forEach(function (date, i) {
            output.forEach(function (project, k) {
              let counter = 0;
              data.forEach(function (value, j) {
                if (
                  date.timesheet_date == value.timesheet_date &&
                  project.project_name == value.project_name
                ) {
                  arr.push(value);
                  counter = 1;
                }
              });
              if (counter == 0) {
                arr.push({
                  timesheet_date: date.timesheet_date,
                  project_name: project.project_name,
                  regular_hours: "00",
                  regular_minutes: "00",
                  ot_hours: "00",
                  ot_minutes: "00",
                  absent_hours: "00",
                  absent_minutes: "00",
                  status: "No Entry",
                });
              }
            });
          });

          const grouped = Object.values(
            arr.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheetsbyyearandmonth";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gethouroftimesheetstatusbyweek
const gethourofapprovertimesheetstatusbyweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_vw_status_hour_of_approver_timesheet_week($1,$2)`,
      [req.user.org_id, req.query.week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gethourofapprovertimesheetstatusbyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var arr = results.rows[0].j;
          const output = (arr) => {
            const obj = {};
            for (let i = 0; i < arr.length; i++) {
              arr[i].regular_and_ot_hours < 10 &&
              arr[i].regular_and_ot_hours != null
                ? (arr[i].regular_and_ot_hours =
                    "0" + arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours >= 10
                ? (arr[i].regular_and_ot_hours = arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours == null ||
                  arr[i].regular_and_ot_hours == 0
                ? (arr[i].regular_and_ot_hours = 0)
                : "00";
              arr[i].regular_and_ot_minutes < 10 &&
              arr[i].regular_and_ot_minutes != null
                ? (arr[i].regular_and_ot_minutes =
                    "0" + arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes >= 10
                ? (arr[i].regular_and_ot_minutes =
                    arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes == null ||
                  arr[i].regular_and_ot_minutes == 0
                ? (arr[i].regular_and_ot_minutes = 0)
                : "00";
              const { status, regular_and_ot_hours, regular_and_ot_minutes } =
                arr[i];
              if (
                status == "submit" ||
                status == "approve" ||
                status == "reject"
              )
                obj[
                  status
                ] = `${regular_and_ot_hours}:${regular_and_ot_minutes}`;
            }
            return obj;
          };
          var data = output(arr);
          var submitkey = data.hasOwnProperty("submit");
          var approvekey = data.hasOwnProperty("approve");
          var rejectkey = data.hasOwnProperty("reject");
          if (submitkey == false) {
            data["submit"] = "00:00";
          }
          if (approvekey == false) {
            data["approve"] = "00:00";
          }
          if (rejectkey == false) {
            data["reject"] = "00:00";
          }
          const result = Object.keys(data)
            .sort()
            .reduce((obj, key) => {
              obj[key] = data[key];
              return obj;
            }, {});
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gethourofapprovertimesheetstatusbyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for gethourofapprovertimesheetstatus
const gethourofapprovertimesheetstatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_vw_status_hour_of_approver_timesheet($1)`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gethourofapprovertimesheetstatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var arr = results.rows[0].j;
          const output = (arr) => {
            const obj = {};
            for (let i = 0; i < arr.length; i++) {
              arr[i].regular_and_ot_hours < 10 &&
              arr[i].regular_and_ot_hours != null
                ? (arr[i].regular_and_ot_hours =
                    "0" + arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours >= 10
                ? (arr[i].regular_and_ot_hours = arr[i].regular_and_ot_hours)
                : arr[i].regular_and_ot_hours == null ||
                  arr[i].regular_and_ot_hours == 0
                ? (arr[i].regular_and_ot_hours = 0)
                : "00";
              arr[i].regular_and_ot_minutes < 10 &&
              arr[i].regular_and_ot_minutes != null
                ? (arr[i].regular_and_ot_minutes =
                    "0" + arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes >= 10
                ? (arr[i].regular_and_ot_minutes =
                    arr[i].regular_and_ot_minutes)
                : arr[i].regular_and_ot_minutes == null ||
                  arr[i].regular_and_ot_minutes == 0
                ? (arr[i].regular_and_ot_minutes = 0)
                : "00";
              const { status, regular_and_ot_hours, regular_and_ot_minutes } =
                arr[i];
              if (
                status == "submit" ||
                status == "approve" ||
                status == "reject"
              )
                obj[
                  status
                ] = `${regular_and_ot_hours}:${regular_and_ot_minutes}`;
            }
            return obj;
          };
          var data = output(arr);
          var submitkey = data.hasOwnProperty("submit");
          var approvekey = data.hasOwnProperty("approve");
          var rejectkey = data.hasOwnProperty("reject");
          if (submitkey == false) {
            data["submit"] = "00:00";
          }
          if (approvekey == false) {
            data["approve"] = "00:00";
          }
          if (rejectkey == false) {
            data["reject"] = "00:00";
          }
          const result = Object.keys(data)
            .sort()
            .reduce((obj, key) => {
              obj[key] = data[key];
              return obj;
            }, {});
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gethourofapprovertimesheetstatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by status
const getallapprovertimeactivitybystatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var status = req.query.status;
    var data1 = [];
    var startdate = moment().utc().weekday(1).format("YYYY-MM-DD");
    var enddate = moment().utc().weekday(7).format("YYYY-MM-DD");
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var week = req.query.week ? req.query.week : weekdays;
    await con.query(
      `SELECT * from timesheets.get_approver_timesheets_by_status2($1,$2);`,
      [req.user.org_id, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by status details";
          returnMessage.error = error;
          returnMessage.label = "getallapprovertimeactivitybystatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            if (item.status == status) {
              data1.push({
                employee_name: item.employee_name,
                project_name: item.project_name,
              });
            } else if (status == "all") {
              data1.push({
                employee_name: item.employee_name,
                project_name: item.project_name,
              });
            }
          });
          var result = data1.reduce((unique, o) => {
            if (
              !unique.some(
                (obj) =>
                  obj.employee_name === o.employee_name &&
                  obj.project_name === o.project_name
              )
            ) {
              unique.push(o);
            }
            return unique;
          }, []);
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallapprovertimeactivitybystatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for filter approvertimeactivity
const filterapprovertimeactivity = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (req.query.week == undefined || req.query.week == "") {
      req.query.week = null;
    }
    if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
      req.query.pagenumber = null;
    }
    if (req.query.pagesize == undefined || req.query.pagesize == "") {
      req.query.pagenumber = null;
    }
    await con.query(
      `SELECT * from timesheets.get_approver_timesheets_filter($1,$2,$3,$4)`,
      [
        req.query.week,
        req.user.org_id,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to filter timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "filterapprovertimeactivity";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "filterapprovertimeactivity";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by week
const getallapprovertimeactivitybyweekandstatus = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var startdate = moment()
      .utc()
      .subtract(1, "week")
      .weekday(1)
      .format("YYYY-MM-DD");
    var enddate = moment()
      .utc()
      .subtract(1, "week")
      .weekday(7)
      .format("YYYY-MM-DD");
    var weekdays = `${startdate}T00:00:00Z-${enddate}T00:00:00Z`;
    var week = req.query.week ? req.query.week : weekdays;
    var status = req.query.status;
    var data1 = [];
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_by_week_and_status($1,$2);`,
      [req.user.org_id, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getallapprovertimeactivitybyweekandstatus";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            if (item.status == status) {
              data.push(item);
            } else if (status == "all") {
              data.push(item);
            }
          });
          if (data1.length > 0) {
            const grouped = Object.values(
              data.reduce((acc, item) => {
                acc[item.project_name] = [
                  ...(acc[item.project_name] || []),
                  item,
                ];
                return acc;
              }, {})
            );

            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = grouped;
            returnMessage.count = data.length;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallapprovertimeactivitybyweekandstatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by date
const getallapprovertimeactivitybydate = async (req, res) => {
  const returnMessage = getMsgFormat();
  var date = `${req.query.date}T00:00:00Z`;
  var startdate = moment(date).utc().weekday(1).format();
  var enddate = moment(date).utc().weekday(7).format();
  var weekdate = `${startdate}-${enddate}`;
  try {
    var week = weekdate;
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_by_week_and_status($1,$2);`,
      [req.user.org_id, week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getallapprovertimeactivitybydate";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          const grouped = Object.values(
            data.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallapprovertimeactivitybydate";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity weeks by empname
const getapprovertimesheetweekbyempname = async (req, res) => {
  const returnMessage = getMsgFormat();
  var status = req.query.status;
  try {
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_week_by_emp_name($1,$2,$3);`,
      [req.user.org_id, req.query.employee_name, status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheetweekbyempname";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheetweekbyempname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity weeks by project name
const getapprovertimesheetweekbyprojectname = async (req, res) => {
  const returnMessage = getMsgFormat();
  var status = req.query.status;
  try {
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_week_by_project_name($1,$2,$3);`,
      [req.user.org_id, req.query.project_name, status],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheetweekbyprojectname";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheetweekbyprojectname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timeactivity by week
const getallapprovertimeactivitybyweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    var week = req.query.week;
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_by_week($1,$2);`,
      [req.user.org_id, req.query.week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch approver timeactivity by week details";
          returnMessage.error = error;
          returnMessage.label = "getallapprovertimeactivitybyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
          });
          const grouped = Object.values(
            data.reduce((acc, item) => {
              acc[item.project_name] = [
                ...(acc[item.project_name] || []),
                item,
              ];
              return acc;
            }, {})
          );

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = grouped;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallapprovertimeactivitybyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get approver timesheet history by employee_name and week
const getapprovertimesheethistorybyweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_history_by_week($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.week,
        req.query.employee_name,
        req.query.project_name,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheethistorybyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            if (item.regular_hours != 0) {
              item.regular_hours < 10 && item.regular_hours != null
                ? (data[index].regular_hours = "0" + item.regular_hours)
                : item.regular_hours >= 10
                ? (data[index].regular_hours = item.regular_hours.toString())
                : item.regular_hours == null
                ? (data[index].regular_hours = 0)
                : item.ot_hours == 0
                ? (data[index].regular_hours = "00")
                : "00";
              item.regular_minutes < 10 && item.regular_minutes != null
                ? (data[index].regular_minutes = "0" + item.regular_minutes)
                : item.regular_minutes >= 10
                ? (data[index].regular_minutes = item.regular_minutes)
                : item.regular_minutes == null
                ? (data[index].regular_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].regular_minutes = "00")
                : "00";
              item.ot_hours < 10 && item.ot_hours != null
                ? (data[index].ot_hours = "0" + item.ot_hours)
                : item.ot_hours >= 10
                ? (data[index].ot_hours = item.ot_hours)
                : item.ot_hours == null
                ? (data[index].ot_hours = 0)
                : item.ot_hours == 0
                ? (data[index].ot_hours = "00")
                : "00";
              item.ot_minutes < 10 && item.ot_minutes != null
                ? (data[index].ot_minutes = "0" + item.ot_minutes)
                : item.ot_minutes >= 10
                ? (data[index].ot_minutes = item.ot_minutes)
                : item.ot_minutes == null
                ? (data[index].ot_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].ot_minutes = "00")
                : "00";
              item.absent_hours < 10 && item.absent_hours != null
                ? (data[index].absent_hours = "0" + item.absent_hours)
                : item.absent_hours >= 10
                ? (data[index].absent_hours = item.absent_hours)
                : item.absent_hours == null
                ? (data[index].absent_hours = 0)
                : item.ot_hours == 0
                ? (data[index].absent_hours = "00")
                : "00";
              item.absent_minutes < 10 && item.absent_minutes != null
                ? (data[index].absent_minutes = "0" + item.absent_minutes)
                : item.absent_minutes >= 10
                ? (data[index].absent_minutes = item.absent_minutes)
                : item.absent_minutes == null
                ? (data[index].absent_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].absent_minutes = "00")
                : "00";
              output.push(item);
            }
          });
          // var result = output.reduce((unique, o) => {
          //   if (
          //     !unique.some(
          //       (obj) =>
          //         obj.regular_hours === o.regular_hours &&
          //         obj.project_name === o.project_name &&
          //         obj.employee_name === o.employee_name
          //     )
          //   ) {
          //     unique.push(o);
          //   }
          //   return unique;
          // }, []);
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = data.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheethistorybyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by employee and week
const gettimesheethistorybyweekandproject = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_by_email_and_week($1,$2,$3,$4);`,
      [req.user.org_id, req.user.email, req.query.week, req.query.project_name],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheethistorybyweekandproject";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            if (item.regular_hours != 0) {
              item.regular_hours < 10 && item.regular_hours != null
                ? (data[index].regular_hours = "0" + item.regular_hours)
                : item.regular_hours >= 10
                ? (data[index].regular_hours = item.regular_hours.toString())
                : item.regular_hours == null
                ? (data[index].regular_hours = 0)
                : item.ot_hours == 0
                ? (data[index].regular_hours = "00")
                : "00";
              item.regular_minutes < 10 && item.regular_minutes != null
                ? (data[index].regular_minutes = "0" + item.regular_minutes)
                : item.regular_minutes >= 10
                ? (data[index].regular_minutes = item.regular_minutes)
                : item.regular_minutes == null
                ? (data[index].regular_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].regular_minutes = "00")
                : "00";
              item.ot_hours < 10 && item.ot_hours != null
                ? (data[index].ot_hours = "0" + item.ot_hours)
                : item.ot_hours >= 10
                ? (data[index].ot_hours = item.ot_hours)
                : item.ot_hours == null
                ? (data[index].ot_hours = 0)
                : item.ot_hours == 0
                ? (data[index].ot_hours = "00")
                : "00";
              item.ot_minutes < 10 && item.ot_minutes != null
                ? (data[index].ot_minutes = "0" + item.ot_minutes)
                : item.ot_minutes >= 10
                ? (data[index].ot_minutes = item.ot_minutes)
                : item.ot_minutes == null
                ? (data[index].ot_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].ot_minutes = "00")
                : "00";
              item.absent_hours < 10 && item.absent_hours != null
                ? (data[index].absent_hours = "0" + item.absent_hours)
                : item.absent_hours >= 10
                ? (data[index].absent_hours = item.absent_hours)
                : item.absent_hours == null
                ? (data[index].absent_hours = 0)
                : item.ot_hours == 0
                ? (data[index].absent_hours = "00")
                : "00";
              item.absent_minutes < 10 && item.absent_minutes != null
                ? (data[index].absent_minutes = "0" + item.absent_minutes)
                : item.absent_minutes >= 10
                ? (data[index].absent_minutes = item.absent_minutes)
                : item.absent_minutes == null
                ? (data[index].absent_minutes = 0)
                : item.ot_hours == 0
                ? (data[index].absent_minutes = "00")
                : "00";
              output.push(item);
            }
          });
          var result = output.reduce((unique, o) => {
            if (
              !unique.some(
                (obj) =>
                  obj.regular_hours === o.regular_hours &&
                  obj.project_name === o.project_name &&
                  obj.employee_name === o.employee_name
              )
            ) {
              unique.push(o);
            }
            return unique;
          }, []);
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = result;
          returnMessage.count = result.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheethistorybyweekandproject";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet status by employee and week
const gettimesheetstatusbyweekandproject = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_by_status($1,$2,$3,$4);`,
      [req.user.org_id, req.user.email, req.query.project_name, req.query.week],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheetstatusbyweekandproject";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            output.push(item);
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = output;
          returnMessage.count = output.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheetstatusbyweekandproject";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get approver timesheet history by employee_name and week
const getapprovertimesheetstatusbyweek = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_history_by_status($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.employee_name,
        req.query.project_name,
        req.query.week,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheethistorybyweek";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            output.push(item);
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = output;
          returnMessage.count = output.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheethistorybyweek";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by date
const gettimesheethistoryperday = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_by_date($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.user.email,
        req.query.project_name,
        req.query.timesheet_date,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheethistoryperday";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            output.push(item);
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = output;
          returnMessage.count = output.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheethistoryperday";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get approver timesheet history by date
const getapprovertimesheethistoryperday = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_history_by_date($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.employee_name,
        req.query.project_name,
        req.query.timesheet_date,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheethistoryperday";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            output.push(item);
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = output;
          returnMessage.count = output.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheethistoryperday";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by date
const gettimesheetstatusperday = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_history_status_by_date($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.user.email,
        req.query.project_name,
        req.query.timesheet_date,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "gettimesheetstatusperday";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            output.push(item);
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = output;
          returnMessage.count = output.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "gettimesheethistoryperday";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get approver timesheet status by date
const getapprovertimesheetstatusperday = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_approver_timesheet_history_status_by_date($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.employee_name,
        req.query.project_name,
        req.query.timesheet_date,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "getapprovertimesheetstatusperday";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          var output = [];
          data.forEach(function (item, index) {
            item.regular_hours < 10 && item.regular_hours != null
              ? (data[index].regular_hours = "0" + item.regular_hours)
              : item.regular_hours >= 10
              ? (data[index].regular_hours = item.regular_hours.toString())
              : item.regular_hours == null
              ? (data[index].regular_hours = 0)
              : item.ot_hours == 0
              ? (data[index].regular_hours = "00")
              : "00";
            item.regular_minutes < 10 && item.regular_minutes != null
              ? (data[index].regular_minutes = "0" + item.regular_minutes)
              : item.regular_minutes >= 10
              ? (data[index].regular_minutes = item.regular_minutes)
              : item.regular_minutes == null
              ? (data[index].regular_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].regular_minutes = "00")
              : "00";
            item.ot_hours < 10 && item.ot_hours != null
              ? (data[index].ot_hours = "0" + item.ot_hours)
              : item.ot_hours >= 10
              ? (data[index].ot_hours = item.ot_hours)
              : item.ot_hours == null
              ? (data[index].ot_hours = 0)
              : item.ot_hours == 0
              ? (data[index].ot_hours = "00")
              : "00";
            item.ot_minutes < 10 && item.ot_minutes != null
              ? (data[index].ot_minutes = "0" + item.ot_minutes)
              : item.ot_minutes >= 10
              ? (data[index].ot_minutes = item.ot_minutes)
              : item.ot_minutes == null
              ? (data[index].ot_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].ot_minutes = "00")
              : "00";
            item.absent_hours < 10 && item.absent_hours != null
              ? (data[index].absent_hours = "0" + item.absent_hours)
              : item.absent_hours >= 10
              ? (data[index].absent_hours = item.absent_hours)
              : item.absent_hours == null
              ? (data[index].absent_hours = 0)
              : item.ot_hours == 0
              ? (data[index].absent_hours = "00")
              : "00";
            item.absent_minutes < 10 && item.absent_minutes != null
              ? (data[index].absent_minutes = "0" + item.absent_minutes)
              : item.absent_minutes >= 10
              ? (data[index].absent_minutes = item.absent_minutes)
              : item.absent_minutes == null
              ? (data[index].absent_minutes = 0)
              : item.ot_hours == 0
              ? (data[index].absent_minutes = "00")
              : "00";
            output.push(item);
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = output;
          returnMessage.count = output.length;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getapprovertimesheetstatusperday";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for service
const insertTimesheets = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createTimeActivityValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insertTimesheets";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    await con.query(
      `SELECT timesheets.insert_timesheets($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35)`,
      [
        req.body.approver_id,
        req.body.approver_notes,
        req.body.client_name,
        req.body.createdby,
        req.body.day_name,
        req.body.day_status,
        req.body.day_status_hours,
        req.body.end_customer,
        req.body.employee_name,
        req.body.history,
        req.body.notes,
        req.body.name_of_employee,
        req.body.org_id,
        req.body.ot_hours,
        req.body.ot_minutes,
        req.body.project_id,
        req.body.project_name,
        req.body.qb_timesheet_id,
        req.body.regular_hours,
        req.body.regular_minutes,
        req.body.record_type_status,
        req.body.status,
        req.body.service_name,
        req.body.timesheet_date,
        req.body.user_id,
        req.body.user_email,
        req.body.absent_type,
        req.body.absent_hours,
        req.body.absent_minutes,
        req.body.client_manager_name,
        req.body.client_manager_email,
        req.body.bill_rate,
        req.body.pay_rate,
        req.body.placement_code,
        req.body.qb_status,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to Add";
          returnMessage.error = error;
          returnMessage.label = "insertTimesheets";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.response = results.rows[0].j;
          returnMessage.data = results.rows[1].j;
          returnMessage.message = "Added Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insertTimesheets";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for timesheet docs list by week and project
const get_timesheet_docs_by_week_and_project = async (req, res) => {
  const returnMessage = getMsgFormat();
  const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;

  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_docs_by_week_and_project($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.week_start_date,
        req.query.week_end_date,
        req.query.project_id,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timesheet documents";
          returnMessage.error = error;
          returnMessage.label = "get_timesheet_docs_by_week_and_project";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (
          results.rows &&
          results.rows[0] &&
          results.rows[0].j &&
          !isEmpty(results.rows[0].j)
        ) {
          results.rows[0].j.map((row, i) => {
            if (results.rows[0].j[i].document_name) {
              results.rows[0].j[i].blobUrl = getBlobUrl(
                containerName,
                `timesheets/${row.document_name}`
              );
            }
          });
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j[0].count || null;
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_timesheet_docs_by_week_and_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// PUT api for deleting timesheet doc by id
const delete_timesheet_document = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_timesheet_document($1,$2);`,
      [req.user.org_id, req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete timesheet document";
          returnMessage.error = error;
          returnMessage.label = "delete_timesheet_document";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_timesheet_document";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get timesheet history by date
const get_multiple_comment = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_multi_comments($1,$2,$3,$4,$5);`,
      [
        req.user.org_id,
        req.user.email,
        req.query.project_id,
        req.query.week_start_date,
        req.query.week_end_date,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timeactivity details";
          returnMessage.error = error;
          returnMessage.label = "get_multiple_comment";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          var data = results.rows[0].j;
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_multiple_comment";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getalltimeactivityweekswise,
  getalltimeactivityweekwise,
  getalltimeactivitybyweek,
  getalltimeactivitybyweeks,
  getalltimeactivitybystatus,
  getalltimeactivity,
  getemployeeprojects,
  inserttimeactivity,
  insertalltimeactivity,
  insertupdatetimeactivity,
  edittimeactivity,
  gettimeactivitybyid,
  filtertimeactivity,
  getalltimedoc,
  gettimedocbyid,
  getalltimehistory,
  getalltimestatus,
  gethouroftimesheetstatus,
  gethouroftimesheetstatusbyweek,
  gettimesheetsbyempname,
  gettimesheetsbyprojectname,
  gettimesheetsbyyearandmonth,
  getalltimeactivitybydate,
  getapprovertimesheetsbyempname,
  getapprovertimesheetsbyprojectname,
  getapprovertimesheetsbyyearandmonth,
  gethourofapprovertimesheetstatusbyweek,
  gethourofapprovertimesheetstatus,
  getallapprovertimeactivitybystatus,
  filterapprovertimeactivity,
  getallapprovertimeactivitybyweekandstatus,
  getallapprovertimeactivitybydate,
  getapprovertimesheetweekbyempname,
  getapprovertimesheetweekbyprojectname,
  getallapprovertimeactivitybyweek,
  gettimesheethistorybyemailandweek,
  gettimesheethistorybystatus,
  getapprovertimesheethistorybyweek,
  gettimesheethistorybyweekandproject,
  gettimesheetstatusbyweekandproject,
  getapprovertimesheetstatusbyweek,
  gettimesheethistoryperday,
  getapprovertimesheethistoryperday,
  gettimesheetstatusperday,
  getapprovertimesheetstatusperday,
  insertTimesheets,
  get_timesheet_docs_by_week_and_project,
  delete_timesheet_document,
  get_multiple_comment,
  // pendingemailfromapprover,
  sendstatusemail,
};
