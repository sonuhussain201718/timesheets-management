const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getalltimedoc,
  gettimedocbyid,
  inserttimedoc,
  get_timesheet_docs_by_week_and_project,
  get_timesheet_documents_by_week,
  delete_timesheet_document,
} = require("../../controllers/timesheetDocumentsController");

// @route GET api/v1/timeactivity/getalltimedoc
// @desc  Route to get all timedocs
// @accesss public
router.get("/getalltimedoc", getalltimedoc);

// @route GET api/v1/timeactivity/gettimedocbyid
// @desc  Route to get all timedocs
// @accesss public
router.get("/gettimedocbyid", gettimedocbyid);

// @route POST api/v1/timesheet_documents/inserttimedoc
// @desc  Route to post documents
// @accesss public
router.post("/inserttimedoc", inserttimedoc);

// @route GET api/v1/timeactivity/get_timesheet_docs_by_week_and_project
// @desc  Route to get get timesheet docs by week and project
// @accesss public
router.get(
  "/get_timesheet_docs_by_week_and_project",
  get_timesheet_docs_by_week_and_project
);

// @route GET api/v1/timeactivity/get_timesheet_documents_by_week
// @desc  Route to get get timesheet docs by week
// @accesss public
router.get("/get_timesheet_documents_by_week", get_timesheet_documents_by_week);

// @route PUT api/v1/timeactivity/delete_timesheet_document
// @desc  Route to delete timesheet document
// @accesss public
router.put("/delete_timesheet_document", delete_timesheet_document);

module.exports = router;
