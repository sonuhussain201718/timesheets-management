var admin = require("firebase-admin");

var serviceAccount = require("./timesheets.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://timesheets-51fc9.firebaseio.com",
});

module.exports.admin = admin;
