var firebaseAdmin = require("firebase-admin");

var { FCM_SETTINGS } = require("../constants");

firebaseAdmin.initializeApp({
  credential: firebaseAdmin.credential.cert(FCM_SETTINGS),
  databaseURL: `https://${FCM_SETTINGS.project_id}.firebaseio.com`,
});

module.exports.firebaseAdmin = firebaseAdmin;
