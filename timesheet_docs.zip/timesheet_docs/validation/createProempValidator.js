const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createproempValidator(data) {
  let errors = {};

  if (validator.isEmpty(String(data.project_name))) {
    errors.project_name = "project_name field is required";
  }

  if (validator.isEmpty(String(data.employee_id))) {
    errors.employee_id = "employee_id field is required";
  }

  if (validator.isEmpty(String(data.org_id))) {
    errors.org_id = "org_id field is required";
  }

  if (validator.isEmpty(data.record_type_status)) {
    errors.record_type_status = "record_type_status field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
