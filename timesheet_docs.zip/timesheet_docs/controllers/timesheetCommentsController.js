const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createTimesheetCommentValidator = require("../validation/createTimesheetCommentValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const moment = require("moment");
const { TS_COMMENT_TYPE, TS_COMMENT_USER_TYPE } = require("../constants");
// con.connect();
const {
  TestEmail,
} = require("../Email/email");

// GET api for comments list by week and project
const get_comments_by_week_and_project = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.get_timesheet_comments_by_week_and_project($1,$2,$3,$4);`,
      [
        req.user.org_id,
        req.query.week_start_date,
        req.query.week_end_date,
        req.query.project_id,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch timesheet comments";
          returnMessage.error = error;
          returnMessage.label = "get_comments_by_week_and_project";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (
          results.rows &&
          results.rows[0] &&
          results.rows[0].j &&
          !isEmpty(results.rows[0].j)
        ) {

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j[0].count || null;
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_comments_by_week_and_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for comment
const insert_comment = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {

    let org_id = req.user.org_id;
    let createdby = req.user.id;
    const { errors, isValid } = createTimesheetCommentValidator({ ...req.body, org_id });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insert_comment";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    var data = req.body;
    let { comment_type = null, timesheet_date, user_type = null, user_id = null, comments = null, project_id = null, week_start_date = null, week_end_date = null, status = null, record_type_status = "Active" } = data;

    comment_type = TS_COMMENT_TYPE.WEEKLY;

    let status_data = await con.query(
      `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
      [org_id, week_start_date, week_end_date, project_id]
    );

    status_data = (status_data && status_data.rows[0].get_timesheet_status_by_week_and_project_id && status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

    if (status_data) {
      timesheet_status_id = status_data.id;
    } else {

      status_data = await con.query(
        `SELECT timesheets.insert_timesheet_status($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
        [
          org_id,
          user_id,
          project_id,
          req.body.week_start_date.split("-")[0],
          parseInt(req.body.week_start_date.split("-")[1]),
          week_start_date,
          week_end_date,
          null,
          null,
          null,
          comments,
          null,
          null,
          createdby,
          record_type_status,
        ]
      );

      status_data =
        (status_data &&
          status_data.rows[1].insert_timesheet_status &&
          status_data.rows[1].insert_timesheet_status[0]) ||
        null;
    }

    var result = await con.query(
      `SELECT timesheets.insert_timesheet_comments($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
      [
        org_id,
        comment_type,
        timesheet_date,
        user_type,
        user_id,
        comments,
        status_data.id,
        project_id,
        week_start_date,
        week_end_date,
        createdby,
        record_type_status
      ], 
      (error, results) => {

        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to Add";
          returnMessage.error = error;
          returnMessage.label = "insert_comment";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.response = results.rows[0].insert_timesheet_comments;
          returnMessage.data = (results.rows && results.rows[1] && results.rows[1].insert_timesheet_comments && results.rows[1].insert_timesheet_comments[0]) || null;
          returnMessage.message = "Added Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insert_comment";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// PUT api for deleting timesheet comment by id
const delete_comment = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_timesheet_comments($1,$2);`,
      [req.user.org_id, req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete timesheet comment";
          returnMessage.error = error;
          returnMessage.label = "delete_comment";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_comment";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for comments list by week and project
const test_email = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {

    await TestEmail({
      org_id:req.user.org_id,
      user_email:"masood.m@msr-it.com"
    });
    returnMessage.isError = false;
    returnMessage.message = "Mail sent";
    returnMessage.data = {};
    res.status(200).json(returnMessage);
  } catch (error) {

    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "test_email";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_comments_by_week_and_project,
  insert_comment,
  delete_comment,
  test_email
};
