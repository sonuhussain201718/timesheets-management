const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  employee_wise_time_management_report,
  employee_wise_projects_time_management_report,
  export_employee_wise_time_management_report,
  project_wise_time_management_report,
  project_wise_employees_time_management_report,
  export_project_wise_time_management_report,
  project_wise_employee_timesheet_report,
  export_project_wise_employee_timesheet_report,
  timesheet_submission_report,
  export_timesheet_submission_report,
  get_employees_report,
  export_employees_report,
  get_projects_report,
  export_projects_report,
  project_timesheet_submission_report,
  export_project_timesheet_submission_report,
  get_qb_logs_report,
  export_qb_logs_report,
  get_user_logs_report,
  export_user_logs_report,
  get_employees_status_report,
  export_employees_status_report,
} = require("../../controllers/reportsController");

// @route GET api/v1/reports/employee_wise_time_management_report
// @desc  Route to get employee_wise_time_management_report
// @accesss public
router.get("/employee_wise_time_management_report", employee_wise_time_management_report);

// @route GET api/v1/reports/employee_wise_projects_time_management_report
// @desc  Route to get employee_wise_projects_time_management_report
// @accesss public
router.get("/employee_wise_projects_time_management_report", employee_wise_projects_time_management_report);

// @route GET api/v1/reports/export_employee_wise_time_management_report
// @desc  Route to get export_employee_wise_time_management_report
// @accesss public
router.get("/export_employee_wise_time_management_report", export_employee_wise_time_management_report);


// @route GET api/v1/reports/project_wise_time_management_report
// @desc  Route to get project_wise_time_management_report
// @accesss public
router.get("/project_wise_time_management_report", project_wise_time_management_report);

// @route GET api/v1/reports/project_wise_employees_time_management_report
// @desc  Route to get project_wise_employees_time_management_report
// @accesss public
router.get("/project_wise_employees_time_management_report", project_wise_employees_time_management_report);

// @route GET api/v1/reports/export_project_wise_time_management_report
// @desc  Route to get export_project_wise_time_management_report
// @accesss public
router.get("/export_project_wise_time_management_report", export_project_wise_time_management_report);

// @route GET api/v1/reports/project_wise_employee_timesheet_report
// @desc  Route to get project_wise_employee_timesheet_report
// @accesss public
router.get("/project_wise_employee_timesheet_report", project_wise_employee_timesheet_report);

// @route GET api/v1/reports/export_project_wise_employee_timesheet_report
// @desc  Route to get export_project_wise_employee_timesheet_report
// @accesss public
router.get("/export_project_wise_employee_timesheet_report", export_project_wise_employee_timesheet_report);

// @route GET api/v1/reports/timesheet_submission_report
// @desc  Route to get timesheet_submission_report
// @accesss public
router.get("/timesheet_submission_report", timesheet_submission_report);

// @route GET api/v1/reports/export_timesheet_submission_report
// @desc  Route to get export_timesheet_submission_report
// @accesss public
router.get("/export_timesheet_submission_report", export_timesheet_submission_report);

// @route GET api/v1/reports/get_employees_report
// @desc  Route to get get_employees_report
// @accesss public
router.get("/get_employees_report", get_employees_report);

// @route GET api/v1/reports/export_employees_report
// @desc  Route to get export_employees_report
// @accesss public
router.get("/export_employees_report", export_employees_report);

// @route GET api/v1/reports/get_projects_report
// @desc  Route to get get_projects_report
// @accesss public
router.get("/get_projects_report", get_projects_report);

// @route GET api/v1/reports/export_projects_report
// @desc  Route to get export_projects_report
// @accesss public
router.get("/export_projects_report", export_projects_report);

// @route GET api/v1/reports/project_timesheet_submission_report
// @desc  Route to get project_timesheet_submission_report
// @accesss public
router.get("/project_timesheet_submission_report", project_timesheet_submission_report);

// @route GET api/v1/reports/export_project_timesheet_submission_report
// @desc  Route to get export_project_timesheet_submission_report
// @accesss public
router.get("/export_project_timesheet_submission_report", export_project_timesheet_submission_report);

// @route GET api/v1/reports/get_qb_logs_report
// @desc  Route to get get_qb_logs_report
// @accesss public
router.get("/get_qb_logs_report", get_qb_logs_report);

// @route GET api/v1/reports/export_qb_logs_report
// @desc  Route to get export_qb_logs_report
// @accesss public
router.get("/export_qb_logs_report", export_qb_logs_report);

// @route GET api/v1/reports/get_user_logs_report
// @desc  Route to get get_user_logs_report
// @accesss public
router.get("/get_user_logs_report", get_user_logs_report);

// @route GET api/v1/reports/export_user_logs_report
// @desc  Route to get export_user_logs_report
// @accesss public
router.get("/export_user_logs_report", export_user_logs_report);

// @route GET api/v1/reports/get_employees_status_report
// @desc  Route to get get_employees_status_report
// @accesss public
router.get("/get_employees_status_report", get_employees_status_report);

// @route GET api/v1/reports/export_employees_status_report
// @desc  Route to get export_employees_status_report
// @accesss public
router.get("/export_employees_status_report", export_employees_status_report);

module.exports = router;
