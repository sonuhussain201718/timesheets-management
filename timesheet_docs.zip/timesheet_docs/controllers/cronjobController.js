const { getMsgFormat, isEmpty } = require("../utils/helpers");
const con = require("../utils/db");
const logger = require("../utils/logger");
const moment = require("moment");

const {
  ALLOWED_PAST_ENTRY_DAYS,
  DEFAULT_ECDB_TOOL_NAME,
  TIMESHEET_STATUS
} = require("../constants");
const {  isEmailReminderOn } = require("../utils/timesheet_helpers");
const { WeeklyReminderEmailToEmployee } = require("../Email/email");

const {
  WeeklyReminderPushNotificationToEmployee
} = require("../utils/push_notifications");

// GET API for weekly_timesheet_reminder

const weekly_timesheet_reminder = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {
    
    let currentDate = moment().format("YYYY-MM-DD");
    var currentDay = moment(currentDate).format("dddd");

    let lastWeek = moment(currentDate, "YYYY-MM-DD").subtract(1, "week").format("YYYY-MM-DD");
    
    let week_start_date = moment(lastWeek).startOf("isoweek").format("YYYY-MM-DD");
    let week_end_date = moment(lastWeek).endOf("isoweek").format("YYYY-MM-DD");

    // console.log("week_start_date", currentDate, lastWeek, week_start_date, week_end_date);

    let range = moment().range(moment(week_start_date), moment(week_end_date));
    let days = range.by("days");
    var dates_range = [...days].map((date) => date.format("YYYY-MM-DD"));
    // console.log("dates_range", dates_range);

    // removed saturday and sunday dates
    dates_range = dates_range.filter((d)=>{
      var tdate = `${d}T00:00:00Z`;
      var day_name = moment(tdate).format("dddd");
      let day_name_lower = day_name.toLowerCase() || ``;
      return !["saturday", "sunday"].includes(day_name_lower);
    });
    
    

    // get organizations list
    let organizations_list = await con.query(`SELECT * FROM timesheets.get_organizations_list()`, []);
    organizations_list = (organizations_list && organizations_list.rows[1] && organizations_list.rows[1].j && organizations_list.rows[1].j) || null;
  
    if (organizations_list && organizations_list.length) {
      for (var i = 0; i < organizations_list.length; i++) {
        
        let orgRow = organizations_list[i] || null;
        let { org_id = null, email_reminder_1 = null, email_reminder_2 = null } = orgRow;

        // console.log("org_id", org_id)
        // if email reminder is set on current day
        if(
          org_id && 
          org_id==255 && 
          (email_reminder_1 || email_reminder_2) && 
          ( (email_reminder_1.toLowerCase() == currentDay.toLowerCase()) ||  (email_reminder_2.toLowerCase() == currentDay.toLowerCase()) )
        ) {

          /////////// fetch employees ///////
          let employees = await con.query(`SELECT * from timesheets.get_employees_list_for_weekly_reminder($1);`, [org_id]);
          employees = (employees && employees.rows && employees.rows[0] && employees.rows[0].j) || null;
          if(employees && employees.length){

            for(var j = 0; j < employees.length; j++){
              
              let employee = employees[j];
              
              let { id: user_id = null } = employee;
              // console.log("user_id", user_id)
              // if(user_id && user_id == 207){
                if(user_id){

                let weekData = await con.query(`SELECT * from timesheets.get_single_week_timesheet($1,$2,$3,$4)`, [ org_id, user_id, week_start_date, week_end_date]);
                weekData = (weekData.rows && weekData.rows[0] && weekData.rows[0].j) || null;
                let projects_length = (weekData && weekData.length) || null;

                // console.log("weekData", projects_length, weekData);

                if(weekData && weekData.length){

                  let unsubmittedDates = dates_range;
                  let already_submitted = false;
                  
                  for(var k = 0; k < weekData.length;  k++){
                    
                    let { timesheet_data = null } = weekData[k];
                    // console.log("unsubmittedDates", unsubmittedDates);
                    let total_saved = 0;
                    let total_submitted = 0;
                    let total_approved = 0;
                    let total_rejected = 0;

                    if(timesheet_data && timesheet_data.length){

                      for(var tdI = 0; tdI < timesheet_data.length; tdI++){
                        let tdRow = timesheet_data[tdI];
                        if(tdRow.status == TIMESHEET_STATUS.SAVED){
                          total_saved++;
                        }
                        if(tdRow.status == TIMESHEET_STATUS.SUBMITTED){
                          total_submitted++;
                        }
                        if(tdRow.status == TIMESHEET_STATUS.APPROVED){
                          total_approved++;
                        }
                        if(tdRow.status == TIMESHEET_STATUS.REJECTED){
                          total_rejected++;
                        }
                      }

                      if(total_submitted == ((timesheet_data.length - total_approved) - total_rejected)){
                        already_submitted = true;
                      }
                      else{
                        for(var tdI = 0; tdI < timesheet_data.length; tdI++){
                          let tdRow = timesheet_data[tdI];
                          // console.log("tdRow", tdRow)
                          
                          if(tdRow.status == TIMESHEET_STATUS.SUBMITTED){
                            unsubmittedDates = unsubmittedDates.filter((row)=>{
                              return  tdRow.timesheet_date != row;
                            });
                          }
  
                        }
                      } 
                    }

                  }

                  if(!already_submitted && (unsubmittedDates && unsubmittedDates.length)){
                    
                    // console.log("unsubmittedDates", unsubmittedDates, "already_submitted", already_submitted);

                    ///////////// Send Email //////////
                    let employee_name = employee.full_name || null;
                    let employee_email = employee.email || null;
                    // employee_email = "masood.m@msr-it.com";
                    let week_range = `${week_start_date}-${week_end_date}`;

                    if(user_id){

                      // send push notification 
                      let notificationData = {
                        org_id: org_id,
                        user_id: user_id, 
                        week_start_date: week_start_date,
                        week_end_date: week_end_date,
                        employee_name: employee_name,
                        employee_email: employee_email,
                        unsubmitted_dates: unsubmittedDates,
                      };
                      await WeeklyReminderPushNotificationToEmployee(notificationData);
                    }

                    if (employee_email) {
                      let emailData = {
                        action: "weekly_timesheet_reminder",
                        org_id: org_id,
                        week_start_date: week_start_date,
                        week_end_date: week_end_date,
                        employee_name: employee_name,
                        employee_email: employee_email,
                        unsubmitted_dates: unsubmittedDates,
                      };

                      let is_email_reminder = await isEmailReminderOn(org_id, user_id);

                      if(is_email_reminder){
                        await WeeklyReminderEmailToEmployee(emailData);
                      }
                    }
                    ///////////////////////////////////
                  }

                  
                  
                }
                
              }

            }
          }
          ///////////////////////////////////

        }
        
      }
    }
    
    if (organizations_list && organizations_list.length) {

      returnMessage.isError = false;
      returnMessage.message = "Weekly Timesheet Reminder Sent Successfully";
      // returnMessage.data = organizations_list;
      res.status(200).json(returnMessage);

    } else {
      returnMessage.isError = true;
      returnMessage.message = "Failed to update";
      returnMessage.error = error;
      returnMessage.label = "weekly_timesheet_reminder";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "weekly_timesheet_reminder";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  weekly_timesheet_reminder,
};
