const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createTimeActivityValidator(data) {
  let errors = {};

  if (validator.isEmpty(data.notes)) {
    errors.notes = "notes is required";
  }

  if (validator.isEmpty(String(data.org_id))) {
    errors.org_id = "org_id field is required";
  }

  if (validator.isEmpty(data.record_type_status)) {
    errors.record_type_status = "record_type_status field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
