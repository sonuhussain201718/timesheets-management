const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function ecdbOrganizationValidator(data) {
  let errors = {};

  if (validator.isEmpty(data.org_name)) {
    errors.org_name = "org_name field is required";
  }

  if (validator.isEmpty(data.org_prefix)) {
    errors.org_prefix = "org_prefix field is required";
  }

  if (validator.isEmpty(String(data.ecdb_tool_name))) {
    errors.ecdb_tool_name = "ecdb_tool_name field is required";
  }

  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }

  if (validator.isEmpty(data.record_type_status)) {
    errors.record_type_status = "record_type_status field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
