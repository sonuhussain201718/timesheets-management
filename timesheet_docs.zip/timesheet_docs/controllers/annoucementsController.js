const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createAnnoucementValidator = require("../validation/annoucementValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const axios = require("axios");
// con.connect();

// GET api for annoucements List
const getallannoucements = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_annoucements($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch annoucements details";
          returnMessage.error = error;
          returnMessage.label = "getallannoucements";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallannoucements";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for annoucements details
const get_annoucement_by_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_annoucement_by_id($1,$2)`,
      [req.query.id, req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch annoucement details";
          returnMessage.error = error;
          returnMessage.label = "get_annoucement_by_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_annoucement_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// // INSERT api for annoucements
const insert_annoucement = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    let createdby = req.user.id;
    const { errors, isValid } = createAnnoucementValidator(req.body);

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "createAnnoucementValidator";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    await con.query(
      `SELECT timesheets.insert_annoucement($1,$2,$3,$4,$5,$6)`,
      [
        org_id,
        req.body.title,
        req.body.description,
        req.body.pulish_date,
        createdby,
        req.body.record_type_status,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to add";
          returnMessage.error = error;
          returnMessage.label = "insert_annoucement";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.response = results.rows[0].insert_annoucement;
          returnMessage.data = results.rows[1].insert_annoucement;
          returnMessage.message = "Added Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insert_annoucement";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for annoucements
const update_annoucement = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    let updatedby = req.user.id;
    const { errors, isValid } = createAnnoucementValidator(req.body);

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "editannoucements validation";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    await con.query(
      `SELECT timesheets.update_annoucement($1,$2,$3,$4,$5,$6,$7)`,
      [
        req.body.id,
        org_id,
        req.body.title,
        req.body.description,
        req.body.pulish_date,
        updatedby,
        req.body.record_type_status,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to update";
          returnMessage.error = error;
          returnMessage.label = "update_annoucement";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.response = results.rows[0].update_annoucement;
          returnMessage.data = results.rows[1].update_annoucement;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "update_annoucement";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// DELETE api for annoucement
const delete_annoucement = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    await con.query(
      `SELECT * from timesheets.delete_annoucement($1,$2);`,
      [req.user.org_id, req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to delete timesheet document";
          returnMessage.error = error;
          returnMessage.label = "delete_annoucement";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_annoucement";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_latest_announcement_by_org_id details
const get_latest_announcement = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let latest_announcement = await con.query(
      `SELECT * from timesheets.get_latest_announcement_by_org_id($1)`,
      [req.user.org_id]
    );
    latest_announcement =
      (latest_announcement &&
        latest_announcement.rows[0] &&
        latest_announcement.rows[0].j &&
        latest_announcement.rows[0].j[0]) ||
      null;
    if (latest_announcement && latest_announcement.id) {
      let read_details = await con.query(
        `SELECT * from timesheets.get_announcement_reads_by_user($1,$2,$3)`,
        [req.user.org_id, latest_announcement.id, req.user.id]
      );

      read_details =
        (read_details &&
          read_details.rows[0] &&
          read_details.rows[0].j &&
          read_details.rows[0].j[0]) ||
        null;
      if (read_details && read_details.id) {
        latest_announcement = null;
      }
    }

    if (latest_announcement) {
      returnMessage.isError = false;
      returnMessage.message = "Records Found";
      returnMessage.data = latest_announcement;
      res.status(200).json(returnMessage);
    } else {
      returnMessage.isError = false;
      returnMessage.message = "No Records Found";
      res.status(200).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_latest_announcement";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// ====*==== api's for Announcement Read ===*====*=====

// GET api for get_announcement_reads_by_user details
// const get_announcement_reads_by_user = async (req, res) => {
//   const returnMessage = getMsgFormat();
//   try {
//     await con.query(
//       `SELECT * from timesheets.get_announcement_reads_by_user($1,$2,$3)`,
//       [req.user.org_id, req.query.announcement_id, req.user.id],
//       (error, results) => {

//         if (error) {
//           returnMessage.isError = true;
//           returnMessage.message = "Failed to fetch annoucement details";
//           returnMessage.error = error;
//           returnMessage.label = "get_announcement_reads_by_user";
//           logger.log({
//             level: "error",
//             message: returnMessage,
//           });
//           res.status(400).json(returnMessage);
//         } else if (isEmpty(results.rows[0].j)) {
//           returnMessage.isError = false;
//           returnMessage.message = "No Records Found";
//           res.status(200).json(returnMessage);
//         } else {
//           returnMessage.isError = false;
//           returnMessage.message = "Records Found";
//           returnMessage.data = results.rows[0].j[0];
//           res.status(200).json(returnMessage);
//         }
//       }
//     );
//   } catch (error) {
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.label = "get_announcement_reads_by_user";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
// };

// // INSERT api for mark as read
const mark_as_read = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    let createdby = req.user.id;

    await con.query(
      `SELECT timesheets.insert_announcement_reads($1,$2,$3,$4,$5)`,
      [
        org_id,
        req.body.id,
        req.user.id,
        createdby,
        req.body.record_type_status,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to add";
          returnMessage.error = error;
          returnMessage.label = "mark_as_read";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.response = results.rows[0].insert_announcement_reads;
          returnMessage.data = results.rows[1].insert_announcement_reads;
          returnMessage.message = "Added Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "mark_as_read";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getallannoucements,
  get_annoucement_by_id,
  insert_annoucement,
  update_annoucement,
  delete_annoucement,
  get_latest_announcement,
  // get_announcement_reads_by_user,
  mark_as_read,
};
