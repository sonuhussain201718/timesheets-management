const { count } = require("console");
var express = require("express");
var router = express.Router();
var fs = require("fs");
var path = require("path");
const { getMsgFormat, isEmpty } = require("../../utils/helpers");
const con = require("../../utils/db");
const logger = require("../../utils/logger");
const { BlobServiceClient } = require("@azure/storage-blob");
const { v1: uuidv1 } = require("uuid");
const createTimesheetDocValidator = require("../../validation/createtimesheetdocValidator");
require("dotenv").config();
const moment = require("moment");
con.connect();

// Insert Timesheet Documents
router.post("/inserttimedoc", async function (req, res) {
  const returnMessage = getMsgFormat();

  try {
    const { errors, isValid } = createTimesheetDocValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "editorganization";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    if (req.files && req.files.file) {
      var data = req.body;
      const {
        org_id,
        user_id,
        project_id,
        week_start_date,
        week_end_date,
        record_type_status = "Active",
        status,
        service_name,
        createdby,
      } = data;
      var images = [];
      var insert_doc_results = [];
      var timesheet_status_id = null;

      req.files.file = !req.files.file.length
        ? [req.files.file]
        : req.files.file;

      const AZURE_STORAGE_CONNECTION_STRING =
        process.env.AZURE_STORAGE_CONNECTION_STRING;
      if (!AZURE_STORAGE_CONNECTION_STRING) {
        throw Error("Azure Storage Connection string not found");
      }

      const blobServiceClient = BlobServiceClient.fromConnectionString(
        AZURE_STORAGE_CONNECTION_STRING
      );
      const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
      const containerClient =
        blobServiceClient.getContainerClient(containerName);
      const createContainerResponse = await containerClient.createIfNotExists();

      // Create a unique name for the blob
      var files = req.files.file;
      for (i = 0; i < files.length; i++) {
        // Create a unique name for the blob
        var docFile = files[i];
        var original_name = docFile.name;
        var document_name = uuidv1() + (docFile.name.replace(/[^a-zA-Z0-9,_;\-.!? ]/g, ''));

        const blockBlobClient = containerClient.getBlockBlobClient(
          `timesheets/${document_name}`
        );
        const uploadBlobResponse = await blockBlobClient.upload(
          docFile.data,
          docFile.data.length
        );

        if (uploadBlobResponse && uploadBlobResponse.requestId) {
          images.push({
            document_name,
            original_name,
          });
        }
      }

      var status_data = await con.query(
        `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`,
        [org_id, week_start_date, week_end_date, project_id]
      );

      status_data =
        (status_data &&
          status_data.rows[0].get_timesheet_status_by_week_and_project_id &&
          status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) ||
        null;

      if (status_data) {
        timesheet_status_id = status_data.id;
      } else {
        let tmpDate = moment(req.body.week_start_date, "YYYY-MM-DD");
        let monthName = tmpDate.format("MMMM");

        status_data = await con.query(
          `SELECT timesheets.insert_timesheet_status($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)`,
          [
            "",
            "",
            createdby,
            monthName,
            "",
            org_id,
            project_id,
            record_type_status,
            status,
            service_name,
            0,
            0,
            user_id,
            `${week_start_date}T00:00:00Z-${week_end_date}T00:00:00Z`,
            req.body.week_start_date.split("-")[0],
            week_start_date,
            week_end_date,
            week_end_date,
            "",
            "",
            "",
          ]
        );

        status_data =
          (status_data &&
            status_data.rows[1].insert_timesheet_status &&
            status_data.rows[1].insert_timesheet_status[0]) ||
          null;
      }

      if (images && images.length) {
        for (i = 0; i < images.length; i++) {
          var result = await con.query(
            `SELECT timesheets.insert_timesheet_documents($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
            [
              createdby,
              org_id,
              status_data.id,
              project_id,
              record_type_status,
              week_start_date,
              week_end_date,
              `${week_start_date}T00:00:00Z-${week_end_date}T00:00:00Z`,
              images[i].original_name,
              images[i].document_name,
            ]
          );

          result =
            (result &&
              result.rows[1].insert_timesheet_documents &&
              result.rows[1].insert_timesheet_documents[0]) ||
            null;
          insert_doc_results.push(result);
        }
      }

      if (insert_doc_results && insert_doc_results.length) {
        returnMessage.isError = false;
        returnMessage.data = {
          timesheet_status_id: status_data.id,
          documents_result: insert_doc_results,
        };
        returnMessage.message = "Added Successfully";
        res.status(200).json(returnMessage);
      } else {
        returnMessage.isError = true;
        returnMessage.message = "Failed to add";
        returnMessage.error = error;
        returnMessage.label = "inserttimedoc";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(500).json(returnMessage);
      }
    } else {
      returnMessage.isError = true;
      returnMessage.message = "Please select file(s)";
      returnMessage.label = "inserttimedoc";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (err) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured";
    returnMessage.error = err;
    returnMessage.label = "inserttimedoc";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    res.status(400).json(returnMessage);
  }
});

module.exports = router;
