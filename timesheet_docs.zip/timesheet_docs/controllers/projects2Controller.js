const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const createProjectValidator = require("../validation/createProjectValidator");
const con = require("../utils/db");
const logger = require("../utils/logger");
const axios = require("axios");
const moment = require("moment");
// con.connect();
const fs = require("fs");
const { BlobServiceClient } = require("@azure/storage-blob");
var mime = require("mime-types");
const excelJS = require("exceljs");
const path = require("path");
const {
  SyncProjectsByUserId,
  ResetPrimaryProjectByUser,
  isQBEnabled,
  isEmailReminderOn,
  isQBTransactionOn,
  getOrgData,
} = require("../utils/timesheet_helpers");
const { ROLES, PROJECTS_STATUS_MAPPING, PROJECTS_STATUS } = require("../constants");
const {
  titleCase,
  titleCaseForHyphen,
  titleCaseForUnderscore,
} = require("../utils/helpers");

const {
  ProjectUpdatedEmailToEmployee
} = require("../Email/email");

// GET api for projects List
const get_all_projects = async (req, res) => {

  const returnMessage = getMsgFormat();

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.user_id = null;
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.is_primary_project = null;
    req.query.record_type_status = null;

    //Is Local or Placement Project
    if (["local", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "local") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    // is Primary or Secondary project
    if (["primary", "secondary"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "primary") {
        req.query.is_primary_project = true;
      } else if (keyword.toLowerCase() == "secondary") {
        req.query.is_primary_project = false;
      } else {
        req.query.is_primary_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{

    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
      req.query.user_id = null;
    }
    if(req.query.project_name == undefined || req.query.project_name == "") {
      req.query.project_name = null;
    }
    if(req.query.placement_code == undefined || req.query.placement_code == "") {
      req.query.placement_code = null;
    }
    if (req.query.project_status == undefined || req.query.project_status == "") {
      req.query.project_status = null;
    }
    if(req.query.is_placement_project == undefined || req.query.is_placement_project == "" ) {
      req.query.is_placement_project = null;
    }
    if(req.query.is_primary_project == undefined || req.query.is_primary_project == "" ) {
      req.query.is_primary_project = null;
    }
    if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
      req.query.record_type_status = null;
    }
  }
  
  if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
    req.query.pagenumber = null;
  }
  if (req.query.pagesize == undefined || req.query.pagesize == "") {
    req.query.pagesize = null;
  }
  

  try {

    await con.query(
      `SELECT * from timesheets.get_all_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11);`,
      [
        req.query.keyword,
        req.user.org_id,
        req.query.user_id,
        req.query.project_name,
        req.query.placement_code,
        req.query.project_status,
        req.query.is_placement_project,
        req.query.is_primary_project,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_all_projects";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          if (results) {
            let data =
              (results.rows && results.rows[1] && results.rows[1].j) || null;
            let count =
              (results.rows && results.rows[2] && results.rows[2].j) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            // don't pass qb details in API response
            if (
              data &&
              data.length &&
              (!is_qb_enabled ||
                ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                ))
            ) {
              for (var i = 0; i < data.length; i++) {
                delete data[i].qb_customer_id;
                delete data[i].qb_customer_name;
                delete data[i].qb_project_id;
                delete data[i].qb_project_name;
                delete data[i].qb_product_id;
                delete data[i].qb_product_name;
                delete data[i].qb_status;
              }
            }

            if (data && data.length) {
              for (var i = 0; i < data.length; i++) {
                delete data[i].bill_rate;
                delete data[i].pay_rate;
                delete data[i].bill_rate_currency;
                delete data[i].ot_bill_rate;
                delete data[i].ot_pay_rate;
                delete data[i].ot_bill_rate_currency;
              }
            }
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = data;
            returnMessage.count = count;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_projects";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for filter projects
// const filter_projects = async (req, res) => {
//   const returnMessage = getMsgFormat();
//   if (req.query.user_id == undefined || req.query.user_id == "") {
//     req.query.user_id = null;
//   }
//   if (req.query.project_name == undefined || req.query.project_name == "") {
//     req.query.project_name = null;
//   }
//   if (req.query.placement_code == undefined || req.query.placement_code == "") {
//     req.query.placement_code = null;
//   }
//   if (req.query.project_status == undefined || req.query.project_status == "") {
//     req.query.project_status = null;
//   }
//   if (
//     req.query.is_placement_project == undefined ||
//     req.query.is_placement_project == ""
//   ) {
//     req.query.is_placement_project = null;
//   }
//   if (
//     req.query.record_type_status == undefined ||
//     req.query.record_type_status == ""
//   ) {
//     req.query.record_type_status = null;
//   }
//   if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
//     req.query.pagenumber = null;
//   }
//   if (req.query.pagesize == undefined || req.query.pagesize == "") {
//     req.query.pagesize = null;
//   }
//   try {
//     var output = [];
//     await con.query(
//       `SELECT * from timesheets.get_projects_filter($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
//       [
//         req.user.org_id,
//         req.query.user_id,
//         req.query.project_name,
//         req.query.placement_code,
//         req.query.project_status,
//         req.query.is_placement_project,
//         req.query.record_type_status,
//         req.query.pagenumber,
//         req.query.pagesize,
//       ],
//       (error, results) => {
//         var data = results.rows[1].j;
//         var count = results.rows[2].j;
//         if (error) {
//           returnMessage.isError = true;
//           returnMessage.message = "Failed to filter project details";
//           returnMessage.error = error;
//           returnMessage.label = "filter_projects";
//           logger.log({
//             level: "error",
//             message: returnMessage,
//           });
//           res.status(400).json(returnMessage);
//         } else {
//           if (results) {
//             let data =
//               (results.rows && results.rows[1] && results.rows[1].j) || null;

              // // don't pass qb details in API response
              // if((data && data.length) && (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
              //   for (var i = 0; i < data.length; i++) {
              //     delete data[i].qb_customer_id;
              //     delete data[i].qb_customer_name;
              //     delete data[i].qb_project_id;
              //     delete data[i].qb_project_name;
              //     delete data[i].qb_product_id;
              //     delete data[i].qb_product_name;
              //     delete data[i].qb_status;
              //   }
              // }
              // if (data && data.length) {
              //   for (var i = 0; i < data.length; i++) {
              //     delete data[i].bill_rate;
              //     delete data[i].pay_rate;
              //     delete data[i].bill_rate_currency;
              //     delete data[i].ot_bill_rate;
              //     delete data[i].ot_pay_rate;
              //     delete data[i].ot_bill_rate_currency;
              //   }
              // }
//             returnMessage.isError = false;
//             returnMessage.message = "Records Found";
//             returnMessage.data = data;
//             returnMessage.count = count;
//             res.status(200).json(returnMessage);
//           } else {
//             returnMessage.isError = false;
//             returnMessage.message = "No Records Found";
//             res.status(200).json(returnMessage);
//           }
//         }
//       }
//     );
//   } catch (error) {
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.label = "filter_projects";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
// };

// GET api for project by id
const get_project_by_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_project_by_id";
      logger.log({
        level: "errr",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_project_by_id($1,$2)`,
        [req.user.org_id, req.query.id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_project_by_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) ||
              null;


            if (data) {

              let is_qb_enabled = await isQBEnabled(req.user.org_id);
              // don't pass qb details in API response
              if(!is_qb_enabled || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
                delete data.qb_customer_id;
                delete data.qb_customer_name;
                delete data.qb_project_id;
                delete data.qb_project_name;
                delete data.qb_product_id;
                delete data.qb_product_name;
                delete data.qb_status;
              }
              
              delete data.bill_rate;
              delete data.pay_rate;
              delete data.bill_rate_currency;
              delete data.ot_bill_rate;
              delete data.ot_pay_rate;
              delete data.ot_bill_rate_currency;
              delete data.project_bill_rates;
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_project_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project by placement code
const get_project_by_placement_code = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.placement_code) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "placement_code can not be null or empty";
      returnMessage.label = "get_project_by_placement_code";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_project_by_placement_code($1,$2)`,
        [req.user.org_id, req.query.placement_code],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_project_by_placement_code";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;
            if (results) {

              let is_qb_enabled = await isQBEnabled(req.user.org_id);

              // don't pass qb details in API response
              if(!is_qb_enabled || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
                delete results.qb_customer_id;
                delete results.qb_customer_name;
                delete results.qb_project_id;
                delete results.qb_project_name;
                delete results.qb_product_id;
                delete results.qb_product_name;
                delete results.qb_status;
              }
              
              delete results.bill_rate;
              delete results.pay_rate;
              delete results.bill_rate_currency;
              delete results.ot_bill_rate;
              delete results.ot_pay_rate;
              delete results.ot_bill_rate_currency;
              delete results.project_bill_rates;
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_project_by_placement_code";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project by placement code excluding id
const get_project_by_placement_code_excluding_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_project_by_placement_code_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.placement_code) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "placement_code can not be null or empty";
      returnMessage.label = "get_project_by_placement_code_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_project_by_placement_code_excluding_id($1,$2,$3)`,
        [req.user.org_id, req.query.id, req.query.placement_code],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_project_by_placement_code_excluding_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;
            if (results) {
              
              let is_qb_enable = await isQBEnabled(req.user.org_id);
              
              // don't pass qb details in API response
              if(!is_qb_enable || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
                delete results.qb_customer_id;
                delete results.qb_customer_name;
                delete results.qb_project_id;
                delete results.qb_project_name;
                delete results.qb_product_id;
                delete results.qb_product_name;
                delete results.qb_status;
              }
              
              delete results.bill_rate;
              delete results.pay_rate;
              delete results.bill_rate_currency;
              delete results.ot_bill_rate;
              delete results.ot_pay_rate;
              delete results.ot_bill_rate_currency;
              delete results.project_bill_rates;

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_project_by_placement_code_excluding_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for projects List by name
const get_projects_list = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_projects_list($1)`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_projects_list";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[1] && results.rows[1].j) || null;
          if (results) {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = results;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_projects_list";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for projects by user id
const get_projects_by_user_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if(!req.query.user_id){
      returnMessage.isError=true
      returnMessage.message="Invalid Parameters"
      returnMessage.error="user_id can not be null or empty"
      returnMessage.label = "get_projects_by_user_id";
      logger.log({
        level:'error',
        message:returnMessage
      })
      return res.status(400).json(returnMessage)
    }
    else{
      await con.query(
        `SELECT * from timesheets.get_projects_by_user_id($1,$2)`,
        [req.user.org_id, req.query.user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_projects_by_user_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[1] && results.rows[1].j) || null;
            if (results) {

              let is_qb_enable = await isQBEnabled(req.user.org_id);

              // don't pass qb details in API response
            if((results && results.length) && (!is_qb_enable || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
              for (var i = 0; i < results.length; i++) {
                delete results[i].qb_customer_id;
                delete results[i].qb_customer_name;
                delete results[i].qb_project_id;
                delete results[i].qb_project_name;
                delete results[i].qb_product_id;
                delete results[i].qb_product_name;
                delete results[i].qb_status;
              }
            }

            if (results && results.length) {
              for (var i = 0; i < results.length; i++) {
                delete results[i].bill_rate;
                delete results[i].pay_rate;
                delete results[i].bill_rate_currency;
                delete results[i].ot_bill_rate;
                delete results[i].ot_pay_rate;
                delete results[i].ot_bill_rate_currency;
              }
            }

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_projects_by_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for projects
const insert_project = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createProjectValidator({ ...req.body, org_id });

    let placement_code_exists = null;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insert_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;

    // project_name(camelCase)
    let project_name = req.body.project_name;
     project_name = project_name ? titleCaseForHyphen(project_name) : "";

    let {
      user_id = null,
      project_status = null,
      start_date = null,
      end_date = null,
      client_manager_name = null,
      client_manager_email = null,
      job_title = null,
      is_placement_project = false,
      placement_type = null,
      placement_project_id = null,
      placement_code = null,
      bill_rate = null,
      pay_rate = null,
      bill_rate_currency = null,
      ot_bill_rate = null,
      ot_pay_rate = null,
      ot_bill_rate_currency = null,
      is_primary_project = null,
      direct_customer_engagement = false,
      end_customer_id = null,
      qb_customer_name = null,
      qb_customer_id = null,
      qb_project_name = null,
      qb_project_id = null,
      qb_product_id = null,
      qb_product_name = null,
      work_country = null,
      work_email = null,
      work_phone = null,
      work_state = null,
      work_city = null,
      is_updated = false,
      cancel_date = null,
      reason = null,
      reason_id = null,
      qb_status = null,
      vendors = null,
    } = req.body;
    let record_type_status = "Active";

    // project status
        if (project_status === PROJECTS_STATUS.REJECTED) {
          end_date = null;
          cancel_date = null;
        }


    let total_projects = await con.query(`SELECT * from timesheets.get_projects_by_user_id($1,$2)`, [org_id, user_id]);
    total_projects = (total_projects.rows && total_projects.rows[1] && total_projects.rows[1].j) || null;

    if(!total_projects || !total_projects.length > 0){
      is_primary_project = true;
    }

    let project_exists = await con.query(
      `SELECT timesheets.get_project_by_placement_code($1, $2)`,
      [org_id, placement_code]
    );
    project_exists =
      (project_exists &&
        project_exists.rows[0].get_project_by_placement_code &&
        project_exists.rows[0].get_project_by_placement_code[0]) ||
      null;
        
      let local_project_exists = await con.query(
         `SELECT timesheets.get_active_local_projects_by_user_id($1, $2)`,
         [req.body.user_id, org_id]
       );

      local_project_exists =
        (local_project_exists &&
          local_project_exists.rows[0].get_active_local_projects_by_user_id) ||
        [];
    // let primary_project_exists = await con.query( `SELECT * FROM timesheets.get_primary_project_by_user_id($1, $2)`, 
    // [org_id, user_id] 
    // );
    // primary_project_exists = (primary_project_exists && primary_project_exists.rows[0].j && primary_project_exists.rows[0].j[0]) || null;
    
    if (project_exists && project_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "placement code already exists";
      returnMessage.error = { placement_code: "placement code already exists" };
      returnMessage.label = "insert_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
    else if (local_project_exists && local_project_exists.length > 0) {
      returnMessage.isError = true;
      returnMessage.message = "This user is already having active local projects";
      returnMessage.error = "This user is already having active local projects";
      returnMessage.label = "insert_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }

    // else if (is_primary_project && primary_project_exists && primary_project_exists.id) {
    //   returnMessage.isError = true;
    //   returnMessage.message = "primary project already exists";
    //   returnMessage.error = { is_primary_project: "primary project already exists" };
    //   returnMessage.label = "insert_project";
    //   logger.log({
    //     level: "error",
    //     message: returnMessage,
    //   });
    //   res.status(400).json(returnMessage);
    // }
    else {
      var projectData = [
        org_id,
        user_id,
        project_name,
        project_status,
        start_date,
        end_date,
        client_manager_name,
        client_manager_email,
        job_title,
        is_placement_project,
        placement_type,
        placement_project_id,
        placement_code,
        bill_rate,
        pay_rate,
        bill_rate_currency,
        ot_bill_rate,
        ot_pay_rate,
        ot_bill_rate_currency,
        is_primary_project,
        direct_customer_engagement,
        end_customer_id,
        qb_customer_name,
        qb_customer_id,
        qb_project_name,
        qb_project_id,
        qb_product_id,
        qb_product_name,
        work_country,
        work_email,
        work_phone,
        work_state,
        work_city,
        is_updated,
        cancel_date,
        reason,
        reason_id,
        qb_status,
        createdby,
        record_type_status,
      ];

      // console.log("projectData", projectData);

      let results = await con.query(
        `SELECT timesheets.insert_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40)`,
        projectData
      );

      var data =
        (results.rows &&
          results.rows[1] &&
          results.rows[1].insert_projects &&
          results.rows[1].insert_projects[0]) ||
        null;

      if (data && data.id) {
        let new_project_id = data.id;

        if(is_primary_project){
          
          // remove other primary projects
          await con.query(`SELECT timesheets.remove_primary_projects_by_user_id($1,$2,$3)`, [ org_id, user_id, updatedby ]);

          // Update project as primary
          await con.query(`SELECT timesheets.update_project_as_primary($1,$2,$3)`, [ new_project_id, org_id, updatedby ]);
        }

        // Insert Project Vendors
        if (vendors && vendors.length) {
          for (var j = 0; j < vendors.length; j++) {
            if (j == 0) {
              let vendorRow = vendors[j] || null;
              let {
                id: customer_id = null,
                isPrime = false,
                createdby = 1,
                record_type_status = "Active",
              } = vendorRow;

              let projectVendorData = [
                org_id,
                new_project_id,
                customer_id,
                isPrime,
                createdby,
                record_type_status,
              ];

              let result = await con.query(
                `SELECT timesheets.insert_project_vendors($1,$2,$3,$4,$5,$6)`,
                projectVendorData
              );
              result =
                (result &&
                  result.rows &&
                  result.rows[1] &&
                  result.rows[1].insert_project_vendors &&
                  result.rows[1].insert_project_vendors[0]) ||
                null;
            }
          }
        }

        // Insert Project Bill Rates

        const date_format = "YYYY-MM-DD";
        var date1 = new Date();
        current_date = moment(date1).format(date_format);
        // console.log("current_date", current_date)

        // if (bill_rate || pay_rate || ot_bill_rate || ot_pay_rate) {
        //   let effective_date = current_date;

        //   let projectBillRateData = [
        //     org_id,
        //     new_project_id,
        //     effective_date,
        //     bill_rate,
        //     pay_rate,
        //     bill_rate_currency,
        //     ot_bill_rate,
        //     ot_pay_rate,
        //     ot_bill_rate_currency,
        //     createdby,
        //     record_type_status,
        //   ];

        //   let result = await con.query(
        //     `SELECT timesheets.insert_project_bill_rates($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        //     projectBillRateData
        //   );

        //   result =
        //     (result &&
        //       result.rows &&
        //       result.rows[1] &&
        //       result.rows[1].insert_project_bill_rates &&
        //       result.rows[1].insert_project_bill_rates[0]) ||
        //     null;
        // }

        let is_qb_enabled = await isQBEnabled(req.user.org_id);

        // don't pass qb details in API response
        if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
          delete data.qb_customer_id;
          delete data.qb_customer_name;
          delete data.qb_project_id;
          delete data.qb_project_name;
          delete data.qb_product_id;
          delete data.qb_product_name;
          delete data.qb_status;
        }

        // don't pass bill rate / pay rate details in response
        delete data.bill_rate;
        delete data.pay_rate;
        delete data.bill_rate_currency;
        delete data.ot_bill_rate;
        delete data.ot_pay_rate;
        delete data.ot_bill_rate_currency;

        returnMessage.isError = false;
        returnMessage.data = data;
        returnMessage.message = "Added Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      } else {
        returnMessage.isError = true;
        returnMessage.message = "Failed to add";
        returnMessage.label = "insert_project";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      }
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insert_project";
    ``;
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for projects
const edit_project = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createProjectValidator({ ...req.body, org_id });

    let placement_code_exists = null;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edit_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;

    // project_name(camelCase)
    let project_name = req.body.project_name;
    project_name = project_name ? titleCaseForHyphen(project_name) : "";

    let {
      id = null,
      user_id = null,
      project_status = null,
      start_date = null,
      end_date = null,
      client_manager_name = null,
      client_manager_email = null,
      job_title = null,
      is_placement_project = null,
      placement_type = null,
      placement_project_id = null,
      placement_code = null,
      bill_rate = null,
      pay_rate = null,
      bill_rate_currency = null,
      ot_bill_rate = null,
      ot_pay_rate = null,
      ot_bill_rate_currency = null,
      is_primary_project = null,
      direct_customer_engagement = false,
      end_customer_id = null,
      qb_customer_name = null,
      qb_customer_id = null,
      qb_project_name = null,
      qb_project_id = null,
      qb_product_id = null,
      qb_product_name = null,
      work_country = null,
      work_email = null,
      work_phone = null,
      work_state = null,
      work_city = null,
      is_updated = false,
      cancel_date = null,
      reason = null,
      reason_id = null,
      qb_status = null,
      vendors = null,
      project_bill_rates = null,
      record_type_status = null,
    } = req.body;

    // project status
    if (project_status === PROJECTS_STATUS.REJECTED) {
      end_date = null;
      cancel_date = null;
    }

    let old_data = await con.query(
      `SELECT timesheets.get_project_by_id($1,$2)`,
      [org_id, id]
    );

    old_data =
      (old_data &&
        old_data.rows[0].get_project_by_id &&
        old_data.rows[0].get_project_by_id[0]) ||
      null;

    let total_projects = await con.query(
      `SELECT * from timesheets.get_projects_by_user_id($1,$2)`,
      [org_id, user_id]
    );
    total_projects =
      (total_projects.rows &&
        total_projects.rows[1] &&
        total_projects.rows[1].j) ||
      null;

    if (total_projects || total_projects.length == 1) {
      is_primary_project = true;
    }

    let project_exists = await con.query(
      `SELECT timesheets.get_project_by_placement_code_excluding_id($1,$2,$3)`,
      [org_id, id, placement_code]
    );

    project_exists =
      (project_exists &&
        project_exists.rows[0].get_project_by_placement_code_excluding_id &&
        project_exists.rows[0].get_project_by_placement_code_excluding_id[0]) ||
      null;

    // let local_project_exists = await con.query(
    //   `SELECT timesheets.get_active_local_projects_by_user_id_excluding_id($1,$2,$3)`,
    //   [req.body.user_id, org_id, id]
    // );
    // local_project_exists =
    //   (local_project_exists &&
    //     local_project_exists.rows[0].get_active_local_projects_by_user_id_excluding_id) ||
    //   [];

    // let primary_project_exists = await con.query( `SELECT * FROM timesheets.get_primary_project_by_user_id_excluding_id($1, $2, $3)`,
    // [org_id, id, user_id]
    // );
    // primary_project_exists = (primary_project_exists && primary_project_exists.rows[0].j && primary_project_exists.rows[0].j[0]) || null;

    if (project_exists && project_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "placement code already exists";
      returnMessage.error = { placement_code: "placement code already exists" };
      returnMessage.label = "edit_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
    // else if(local_project_exists.length > 0) {
    //   returnMessage.isError = true;
    //   returnMessage.message = "This user is alraedy having active local project";
    //   returnMessage.error = "This user is alraedy having active local project";
    //   returnMessage.label = "edit_project";
    //   logger.log({
    //     level: "error",
    //     message: returnMessage,
    //   });
    //   res.status(400).json(returnMessage);
    // }
    // else if (is_primary_project && primary_project_exists && primary_project_exists.id) {
    //   returnMessage.isError = true;
    //   returnMessage.message = "primary project already exists";
    //   returnMessage.error = { is_primary_project: "primary project already exists" };
    //   returnMessage.label = "edit_project";
    //   logger.log({
    //     level: "error",
    //     message: returnMessage,
    //   });
    //   res.status(400).json(returnMessage);
    // }
    else {
      var projectData = [
        id,
        org_id,
        user_id,
        project_name,
        project_status,
        start_date,
        end_date,
        client_manager_name,
        client_manager_email,
        job_title,
        is_placement_project,
        placement_type,
        placement_project_id,
        placement_code,
        old_data.bill_rate || null,
        old_data.pay_rate || null,
        old_data.bill_rate_currency || null,
        old_data.ot_bill_rate || null,
        old_data.ot_pay_rate || null,
        old_data.ot_bill_rate_currency || null,
        is_primary_project,
        direct_customer_engagement,
        end_customer_id,
        qb_customer_name,
        qb_customer_id,
        qb_project_name,
        qb_project_id,
        qb_product_id,
        qb_product_name,
        work_country,
        work_email,
        work_phone,
        work_state,
        work_city,
        is_updated,
        cancel_date,
        reason,
        reason_id,
        qb_status,
        updatedby,
        record_type_status,
      ];

      // console.log("projectData", projectData);

      let results = await con.query(
        `SELECT timesheets.update_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
        projectData
      );

      var data =
        (results.rows &&
          results.rows[1] &&
          results.rows[1].update_projects &&
          results.rows[1].update_projects[0]) ||
        null;

      if (data && data.id) {
        if (is_primary_project) {
          // remove other primary projects
          await con.query(
            `SELECT timesheets.remove_primary_projects_by_user_id($1,$2,$3)`,
            [org_id, user_id, updatedby]
          );

          // Update project as primary
          await con.query(
            `SELECT timesheets.update_project_as_primary($1,$2,$3)`,
            [id, org_id, updatedby]
          );

          if (
            project_status == PROJECTS_STATUS.COMPLETED &&
            old_data.project_status != PROJECTS_STATUS.COMPLETED
          ) {
            await ResetPrimaryProjectByUser({
              org_id: org_id,
              user_id: user_id,
              exlcuded_project_id: id,
              updatedby: updatedby,
            });
          }
        }

        // Insert Project Vendors
        let delete_project_vendors = await con.query(
          `SELECT timesheets.delete_project_vendors_by_project_id($1, $2)`,
          [org_id, id]
        );

        if (vendors && vendors.length) {
          for (var j = 0; j < vendors.length; j++) {
            if (j == 0) {
              let vendorRow = vendors[j] || null;
              let {
                id: customer_id = null,
                isPrime = false,
                createdby = 1,
                record_type_status = "Active",
              } = vendorRow;

              let projectVendorData = [
                org_id,
                id,
                customer_id,
                isPrime,
                createdby,
                record_type_status,
              ];

              let result = await con.query(
                `SELECT timesheets.insert_project_vendors($1,$2,$3,$4,$5,$6)`,
                projectVendorData
              );
              result =
                (result &&
                  result.rows &&
                  result.rows[1] &&
                  result.rows[1].insert_project_vendors &&
                  result.rows[1].insert_project_vendors[0]) ||
                null;
            }
          }
        }

        // Insert Project Bill Rates

        const date_format = "YYYY-MM-DD";
        var date1 = new Date();
        current_date = moment(date1).format(date_format);
        // console.log("current_date", current_date);

        // let delete_project_bill_rates = await con.query(
        //   `SELECT timesheets.delete_project_bill_rates_by_project_id($1, $2)`,
        //   [org_id, id]
        // );
        // delete_project_bill_rates =
        //   (delete_project_bill_rates &&
        //     delete_project_bill_rates.rows[0]
        //       .delete_project_bill_rates_by_project_id &&
        //     delete_project_bill_rates.rows[0]
        //       .delete_project_bill_rates_by_project_id[0]) ||
        //   null;

        // if (project_bill_rates && project_bill_rates.length) {
        //   for (var j = 0; j < project_bill_rates.length; j++) {
        //     let billRatesRow = project_bill_rates[j] || null;

        //     if (current_date != billRatesRow.effective_date) {
        //       let projectBillRateData = [
        //         org_id,
        //         id,
        //         billRatesRow.effective_date || null,
        //         billRatesRow.bill_rate || null,
        //         billRatesRow.agreed_pay_rate || null,
        //         billRatesRow.bill_rate_currency || null,
        //         billRatesRow.ot_bill_rate || null,
        //         billRatesRow.ot_agreed_pay_rate || null,
        //         billRatesRow.ot_bill_rate_currency || null,
        //         createdby,
        //         record_type_status,
        //       ];

        //       let result = await con.query(
        //         `SELECT timesheets.insert_project_bill_rates($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        //         projectBillRateData
        //       );
        //       result =
        //         (result &&
        //           result.rows &&
        //           result.rows[1] &&
        //           result.rows[1].insert_project_bill_rates &&
        //           result.rows[1].insert_project_bill_rates[0]) ||
        //         null;
        //     }
        //   }
        // }

        // if (bill_rate || pay_rate || ot_bill_rate || ot_pay_rate) {
        //   let effective_date = current_date;

        //   let projectBillRateData = [
        //     org_id,
        //     id,
        //     effective_date,
        //     bill_rate,
        //     pay_rate,
        //     bill_rate_currency,
        //     ot_bill_rate,
        //     ot_pay_rate,
        //     ot_bill_rate_currency,
        //     createdby,
        //     record_type_status,
        //   ];

        //   let result = await con.query(
        //     `SELECT timesheets.insert_project_bill_rates($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        //     projectBillRateData
        //   );

        //   result =
        //     (result &&
        //       result.rows &&
        //       result.rows[1] &&
        //       result.rows[1].insert_project_bill_rates &&
        //       result.rows[1].insert_project_bill_rates[0]) ||
        //     null;
        // }

        // don't pass qb details in API response

        let is_qb_enabled = await isQBEnabled(req.user.org_id);

        if (
          !is_qb_enabled ||
          ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
            req.user.role_id
          )
        ) {
          delete data.qb_customer_id;
          delete data.qb_customer_name;
          delete data.qb_project_id;
          delete data.qb_project_name;
          delete data.qb_product_id;
          delete data.qb_product_name;
          delete data.qb_status;
        }

        // don't pass bill rate / pay rate details in response
        delete data.bill_rate;
        delete data.pay_rate;
        delete data.bill_rate_currency;
        delete data.ot_bill_rate;
        delete data.ot_pay_rate;
        delete data.ot_bill_rate_currency;

        ////// Send Email to employee
        let consultant_data = await con.query(
          `SELECT * from timesheets.get_user_by_id($1,$2)`,
          [user_id, org_id]
        );
        consultant_data =
          (consultant_data &&
            consultant_data.rows &&
            consultant_data.rows[0] &&
            consultant_data.rows[0].j &&
            consultant_data.rows[0].j[0]) ||
          null;

        let employee_name =
          (consultant_data && consultant_data.full_name) || null;
        let employee_email = (consultant_data && consultant_data.email) || null;
        // employee_email = "masood.m@msr-it.com";

        if (employee_email) {
          let emailData = {
            org_id: org_id,
            project_name: project_name,
            employee_name: employee_name,
            employee_email: employee_email,
          };

          let user_id = consultant_data.id;
          let is_email_reminder = await isEmailReminderOn(org_id, user_id);

          if (is_email_reminder) {
            await ProjectUpdatedEmailToEmployee(emailData);
          }
        }
        ////////////////////////////////////
        returnMessage.isError = false;
        returnMessage.data = data;
        returnMessage.message = "Updated Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      } else {
        returnMessage.isError = true;
        returnMessage.message = "Failed to update";
        returnMessage.label = "edit_project";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      }
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "edit_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// DELETE api for projects
const delete_project = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT timesheets.delete_project($1)`,
      [req.body.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to Delete";
          returnMessage.label = "delete_project";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_project";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_all_projects
const export_all_projects = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.user_id = null;
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.is_primary_project = null;
    req.query.record_type_status = null;

    // is local and placement project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    // is Primary or Secondary project
    if (["primary", "secondary"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "primary") {
        req.query.is_primary_project = true;
      } else if (keyword.toLowerCase() == "secondary") {
        req.query.is_primary_project = false;
      } else {
        req.query.is_primary_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{

    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
      req.query.user_id = null;
    }
    if(req.query.project_name == undefined || req.query.project_name == "") {
      req.query.project_name = null;
    }
    if(req.query.placement_code == undefined || req.query.placement_code == "") {
      req.query.placement_code = null;
    }
    if (req.query.project_status == undefined || req.query.project_status == "") {
      req.query.project_status = null;
    }
    if(req.query.is_placement_project == undefined || req.query.is_placement_project == "" ) {
      req.query.is_placement_project = null;
    }
    if(req.query.is_primary_project == undefined || req.query.is_primary_project == "" ) {
      req.query.is_primary_project = null;
    }
    if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
      req.query.record_type_status = null;
    }
  }

  try {
    await con.query(
      `SELECT * from timesheets.export_all_projects($1,$2,$3,$4,$5,$6,$7,$8,$9);`,
      [
        req.query.keyword,
        org_id,
        req.query.user_id,
        req.query.project_name,
        req.query.placement_code,
        req.query.project_status,
        req.query.is_placement_project,
        req.query.is_primary_project,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_project";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          let is_qb_transaction_on1 = await isQBTransactionOn(
            req.user.org_id,
            "getcustomerdatabyname"
          );

          let is_qb_transaction_on2 = await isQBTransactionOn(
            req.user.org_id,
            "getitemdatabyname"
          );

          // don't pass qb details in API response for getcustomerdatabyname
          if (
            results &&
            results.length &&
            (!is_qb_enabled ||
              !is_qb_transaction_on1 ||
              ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id
              ))
          ) {
            for (var i = 0; i < results.length; i++) {
              delete results[i].qb_customer_id;
              delete results[i].qb_customer_name;
              delete results[i].qb_project_id;
              delete results[i].qb_project_name;
              delete results[i].qb_status;
            }
          }

          // don't pass qb details in API response for getitemdatabyname
          if (
            results &&
            results.length &&
            (!is_qb_enabled ||
              !is_qb_transaction_on2 ||
              ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id
              ))
          ) {
            for (var i = 0; i < results.length; i++) {
              delete results[i].qb_product_id;
              delete results[i].qb_product_name;
            }
          }

          if (results && results.length) {
            for (var i = 0; i < results.length; i++) {
              delete results[i].bill_rate;
              delete results[i].pay_rate;
              delete results[i].bill_rate_currency;
              delete results[i].ot_bill_rate;
              delete results[i].ot_pay_rate;
              delete results[i].ot_bill_rate_currency;
            }
          }

          if (results && results.length) {
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportProjectsData");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              {
                header: "PROJECT TYPE",
                key: "is_placement_project",
                width: 10,
              },
              { header: "PLACEMENT CODE", key: "placement_code", width: 10 },
              { header: "CONSULTANT TYPE", key: "placement_type", width: 10 },
              { header: "CONSULTANT NAME", key: "full_name", width: 10 },
              { header: "PROJECT NAME", key: "project_name", width: 10 },
              { header: "START DATE", key: "start_date", width: 10 },
              {
                header: "PRIMARY PROJECT",
                key: "is_primary_project",
                width: 10,
              },
            ];

            if (
              is_qb_enabled &&
              is_qb_transaction_on1 &&
              [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id
              )
            ) {
              worksheet.columns = [
                ...worksheet.columns,
                { header: "QB CLIENT NAME", key: "qb_customer_name", width: 10 },
                { header: "QB CLIENT ID", key: "qb_customer_id", width: 10 },
                { header: "QB PROJECT ID", key: "qb_project_id", width: 10 },
              ];
            }

            if (
              is_qb_enabled &&
              is_qb_transaction_on2 &&
              [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id
              )
            ) {
              worksheet.columns = [
                ...worksheet.columns,
                { header: "QB PRODUCT ID", key: "qb_product_id", width: 10 },
              ];
            }

            worksheet.columns = [
              ...worksheet.columns,
              { header: "STATUS", key: "project_status", width: 10 },
            ];

            for (i = 0; i < results.length; i++) {
              row = results[i];

              let is_placement_project =
                row.is_placement_project == true ? "Placement" : "Bench";

              let is_primary_project =
                row.is_primary_project == true ? "Primary" : "Secondary";

              let full_name = row.full_name ? titleCase(row.full_name) : "";

              // let project_name = row.project_name ? titleCase(row.project_name): "";
              let project_name = row.project_name;
              project_name = project_name
                ? titleCaseForHyphen(project_name)
                : "";

              let project_status = row.project_status;
              project_status = project_status
                ? titleCaseForUnderscore(project_status)
                : "";
              project_status = project_status ? titleCase(project_status) : "";

              let start_date = moment(row.start_date, "YYYY-MM-DD");
              start_date =
                start_date && start_date.isValid()
                  ? start_date.format("MM/DD/YYYY")
                  : "-";

              let tmpRow = [
                is_placement_project,
                row.placement_code,
                row.placement_type,
                full_name,
                project_name,
                start_date,
                is_primary_project,
              ];
              if (
                is_qb_enabled &&
                is_qb_transaction_on1 &&
                [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                )
              ) {
                tmpRow = [
                  ...tmpRow,
                  row.qb_customer_name,
                  row.qb_customer_id,
                  row.qb_project_id,
                ];
              }
              if (
                is_qb_enabled &&
                is_qb_transaction_on2 &&
                [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                )
              ) {
                tmpRow = [
                  ...tmpRow,
                  row.qb_product_id,
                ];
              }
              tmpRow = [...tmpRow, project_status];

              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/exports/projects"
            );
            let fileName = `projects-list-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/exports/projects/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {
                let orgData = await getOrgData(org_id);
                let newFileName  = `projects-list-${((orgData && orgData.org_name) || ``)}.xlsx`
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/exports/projects/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);
              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_all_projects";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project by id
const sync_projects_by_user_id = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {

    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "sync_projects_by_user_id";
      logger.log({
        level: "errr",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {

      let org_id = req.user.org_id;
      let user_id = req.query.user_id;

      let results = await SyncProjectsByUserId(org_id, user_id);

      // console.log("results", results)

      if (results && results.length) {

        let is_qb_enabled = await isQBEnabled(req.user.org_id);

        // don't pass qb details in API response
        if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
          for (var i = 0; i < results.length; i++) {
            delete results[i].qb_customer_id;
            delete results[i].qb_customer_name;
            delete results[i].qb_project_id;
            delete results[i].qb_project_name;
            delete results[i].qb_product_id;
            delete results[i].qb_product_name;
            delete results[i].qb_status;
          }
        }

        for (var i = 0; i < results.length; i++) {
          delete results[i].bill_rate;
          delete results[i].pay_rate;
          delete results[i].bill_rate_currency;
          delete results[i].ot_bill_rate;
          delete results[i].ot_pay_rate;
          delete results[i].ot_bill_rate_currency;
        }
        
        returnMessage.isError = false;
        returnMessage.message = "Projects synced successfully";
        returnMessage.data = results;
        res.status(200).json(returnMessage);
      } else {
        returnMessage.isError = false;
        returnMessage.message = "Projects not found";
        res.status(200).json(returnMessage);
      }

    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "sync_projects_by_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for projects by user id
const get_primary_project_by_user_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if(!req.query.user_id){
      returnMessage.isError=true
      returnMessage.message="Invalid Parameters"
      returnMessage.error="user_id can not be null or empty"
      returnMessage.label = "get_primary_project_by_user_id";
      logger.log({
        level:'error',
        message:returnMessage
      })
      return res.status(400).json(returnMessage)
    }
    else{
      await con.query(
        `SELECT * from timesheets.get_primary_project_by_user_id($1,$2)`,
        [req.user.org_id, req.query.user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_primary_project_by_user_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            results = (results && results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

            if (results) {

              // don't pass qb details in API response
              if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                  delete results.qb_customer_id;
                  delete results.qb_customer_name;
                  delete results.qb_project_id;
                  delete results.qb_project_name;
                  delete results.qb_product_id;
                  delete results.qb_product_name;
                  delete results.qb_status;
                
              }

              
              delete results.bill_rate;
              delete results.pay_rate;
              delete results.bill_rate_currency;
              delete results.ot_bill_rate;
              delete results.ot_pay_rate;
              delete results.ot_bill_rate_currency;


              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_primary_project_by_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// UPDATE api for project_name
const update_project_names = async (req, res) => {
  const returnMessage = getMsgFormat();

  let updatedProjects = []; // Array to store updated projects

  try {
    
    let org_id = req.user.org_id;
    let projects = req.body.projects;

    if (!projects || projects.length === 0) {
      return res.status(200).json({
        isError: true,
        message: "No projects found in the request.",
        label: "update_project_names",
      });
    }

    // Loop through the projects array and update the project_name for each project
    for (let i = 0; i < projects.length; i++) {
      let project = projects[i];
      let id = project.id;
      let project_name = titleCaseForHyphen(`${project.consultant_name}-${project.client_name}`);
      let updated = await con.query(`SELECT timesheets.update_project_name($1,$2,$3)`, 
      [id, org_id, project_name]);
      updated = (updated.rows && updated.rows[1] && updated.rows[1].update_project_name && updated.rows[1].update_project_name[0]) || null;
      
      updatedProjects.push(updated);
    }

    returnMessage.isError = false;
    returnMessage.data = updatedProjects;
    returnMessage.message = "Project Names Updated Successfully";
    res.status(200).json(returnMessage);
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "update_project_names";
    returnMessage.message = "Error Occurred! Please try again.";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

const get_active_local_projects_by_user_id = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "get_active_local_projects_by_user_id";
      logger.log({
        level: "errr",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_active_local_projects_by_user_id($1,$2)`,
        [req.query.user_id,org_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_active_local_projects_by_user_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j) ||
              null;

            if (data) {
              let is_qb_enabled = await isQBEnabled(req.user.org_id);
              // don't pass qb details in API response
              if (
                !is_qb_enabled ||
                ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                )
              ) {
                delete data.qb_customer_id;
                delete data.qb_customer_name;
                delete data.qb_project_id;
                delete data.qb_project_name;
                delete data.qb_product_id;
                delete data.qb_product_name;
                delete data.qb_status;
              }

              delete data.bill_rate;
              delete data.pay_rate;
              delete data.bill_rate_currency;
              delete data.ot_bill_rate;
              delete data.ot_pay_rate;
              delete data.ot_bill_rate_currency;
              delete data.project_bill_rates;

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              returnMessage.count = results.rows[1].j;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_active_local_projects_by_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_all_projects,
  // filter_projects,
  get_project_by_id,
  get_project_by_placement_code,
  get_project_by_placement_code_excluding_id,
  get_projects_list,
  get_projects_by_user_id,
  insert_project,
  edit_project,
  delete_project,
  export_all_projects,
  sync_projects_by_user_id,
  get_primary_project_by_user_id,
  update_project_names,
  get_active_local_projects_by_user_id,
};
