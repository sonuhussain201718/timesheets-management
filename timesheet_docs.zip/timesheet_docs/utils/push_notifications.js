const isEmpty = require("../validation/is-empty");
const con = require("../utils/db");
const logger = require("../utils/logger");
const { getMsgFormat } = require("../utils/helpers");
const { firebaseAdmin } = require("../utils/firebase");

async function getOrgName(org_id = null) {

  let org_name = ``;
  if(org_id){
    let org_data = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    
    org_data = (org_data && org_data.rows[0].get_organizations_by_orgid && org_data.rows[0].get_organizations_by_orgid[0]) || null;
    if(org_data && org_data.org_name){
      org_name = org_data.org_name;
    };
  }
  return org_name;
}

async function getActiveDeviceTokens(org_id = null, user_id = null) {

  let tokens = null;
  if(org_id && user_id){
    let tokens_data = await con.query(`SELECT * FROM timesheets.get_mobile_device_tokens_by_user_and_status($1,$2,$3)`,
    [org_id, user_id, true]);
    
    tokens_data = (tokens_data && tokens_data.rows[0].j && tokens_data.rows[0].j) || null;
    if(tokens_data && tokens_data.length){
        tokens = [];
        for(var i = 0; i < tokens_data.length; i ++){
          let token = tokens_data[i].device_token;
          tokens.push(token);
        }
    };
  }
  return tokens;
}

async function sendPushNotification(registrationTokens = null, data = null) {

  // console.log("data", data);
  const returnMessage = getMsgFormat();

  if (registrationTokens && data && data.payload) {
    
    let { org_id = null, payload = null } = data || null;
    
    try{
      
      const options = {
        priority: "high",
        timeToLive: 60 * 60 * 24,
      };

      firebaseAdmin
      .messaging()
      .sendToDevice(registrationTokens, payload, options)
      .then((response) => {
        return response;
      })
      .catch((error) => {
          returnMessage.isError = true;
          returnMessage.error = error;
          returnMessage.message = "Failed to send push notification";
          returnMessage.label = "sendPushNotification";
          logger.log({
          level: "error",
          message: returnMessage,
          });
          return error;
      });
      
    }
    catch (error) {
      
      returnMessage.isError = true;
      returnMessage.error = error;
      returnMessage.message = "Failed to send push notification";
      returnMessage.label = "sendPushNotification";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      
    }
  }
  else {
    returnMessage.isError = true;
    returnMessage.error = data;
    returnMessage.message = "Incorrect data";
    returnMessage.label = "sendPushNotification";
    logger.log({
      level: "error",
      message: returnMessage,
    });
  }
}

async function ApprovedPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Approved`,
          body : `Timesheet approved for week ${week_range}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}


async function ApprovedSingleDayPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let timesheet_date = (data && data.timesheet_date) || null;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Approved`,
          body : `Timesheet approved for date ${timesheet_date}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function ApprovedMonthlyPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let year = (data && data.year) || null;
  let month = (data && data.month) || null;
  
  let monthName = (data && data.monthName) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;
  
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;

  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Approved`,
          body : `Timesheet approved for the month of ${monthName}, ${year}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        year: (year && year.toString() || ``),
        month: (month && month.toString() || ``),
        monthName: (monthName && monthName.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function RejectedPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Rejected`,
          body : `Timesheet rejected for week ${week_range}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function RejectedSingleDayPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let timesheet_date = (data && data.timesheet_date) || null;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Rejected`,
          body : `Timesheet rejected for date ${timesheet_date}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function RejectedMonthlyPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let year = (data && data.year) || null;
  let month = (data && data.month) || null;
  let monthName = (data && data.monthName) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;
  
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;

  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Rejected`,
          body : `Timesheet rejected for the month of ${monthName}, ${year}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        year: (year && year.toString() || ``),
        month: (month && month.toString() || ``),
        monthName: (monthName && monthName.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function WeeklyReminderPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let unsubmitted_dates = (data && data.unsubmitted_dates) || null;
  unsubmitted_dates = (unsubmitted_dates && unsubmitted_dates.length && unsubmitted_dates.map((d)=>{
    return `${d}`;
  })).join(` `) || ``;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Weekly Timesheet Reminder`,
          body : `Timesheet is pending for submission for the week ${week_range}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function RevertedPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Reverted`,
          body : `Timesheet reverted for week ${week_range}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function RevertedSingleDayPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let timesheet_date = (data && data.timesheet_date) || null;
  
  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Reverted`,
          body : `Timesheet reverted for date ${timesheet_date}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

async function RevertedMonthlyPushNotificationToEmployee(data) {
  
  let action = (data && data.action) || ``;
  let org_id = (data && data.org_id) || null;
  let user_id = (data && data.user_id) || null;
  let year = (data && data.year) || null;
  let month = (data && data.month) || null;
  let monthName = (data && data.monthName) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;
  
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;

  let result = null;
  
  if(org_id && user_id){

    let org_name = await getOrgName(org_id);
    let registrationTokens = await getActiveDeviceTokens(org_id, user_id);

    const payload = { 
      notification : {
          title : `Timesheet Reverted`,
          body : `Timesheet reverted for the month of ${monthName}, ${year}`,
      },
      data: {
        org_id: (org_id && org_id.toString() || ``),
        action: (action && action.toString() || ``),
        user_id: (user_id && user_id.toString() || ``),
        year: (year && year.toString() || ``),
        month: (month && month.toString() || ``),
        monthName: (monthName && monthName.toString() || ``),
        week_start_date: (week_start_date && week_start_date.toString() || ``),
        week_end_date: (week_end_date && week_end_date.toString() || ``),
      }
    }

    // console.log("registrationTokens", registrationTokens);

    let notificaionData = {
      org_id: org_id, 
      payload: payload,
    }
    result = await sendPushNotification(registrationTokens, notificaionData);
  }

  return result;
}

module.exports = {
  ApprovedPushNotificationToEmployee,
  ApprovedSingleDayPushNotificationToEmployee,
  ApprovedMonthlyPushNotificationToEmployee,
  RejectedPushNotificationToEmployee,
  RejectedSingleDayPushNotificationToEmployee,
  RejectedMonthlyPushNotificationToEmployee,
  WeeklyReminderPushNotificationToEmployee,
  RevertedPushNotificationToEmployee,
  RevertedSingleDayPushNotificationToEmployee,
  RevertedMonthlyPushNotificationToEmployee
};
