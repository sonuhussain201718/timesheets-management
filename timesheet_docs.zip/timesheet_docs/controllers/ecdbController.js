const { getMsgFormat, isEmpty } = require("../utils/helpers");
const ecdbOrganizationValidator = require("../validation/ecdbOrganizationValidator");
const createuserValidator = require("../validation/createUser2Validator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const {
  ALLOWED_PAST_ENTRY_DAYS,
  DEFAULT_ECDB_TOOL_NAME,
} = require("../constants");
const { OrganizationsSyncEmail } = require("../Email/email");
// con.connect();

// INSERT api for organization
const insert_organization_data = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    const { errors, isValid } = ecdbOrganizationValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insert_organization_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    var org_data = [];

    const exists_data = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [req.body.org_id]
    );
    if (
      exists_data &&
      exists_data.rows[0].get_organizations_by_orgid &&
      exists_data.rows[0].get_organizations_by_orgid[0]
    ) {
      returnMessage.isError = true;
      returnMessage.message = "org_id already exists";
      returnMessage.error = { org_id: "org_id already exists" };
      returnMessage.label = "insert_organization_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      let allowed_past_entry_days = ALLOWED_PAST_ENTRY_DAYS;
      let {
        allow_placement = true,
        createdby = null,
        updatedby = null,
        domain = null,
        org_id = null,
        org_name = null,
        org_prefix = null,
        prospective_admin_id = null,
        logo = null,
        email_reminder_1 = null,
        email_reminder_2 = null,
        record_type_status,
        from_email = null,
        max_regular_hours = 8,
        notify_to_email = null,
        notification_enabled = true
      } = req.body;

      let ecdb_tool_name = DEFAULT_ECDB_TOOL_NAME;
      let result = null;

      record_type_status =
        record_type_status && record_type_status.toLowerCase() == "active"
          ? "Active"
          : "Inactive";

      let org_data = [
        allow_placement,
        createdby,
        domain,
        ecdb_tool_name,
        org_id,
        org_name,
        org_prefix,
        prospective_admin_id,
        logo,
        record_type_status,
        email_reminder_1,
        email_reminder_2,
        allowed_past_entry_days,
        max_regular_hours,
        notify_to_email,
        notification_enabled
      ];

      result = await con.query(
        `SELECT timesheets.insert_organizations($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
        org_data
      );
      result =
        (result.rows &&
          result.rows[1] &&
          result.rows[1].insert_organizations &&
          result.rows[1].insert_organizations[0]) ||
        null;

      /// add from email in email_config
      if (result) {
        let email_config_data = await con.query(
          `SELECT timesheets.get_email_config_by_org_id($1)`,
          [org_id]
        );

        email_config_data =
          (email_config_data &&
            email_config_data.rows[0].get_email_config_by_org_id &&
            email_config_data.rows[0].get_email_config_by_org_id[0]) ||
          null;

        let new_from_email =
          from_email ||
          (email_config_data && email_config_data.from_email) ||
          null;

        email_config_result = await con.query(
          `SELECT timesheets.insert_email_config($1,$2,$3,$4)`,
          [org_id, new_from_email, null, "Active"]
        );
      }

      returnMessage.isError = false;
      returnMessage.message = "Inserted Successfully";
      returnMessage.data = result;
      res.status(200).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insert_organization_data";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for users
const insert_user_data = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createuserValidator(req.body);

    let email_exists = false;
    let ecdb_user_exists = false;
    let prospective_user_exists = false;
    let adp_associate_exists = false;

    let {
      org_id,
      employee_type = null,
      role_name,
      prefix = null,
      first_name,
      middle_name,
      last_name,
      full_name,
      email,
      gender,
      adp_associate_id = null,
      phone_number,
      branch_id = null,
      branch_name = null,
      department_id = null,
      department_name = null,
      employee_id = null,
      ecdb_user_id = null,
      prospective_user_id = null,
      joining_date = null,
      leaving_date = null,
      qb_employee_name = "",
      qb_employee_id = null,
      user_status,
      work_location,
      work_country,
      work_state,
      work_city,
      work_street_address,
      permanent_address,
      work_address,
      zipcode,
      email_notifications = false,
      push_notifications = false,
      createdby = null,
      visa_status = null,
      adp_validated = false
    } = req.body;

    //get role id from local db by role name
    let role_data = await con.query(`SELECT timesheets.get_role_by_name($1)`, [
      role_name,
    ]);
    role_data =
      (role_data &&
        role_data.rows[0].get_role_by_name &&
        role_data.rows[0].get_role_by_name[0]) ||
      null;
    let role_id = (role_data && role_data.id) || null;

    full_name = `${first_name} ${last_name}`.trim();
    let record_type_status =
      user_status.toLowerCase() == "active" ? "Active" : "Inactive";

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_user_by_email($1, $2)`,
        [org_id, email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_user_by_email &&
          email_exists.rows[0].get_user_by_email[0]) ||
        null;
    }

    // check if ecdb_user_id already exists
    if (ecdb_user_id) {
      ecdb_user_exists = await con.query(
        `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
        [org_id, ecdb_user_id]
      );
      ecdb_user_exists =
        (ecdb_user_exists &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id[0]) ||
        null;
    }

    // check if prospective_user_id already exists
    if (prospective_user_id) {
      prospective_user_exists = await con.query(
        `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
        [org_id, prospective_user_id]
      );
      prospective_user_exists =
        (prospective_user_exists &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id[0]) ||
        null;
    }

    // check if adp associate id already exists
    if (adp_associate_id) {
      adp_associate_exists = await con.query(
        `SELECT timesheets.get_user_by_adp_associate_id($1,$2 )`,
        [org_id, adp_associate_id]
      );
      adp_associate_exists =
        (adp_associate_exists &&
          adp_associate_exists.rows[0].get_user_by_adp_associate_id &&
          adp_associate_exists.rows[0].get_user_by_adp_associate_id[0]) ||
        null;
    } 

    // check if organization id does not exist
    let org_id_not_exist;
    if (org_id) {
      org_id_not_exist = await con.query(
        `SELECT timesheets.get_organizations_by_orgid($1)`,
        [org_id]
      );
      org_id_not_exist =
        (org_id_not_exist &&
          org_id_not_exist.rows[0].get_organizations_by_orgid &&
          org_id_not_exist.rows[0].get_organizations_by_orgid[0]) ||
        null;
    }

    if (!org_id_not_exist) {
      returnMessage.isError = true;
      returnMessage.message = "org_id does not exists";
      returnMessage.error = { org_id: "org_id does not exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }

    if (email_exists && email_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "email already exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (ecdb_user_exists && ecdb_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "ecdb_user_id already exists";
      returnMessage.error = { email: "ecdb_user_id already exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (prospective_user_exists && prospective_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "prospective_user_id already exists";
      returnMessage.error = { email: "prospective_user_id already exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (adp_associate_exists && adp_associate_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "adp_associate_id already exists";
      returnMessage.error = {
        adp_associate_id: "adp_associate_id already exists",
      };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      let userData = [
        org_id,
        employee_type,
        role_id,
        prefix,
        first_name,
        middle_name,
        last_name,
        full_name,
        email,
        gender,
        adp_associate_id,
        phone_number,
        branch_id,
        branch_name,
        department_id,
        department_name,
        work_country, // country_name
        work_state, // state_name
        employee_id,
        ecdb_user_id,
        prospective_user_id,
        joining_date,
        leaving_date,
        qb_employee_name,
        qb_employee_id,
        user_status,
        work_location,
        work_country,
        work_state,
        work_city,
        work_street_address,
        "", // work_status
        permanent_address,
        work_address,
        zipcode,
        email_notifications,
        push_notifications,
        createdby,
        record_type_status,
        visa_status,
        adp_validated,
      ];
      await con.query(
        `SELECT timesheets.insert_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
        userData,
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insert_user_data";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Inserted Successfully";
            // returnMessage.response = results.rows[0].insert_users;
            returnMessage.data = results.rows[1].insert_users;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insert_user_data";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// POST API for insert/update user
const update_user_data = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createuserValidator({ ...req.body });

    let email_exists = false;
    let ecdb_user_exists = false;
    let prospective_user_exists = false;
    let adp_associate_exists = false;

    let {
      ecdb_user_id = null,
      org_id,
      role_name,
      employee_type = null,
      prefix = null,
      first_name = null,
      middle_name = null,
      last_name,
      full_name,
      email,
      gender,
      adp_associate_id = null,
      phone_number,
      branch_id = null,
      branch_name = null,
      department_id = null,
      department_name = null,
      employee_id = null,
      prospective_user_id = null,
      joining_date = null,
      leaving_date = null,
      qb_employee_name = "",
      qb_employee_id = null,
      user_status,
      work_location,
      work_country,
      work_state,
      work_city,
      work_street_address,
      permanent_address,
      work_address,
      zipcode,
      email_notifications = false,
      push_notifications = false,
      createdby = null,
      updatedby = null,
      visa_status = null,
      adp_validated = false,
    } = req.body;

    //get role id from local db by role name
    let role_data = await con.query(`SELECT timesheets.get_role_by_name($1)`, [
      role_name,
    ]);
    role_data = (role_data && role_data.rows[0].get_role_by_name && role_data.rows[0].get_role_by_name[0]) || null;
    let role_id = (role_data && role_data.id) || null;

    full_name = `${first_name} ${last_name}`.trim();
    let record_type_status = user_status.toLowerCase() == "active" ? "Active" : "Inactive";

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "update_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }


    let org_id_not_exist;
    if (org_id) {
      org_id_not_exist = await con.query(
        `SELECT timesheets.get_organizations_by_orgid($1)`,
        [org_id]
      );
      org_id_not_exist =
        (org_id_not_exist &&
          org_id_not_exist.rows[0].get_organizations_by_orgid &&
          org_id_not_exist.rows[0].get_organizations_by_orgid[0]) ||
        null;
    }

    if (!org_id_not_exist) {
      returnMessage.isError = true;
      returnMessage.message = "org_id does not exists";
      returnMessage.error = { org_id: "org_id does not exists" };
      returnMessage.label = "update_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_user_by_email($1, $2)`,
        [org_id, email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_user_by_email &&
          email_exists.rows[0].get_user_by_email[0]) ||
        null;
    }

    let id = (email_exists && email_exists.id) || null;

    // check if ecdb_user_id already exists
    if (ecdb_user_id) {
      ecdb_user_exists = await con.query(
        `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
        [org_id, ecdb_user_id]
      );
      ecdb_user_exists =
        (ecdb_user_exists &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id[0]) ||
        null;
    }
    // let id = ecdb_user_exists.id;

    // check if prospective_user_id already exists
    if (prospective_user_id) {
      prospective_user_exists = await con.query(
        `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
        [org_id, prospective_user_id]
      );
      prospective_user_exists =
        (prospective_user_exists &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id[0]) ||
        null;
    }

    // check if adp associate id already exists
    if(adp_associate_id) {
      adp_associate_exists = await con.query(`SELECT timesheets.get_user_by_adp_associate_id($1,$2)`,
      [org_id, adp_associate_id]
      );
      adp_associate_exists =
        (adp_associate_exists &&
        adp_associate_exists.rows[0].get_user_by_adp_associate_id && 
        adp_associate_exists.rows[0].get_user_by_adp_associate_id[0]) || null;
    }
    // console.log("id", id, adp_associate_exists);
    // update user
    if(email_exists && email_exists.id){
      
      if (email_exists && email_exists.id && email_exists.id != id) {
        returnMessage.isError = true;
        returnMessage.message = "email already exists";
        returnMessage.error = { email: "email already exists" };
        returnMessage.label = "update_user_data";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      } else if (
        ecdb_user_exists &&
        ecdb_user_exists.id &&
        ecdb_user_exists.id != id
      ) {
        returnMessage.isError = true;
        returnMessage.message = "ecdb_user_id already exists";
        returnMessage.error = { email: "ecdb_user_id already exists" };
        returnMessage.label = "update_user_data";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      } else if (
        prospective_user_exists &&
        prospective_user_exists.id &&
        prospective_user_exists.id != id
      ) {
        returnMessage.isError = true;
        returnMessage.message = "prospective_user_id already exists";
        returnMessage.error = { email: "prospective_user_id already exists" };
        returnMessage.label = "update_user_data";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      } else if(
        adp_associate_exists && 
        adp_associate_exists.id && 
        adp_associate_exists.id != id
        ) {
        returnMessage.isError = true;
        returnMessage.message = "adp_associate_id already exists";
        returnMessage.error = {
          adp_associate_id: "adp_associate_id already exists",
        };
        returnMessage.label = "edituser";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      } else {

        employee_id = employee_id || email_exists.employee_id || null;
        prefix = prefix || email_exists.prefix || null;
        email_notifications = email_exists.email_notifications;
        push_notifications = email_exists.push_notifications;
        
        await con.query(
          `SELECT timesheets.update_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42)`,
          [
            id,
            org_id,
            employee_type,
            role_id,
            prefix,
            first_name,
            middle_name,
            last_name,
            full_name,
            email,
            gender,
            adp_associate_id,
            phone_number,
            branch_id,
            branch_name,
            department_id,
            department_name,
            work_country, // country_name
            work_state, // state_name
            employee_id,
            ecdb_user_id,
            prospective_user_id,
            joining_date,
            leaving_date,
            qb_employee_name,
            qb_employee_id,
            user_status,
            work_location,
            work_country,
            work_state,
            work_city,
            work_street_address,
            "", // work_status
            permanent_address,
            work_address,
            zipcode,
            email_notifications,
            push_notifications,
            updatedby,
            record_type_status,
            visa_status,
            adp_validated,
          ],
          (error, results) => {
            if (error) {
              returnMessage.isError = true;
              returnMessage.message = "Failed to update";
              returnMessage.error = error;
              returnMessage.label = "update_user_data";
              logger.log({
                level: "error",
                message: returnMessage,
              });
              res.status(400).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "Updated Successfully";
              returnMessage.data = results.rows[1].update_users;
              res.status(200).json(returnMessage);
            }
          }
        );
      }
    }
    else{
      // insert

    if (email_exists && email_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "email already exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (ecdb_user_exists && ecdb_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "ecdb_user_id already exists";
      returnMessage.error = { email: "ecdb_user_id already exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (prospective_user_exists && prospective_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "prospective_user_id already exists";
      returnMessage.error = { email: "prospective_user_id already exists" };
      returnMessage.label = "insert_user_data";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (adp_associate_exists && adp_associate_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "adp_associate_id already exists";
      returnMessage.error = {
        adp_associate_id: "adp_associate_id already exists",
      };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {

      let new_employee_id = await con.query(`SELECT timesheets.get_new_employee_id($1)`, [org_id]);
      new_employee_id = (new_employee_id && new_employee_id.rows[0].get_new_employee_id && new_employee_id.rows[0].get_new_employee_id[0]) || null;
      employee_id = employee_id || new_employee_id.employee_id || null;

      let userData = [
        org_id,
        employee_type,
        role_id,
        prefix,
        first_name,
        middle_name,
        last_name,
        full_name,
        email,
        gender,
        adp_associate_id,
        phone_number,
        branch_id,
        branch_name,
        department_id,
        department_name,
        work_country, // country_name
        work_state, // state_name
        employee_id,
        ecdb_user_id,
        prospective_user_id,
        joining_date,
        leaving_date,
        qb_employee_name,
        qb_employee_id,
        user_status,
        work_location,
        work_country,
        work_state,
        work_city,
        work_street_address,
        "", // work_status
        permanent_address,
        work_address,
        zipcode,
        email_notifications,
        push_notifications,
        createdby,
        record_type_status,
        visa_status,
        adp_validated,
      ];
      await con.query(
        `SELECT timesheets.insert_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
        userData,
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insert_user_data";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Inserted Successfully";
            // returnMessage.response = results.rows[0].insert_users;
            returnMessage.data = results.rows[1].insert_users;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    }

    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "update_user_data";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_projects_by_ecdb_user_id
const get_projects_by_ecdb_user_id = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.query.org_id;
  let ecdb_user_id = req.query.ecdb_user_id;
  try {
    await con.query(
      `SELECT * from timesheets.get_projects_by_ecdb_user_id($1, $2)`,
      [org_id, ecdb_user_id],
      (error, results) => {

        if (error) {
          returnMessage.isError = true;
          returnMessage.message =
            "Failed to fetch projects";
          returnMessage.error = error;
          returnMessage.label = "get_projects_by_ecdb_user_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {

          // console.log("results", results);

          results = (results.rows && results.rows[0] && results.rows[0].j) || null;

          if(results && results.length){
            // vendor name fetching
            let new_response = [];
            for (var i = 0; i< results.length; i++) {
              let row = results[i];
              let vendor_name =
                (row.vendors &&
                  row.vendors.length &&
                  row.vendors[0] &&
                  row.vendors[0].client_name) ||
                null;
            // let vendors = {
            //     vendor_name: vendor_name,
            // };
              let client_name = row.end_customer_name;
              if(row.direct_customer_engagement){
                client_name = row.end_customer_name;
              }
              else{
                if(row.vendors && row.vendors.length){
                  for (var vendorI = 0; vendorI < row.vendors.length; vendorI++) {
                    tmpVendor = vendors[vendorI];
                    if(tmpVendor.is_prime){
                      client_name = tmpVendor.client_name;
                    }
                  }
                }
              }

              new_response.push({
                employee_name: row.employee_name || null,
                project_name: row.project_name || null,
                end_customer: row.end_customer_name || null,
                client_name: client_name || null,
                is_placement_project: row.is_placement_project,
                placement_project_id: row.placement_project_id || null,
                direct_customer_engagement: row.direct_customer_engagement,
                placement_code: row.placement_code || null,
                project_status: row.project_status || null,
                start_date: row.start_date || null,
                end_date: row.end_date || null,
                vendor_name: vendor_name || null,
                // vendors,
              });
            }

            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = new_response;
            res.status(200).json(returnMessage);
          }
          else{

            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          
        }
      }
    );
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_projects_by_ecdb_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  insert_organization_data,
  insert_user_data,
  update_user_data,
  get_projects_by_ecdb_user_id,
};
