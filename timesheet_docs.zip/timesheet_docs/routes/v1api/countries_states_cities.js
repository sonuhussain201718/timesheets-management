const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getallcountries,
  countries_by_name,
  get_states_by_country_id,
  get_cities_by_state_id,
} = require("../../controllers/countriesStatesCitiesController");

// @route GET api/v1/countrystatecity/getallcountries
// @desc  Route to get all countries
// @accesss public
router.get("/getallcountries", getallcountries);

// @route GET api/v1/countrystatecity/countries_by_name
// @desc  Route to get countries_by_name
// @accesss public
router.get("/countries_by_name", countries_by_name);

// @route GET api/v1/countrystatecity/get_states_by_country_id
// @desc  Route to get get_states_by_country_id
// @accesss public
router.get("/get_states_by_country_id", get_states_by_country_id);

// @route GET api/v1/countrystatecity/get_cities_by_state_id
// @desc  Route to get get_cities_by_state_id
// @accesss public
router.get("/get_cities_by_state_id", get_cities_by_state_id);

module.exports = router;
