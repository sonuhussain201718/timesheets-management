const express = require("express");
const router = express.Router();

const { authMiddleware } = require("../../middlewares/auth"); // load auth middlware
const { errMiddleware } = require("../../middlewares/error"); // load error middlware

const {
  get_all_mobile_force_update,
  get_mobile_force_update_by_id,
  get_mobile_force_update_by_os_and_version,
  insert_mobile_force_update,
  edit_mobile_force_update,
  update_mobile_device,
  insert_mobile_force_update_access,
  get_mobile_force_update_access_by_email,
  delete_mobile_force_update,
  delete_mobile_force_update_access,
  get_current_date_time
} = require("../../controllers/mobileController");

// @route GET api/v1/mobile/get_all_mobile_force_update
// @desc  Route to get all mobile
// @accesss public
router.get("/get_all_mobile_force_update", authMiddleware, errMiddleware, get_all_mobile_force_update);

// @route GET api/v1/mobile/get_mobile_force_update_by_id
// @desc  Route to get_mobile_force_update_by_id
// @accesss public
router.get("/get_mobile_force_update_by_id", authMiddleware, errMiddleware, get_mobile_force_update_by_id);

// @route GET api/v1/mobile/get_mobile_force_update_by_os_and_version
// @desc  Route to get_mobile_force_update_by_os_and_version
// @accesss public
router.get("/get_mobile_force_update_by_os_and_version", get_mobile_force_update_by_os_and_version);

// @route POST api/v1/mobile/insert_mobile_force_update
// @desc  Route to post mobile_force_update
// @accesss public
router.post("/insert_mobile_force_update", authMiddleware, errMiddleware, insert_mobile_force_update);

// @route PUT api/v1/mobile/edit_mobile_force_update
// @desc  Route to edit mobile_force_update
// @accesss public
router.put("/edit_mobile_force_update", authMiddleware, errMiddleware, edit_mobile_force_update);

// @route POST api/v1/mobile/update_mobile_device
// @desc  Route to edit update_mobile_device
// @accesss public
router.post("/update_mobile_device", authMiddleware, errMiddleware, update_mobile_device);

// @route POST api/v1/mobile/insert_mobile_force_update_access
// @desc  Route to edit insert_mobile_force_update_access
// @accesss public
router.post("/insert_mobile_force_update_access", authMiddleware, errMiddleware, insert_mobile_force_update_access);

// @route GET api/v1/mobile/get_mobile_force_update_access_by_email
// @desc  Route to edit get_mobile_force_update_access_by_email
// @accesss public
router.get("/get_mobile_force_update_access_by_email", authMiddleware, errMiddleware, get_mobile_force_update_access_by_email);

// @route POST api/v1/mobile/delete_mobile_force_update
// @desc  Route to post delete_mobile_force_update
// @accesss public
router.post("/delete_mobile_force_update", authMiddleware, errMiddleware, delete_mobile_force_update);

// @route POST api/v1/mobile/delete_mobile_force_update_access
// @desc  Route to post delete_mobile_force_update_access
// @accesss public
router.post("/delete_mobile_force_update_access", authMiddleware, errMiddleware, delete_mobile_force_update_access);

// @route GET api/v1/mobile/get_current_date_time
// @desc  Route to get get_current_date_time
// @accesss public
router.get("/get_current_date_time", get_current_date_time);


module.exports = router;