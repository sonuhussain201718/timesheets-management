const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createMobileForceUpdateValidator(data) {
  let errors = {};

  // if (data.hasOwnProperty("id") && !data.id) {
  //   errors.id = "id field is required";
  // }

  if (!data.os) {
    errors.os = "os field is required";
  }

  if (!data.app_version) {
    errors.app_version = "app_version field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
