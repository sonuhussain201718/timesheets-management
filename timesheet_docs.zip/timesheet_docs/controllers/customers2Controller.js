const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const createCustomerValidator = require("../validation/createCustomerValidator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const axios = require("axios");
const fs = require("fs");
const { BlobServiceClient } = require("@azure/storage-blob");
var mime = require("mime-types");
const excelJS = require("exceljs");
const path = require("path");
const { ROLES } = require("../constants");
const {
  isQBEnabled,
  isQBTransactionOn,
  getOrgData,
} = require("../utils/timesheet_helpers");
const { titleCase } = require("../utils/helpers");

// GET api for customers List
const get_all_customers = async (req, res) => {
  const returnMessage = getMsgFormat();

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.client_name == undefined || req.query.client_name == "") {
    req.query.client_name = null;
  }
  if (
    req.query.qb_customer_name == undefined ||
    req.query.qb_customer_name == ""
  ) {
    req.query.qb_customer_name = null;
  }
  if (req.query.qb_customer_id == undefined || req.query.qb_customer_id == "") {
    req.query.qb_customer_id = null;
  }
  if (
    req.query.record_type_status == undefined ||
    req.query.record_type_status == ""
  ) {
    req.query.record_type_status = null;
  }
  if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
    req.query.pagenumber = null;
  }
  if (req.query.pagesize == undefined || req.query.pagesize == "") {
    req.query.pagesize = null;
  }
  try {
    await con.query(
      `SELECT * from timesheets.get_all_customers($1,$2,$3,$4,$5,$6,$7,$8);`,
      [
        req.query.keyword,
        req.user.org_id,
        req.query.client_name,
        req.query.qb_customer_name,
        req.query.qb_customer_id,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch customer details";
          returnMessage.error = error;
          returnMessage.label = "get_all_customers";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {

          let data = (results.rows && results.rows[1] && results.rows[1].j) || null;

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          // don't pass qb details in API response
          if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
            for (var i = 0; i < data.length; i++) {
              delete data[i].qb_customer_id;
              delete data[i].qb_customer_name;
              delete data[i].qb_vendor_id;
              delete data[i].qb_vendor_name;
            }
          }

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_customers";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for search/filter customers
// const filter_customers = async (req, res) => {
//   const returnMessage = getMsgFormat();
//   if (req.query.client_name == undefined || req.query.client_name == "") {
//     req.query.client_name = null;
//   }
//   if (
//     req.query.qb_customer_name == undefined ||
//     req.query.qb_customer_name == ""
//   ) {
//     req.query.qb_customer_name = null;
//   }
//   if (req.query.qb_customer_id == undefined || req.query.qb_customer_id == "") {
//     req.query.qb_customer_id = null;
//   }
//   if (
//     req.query.record_type_status == undefined ||
//     req.query.record_type_status == ""
//   ) {
//     req.query.record_type_status = null;
//   }
//   if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
//     req.query.pagenumber = null;
//   }
//   if (req.query.pagesize == undefined || req.query.pagesize == "") {
//     req.query.pagesize = null;
//   }
//   try {
//     var output = [];
//     await con.query(
//       `SELECT * from timesheets.get_customers_filter($1,$2,$3,$4,$5,$6,$7)`,
//       [
//         req.user.org_id,
//         req.query.client_name,
//         req.query.qb_customer_name,
//         req.query.qb_customer_id,
//         req.query.record_type_status,
//         req.query.pagenumber,
//         req.query.pagesize,
//       ],
//       (error, results) => {
//         if (error) {
//           returnMessage.isError = true;
//           returnMessage.message = "Failed to filter customer details";
//           returnMessage.error = error;
//           returnMessage.label = "filtercustomers";
//           logger.log({
//             level: "error",
//             message: returnMessage,
//           });
//           res.status(400).json(returnMessage);
//         } else {
//           counts = results.rows[1].j;
//           data =
//             (results.rows && results.rows[0] && results.rows[0].j) || null;


          // don't pass qb details in API response
          // if((data && data.length) && (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
          //   for (var i = 0; i < data.length; i++) {
          //     delete data[i].qb_customer_id;
          //     delete data[i].qb_customer_name;
          //     delete data[i].qb_vendor_id;
          //     delete data[i].qb_vendor_name;
          //   }
          // }
//           if (results) {
//             returnMessage.isError = false;
//             returnMessage.message = "Records Found";
//             returnMessage.data = data;
//             returnMessage.count = counts;
//             res.status(200).json(returnMessage);
//           } else {
//             returnMessage.isError = false;
//             returnMessage.message = "No Records Found";
//             res.status(200).json(returnMessage);
//           }
//         }
//       }
//     );
//   } catch (error) {
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.label = "filtercustomers";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
// };

// GET api for customer details
const get_customer_by_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.messag = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_customer_by_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_customer_by_id($1,$2)`,
        [req.user.org_id, req.query.id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch customer details";
            returnMessage.error = error;
            returnMessage.label = "get_customer_by_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;
            if (results) {

              let is_qb_enabled = await isQBEnabled(req.user.org_id);

              if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                delete results.qb_customer_id;
                delete results.qb_customer_name;
                delete results.qb_vendor_id;
                delete results.qb_vendor_name;
              }

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_customer_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for customers List
const get_customers_list = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_customers_list($1);`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch customer list";
          returnMessage.error = error;
          returnMessage.label = "get_customers_list";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[1] && results.rows[1].j) || null;
          if (results) {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = results;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_customers_list";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for customers
const insert_customer = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createCustomerValidator({
      ...req.body,
      org_id,
    });
    let customer_exists_1 = null;
    let customer_exists_2 = null;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insert_customer";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let {
      client_name = null,
      dba = null,
      is_placement_client = false,
      placement_client_id = null,
      qb_customer_name = null,
      qb_customer_id = null,
      qb_vendor_name = null,
      qb_vendor_id = null,
    } = req.body;

    if (client_name) {
      customer_exists_1 = await con.query(
        `SELECT timesheets.get_customer_by_client_name($1, $2)`,
        [org_id, client_name]
      );

      customer_exists_1 =
        (customer_exists_1 &&
          customer_exists_1.rows[1] &&
          customer_exists_1.rows[1].get_customer_by_client_name &&
          customer_exists_1.rows[1].get_customer_by_client_name[0]) ||
        null;
    }

    if (placement_client_id) {
      customer_exists_2 = await con.query(
        `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
        [org_id, placement_client_id]
      );
      customer_exists_2 =
        (customer_exists_2 &&
          customer_exists_2.rows[0] &&
          customer_exists_2.rows[0].get_customer_by_placement_client_id &&
          customer_exists_2.rows[0].get_customer_by_placement_client_id[0]) ||
        null;
    }

    if (customer_exists_1 && customer_exists_1.id) {
      returnMessage.isError = true;
      returnMessage.message = "customer/client name already exists";
      returnMessage.error = {
        client_name: "customer/client name already exists",
      };
      returnMessage.label = "insert_customer";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (customer_exists_2 && customer_exists_2.id) {
      returnMessage.isError = true;
      returnMessage.message = "placement_client_id already exists";
      returnMessage.error = { email: "placement_client_id already exists" };
      returnMessage.label = "insert_customer";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [
          org_id,
          client_name,
          dba,
          is_placement_client,
          placement_client_id,
          qb_customer_name,
          qb_customer_id,
          qb_vendor_name,
          qb_vendor_id,
          createdby,
          "Active",
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insert_customer";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let data =
              (results &&
                results.rows &&
                results.rows[1] &&
                results.rows[1].insert_customers &&
                results.rows[1].insert_customers[0]) ||
              null;

              let is_qb_enabled = await isQBEnabled(req.user.org_id);

            // don't pass qb details in API response
            if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
              delete data.qb_customer_id;
              delete data.qb_customer_name;
              delete data.qb_vendor_id;
              delete data.qb_vendor_name;
            }

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insert_customer";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for customers
const edit_customer = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createCustomerValidator({
      ...req.body,
      org_id,
    });

    let customer_exists_1 = null;
    let customer_exists_2 = null;

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edit_customer";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let updatedby = req.user.id;
    let {
      id = null,
      client_name = null,
      dba = null,
      is_placement_client = false,
      placement_client_id = null,
      qb_customer_name = null,
      qb_customer_id = null,
      qb_vendor_name = null,
      qb_vendor_id = null,
      record_type_status = null,
    } = req.body;

    if (client_name) {
      customer_exists_1 = await con.query(
        `SELECT timesheets.get_customer_by_client_name_excluding_id($1,$2,$3)`,
        [org_id, id, client_name]
      );

      customer_exists_1 =
        (customer_exists_1 &&
          customer_exists_1.rows[1] &&
          customer_exists_1.rows[1].get_customer_by_client_name_excluding_id &&
          customer_exists_1.rows[1]
            .get_customer_by_client_name_excluding_id[0]) ||
        null;
    }

    if (placement_client_id) {
      customer_exists_2 = await con.query(
        `SELECT timesheets.get_customer_by_placement_client_id_excluding_id($1,$2,$3)`,
        [org_id, id, placement_client_id]
      );
      customer_exists_2 =
        (customer_exists_2 &&
          customer_exists_2.rows[0] &&
          customer_exists_2.rows[0]
            .get_customer_by_placement_client_id_excluding_id &&
          customer_exists_2.rows[0]
            .get_customer_by_placement_client_id_excluding_id[0]) ||
        null;
    }

    if (customer_exists_1 && customer_exists_1.id) {
      returnMessage.isError = true;
      returnMessage.message = "customer/client name already exists";
      returnMessage.error = {
        client_name: "customer/client name already exists",
      };
      returnMessage.label = "edit_customer";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (customer_exists_2 && customer_exists_2.id) {
      returnMessage.isError = true;
      returnMessage.message = "placement_client_id already exists";
      returnMessage.error = { email: "placement_client_id already exists" };
      returnMessage.label = "edit_customer";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.update_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [
          id,
          org_id,
          client_name,
          dba,
          is_placement_client,
          placement_client_id,
          qb_customer_name,
          qb_customer_id,
          qb_vendor_name,
          qb_vendor_id,
          updatedby,
          record_type_status,
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "edit_customer";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            var data = (results.rows && results.rows[1] && results.rows[1].update_customers) || null;
            // don't pass qb details in API response
            if(data && data[0] && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
              delete data[0].qb_customer_id;
              delete data[0].qb_customer_name;
              delete data[0].qb_vendor_id;
              delete data[0].qb_vendor_name;
            }

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "edit_customer";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_all_customers
const export_all_customers = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.client_name == undefined || req.query.client_name == "") {
    req.query.client_name = null;
  }
  if (
    req.query.qb_customer_name == undefined ||
    req.query.qb_customer_name == ""
  ) {
    req.query.qb_customer_name = null;
  }
  if (req.query.qb_customer_id == undefined || req.query.qb_customer_id == "") {
    req.query.qb_customer_id = null;
  }
  if (
    req.query.record_type_status == undefined ||
    req.query.record_type_status == ""
  ) {
    req.query.record_type_status = null;
  }
  try {
    await con.query(
      `SELECT * from timesheets.export_all_customers($1,$2,$3,$4,$5,$6);`,
      [
        req.query.keyword,
        org_id,
        req.query.client_name,
        req.query.qb_customer_name,
        req.query.qb_customer_id,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_customers";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {

            let is_qb_enabled = await isQBEnabled(req.user.org_id);
            let is_qb_transaction_on = await isQBTransactionOn(
              req.user.org_id,
              "getcustomerdatabyname"
            );

            // don't pass qb details in API response
            if((results && results.length) && ( !is_qb_enabled || !is_qb_transaction_on || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
              for (var i = 0; i < results.length; i++) {
                delete results[i].qb_customer_id;
                delete results[i].qb_customer_name;
                delete results[i].qb_vendor_id;
                delete results[i].qb_vendor_name;
              }
            }
            
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportCustomersData");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "CLIENT", key: "client_name", width: 10 },
            ];

            if (
              is_qb_enabled &&
              is_qb_transaction_on &&
              [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id
              )
            ) {
              worksheet.columns = [
                ...worksheet.columns,
                {
                  header: "QB CLIENT NAME",
                  key: "qb_customer_name",
                  width: 10,
                },
                { header: "QB CLIENT ID", key: "qb_customer_id", width: 10 },
              ];
            }
            
            worksheet.columns = [
              ...worksheet.columns,
              { header: "STATUS", key: "record_type_status", width: 10 },
            ];

            for (i = 0; i < results.length; i++) {
              row = results[i];

              let client_name = row.client_name ? titleCase(row.client_name) : "";
              let record_type_status = row.record_type_status;
              record_type_status = record_type_status.replace("Inactive", "In Active");

              let tmpRow = [
                client_name,
              ];
               if (
                 is_qb_enabled &&
                 is_qb_transaction_on &&
                 [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                   req.user.role_id
                 )
               ) {
                 tmpRow = [...tmpRow, row.qb_customer_name, row.qb_customer_id];
               }
               tmpRow = [...tmpRow, record_type_status];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/exports/customers"
            );
            let fileName = `customers-list-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/exports/customers/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {

                let orgData = await getOrgData(org_id);
                let newFileName = `customers-list-${((orgData && orgData.org_name) || ``)}.xlsx`
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/exports/customers/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);
              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_all_customers";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for customer details
const get_default_org_as_customer = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {

      let org_id = req.user.org_id;
      let exists = await con.query(`SELECT * from timesheets.get_default_org_as_customer($1)`,
      [org_id]);
      exists = (exists.rows && exists.rows[0] && exists.rows[0].j && exists.rows[0].j[0]) || null;

      if(exists){

        let is_qb_enabled = await isQBEnabled(req.user.org_id); 
        
        if(!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
          delete exists.qb_customer_id;
          delete exists.qb_customer_name;
          delete exists.qb_vendor_id;
          delete exists.qb_vendor_name;
        }

        returnMessage.isError = false;
        returnMessage.message = "Records Found";
        returnMessage.data = exists;
        res.status(200).json(returnMessage);
      }
      else{

        let client_name = null;
        let org_data = await con.query(`SELECT * FROM timesheets.get_organizations_by_orgid($1)`,
        [org_id]);
        
        org_data = (org_data && org_data.rows[0].j && org_data.rows[0].j[0]) || null;
        if(org_data && org_data.org_name){
          client_name = org_data.org_name;
        };

        if(client_name){
          await con.query(
            `SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
            [
              org_id,
              client_name,
              null,
              false,
              null,
              null,
              null,
              null,
              null,
              req.user.id,
              "Active",
            ],
            async (error, results) => {
              if (error) {
                returnMessage.isError = true;
                returnMessage.message = "Failed to add";
                returnMessage.error = error;
                returnMessage.label = "get_default_org_as_customer";
                logger.log({
                  level: "error",
                  message: returnMessage,
                });
                res.status(400).json(returnMessage);
              } else {
                let data = (results && results.rows && results.rows[1] && results.rows[1].insert_customers &&
                    results.rows[1].insert_customers[0]) || null;

                    let is_qb_enabled = await isQBEnabled(req.user.org_id);
  
                // don't pass qb details in API response
                if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                  delete data.qb_customer_id;
                  delete data.qb_customer_name;
                  delete data.qb_vendor_id;
                  delete data.qb_vendor_name;
                }
    
                returnMessage.isError = false;
                returnMessage.data = data;
                returnMessage.message = "Records Found";
                res.status(200).json(returnMessage);
              }
            }
          );
        }
      }
    
      
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_default_org_as_customer";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_all_customers,
  // filter_customers,
  get_customer_by_id,
  get_customers_list,
  insert_customer,
  edit_customer,
  export_all_customers,
  get_default_org_as_customer,
};
