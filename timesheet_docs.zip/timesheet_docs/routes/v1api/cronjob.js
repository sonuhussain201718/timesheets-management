const express = require("express");
const router = express.Router();

const {
  weekly_timesheet_reminder,

} = require("../../controllers/cronjobController");

// @route POST api/v1/cronjob/weekly_timesheet_reminder
// @desc  Route to get weekly_timesheet_reminder
// @accesss public
router.get("/weekly_timesheet_reminder", weekly_timesheet_reminder);


module.exports = router;
