const jwt = require("jsonwebtoken");
const axios = require("axios");
const nodecache = require("node-cache");
const logger = require("../utils/logger");
const appCache = new nodecache({ stdTTL: 3599 });

const auth = async (req, res, next) => {
  const bearerToken = req.header("Authorization");
  if (!bearerToken) {
    return res.status(401).send({
      error:
        "Not authorized to access this resource. Please provide access token",
    });
  }

  const token = bearerToken.replace("Bearer ", "");
  let tokenData = null;

  // Verify token
  try {
    tokenData = jwt.verify(token, process.env.SECRET_OR_KEY);
  } catch (error) {
    logger.error("error--- ", JSON.stringify(error));
    logger.debug(error.name);
    if (error.name && error.name === "TokenExpiredError") {
      return res.status(401).send({
        error: "Not authorized to access this resource. Token Expired!",
      });
    }

    return res.status(401).send({
      error: "Not authorized to access this resource. Incorrect token",
    });
  }

  // fetch user based on token
  try {
    var user = {};
    var secret = process.env.SECRET_OR_KEY;
    var authToken = bearerToken.split("Bearer ")[1];
    user = jwt.verify(authToken, secret);
    appCache.set("req.user", user);
    req.user = user;
    next();
  } catch (error) {
    res.status(500).send(error);
  }
};

module.exports = { authMiddleware: auth };
