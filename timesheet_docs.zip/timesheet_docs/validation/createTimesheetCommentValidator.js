const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createTimesheetCommentValidator(data) {
  let errors = {};

  if (!data.comments) {
    errors.org_name = "comment field is required";
  }
  
  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
