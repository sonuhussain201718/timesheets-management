const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_all_employee_documents,
  export_all_employee_documents,
  get_employee_document_by_id,
  get_employee_documents_by_user_id,
  insert_employee_document,
  edit_employee_document,
  delete_employee_document_by_id,
} = require("../../controllers/employeeDocumentsController");

// @route GET api/v1/employee_documents/get_all_employee_documents
// @desc  Route to get_all_employee_documents
// @accesss public
router.get("/get_all_employee_documents", get_all_employee_documents);

// @route GET api/v1/employee_documents/export_all_employee_documents
// @desc  Route to export_all_employee_documents
// @accesss public
router.get("/export_all_employee_documents", export_all_employee_documents);

// @route GET api/v1/employee_documents/get_employee_document_by_id
// @desc  Route to get_employee_document_by_id
// @accesss public
router.get("/get_employee_document_by_id", get_employee_document_by_id);

// @route GET api/v1/employee_documents/get_employee_documents_by_user_id
// @desc  Route to get_employee_documents_by_user_id
// @accesss public
router.get("/get_employee_documents_by_user_id", get_employee_documents_by_user_id);

// @route POST api/v1/employee_documents/insert_employee_document
// @desc  Route to insert_employee_document
// @accesss public
router.post("/insert_employee_document", insert_employee_document);

// @route PUT api/v1/employee_documents/edit_employee_document
// @desc  Route to edit_employee_document
// @accesss public
router.put("/edit_employee_document", edit_employee_document);

// @route PUT api/v1/employee_documents/delete_employee_document_by_id
// @desc  Route to delete_employee_document_by_id
// @accesss public
router.post("/delete_employee_document_by_id", delete_employee_document_by_id);


module.exports = router;
