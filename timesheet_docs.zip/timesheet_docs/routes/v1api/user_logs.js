const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_all_user_logs,
  export_all_user_logs,
} = require("../../controllers/userLogsController");

// @route GET api/v1/user_logs/get_all_user_logs
// @desc  Route to get all user_logs
// @accesss public
router.get("/get_all_user_logs", get_all_user_logs);

// @route GET api/v1/user_logs/export_all_user_logs
// @desc  Route to get all user_logs
// @accesss public
router.get("/export_all_user_logs", export_all_user_logs);

module.exports = router;
