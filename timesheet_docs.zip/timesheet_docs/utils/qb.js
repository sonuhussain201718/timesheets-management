const QuickBooks = require("node-quickbooks");
const con = require("../utils/db");

const qbodata = async (org_id) => {
  try {
    var result = await con.query(
      `SELECT * from timesheets.get_qb_auth_by_orgid($1);`,
      [org_id]
    );
    var dbdata = result.rows[0].j[0];
    var qbo = new QuickBooks(
      dbdata.client_id,
      dbdata.client_secret,
      dbdata.access_token /* oAuth access token */,
      false /* no token secret for oAuth 2.0 */,
      dbdata.realm_id,
      true /* use a sandbox account */,
      true /* turn debugging on */,
      4 /* minor version */,
      "2.0" /* oauth version */,
      dbdata.refresh_token /* refresh token */
    );
    return qbo;
  } catch (err) {
    return err;
  }
};

module.exports = qbodata;
