const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getalltimeactivityweekwise,
  getalltimeactivityweekswise,
  getalltimeactivitybyweeks,
  getalltimeactivitybyweek,
  getalltimeactivitybydate,
  getalltimeactivitybystatus,
  getalltimeactivity,
  getemployeeprojects,
  inserttimeactivity,
  insertalltimeactivity,
  insertupdatetimeactivity,
  edittimeactivity,
  gettimeactivitybyid,
  filtertimeactivity,
  getalltimedoc,
  gettimedocbyid,
  getalltimehistory,
  getalltimestatus,
  gethouroftimesheetstatus,
  gethouroftimesheetstatusbyweek,
  gettimesheetsbyempname,
  gettimesheetsbyprojectname,
  gettimesheetsbyyearandmonth,
  gettimesheethistorybyemailandweek,
  getapprovertimesheetsbyempname,
  getapprovertimesheetsbyprojectname,
  getapprovertimesheetsbyyearandmonth,
  gethourofapprovertimesheetstatusbyweek,
  gethourofapprovertimesheetstatus,
  getallapprovertimeactivitybystatus,
  filterapprovertimeactivity,
  getallapprovertimeactivitybyweekandstatus,
  getallapprovertimeactivitybydate,
  getapprovertimesheetweekbyempname,
  getapprovertimesheetweekbyprojectname,
  getallapprovertimeactivitybyweek,
  getapprovertimesheethistorybyweek,
  gettimesheethistorybyweekandproject,
  gettimesheetstatusbyweekandproject,
  getapprovertimesheetstatusbyweek,
  gettimesheethistoryperday,
  getapprovertimesheethistoryperday,
  gettimesheetstatusperday,
  getapprovertimesheetstatusperday,
  insertTimesheets,
  get_timesheet_docs_by_week_and_project,
  delete_timesheet_document,
  get_multiple_comment,
  sendstatusemail,
} = require("../../controllers/timeactivityController");

// @route GET api/v1/timeactivity/getalltimeactivityweekwise
// @desc  Route to get all getalltimeactivityweekwise
// @accesss public
router.get("/getalltimeactivityweekwise", getalltimeactivityweekwise);

// @route GET api/v1/timeactivity/getalltimeactivityweekswise
// @desc  Route to get all getalltimeactivityweekswise
// @accesss public
router.get("/getalltimeactivityweekswise", getalltimeactivityweekswise);

// @route GET api/v1/timeactivity/getalltimeactivitybyweeks
// @desc  Route to get all getalltimeactivitybyweeks
// @accesss public
router.get("/getalltimeactivitybyweeks", getalltimeactivitybyweeks);

// @route GET api/v1/timeactivity/getalltimeactivitybyweek
// @desc  Route to get all timeactivitys
// @accesss public
router.get("/getalltimeactivitybyweek", getalltimeactivitybyweek);

// @route GET api/v1/timeactivity/getalltimeactivitybystatus
// @desc  Route to get all getalltimeactivitybystatus
// @accesss public
router.get("/getalltimeactivitybystatus", getalltimeactivitybystatus);

// @route GET api/v1/timeactivity/getalltimeactivity
// @desc  Route to get all timeactivitys
// @accesss public
router.get("/getalltimeactivity", getalltimeactivity);

// @route GET api/v1/timeactivity/getemployeeprojects
// @desc  Route to get all timeactivitys
// @accesss public
router.get("/getemployeeprojects", getemployeeprojects);

// @route GET api/v1/timeactivity/gettimeactivitybyid
// @desc  Route to get timeactivitys by id
// @accesss public
router.get("/gettimeactivitybyid", gettimeactivitybyid);

// @route POST api/v1/timeactivity/insertalltimeactivity
// @desc  Route to post timeactivitys
// @accesss public
router.post("/insertalltimeactivity", insertalltimeactivity);

// @route POST api/v1/timeactivity/inserttimeactivity
// @desc  Route to post timeactivitys
// @accesss public
router.post("/inserttimeactivity", inserttimeactivity);

// @route POST api/v1/timeactivity/insertupdatetimeactivity
// @desc  Route to post timeactivitys
// @accesss public
router.post("/insertupdatetimeactivity", insertupdatetimeactivity);

// @route PUT api/v1/timeactivity/edittimeactivity
// @desc  Route to edit timeactivitys
// @accesss public
router.put("/edittimeactivity", edittimeactivity);

// @route GET api/v1/timeactivity/filtertimeactivitys
// @desc  Route to get timeactivitys by filter
// @accesss public
router.get("/filtertimeactivity", filtertimeactivity);

// @route GET api/v1/timeactivity/getalltimedoc
// @desc  Route to get all timedocs
// @accesss public
router.get("/getalltimedoc", getalltimedoc);

// @route GET api/v1/timeactivity/gettimedocbyid
// @desc  Route to get all timedocs
// @accesss public
router.get("/gettimedocbyid", gettimedocbyid);

// @route GET api/v1/timeactivity/getalltimehistory
// @desc  Route to get all timehistorys
// @accesss public
router.get("/getalltimehistory", getalltimehistory);

// @route GET api/v1/timeactivity/getalltimestatus
// @desc  Route to get all timestatuss
// @accesss public
router.get("/getalltimestatus", getalltimestatus);

// @route GET api/v1/timeactivity/gethouroftimesheetstatus
// @desc  Route to get all timestatus hours
// @accesss public
router.get("/gethouroftimesheetstatus", gethouroftimesheetstatus);

// @route GET api/v1/timeactivity/gethouroftimesheetstatusbyweek
// @desc  Route to get all timestatus hours
// @accesss public
router.get("/gethouroftimesheetstatusbyweek", gethouroftimesheetstatusbyweek);

// @route GET api/v1/timeactivity/gettimesheetsbyempname
// @desc  Route to get all timestatus by employee name
// @accesss public
router.get("/gettimesheetsbyempname", gettimesheetsbyempname);

// @route GET api/v1/timeactivity/gettimesheetsbyprojectname
// @desc  Route to get all timestatus by projectname
// @accesss public
router.get("/gettimesheetsbyprojectname", gettimesheetsbyprojectname);

// @route GET api/v1/timeactivity/gettimesheetsbyyearandmonth
// @desc  Route to get all timestatus by projectname
// @accesss public
router.get("/gettimesheetsbyyearandmonth", gettimesheetsbyyearandmonth);

// @route GET api/v1/timeactivity/gettimesheethistorybyemailandweek
// @desc  Route to get all timestatus by projectname
// @accesss public
router.get(
  "/gettimesheethistorybyemailandweek",
  gettimesheethistorybyemailandweek
);

// @route GET api/v1/timeactivity/getalltimeactivitybydate
// @desc  Route to get all timeactivitys by date
// @accesss public
router.get("/getalltimeactivitybydate", getalltimeactivitybydate);

// @route GET api/v1/timeactivity/getapprovertimesheetsbyempname
// @desc  Route to get all approver timestatus by employee name
// @accesss public
router.get("/getapprovertimesheetsbyempname", getapprovertimesheetsbyempname);

// @route GET api/v1/timeactivity/getapprovertimesheetsbyprojectname
// @desc  Route to get all approver timestatus by project name
// @accesss public
router.get(
  "/getapprovertimesheetsbyprojectname",
  getapprovertimesheetsbyprojectname
);

// @route GET api/v1/timeactivity/getapprovertimesheetsbyyearandmonth
// @desc  Route to get all timestatus by projectname
// @accesss public
router.get(
  "/getapprovertimesheetsbyyearandmonth",
  getapprovertimesheetsbyyearandmonth
);

// @route GET api/v1/timeactivity/gethourofapprovertimesheetstatusbyweek
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/gethourofapprovertimesheetstatusbyweek",
  gethourofapprovertimesheetstatusbyweek
);

// @route GET api/v1/timeactivity/gethourofapprovertimesheetstatus
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/gethourofapprovertimesheetstatus",
  gethourofapprovertimesheetstatus
);

// @route GET api/v1/timeactivity/getallapprovertimeactivitybystatus
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/getallapprovertimeactivitybystatus",
  getallapprovertimeactivitybystatus
);

// @route GET api/v1/timeactivity/filterapprovertimeactivity
// @desc  Route to get approver timestatus hours
// @accesss public
router.get("/filterapprovertimeactivity", filterapprovertimeactivity);

// @route GET api/v1/timeactivity/getallapprovertimeactivitybyweekandstatus
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/getallapprovertimeactivitybyweekandstatus",
  getallapprovertimeactivitybyweekandstatus
);

// @route GET api/v1/timeactivity/getallapprovertimeactivitybydate
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/getallapprovertimeactivitybydate",
  getallapprovertimeactivitybydate
);

// @route GET api/v1/timeactivity/getapprovertimesheetweekbyempname
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/getapprovertimesheetweekbyempname",
  getapprovertimesheetweekbyempname
);

// @route GET api/v1/timeactivity/getapprovertimesheetweekbyprojectname
// @desc  Route to get approver timestatus hours
// @accesss public
router.get(
  "/getapprovertimesheetweekbyprojectname",
  getapprovertimesheetweekbyprojectname
);

// @route GET api/v1/timeactivity/getallapprovertimeactivitybyweek
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/getallapprovertimeactivitybyweek",
  getallapprovertimeactivitybyweek
);

// @route GET api/v1/timeactivity/getapprovertimesheethistorybyweek
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/getapprovertimesheethistorybyweek",
  getapprovertimesheethistorybyweek
);

// @route GET api/v1/timeactivity/gettimesheethistorybyweekandproject
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/gettimesheethistorybyweekandproject",
  gettimesheethistorybyweekandproject
);

// @route GET api/v1/timeactivity/gettimesheetstatusbyweekandproject
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/gettimesheetstatusbyweekandproject",
  gettimesheetstatusbyweekandproject
);

// @route GET api/v1/timeactivity/getapprovertimesheetstatusbyweek
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/getapprovertimesheetstatusbyweek",
  getapprovertimesheetstatusbyweek
);

// @route GET api/v1/timeactivity/gettimesheethistoryperday
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get("/gettimesheethistoryperday", gettimesheethistoryperday);

// @route GET api/v1/timeactivity/getapprovertimesheethistoryperday
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/getapprovertimesheethistoryperday",
  getapprovertimesheethistoryperday
);

// @route GET api/v1/timeactivity/gettimesheetstatusperday
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get("/gettimesheetstatusperday", gettimesheetstatusperday);

// @route GET api/v1/timeactivity/getapprovertimesheetstatusperday
// @desc  Route to get approver timesheet data by week
// @accesss public
router.get(
  "/getapprovertimesheetstatusperday",
  getapprovertimesheetstatusperday
);

// @route POST api/v1/timeactivity/inserttimesheets
// @desc  Route to post inserttimesheets
// @accesss public
router.post("/inserttimesheets", insertTimesheets);

// @route GET api/v1/timeactivity/get_timesheet_docs_by_week_and_project
// @desc  Route to get get timesheet docs by week and project
// @accesss public
router.get(
  "/get_timesheet_docs_by_week_and_project",
  get_timesheet_docs_by_week_and_project
);

// @route PUT api/v1/timeactivity/delete_timesheet_document
// @desc  Route to delete timesheet document
// @accesss public
router.put("/delete_timesheet_document", delete_timesheet_document);

// @route get api/v1/timeactivity/get_multiple_comment
// @desc  Route to get timesheet comments
// @accesss public
router.get("/get_multiple_comment", get_multiple_comment);

// @route get api/v1/timeactivity/sendstatusemail
// @desc  Route to send emails
// @accesss public
router.get("/sendstatusemail", sendstatusemail);

module.exports = router;
