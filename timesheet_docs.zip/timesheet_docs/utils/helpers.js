const log4js = require("log4js");
const axios = require("axios");
const jwt_decode = require("jwt-decode");
const {
  BlobServiceClient,
  generateAccountSASQueryParameters,
  generateBlobSASQueryParameters,
  AccountSASPermissions,
  AccountSASServices,
  AccountSASResourceTypes,
  StorageSharedKeyCredential,
  SASProtocol,
} = require("@azure/storage-blob");
const { PREVIEW_EXTENSIONS } = require("../constants");

const getLogger = (moduleName) => {
  const logger = log4js.getLogger(moduleName);
  logger.level = "DEBUG";
  return logger;
};

const isEmpty = (value) =>
  value === undefined ||
  value === null ||
  (typeof value === "object" && Object.keys(value).length === 0) ||
  (typeof value === "string" && value.trim().length === 0);

const getMsgFormat = () => {
  let msgFormat = {
    isError: true,
    message: "Error occured!",
    data: null,
    errors: null, // if there are errors then this will become an object containing errors
    label: null,
  };

  return { ...msgFormat };
};

const returnAuthPayload = (user) => {
  return {
    org_id: user.org_id,
    email: user.email,
  };
};

const sortByLatestRecords = (data) => {
  return data.sort((a, b) => b.createddate - a.createddate);
};

const getBlobUrl = (containerName, blobName, preview = false, newFileName = ``) => {
  let extension = blobName.substring(blobName.lastIndexOf(".") + 1);
  // console.log("extension", extension);
  lowerExt = (extension && extension.toLowerCase()) || ``;

  try {
    ///// Code to generate blob url with preview

    if (PREVIEW_EXTENSIONS.includes(lowerExt) && preview == true) {
      var blobUrl = null;
      if (containerName && blobName) {
        const accountName = process.env.AZURE_STORAGE_ACCOUNT_NAME;
        const accountKey = process.env.AZURE_STORAGE_ACCOUNT_KEY;

        const sharedKeyCredential = new StorageSharedKeyCredential(
          accountName,
          accountKey
        );

        const sasOptions = {
          services: AccountSASServices.parse("btqf").toString(), // blobs, tables, queues, files
          resourceTypes: AccountSASResourceTypes.parse("sco").toString(), // service, container, object
          permissions: AccountSASPermissions.parse("rwdlacupi"), // permissions
          protocol: SASProtocol.Https,
          startsOn: new Date(new Date().valueOf() - 30 * 60 * 1000), // 30 minutes
          expiresOn: new Date(new Date().valueOf() + 30 * 60 * 1000), // 30 minutes
        };

        const sasToken = generateAccountSASQueryParameters(
          sasOptions,
          sharedKeyCredential
        ).toString();

        blobUrl = `https://${accountName}.blob.core.windows.net/${containerName}/${blobName}?${sasToken}`;
      }
      return blobUrl;
    } else {
      ///// code to generate downloadable blob url

      var blobUrl = null;
      if (containerName && blobName) {
        const accountName = process.env.AZURE_STORAGE_ACCOUNT_NAME;
        const accountKey = process.env.AZURE_STORAGE_ACCOUNT_KEY;

        const sharedKeyCredential = new StorageSharedKeyCredential(
          accountName,
          accountKey
        );

        const sasOptions = {
          containerName: containerName,
          blobName: blobName,
          // contentType: 'application/octet-stream',
          contentDisposition: `attachment; filename="${(newFileName)?newFileName:blobName.substring(
            blobName.lastIndexOf("/") + 1
          )}"`,
          // contentEncoding: 'gzip'
          services: AccountSASServices.parse("btqf").toString(), // blobs, tables, queues, files
          resourceTypes: AccountSASResourceTypes.parse("sco").toString(), // service, container, object
          permissions: AccountSASPermissions.parse("rwd"), // permissions
          protocol: SASProtocol.Https,
          startsOn: new Date(new Date().valueOf() - 30 * 60 * 1000), // 30 minutes
          expiresOn: new Date(new Date().valueOf() + 30 * 60 * 1000), // 30 minutes
        };

        const sasToken = generateBlobSASQueryParameters(
          sasOptions,
          sharedKeyCredential
        ).toString();

        blobUrl = `https://${accountName}.blob.core.windows.net/${containerName}/${blobName}?${sasToken}`;
      }
      return blobUrl;
    }
  } catch (e) {
    // console.log(e);
    const returnMessage = getMsgFormat();
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getBlobUrl";
    logger.log({
      level: "error",
      message: returnMessage,
    });
  }
  ////////////
};

// Capitalation condition after space
function titleCase(str) {
  let result = ``;
  if (str) {
    var splitStr = str.toLowerCase().split(" ");
    for (var i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] =
        splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    // Directly return the joined string
    result = splitStr.join(" ");
  }

  return result;
}

//Capitalation condition after Hyphen
// function titleCaseForHyphen(str) {
//   if (!str) {
//     return str; // Return empty or undefined strings directly
//   }

//   const words = str.split("-");
//   const firstWord = words[0].split(" ");
//   let final = "";
//   for (let i = 0; i < firstWord.length; i++) {
//     final += firstWord[i].charAt(0).toUpperCase() + firstWord[i].slice(1);
//     if (i !== firstWord.length - 1) final += " ";
//   }
//   final += "-" + words[1];
//   return final;
// }

function titleCaseForHyphen(str) {
  if (!str) {
    return str; // Return empty or undefined strings directly
  }

  const words = str.split("-");
  let final = "";

  for (let j = 0; j < words.length; j++) {
    const currentWord = words[j].split(" ");
    for (let i = 0; i < currentWord.length; i++) {
      final += currentWord[i].charAt(0).toUpperCase() + currentWord[i].slice(1);
      if (i !== currentWord.length - 1) final += " ";
    }
    if (j !== words.length - 1) final += "-";
  }

  return final;
}

// title Case For Underscore
function titleCaseForUnderscore(str) {
  let words = str.split("_");
  for (let i = 0; i < words.length; i++) {
    words[i] = words[i].charAt(0).toUpperCase() + words[i].slice(1);
  }
  return words.join(" ");
}

module.exports = {
  getLogger,
  isEmpty,
  getMsgFormat,
  returnAuthPayload,
  sortByLatestRecords,
  getBlobUrl,
  titleCase,
  titleCaseForHyphen,
  titleCaseForUnderscore,
};
