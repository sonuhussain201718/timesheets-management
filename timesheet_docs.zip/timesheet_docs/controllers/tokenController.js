const { getMsgFormat, isEmpty } = require("../utils/helpers");
const con = require("../utils/db");
const request = require("request");
const restartCommand = "pm2 restart all";
const listCommand = "pm2 list";
const { exec } = require("child_process");
con.connect();

//restart app every 1 hour
const restartApp = function () {
  exec(restartCommand, (err, stdout, stderr) => {
    if (!err && !stderr) {
      // listApps();
    } else if (err || stderr) {
    }
  });
};

// GET api for users List
const refreshToken = async (req, res) => {
  const returnMessage = getMsgFormat();
  var org_id = req.user.org_id;
  var result = await con.query(
    `SELECT * from timesheets.get_qb_auth_by_orgid($1);`,
    [org_id]
  );
  if (result.rows[0].j == null) {
    returnMessage.isError = true;
    returnMessage.message = "No Organization Details";
    res.status(400).json(returnMessage);
  } else {
    var dbdata = result.rows[0].j[0];
    const parseRedirect = req.url;
    var auth = Buffer.from(
      dbdata.client_id + ":" + dbdata.client_secret
    ).toString("base64");
    var postBody = {
      url: "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: "Basic " + auth,
      },
      form: {
        grant_type: "refresh_token",
        refresh_token: dbdata.refresh_token,
      },
    };
    request.post(postBody, async function (err, result, data) {
      if (err) {
        returnMessage.isError = true;
        returnMessage.message = "Failed to generate token";
        res.status(400).json(returnMessage);
      }
      var authdetails = JSON.parse(data);
      await con.query(
        `SELECT timesheets.update_qb_authentication($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [
          dbdata.id,
          authdetails.access_token,
          dbdata.client_id,
          dbdata.client_secret,
          "sandbox",
          authdetails.expires_in,
          dbdata.org_id,
          authdetails.refresh_token,
          "ACTIVE",
          dbdata.realm_id,
        ],
        (error, results) => {
          if (error) {
          } else {
          }
        }
      );
      returnMessage.isError = false;
      returnMessage.message = "Token Generated Successfully";
      returnMessage.data = authdetails;
      res.status(200).json(returnMessage);
      // restartApp();
    });
  }
};

module.exports = {
  refreshToken,
};
