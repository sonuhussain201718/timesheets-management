const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_global_config,
  update_global_config,
} = require("../../controllers/globalConfigController");

// @route GET api/v1/global_config/get_global_config
// @desc  Route to get global_config
// @accesss public
router.get("/get_global_config", get_global_config);

// @route GET api/v1/global_config/update_global_config
// @desc  Route to update global_config
// @accesss public
router.post("/update_global_config", update_global_config);

module.exports = router;
