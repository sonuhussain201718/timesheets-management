const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createEmailConfigValidator(data) {
  let errors = {};

  // if (validator.isEmpty(String(data.org_id))) {
  //   errors.org_id = "org_id field is required";
  // }

  // if (validator.isEmpty(data.from_email)) {
  //   errors.from_email = "from_email field is required";
  // }

  // if (validator.isEmpty(data.record_type_status)) {
  //   errors.record_type_status = "record_type_status field is required";
  // }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
