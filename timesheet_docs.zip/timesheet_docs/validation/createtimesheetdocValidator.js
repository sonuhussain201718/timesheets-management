const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createtimesheetdocValidator(data) {
  let errors = {};

  if (!data.project_id) {
    errors.project_id = "project_id field is required";
  }

  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }

  if (validator.isEmpty(String(data.week_start_date))) {
    errors.org_id = "week_start_date field is required";
  }

  if (validator.isEmpty(String(data.week_end_date))) {
    errors.org_id = "week_end_date field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
