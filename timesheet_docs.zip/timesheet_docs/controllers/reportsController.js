const fs = require("fs");
const { BlobServiceClient } = require("@azure/storage-blob");
var mime = require("mime-types");
const excelJS = require("exceljs");
const moment = require("moment");
const path = require("path");
const con = require("../utils/db");
const logger = require("../utils/logger");
const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const { ROLES, PROJECTS_STATUS_MAPPING } = require("../constants");
const {  titleCase, titleCaseForHyphen, titleCaseForUnderscore } = require("../utils/helpers");

const { isQBEnabled, getOrgData } = require('../utils/timesheet_helpers');

// GET api for employee_wise_time_management_report
const employee_wise_time_management_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "employee_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "employee_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      if (req.query.user_id == undefined || req.query.user_id == "") {
        req.query.user_id = null;
      }
      if (req.query.employee_type == undefined || req.query.employee_type == "") {
        req.query.employee_type = null;
      }
      if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
        req.query.pagenumber = null;
      }
      if (req.query.pagesize == undefined || req.query.pagesize == "") {
        req.query.pagesize = null;
      }
      await con.query(
        `SELECT * from timesheets.get_employee_wise_time_management_report($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          req.query.keyword,
          org_id,
          req.query.start_date,
          req.query.end_date,
          req.query.user_id,
          req.query.employee_type,
          req.query.pagenumber,
          req.query.pagesize,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "employee_wise_time_management_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let count = (results.rows && results.rows[1] && results.rows[1].j && results.rows[1].j[0] && results.rows[1].j[0].count) || null;
            
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.count = count;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "employee_wise_time_management_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for employee_wise_projects_time_management_report
const employee_wise_projects_time_management_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "employee_wise_projects_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "employee_wise_projects_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "employee_wise_projects_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_employee_wise_projects_time_management_report($1,$2,$3,$4)`,
        [org_id, req.query.start_date, req.query.end_date, req.query.user_id],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label =
              "employee_wise_projects_time_management_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;

              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "employee_wise_projects_time_management_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_employee_wise_time_management_report
const export_employee_wise_time_management_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "export_employee_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "export_employee_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      if (req.query.user_id == undefined || req.query.user_id == "") {
        req.query.user_id = null;
      }

      await con.query(
        `SELECT * from timesheets.export_employee_wise_time_management_report($1,$2,$3,$4,$5,$6)`,
        [req.query.keyword, org_id, req.query.start_date, req.query.end_date, req.query.user_id,req.query.employee_type],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "export_employee_wise_time_management_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              const workbook = new excelJS.Workbook(); // Create a new workbook
              const worksheet = workbook.addWorksheet("TimeManagementReport");

              // Column for data in excel. key must match data key
              worksheet.columns = [
                { header: "EMPLOYEE ID", key: "employee_id", width: 10 },
                { header: "ASSOCIATE ID", key: "adp_associate_id", width: 10 },
                { header: "ROLE", key: "role_name", width: 10 },
                { header: "CONSULTANT TYPE", key: "employee_type", width: 10 },
                { header: "FIRST NAME", key: "first_name", width: 10 },
                { header: "LAST NAME", key: "last_name", width: 10 },
                { header: "EMAIL", key: "email", width: 10 },
                { header: "MOBILE", key: "phone_number", width: 10 },
                { header: "DATE OF JOINING", key: "joining_date", width: 10 },
                { header: "DATE OF LEAVING", key: "leaving_date", width: 10 },
                { header: "STATUS", key: "record_type_status", width: 10 },
              ];

              for (i = 0; i < results.length; i++) {
                row = results[i];
                
                let joining_date = moment(row.joining_date, "YYYY-MM-DD");
                joining_date = joining_date && joining_date.isValid() ? joining_date.format("DD-MMM-YYYY") : "-";
                
                let leaving_date = moment(row.leaving_date, "YYYY-MM-DD");
                leaving_date = leaving_date && leaving_date.isValid() ? leaving_date.format("DD-MMM-YYYY") : "-";
                
                let tmpRow = [
                  row.employee_id,
                  row.adp_associate_id,
                  row.role_name,
                  row.employee_type,
                  row.first_name,
                  row.last_name,
                  row.email,
                  row.phone_number,
                  joining_date,
                  leaving_date,
                  row.record_type_status
                ];
                worksheet.addRow(tmpRow); // Add data in worksheet
              }
              // Making first line in excel bold
              worksheet.getRow(1).eachCell((cell) => {
                cell.font = { bold: true };
              });

              let folderPath = path.join(
                global.appDir,
                "./",
                "public/reports/time-management-reports"
              );
              let fileName = `employee-wise-time-management-report-${new Date().getTime()}.xlsx`;
              let filePath = `${folderPath}/${fileName}`;

              await workbook.xlsx.writeFile(filePath).then(async () => {
                const AZURE_STORAGE_CONNECTION_STRING =
                  process.env.AZURE_STORAGE_CONNECTION_STRING;
                if (!AZURE_STORAGE_CONNECTION_STRING) {
                  throw Error("Azure Storage Connection string not found");
                }
                const blobServiceClient =
                  BlobServiceClient.fromConnectionString(
                    AZURE_STORAGE_CONNECTION_STRING
                  );

                const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
                const containerClient =
                  blobServiceClient.getContainerClient(containerName);
                const createContainerResponse =
                  await containerClient.createIfNotExists();

                //////////Upload to Azure Blob//////
                const blockBlobClient = containerClient.getBlockBlobClient(
                  `${org_id}/reports/time-management-reports/${fileName}`
                );

                let contentType = mime.lookup(fileName);
                const blobOptions = {
                  blobHTTPHeaders: { blobContentType: contentType },
                };

                const uploadBlobResponse = await blockBlobClient.uploadFile(
                  filePath,
                  blobOptions
                );

                let blobUrl = "";
                if (uploadBlobResponse && uploadBlobResponse.requestId) {

                  let orgData = await getOrgData(org_id);
                  let newFileName = `time-management-reports-${((orgData && orgData.org_name) || ``)}.xlsx`;
                  blobUrl = getBlobUrl(
                    containerName,
                    `${org_id}/reports/time-management-reports/${fileName}`,
                    false,
                    newFileName
                  );
                }

                //delete local file after upload to azure
                fs.unlinkSync(filePath);

                //////////////
                returnMessage.isError = false;
                returnMessage.message = "File downloaded successfully";
                returnMessage.data = {
                  // url: filePath,
                  blobUrl: blobUrl,
                };
                res.status(200).json(returnMessage);
              });
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_employee_wise_time_management_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project_wise_time_management_report
const project_wise_time_management_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

   let keyword = req.query.keyword;

  if (keyword) {
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.record_type_status = null;

    //Is Local or Placement Project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{ 
    req.query.keyword = null;

    if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }
      if (req.query.placement_type == undefined || req.query.placement_type == "") {
        req.query.placement_type = null;
      }
      if (req.query.employee_id == undefined || req.query.employee_id == "") {
        req.query.employee_id = null;
      }
      if (req.query.client_name == undefined || req.query.client_name == "") {
        req.query.client_name = null;
      }
      if (req.query.project_status == undefined || req.query.project_status == "") {
        req.query.project_status = null;
      }
    }
      
    if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
      req.query.pagenumber = null;
    }
    if (req.query.pagesize == undefined || req.query.pagesize == "") {
      req.query.pagesize = null;
    }

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "project_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "project_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_project_wise_time_management_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
        [
          req.query.keyword,
          org_id,
          req.query.user_id,
          req.query.start_date,
          req.query.end_date,
          req.query.project_id,
          req.query.placement_type,
          req.query.is_placement_project,
          req.query.employee_id,
          req.query.client_name,
          req.query.end_customer,
	        req.query.project_status,
          req.query.project_start_date,
          req.query.pagenumber,
          req.query.pagesize,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "project_wise_time_management_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let count = (results.rows && results.rows[1] && results.rows[1].j && results.rows[1].j[0] && results.rows[1].j[0].count) || null;

            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.count = count;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "project_wise_time_management_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project_wise_employees_time_management_report
const project_wise_employees_time_management_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.project_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "project_id can not be null or empty";
      returnMessage.label = "project_wise_employees_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "project_wise_employees_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "project_wise_employees_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_project_wise_employees_time_management_report($1,$2,$3,$4)`,
        [
          org_id,
          req.query.start_date,
          req.query.end_date,
          req.query.project_id,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label =
              "project_wise_employees_time_management_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;

              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "project_wise_employees_time_management_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_project_wise_time_management_report
const export_project_wise_time_management_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.record_type_status = null;

    //Is Local or Placement Project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{ 
    req.query.keyword = null;

    if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }
      if (req.query.placement_type == undefined || req.query.placement_type == "") {
        req.query.placement_type = null;
      }
      if (req.query.employee_id == undefined || req.query.employee_id == "") {
        req.query.employee_id = null;
      }
      if (req.query.client_name == undefined || req.query.client_name == "") {
        req.query.client_name = null;
      }
      if (req.query.project_status == undefined || req.query.project_status == "") {
        req.query.project_status = null;
      }
    }

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "export_project_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "export_project_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }

      await con.query(
        `SELECT * from timesheets.export_project_wise_time_management_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
        [
           req.query.keyword,
          org_id,
          req.query.user_id,
          req.query.start_date,
          req.query.end_date,
          req.query.project_id,
          req.query.placement_type,
          req.query.is_placement_project,
          req.query.employee_id,
          req.query.client_name,
          req.query.end_customer,
	        req.query.project_status,
	        req.query.project_start_date,
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "export_project_wise_time_management_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              const workbook = new excelJS.Workbook(); // Create a new workbook
              const worksheet = workbook.addWorksheet("TimeManagementReport");

              // Column for data in excel. key must match data key				
              worksheet.columns = [
                { header: "EMPLOYEE NAME", key: "full_name", width: 10 },
                { header: "EMPLOYEE TYPE", key: "employee_type", width: 10 },
                { header: "PROJECT TYPE", KEY: "is_placement_project", width: 10 },
                { header: "PLACEMENT ID", key: "placement_code", width: 10 },
                { header: "PROJECT NAME", key: "project_name", width: 10 },
                { header: "END CUSTOMER", key: "end_customer", width: 10 },
                { header: "CLIENT", key: "client_name", width: 10 },
                { header: "START DATE", key: "start_date", width: 10 },
                { header: "END/CANCELLED DATE", key: "closure_date", width: 10 },
                { header: "PROJECT STATUS", key: "project_status", width: 10 },
              ];

              for (i = 0; i < results.length; i++) {
                row = results[i];
                 let client_name = 
                 (row.project_vendors && row.project_vendors[0] && row.project_vendors[0].client_name) || `-`;

                 let is_placement_project =
                row.is_placement_project == true ? "Placement" : "Bench";

              let full_name = row.full_name ? titleCase(row.full_name) :'';

              // let project_name = row.project_name ? titleCase(row.project_name): "";
              let project_name = row.project_name;
              project_name = project_name ? titleCaseForHyphen(project_name) : "";

                let start_date = moment(row.start_date, "YYYY-MM-DD");
                start_date = start_date && start_date.isValid() ? start_date.format("DD-MMM-YYYY") : "-";
                let end_date = moment(row.end_date, "YYYY-MM-DD");
                end_date = end_date && end_date.isValid() ? end_date.format("DD-MMM-YYYY") : "-";

                let project_status = row.project_status;
                // project_status = project_status.replace (/_/g, " ");
                project_status = project_status ? titleCaseForUnderscore(project_status) : "";
                project_status = project_status ? titleCase(project_status) : "";
                // console.log('status--',project_status);

                let project_end_date = row.end_date; 
                let cancel_date = row.cancel_date;
                let closure_date = null;
                if(project_status == "COMPLETED" || project_status == "Completed") {
                  closure_date = project_end_date;
                }else if(project_status == "CANCELLED" || project_status == "Cancelled"){
                  closure_date = cancel_date;
                }else{
                  closure_date = "-";
                }
                closure_date = moment(closure_date, "YYYY-MM-DD");

                closure_date = closure_date && closure_date.isValid() ? closure_date.format("DD-MMM-YYYY") : "-";

                 let tmpRow = [
                   full_name,
                   row.employee_type,
                   is_placement_project,
                   row.placement_code,
                   project_name,
                   row.end_customer,
                   client_name,
                   start_date,
                   closure_date,
                   project_status,
                 ];
                worksheet.addRow(tmpRow); // Add data in worksheet
              }

              // Making first line in excel bold
              worksheet.getRow(1).eachCell((cell) => {
                cell.font = { bold: true };
              });

              let folderPath = path.join(
                global.appDir,
                "./",
                "public/reports/time-management-reports"
              );
              let fileName = `project-wise-time-management-report-${new Date().getTime()}.xlsx`;
              let filePath = `${folderPath}/${fileName}`;

              await workbook.xlsx.writeFile(filePath).then(async () => {
                const AZURE_STORAGE_CONNECTION_STRING =
                  process.env.AZURE_STORAGE_CONNECTION_STRING;
                if (!AZURE_STORAGE_CONNECTION_STRING) {
                  throw Error("Azure Storage Connection string not found");
                }
                const blobServiceClient =
                  BlobServiceClient.fromConnectionString(
                    AZURE_STORAGE_CONNECTION_STRING
                  );

                const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
                const containerClient =
                  blobServiceClient.getContainerClient(containerName);
                const createContainerResponse =
                  await containerClient.createIfNotExists();

                //////////Upload to Azure Blob//////
                const blockBlobClient = containerClient.getBlockBlobClient(
                  `${org_id}/reports/time-management-reports/${fileName}`
                );

                let contentType = mime.lookup(fileName);
                const blobOptions = {
                  blobHTTPHeaders: { blobContentType: contentType },
                };

                const uploadBlobResponse = await blockBlobClient.uploadFile(
                  filePath,
                  blobOptions
                );

                let blobUrl = "";
                if (uploadBlobResponse && uploadBlobResponse.requestId) {

                  let orgData = await getOrgData(org_id);
                  let newFileName = `time-management-reports-${((orgData && orgData.org_name) || ``)}.xlsx`;
                  blobUrl = getBlobUrl(
                    containerName,
                    `${org_id}/reports/time-management-reports/${fileName}`,
                    false,
                    newFileName
                  );
                }

                //delete local file after upload to azure
                fs.unlinkSync(filePath);
                //////////////
                returnMessage.isError = false;
                returnMessage.message = "File downloaded successfully";
                returnMessage.data = {
                  // url: filePath,
                  blobUrl: blobUrl,
                };
                res.status(200).json(returnMessage);
              });
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_project_wise_time_management_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project_wise_employee_timesheet_report
const project_wise_employee_timesheet_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;
  let start_date = req.query.start_date || null;
  let end_date = req.query.end_date || null;

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.record_type_status = null;

    //Is Local or Placement Project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{ 
    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
        req.query.user_id = null;
      }
      if (req.query.employee_type == undefined || req.query.employee_type == "") {
        req.query.employee_type = null;
      }
      if (req.query.employee_id == undefined || req.query.employee_id == "") {
        req.query.employee_id = null;
      }
      if (req.query.employee_name == undefined || req.query.employee_name == "") {
        req.query.employee_name = null;
      }
      if (req.query.project_name == undefined || req.query.project_name == "") {
        req.query.project_name = null;
      }
      if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }
      if (req.query.project_status == undefined || req.query.project_status == "") {
        req.query.project_status = null;
      }
    }
    if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
      req.query.pagenumber = null;
    }
    if (req.query.pagesize == undefined || req.query.pagesize == "") {
      req.query.pagesize = null;
    }

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "project_wise_employee_timesheet_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "project_wise_employee_timesheet_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_project_wise_employee_timesheet_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
        [
          req.query.keyword,
          org_id,
          req.query.start_date,
          req.query.end_date,
          req.query.user_id,
          req.query.employee_type,
          req.query.employee_id,
          req.query.employee_name,
          req.query.project_name,
	        req.query.project_id,
          req.query.project_status,
          req.query.pagenumber,
          req.query.pagesize,
        ],
        (error, results) => {
          

          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "project_wise_employee_timesheet_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            
            let count = (results.rows && results.rows[1] && results.rows[1].j && results.rows[1].j[0] && results.rows[1].j[0].count) || null;
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {

              var report_data = [];

              let tmp_start_date = `${start_date}T00:00:00Z`;
              let tmp_end_date = `${end_date}T00:00:00Z`;

              let range = moment().range(moment(tmp_start_date), moment(tmp_end_date));

              let days = range.by("days");
              var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

              if (dates && dates.length) {

                for (var i = 0; i < results.length; i++) {

                  let row = results[i];                  
                  tdRows = row.timesheet_data || [];
                  results[i].timesheet_data = [];
                  for(j = 0; j < dates.length; j++){
                    
                    let existstRow = tdRows.filter((tmpRow) => {
                      return (dates[j] == tmpRow.timesheet_date);
                    })[0] || null;

                    if(existstRow){
                      results[i].timesheet_data.push(existstRow);
                    }
                    else{

                      results[i].timesheet_data.push({
                        timesheet_date: dates[j],
                        user_id: results[i].user_id || null,
                        project_id: results[i].project_id || null,
                        regular_hours: results[i].regular_hours || null,
                        regular_minutes: results[i].regular_minutes || null,
                        ot_hours: results[i].ot_hours || null,
                        ot_minutes: results[i].ot_minutes || null,
                        absent_type: results[i].absent_type || null,
                        absent_hours: results[i].absent_hours || null,
                        absent_minutes: results[i].absent_minutes || null,
                        status: results[i].status || null,
                        regular_hours_minutes: results[i].regular_hours_minutes || null,
                        ot_hours_minutes: results[i].ot_hours_minutes || null,
                        total_hours_minutes: results[i].total_hours_minutes || null,
                      });
                      
                    }
                  } 
                }
              }

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.count = count;
              res.status(200).json(returnMessage);

            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "project_wise_employee_timesheet_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_project_wise_employee_timesheet_report
const export_project_wise_employee_timesheet_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;
  let start_date = req.query.start_date || null;
  let end_date = req.query.end_date || null;

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.record_type_status = null;

    //Is Local or Placement Project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{ 
    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
        req.query.user_id = null;
      }
      if (req.query.employee_type == undefined || req.query.employee_type == "") {
        req.query.employee_type = null;
      }
      if (req.query.employee_id == undefined || req.query.employee_id == "") {
        req.query.employee_id = null;
      }
      if (req.query.employee_name == undefined || req.query.employee_name == "") {
        req.query.employee_name = null;
      }
      if (req.query.project_name == undefined || req.query.project_name == "") {
        req.query.project_name = null;
      }
      if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }
      if (req.query.project_status == undefined || req.query.project_status == "") {
        req.query.project_status = null;
      }
    }

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "export_project_wise_employee_timesheet_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "export_project_wise_employee_timesheet_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.export_project_wise_employee_timesheet_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [
          req.query.keyword,
          org_id,
          req.query.start_date,
          req.query.end_date,
          req.query.user_id,
          req.query.employee_type,
          req.query.employee_id,
          req.query.employee_name,
          req.query.project_name,
	        req.query.project_id,
          req.query.project_status,
        ],
        async (error, results) => {
          
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "export_project_wise_employee_timesheet_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {

              var report_data = [];

              let tmp_start_date = `${start_date}T00:00:00Z`;
              let tmp_end_date = `${end_date}T00:00:00Z`;

              let range = moment().range(moment(tmp_start_date), moment(tmp_end_date));

              let days = range.by("days");
              var dates = [...days].map((date) => date.format("YYYY-MM-DD"));

              if (dates && dates.length) {

                for (var i = 0; i < results.length; i++) {

                  let row = results[i];                  
                  tdRows = row.timesheet_data || [];
                  results[i].timesheet_data = [];
                  for(j = 0; j < dates.length; j++){
                    
                    let existstRow = tdRows.filter((tmpRow) => {
                      return (dates[j] == tmpRow.timesheet_date);
                    })[0] || null;

                    if(existstRow){
                      results[i].timesheet_data.push(existstRow);
                    }
                    else{

                      results[i].timesheet_data.push({
                        timesheet_date: dates[j],
                        user_id: results[i].user_id || null,
                        project_id: results[i].project_id || null,
                        regular_hours: results[i].regular_hours || null,
                        regular_minutes: results[i].regular_minutes || null,
                        ot_hours: results[i].ot_hours || null,
                        ot_minutes: results[i].ot_minutes || null,
                        absent_type: results[i].absent_type || null,
                        absent_hours: results[i].absent_hours || null,
                        absent_minutes: results[i].absent_minutes || null,
                        status: results[i].status || null,
                      });
                      
                    }
                  } 
                }
              }


              /////////////////////////////////////
              
              const workbook = new excelJS.Workbook(); // Create a new workbook
              const worksheet = workbook.addWorksheet("TimesheetReport");

              // Column for data in excel. key must match data key
              worksheet.columns = [
                { header: "EMPLOYEE NAME", key: "full_name", width: 15 },
                { header: "EMPLOYEE TYPE", key: "employee_type", width: 15 },
                { header: "DATE RANGE", key: "date_range", width: 15 },
                { header: "CONSULTANT ID", key: "employee_id", width: 15 },
                { header: "ASSOCIATE ID", key: "adp_associate_id", width: 15 },
                { header: "PROJECT NAME", key: "project_name", width: 15 },
                { header: "PROJECT ID", key: "project_id", width: 15 },
                { header: "PROJECT STATUS", key: "project_status", width: 15 },
                { header: "CLOSURE DATE", key: "closure_date", width: 15 },
                { header: "TOTAL REGULAR HOURS", key: "regular_hours_minutes", width: 15 },
                { header: "TOTAL OT HOURS", key: "ot_hours_minutes", width: 15 },
                { header: "TOTAL HOURS", key: "total_hours_minutes", width: 15 },
              ];

              // let currentRowIdx = worksheet.rowCount;
              // let endColumnIdx = worksheet.columnCount;
              // console.log("endColumnIdx", endColumnIdx);
              // worksheet.mergeCells(currentRowIdx, 9, currentRowIdx, 11);

              if (dates && dates.length) {
                let currCol = 13;
                for(j = 0; j < dates.length; j++){

                  let tdate = `${dates[j]}T00:00:00Z`;
                  let day_name = moment(tdate).format("dddd");

                  worksheet.columns = [...worksheet.columns, { header: `${day_name} ${dates[j]}`, key: `${dates[j]}`, width: 15 }];
                  let currentRowIdx = worksheet.rowCount;
                  let endColumnIdx = worksheet.columnCount;
                  worksheet.mergeCells(currentRowIdx, currCol, currentRowIdx, (currCol+2));
                  currCol = currCol + 3;
                }

                // add subheader
                subHeader = ["", "", "", "", "", "", "", "","","","",""];
                for(j = 0; j < dates.length; j++){
                  subHeader = [...subHeader, "Regular Hours", "OT Hours", "Status"];
                }
                worksheet.addRow(subHeader);
                
              }
              
              for (i = 0; i < results.length; i++) {
                row = results[i];

                let full_name = row.full_name ? titleCase(row.full_name) : "";
                let project_name = row.project_name;
                project_name = project_name ? titleCaseForHyphen(project_name) : "";

                let project_status = row.project_status;
                project_status = project_status ? titleCaseForUnderscore(project_status) : "";
                project_status = project_status ? titleCase(project_status) : "";

                let date_range = ((req.query.start_date && moment(req.query.start_date, "YYYY-MM-DD").format("DD-MMM-YYYY")) || ``) + " To " + ((req.query.end_date && moment(req.query.end_date, "YYYY-MM-DD").format("DD-MMM-YYYY")) || ``);

                let closure_date = "";
                if(row.project_status == "COMPLETED") {
                  closure_date = (row.end_date && moment(row.end_date, "YYYY-MM-DD").format("DD-MMM-YYYY")) || ``;
                }else if(row.project_status == "CANCELLED"){
                  closure_date = (row.cancel_date && moment(row.cancel_date, "YYYY-MM-DD").format("DD-MMM-YYYY")) || ``;
                }else{
                  closure_date = "-";
                }
                
                let total_regular_hours_minutes = (row.timesheet_total_data && row.timesheet_total_data[0] && row.timesheet_total_data[0].regular_hours_minutes) || ``;
                let total_ot_hours_minutes = (row.timesheet_total_data && row.timesheet_total_data[0] && row.timesheet_total_data[0].ot_hours_minutes) || ``;
                let total_hours_minutes = (row.timesheet_total_data && row.timesheet_total_data[0] && row.timesheet_total_data[0].total_hours_minutes) || ``;

                let tmpRow = [
                  full_name,
                  row.employee_type,
                  date_range,
                  row.employee_id,
                  row.adp_associate_id,
                  project_name,
                  row.project_id,
                  project_status,
                  closure_date,
                  total_regular_hours_minutes,
                  total_ot_hours_minutes,
                  total_hours_minutes,
                ];

                if(row.timesheet_data && row.timesheet_data.length){

                  for (j = 0; j < row.timesheet_data.length; j++) {
                    let tsdRow = row.timesheet_data[j];
                    
                    let regular_hours = tsdRow.regular_hours || 0;
                    regular_hours = (regular_hours > 9)?regular_hours:`0${regular_hours}`;

                    let regular_minutes = tsdRow.regular_minutes || 0;
                    regular_minutes = (regular_minutes > 9)?regular_minutes:`0${regular_minutes}`;

                    let regular_hours_minutes = `${regular_hours}:${regular_minutes}`;

                    let ot_hours = tsdRow.ot_hours || 0;
                    ot_hours = (ot_hours > 9)?ot_hours:`0${ot_hours}`;

                    let ot_minutes = tsdRow.ot_minutes || 0;
                    ot_minutes = (ot_minutes > 9)?ot_minutes:`0${ot_minutes}`;

                    let ot_hours_minutes = `${ot_hours}:${ot_minutes}`;

                    let status = tsdRow.status;

                    
                    tmpRow = [...tmpRow, regular_hours_minutes, ot_hours_minutes, status ];

                  }

                }

                worksheet.addRow(tmpRow); // Add data in worksheet
              }

              // Making first line in excel bold
              worksheet.getRow(1).eachCell((cell) => {
                cell.font = { bold: true };
              });
              // Making second line in excel bold
              worksheet.getRow(2).eachCell((cell) => {
                cell.font = { bold: true };
              });

              let folderPath = path.join(
                global.appDir,
                "./",
                "public/reports/timesheet-reports"
              );
              let fileName = `project-wise-timesheet-report-${new Date().getTime()}.xlsx`;
              let filePath = `${folderPath}/${fileName}`;

              await workbook.xlsx.writeFile(filePath).then(async () => {
                const AZURE_STORAGE_CONNECTION_STRING =
                  process.env.AZURE_STORAGE_CONNECTION_STRING;
                if (!AZURE_STORAGE_CONNECTION_STRING) {
                  throw Error("Azure Storage Connection string not found");
                }
                const blobServiceClient =
                  BlobServiceClient.fromConnectionString(
                    AZURE_STORAGE_CONNECTION_STRING
                  );

                const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
                const containerClient =
                  blobServiceClient.getContainerClient(containerName);
                const createContainerResponse =
                  await containerClient.createIfNotExists();

                //////////Upload to Azure Blob//////
                const blockBlobClient = containerClient.getBlockBlobClient(
                  `${org_id}/reports/timesheet-reports/${fileName}`
                );

                let contentType = mime.lookup(fileName);
                const blobOptions = {
                  blobHTTPHeaders: { blobContentType: contentType },
                };

                const uploadBlobResponse = await blockBlobClient.uploadFile(
                  filePath,
                  blobOptions
                );

                let blobUrl = "";
                if (uploadBlobResponse && uploadBlobResponse.requestId) {

                  let orgData = await getOrgData(org_id);
                  let newFileName = `timesheet-reports-${((orgData && orgData.org_name) || ``)}.xlsx`;
                  blobUrl = getBlobUrl(
                    containerName,
                    `${org_id}/reports/timesheet-reports/${fileName}`,
                    false,
                    newFileName
                  );
                }

                //delete local file after upload to azure
                fs.unlinkSync(filePath);
                //////////////
                returnMessage.isError = false;
                returnMessage.message = "File downloaded successfully";
                returnMessage.data = {
                  // url: filePath,
                  blobUrl: blobUrl,
                };
                res.status(200).json(returnMessage);
              });
            
              ////////////////////////////////////

            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_project_wise_employee_timesheet_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for timesheet_submission_report
const timesheet_submission_report = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {

      if (req.query.user_id == undefined || req.query.user_id == "") {
        req.query.user_id = null;
      }
      if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }
      if (req.query.project_status == undefined || req.query.project_status == "") {
        req.query.project_status = null;
      }
      if (req.query.joining_date == undefined || req.query.joining_date == "") {
        req.query.joining_date = null;
      }
      if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
        req.query.record_type_status = null;
      }
      if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
        req.query.pagenumber = null;
      }
      if (req.query.pagesize == undefined || req.query.pagesize == "") {
        req.query.pagesize = null;
      }

      await con.query(
        `SELECT * from timesheets.get_timesheet_submission_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [
          req.query.keyword,
          org_id,
          req.query.start_date,
          req.query.end_date,
          req.query.user_id,
          req.query.employee_type,
          req.query.project_id,
          req.query.project_status,
          req.query.joining_date,
          req.query.record_type_status,
          req.query.pagenumber,
          req.query.pagesize,
        ],
        (error, results) => {

          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "timesheet_submission_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let count = (results.rows && results.rows[1] && results.rows[1].j && results.rows[1].j[0] && results.rows[1].j[0].count) || null;
            results = (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.count = count;
              res.status(200).json(returnMessage);

            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "timesheet_submission_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_timesheet_submission_report
const export_timesheet_submission_report = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {

      if (req.query.user_id == undefined || req.query.user_id == "") {
        req.query.user_id = null;
      }
      if (req.query.project_id == undefined || req.query.project_id == "") {
        req.query.project_id = null;
      }
      if (req.query.project_status == undefined || req.query.project_status == "") {
        req.query.project_status = null;
      }
      if (req.query.joining_date == undefined || req.query.joining_date == "") {
        req.query.joining_date = null;
      }
      if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
        req.query.record_type_status = null;
      }

      await con.query(
        `SELECT * from timesheets.export_timesheet_submission_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [
          req.query.keyword,
          org_id,
          req.query.start_date,
          req.query.end_date,
          req.query.user_id,
          req.query.employee_type,
          req.query.project_id,
          req.query.project_status,
          req.query.joining_date,
	        req.query.record_type_status
        ],
        async (error, results) => {
          
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "export_timesheet_submission_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            results = (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {

              var report_data = [];

              /////////////////////////////////////
              
              const workbook = new excelJS.Workbook(); // Create a new workbook
              const worksheet = workbook.addWorksheet("TimesheetSubmissionReport");

              // Column for data in excel. key must match data key
              worksheet.columns = [
                { header: "EMPLOYEE ID", key: "employee_id", width: 15 },
                { header: "EMPLOYEE NAME", key: "full_name", width: 15 },
                { header: "CONSULTANT TYPE", key: "employee_type", width: 15 },
                { header: "PROJECT NAME", key: "project_name", width: 15 },
                { header: "LAST TIMESHEET SUBMISSION DATE", key: "last_timesheet_submission_date", width: 15 },
                { header: "REGULAR HOURS", key: "regular_hours_minutes", width: 15 },
                { header: "OT HOURS", key: "ot_hours_minutes", width: 15 },
                { header: "TOTAL HOURS SUBMITTED TILL NOW", key: "total_hours_minutes", width: 15 },
              ];
              for (i = 0; i < results.length; i++) {

                row = results[i];

                let full_name = row.full_name ? titleCase(row.full_name) :'' ;

                let project_name = row.project_name;
                project_name = project_name ? titleCaseForHyphen(project_name) : "";

                let timesheet_date = row.last_timesheet_data && row.last_timesheet_data[0] && row.last_timesheet_data[0].timesheet_date;
                    timesheet_date = moment(timesheet_date, "YYYY-MM-DD");
                    timesheet_date = timesheet_date && timesheet_date.isValid() ? timesheet_date.format("DD-MMM-YYYY") : "-";

                let regular_hours_minutes = (row.total_timesheet_data && row.total_timesheet_data[0] && row.total_timesheet_data[0].regular_hours_minutes) || `-`;
                
                let ot_hours_minutes = (row.total_timesheet_data && row.total_timesheet_data[0] && row.total_timesheet_data[0].ot_hours_minutes) || `-`;
                
                let total_hours_minutes = (row.total_timesheet_data && row.total_timesheet_data[0] && row.total_timesheet_data[0].total_hours_minutes) || `-`;

                let tmpRow = [
                  row.employee_id,
                  full_name,
                  row.employee_type,
                  project_name,
                  timesheet_date,
                  regular_hours_minutes,
                  ot_hours_minutes,
                  total_hours_minutes
                ];

                worksheet.addRow(tmpRow); // Add data in WORKSHEET
              }

              // Making first line in excel bold
              worksheet.getRow(1).eachCell((cell) => {
                cell.font = { bold: true };
              });
              
              let folderPath = path.join(
                global.appDir,
                "./",
                "public/reports/timesheet-submission-reports"
              );
              let fileName = `timesheet-submission-report-${new Date().getTime()}.xlsx`;
              let filePath = `${folderPath}/${fileName}`;

              await workbook.xlsx.writeFile(filePath).then(async () => {
                const AZURE_STORAGE_CONNECTION_STRING =
                  process.env.AZURE_STORAGE_CONNECTION_STRING;
                if (!AZURE_STORAGE_CONNECTION_STRING) {
                  throw Error("Azure Storage Connection string not found");
                }
                const blobServiceClient =
                  BlobServiceClient.fromConnectionString(
                    AZURE_STORAGE_CONNECTION_STRING
                  );

                const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
                const containerClient =
                  blobServiceClient.getContainerClient(containerName);
                const createContainerResponse =
                  await containerClient.createIfNotExists();

                //////////Upload to Azure Blob//////
                const blockBlobClient = containerClient.getBlockBlobClient(
                  `${org_id}/reports/timesheet-submission-reports/${fileName}`
                );

                let contentType = mime.lookup(fileName);
                const blobOptions = {
                  blobHTTPHeaders: { blobContentType: contentType },
                };

                const uploadBlobResponse = await blockBlobClient.uploadFile(
                  filePath,
                  blobOptions
                );

                let blobUrl = "";
                if (uploadBlobResponse && uploadBlobResponse.requestId) {

                  let orgData = await getOrgData(org_id);
                  let newFileName = `timesheets-submission-reports-${((orgData && orgData.org_name) || ``)}.xlsx`;
                  blobUrl = getBlobUrl(
                    containerName,
                    `${org_id}/reports/timesheet-submission-reports/${fileName}`,
                    false,
                    newFileName
                  );
                }

                //delete local file after upload to azure
                fs.unlinkSync(filePath);
                //////////////
                returnMessage.isError = false;
                returnMessage.message = "File downloaded successfully";
                returnMessage.data = {
                  // url: filePath,
                  blobUrl: blobUrl,
                };
                res.status(200).json(returnMessage);
              });
            
              ////////////////////////////////////

            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_timesheet_submission_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_employees_report
const get_employees_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (req.query.keyword == undefined || req.query.keyword == "") {
      req.query.keyword = null;
    }
    if (req.query.employee_type == undefined || req.query.employee_type == "") {
      req.query.employee_type = null;
    }
    if (req.query.role_id == undefined || req.query.role_id == "") {
      req.query.role_id = null;
    }
    if (req.query.first_name == undefined || req.query.first_name == "") {
      req.query.first_name = null;
    }
    if (req.query.last_name == undefined || req.query.last_name == "") {
      req.query.last_name = null;
    }
    if (req.query.full_name == undefined || req.query.full_name == "") {
      req.query.full_name = null;
    }
    if (req.query.email == undefined || req.query.email == "") {
      req.query.email = null;
    }
    if (
      req.query.adp_associate_id == undefined ||
      req.query.adp_associate_id == ""
    ) {
      req.query.adp_associate_id = null;
    }
    if (req.query.department_id == undefined || req.query.department_id == "") {
      req.query.department_id = null;
    }
    if (
      req.query.department_name == undefined ||
      req.query.department_name == ""
    ) {
      req.query.department_name = null;
    }
    if (req.query.country_name == undefined || req.query.country_name == "") {
      req.query.country_name = null;
    }
    if (req.query.employee_id == undefined || req.query.employee_id == "") {
      req.query.employee_id = null;
    }
    if (req.query.ecdb_user_id == undefined || req.query.ecdb_user_id == "") {
      req.query.ecdb_user_id = null;
    }
    if (
      req.query.prospective_user_id == undefined ||
      req.query.prospective_user_id == ""
    ) {
      req.query.prospective_user_id = null;
    }
    if (
    req.query.joining_date == undefined ||
    req.query.joining_date == ""
    ) {
      req.query.joining_date = null;
    }
    if (
      req.query.qb_employee_name == undefined ||
      req.query.qb_employee_name == ""
    ) {
      req.query.qb_employee_name = null;
    }
    if (
      req.query.qb_employee_id == undefined ||
      req.query.qb_employee_id == ""
    ) {
      req.query.qb_employee_id = null;
    }
    if (req.query.user_status == undefined || req.query.user_status == "") {
      req.query.user_status = null;
    }
    if (req.query.work_country == undefined || req.query.work_country == "") {
      req.query.work_country = null;
    }
    if (
      req.query.record_type_status == undefined ||
      req.query.record_type_status == ""
    ) {
      req.query.record_type_status = null;
    }


    await con.query(
      `SELECT * from timesheets.get_employees_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
      [
        req.query.keyword,
        org_id,
        req.query.employee_type,
        req.query.role_id,
        req.query.first_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.adp_associate_id,
        req.query.department_id,
        req.query.department_name,
        req.query.country_name,
        req.query.employee_id,
        req.query.ecdb_user_id,
        req.query.prospective_user_id,
        req.query.joining_date,
        req.query.leaving_date,
        req.query.qb_employee_name,
        req.query.qb_employee_id,
        req.query.user_status,
        req.query.work_country,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch user details";
          returnMessage.error = error;
          returnMessage.label = "get_employees_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          let is_qb_enabled = await isQBEnabled(req.user.org_id);
          // don't pass qb details in API response
          let data =
            (results && results.rows && results.rows[0] && results.rows[0].j) ||
            null;
          if (
            data &&
            data.length &&
            (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
              req.user.role_id
            )))
          ) {
            for (var i = 0; i < data.length; i++) {
              delete data[i].qb_employee_id;
              delete data[i].qb_employee_name;
            }
          }
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employees_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_employees_report
const export_employees_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.employee_type == undefined || req.query.employee_type == "") {
    req.query.employee_type = null;
  }
  if (req.query.role_id == undefined || req.query.role_id == "") {
    req.query.role_id = null;
  }
  if (req.query.first_name == undefined || req.query.first_name == "") {
    req.query.first_name = null;
  }
  if (req.query.last_name == undefined || req.query.last_name == "") {
    req.query.last_name = null;
  }
  if (req.query.full_name == undefined || req.query.full_name == "") {
    req.query.full_name = null;
  }
  if (req.query.email == undefined || req.query.email == "") {
    req.query.email = null;
  }
  if (
    req.query.adp_associate_id == undefined ||
    req.query.adp_associate_id == ""
  ) {
    req.query.adp_associate_id = null;
  }
  if (req.query.department_id == undefined || req.query.department_id == "") {
    req.query.department_id = null;
  }
  if (
    req.query.department_name == undefined ||
    req.query.department_name == ""
  ) {
    req.query.department_name = null;
  }
  if (req.query.country_name == undefined || req.query.country_name == "") {
    req.query.country_name = null;
  }
  if (req.query.employee_id == undefined || req.query.employee_id == "") {
    req.query.employee_id = null;
  }
  if (req.query.ecdb_user_id == undefined || req.query.ecdb_user_id == "") {
    req.query.ecdb_user_id = null;
  }
  if (
    req.query.prospective_user_id == undefined ||
    req.query.prospective_user_id == ""
  ) {
    req.query.prospective_user_id = null;
  }
  if (
    req.query.joining_date == undefined ||
    req.query.joining_date == ""
  ) {
    req.query.joining_date = null;
  }
  if (
    req.query.qb_employee_name == undefined ||
    req.query.qb_employee_name == ""
  ) {
    req.query.qb_employee_name = null;
  }
  if (req.query.qb_employee_id == undefined || req.query.qb_employee_id == "") {
    req.query.qb_employee_id = null;
  }
  if (req.query.user_status == undefined || req.query.user_status == "") {
    req.query.user_status = null;
  }
  if (req.query.work_country == undefined || req.query.work_country == "") {
    req.query.work_country = null;
  }
  if (
    req.query.record_type_status == undefined ||
    req.query.record_type_status == ""
  ) {
    req.query.record_type_status = null;
  }

  try {
    await con.query(
      `SELECT * from timesheets.export_employees_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21);`,
      [
        req.query.keyword,
        org_id,
        req.query.employee_type,
        req.query.role_id,
        req.query.first_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.adp_associate_id,
        req.query.joining_date,
        req.query.department_id,
        req.query.department_name,
        req.query.country_name,
        req.query.employee_id,
        req.query.ecdb_user_id,
        req.query.prospective_user_id,
        req.query.qb_employee_name,
        req.query.qb_employee_id,
        req.query.user_status,
        req.query.work_country,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_employees_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            // don't pass qb details in API response
            if(!is_qb_enabled || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
              for (var i = 0; i < results.length; i++) {
                delete results[i].qb_employee_id;
                delete results[i].qb_employee_name;
              }
            }
            
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportEmployeesReports");

             		 	 	 	 	
            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "CONSULTANT ID", key: "employee_id", width: 10 },
              { header: "CONSULTANT NAME", key: "full_name", width: 10 },
              { header: "CONSULTANT TYPE", key: "employee_type", width: 10 },
              { header: "EMAIL", key: "email", width: 10 },
              {
                header: "ADP ASSOCIATE ID",
                key: "adp_associate_id",
                width: 10,
              },
              {
                header: "JOINING DATE",
                key: "joining_date",
                width: 10,
              },
              { header: "ECDB USER ID", key: "ecdb_user_id", width: 10 },
              {
                header: "PROSPECTIVE USER ID",
                key: "prospective_user_id",
                width: 10,
              },
            ];

            if(is_qb_enabled && [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
              worksheet.columns = [
                ...worksheet.columns,
                {
                  header: "QB CONSULTANT ID",
                  key: "qb_employee_id",
                  width: 10,
                },
                {
                  header: "QB CONSULTANT NAME",
                  key: "qb_employee_name",
                  width: 10,
                },
              ];
            }

            worksheet.columns = [
              ...worksheet.columns,
              { header: "DEPARTMENT ID", key: "department_id", width: 10 },
              { header: "DEPARTMENT NAME", key: "department_name", width: 10 },
              { header: "COUNTRY NAME", key: "country_name", width: 10 },
              { header: "WORK COUNTRY", key: "work_country", width: 10 },
              {
                header: "STATUS",
                key: "record_type_status",
                width: 10,
              },
            ];
            
            for (i = 0; i < results.length; i++) {
              row = results[i];
              worksheet.addRow(row); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/reports/employees-reports"
            );
            let fileName = `employees-report-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/reports/employees-reports/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/reports/employees-reports/${fileName}`
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);

              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_employees_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_projects_report
const get_projects_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.user_id = null;
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.record_type_status = null;

    if (["local", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "local") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  } else {
    req.query.keyword = null;

    if (
      req.query.project_status == undefined ||
      req.query.project_status == ""
    ) {
      req.query.project_status = null;
    }
    if (req.query.start_date == undefined || req.query.start_date == "") {
      req.query.start_date = null;
    }
    if (req.query.end_date == undefined || req.query.end_date == "") {
      req.query.end_date = null;
    }
    if (
      req.query.client_manager_name == undefined ||
      req.query.client_manager_name == ""
    ) {
      req.query.client_manager_name = null;
    }
    if (
      req.query.client_manager_email == undefined ||
      req.query.client_manager_email == ""
    ) {
      req.query.client_manager_email = null;
    }
    if (req.query.job_title == undefined || req.query.job_title == "") {
      req.query.job_title = null;
    }
    if (
      req.query.is_placement_project == undefined ||
      req.query.is_placement_project == ""
    ) {
      req.query.is_placement_project = null;
    }
    if (
      req.query.placement_type == undefined ||
      req.query.placement_type == ""
    ) {
      req.query.placement_type = null;
    }
    if (
      req.query.placement_project_id == undefined ||
      req.query.placement_project_id == ""
    ) {
      req.query.placement_project_id = null;
    }
    if (
      req.query.placement_code == undefined ||
      req.query.placement_code == ""
    ) {
      req.query.placement_code = null;
    }
    if (
      req.query.is_primary_project == undefined ||
      req.query.is_primary_project == ""
    ) {
      req.query.is_primary_project = null;
    }
    if (
      req.query.direct_customer_engagement == undefined ||
      req.query.direct_customer_engagement == ""
    ) {
      req.query.direct_customer_engagement = null;
    }
    if (
      req.query.end_customer_id == undefined ||
      req.query.end_customer_id == ""
    ) {
      req.query.end_customer_id = null;
    }
    if (
      req.query.qb_customer_name == undefined ||
      req.query.qb_customer_name == ""
    ) {
      req.query.qb_customer_name = null;
    }
    if (
      req.query.qb_customer_id == undefined ||
      req.query.qb_customer_id == ""
    ) {
      req.query.qb_customer_id = null;
    }
    if (
      req.query.qb_project_name == undefined ||
      req.query.qb_project_name == ""
    ) {
      req.query.qb_project_name = null;
    }
    if (req.query.qb_project_id == undefined || req.query.qb_project_id == "") {
      req.query.qb_project_id = null;
    }
    if (req.query.qb_product_id == undefined || req.query.qb_product_id == "") {
      req.query.qb_product_id = null;
    }
    if (
      req.query.qb_product_name == undefined ||
      req.query.qb_product_name == ""
    ) {
      req.query.qb_product_name = null;
    }
    if (req.query.work_country == undefined || req.query.work_country == "") {
      req.query.work_country = null;
    }
    if (req.query.reason == undefined || req.query.reason == "") {
      req.query.reason = null;
    }
    if (req.query.reason_id == undefined || req.query.reason_id == "") {
      req.query.reason_id = null;
    }
    if (req.query.qb_status == undefined || req.query.qb_status == "") {
      req.query.qb_status = null;
    }
    if (
      req.query.record_type_status == undefined ||
      req.query.record_type_status == ""
    ) {
      req.query.record_type_status = null;
    }
  }

  if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
    req.query.pagenumber = null;
  }
  if (req.query.pagesize == undefined || req.query.pagesize == "") {
    req.query.pagesize = null;
  }

  try {
    await con.query(
      `SELECT * from timesheets.get_projects_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32)`,
      [
        req.query.keyword,
        req.query.full_name,
        req.query.client_name,
        req.user.org_id,
        req.query.user_id,
        req.query.project_name,
        req.query.project_status,
        req.query.start_date,
        req.query.end_date,
        req.query.client_manager_name,
        req.query.client_manager_email,
        req.query.job_title,
        req.query.is_placement_project,
        req.query.placement_type,
        req.query.placement_project_id,
        req.query.placement_code,
        req.query.is_primary_project,
        req.query.direct_customer_engagement,
        req.query.end_customer_id,
        req.query.qb_customer_name,
        req.query.qb_customer_id,
        req.query.qb_project_name,
        req.query.qb_project_id,
        req.query.qb_product_id,
        req.query.qb_product_name,
        req.query.work_country,
        req.query.reason,
        req.query.reason_id,
        req.query.qb_status,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch project details";
          returnMessage.error = error;
          returnMessage.label = "get_projects_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          if (results) {
            let data =
              (results.rows && results.rows[0] && results.rows[0].j) || null;
            let count =
              (results.rows && results.rows[1] && results.rows[1].j) || null;

              let is_qb_enabled = await isQBEnabled(req.user.org_id);

            // don't pass qb details in API response
            if (
              data &&
              data.length &&
              (!is_qb_enabled || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id)
              )
            ) {
              for (var i = 0; i < data.length; i++) {
                delete data[i].qb_customer_id;
                delete data[i].qb_customer_name;
                delete data[i].qb_project_id;
                delete data[i].qb_project_name;
                delete data[i].qb_product_id;
                delete data[i].qb_product_name;
                delete data[i].qb_status;
              }
            }

            if (data && data.length) {
              for (var i = 0; i < data.length; i++) {
                delete data[i].bill_rate;
                delete data[i].pay_rate;
                delete data[i].bill_rate_currency;
                delete data[i].ot_bill_rate;
                delete data[i].ot_pay_rate;
                delete data[i].ot_bill_rate_currency;
              }
            }
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = data;
            returnMessage.count = count;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_projects_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_projects_report
const export_projects_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

  let keyword = req.query.keyword;

  if (keyword) {

    req.query.user_id = null;
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.record_type_status = null;
    
    if(["local", "placement"].includes(keyword.toLowerCase())){
      if(keyword.toLowerCase() == "local"){
        req.query.is_placement_project = false;
      }
      else if(keyword.toLowerCase() == "placement"){
        req.query.is_placement_project = true;
      }
      else{
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if(Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)){
      req.query.project_status = project_status_keyword;
    }
    
  }
  else{

    req.query.keyword = null;

    if (
      req.query.project_status == undefined ||
      req.query.project_status == ""
    ) {
      req.query.project_status = null;
    }
    if (req.query.start_date == undefined || req.query.start_date == "") {
      req.query.start_date = null;
    }
    if (req.query.end_date == undefined || req.query.end_date == "") {
      req.query.end_date = null;
    }
    if (
      req.query.client_manager_name == undefined ||
      req.query.client_manager_name == ""
    ) {
      req.query.client_manager_name = null;
    }
    if (
      req.query.client_manager_email == undefined ||
      req.query.client_manager_email == ""
    ) {
      req.query.client_manager_email = null;
    }
    if (req.query.job_title == undefined || req.query.job_title == "") {
      req.query.job_title = null;
    }
    if (
      req.query.is_placement_project == undefined ||
      req.query.is_placement_project == ""
    ) {
      req.query.is_placement_project = null;
    }
    if (
      req.query.placement_type == undefined ||
      req.query.placement_type == ""
    ) {
      req.query.placement_type = null;
    }
    if (
      req.query.placement_project_id == undefined ||
      req.query.placement_project_id == ""
    ) {
      req.query.placement_project_id = null;
    }
    if (
      req.query.placement_code == undefined ||
      req.query.placement_code == ""
    ) {
      req.query.placement_code = null;
    }
    if (
      req.query.is_primary_project == undefined ||
      req.query.is_primary_project == ""
    ) {
      req.query.is_primary_project = null;
    }
    if (
      req.query.direct_customer_engagement == undefined ||
      req.query.direct_customer_engagement == ""
    ) {
      req.query.direct_customer_engagement = null;
    }
    if (
      req.query.end_customer_id == undefined ||
      req.query.end_customer_id == ""
    ) {
      req.query.end_customer_id = null;
    }
    if (
      req.query.qb_customer_name == undefined ||
      req.query.qb_customer_name == ""
    ) {
      req.query.qb_customer_name = null;
    }
    if (
      req.query.qb_customer_id == undefined ||
      req.query.qb_customer_id == ""
    ) {
      req.query.qb_customer_id = null;
    }
    if (
      req.query.qb_project_name == undefined ||
      req.query.qb_project_name == ""
    ) {
      req.query.qb_project_name = null;
    }
    if (req.query.qb_project_id == undefined || req.query.qb_project_id == "") {
      req.query.qb_project_id = null;
    }
    if (req.query.qb_product_id == undefined || req.query.qb_product_id == "") {
      req.query.qb_product_id = null;
    }
    if (
      req.query.qb_product_name == undefined ||
      req.query.qb_product_name == ""
    ) {
      req.query.qb_product_name = null;
    }
    if (req.query.work_country == undefined || req.query.work_country == "") {
      req.query.work_country = null;
    }
    if (req.query.reason == undefined || req.query.reason == "") {
      req.query.reason = null;
    }
    if (req.query.reason_id == undefined || req.query.reason_id == "") {
      req.query.reason_id = null;
    }
    if (req.query.qb_status == undefined || req.query.qb_status == "") {
      req.query.qb_status = null;
    }
    if (
      req.query.record_type_status == undefined ||
      req.query.record_type_status == ""
    ) {
      req.query.record_type_status = null;
    }
  }

  try {
    await con.query(
      `SELECT * from timesheets.export_projects_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29)`,
      [
        req.query.keyword,
        req.query.full_name,
        org_id,
        req.query.user_id,
        req.query.project_name,
        req.query.project_status,
        req.query.start_date,
        req.query.end_date,
        req.query.client_manager_name,
        req.query.client_manager_email,
        req.query.job_title,
        req.query.is_placement_project,
        req.query.placement_type,
        req.query.placement_project_id,
        req.query.placement_code,
        req.query.is_primary_project,
        req.query.direct_customer_engagement,
        req.query.end_customer_id,
        req.query.qb_customer_name,
        req.query.qb_customer_id,
        req.query.qb_project_name,
        req.query.qb_project_id,
        req.query.qb_product_id,
        req.query.qb_product_name,
        req.query.work_country,
        req.query.reason,
        req.query.reason_id,
        req.query.qb_status,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_project";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          // don't pass qb details in API response
          if (
            results &&
            results.length &&
            (!is_qb_enabled || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
              req.user.role_id
            ))
          ) {
            for (var i = 0; i < results.length; i++) {
              delete results[i].qb_customer_id;
              delete results[i].qb_customer_name;
              delete results[i].qb_project_id;
              delete results[i].qb_project_name;
              delete results[i].qb_product_id;
              delete results[i].qb_product_name;
              delete results[i].qb_status;
            }
          }

          if (results && results.length) {
            for (var i = 0; i < results.length; i++) {
              delete results[i].bill_rate;
              delete results[i].pay_rate;
              delete results[i].bill_rate_currency;
              delete results[i].ot_bill_rate;
              delete results[i].ot_pay_rate;
              delete results[i].ot_bill_rate_currency;
            }
          }

          if (results && results.length) {
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportProjectsReports");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              {
                header: "PROJECT TYPE",
                key: "is_placement_project",
                width: 10,
              },
              { header: "CONSULTANT NAME", key: "full_name", width: 10 },
              { header: "PROJECT NAME", key: "project_name", width: 10 },
              {
                header: "CLIENT MANAGER NAME",
                key: "client_manager_name",
                width: 10,
              },
              {
                header: "CLIENT MANAGER EMAIL",
                key: "client_manager_email",
                width: 10,
              },
              { header: "PROJECT STATUS", key: "project_status", width: 10 },
              { header: "START DATE", key: "start_date", width: 10 },
              { header: "END DATE", key: "end_date", width: 10 },
              { header: "JOB TITLE", key: "job_title", width: 10 },
              { header: "PLACEMENT TYPE", key: "placement_type", width: 10 },
              {
                header: "PLACEMENT PROJECT ID",
                key: "placement_project_id",
                width: 10,
              },
              { header: "PLACEMENT CODE", key: "placement_code", width: 10 },
              {
                header: "IS PRIMARY PROJECT",
                key: "is_primary_project",
                width: 10,
              },
              {
                header: "DIRECT CUSTOMER ENGAGEMENT",
                key: "direct_customer_engagement",
                width: 10,
              },
              { header: "END CUSTOMER ID", key: "end_customer_id", width: 10 },
            ];

            if (
              is_qb_enabled && [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                req.user.role_id
              )
            ) {
              worksheet.columns = [
                ...worksheet.columns,
                { header: "QB CUSTOMER ID", key: "qb_customer_id", width: 10 },
                {
                  header: "QB CUSTOMER NAME",
                  key: "qb_customer_name",
                  width: 10,
                },
                { header: "QB PROJECT ID", key: "qb_project_id", width: 10 },
                {
                  header: "QB PROJECT NAME",
                  key: "qb_project_name",
                  width: 10,
                },
                { header: "QB PRODUCT ID", key: "qb_product_id", width: 10 },
                {
                  header: "QB PRODUCT NAME",
                  key: "qb_product_name",
                  width: 10,
                },
                { header: "QB STATUS", key: "qb_status", width: 10 },
              ];
            }
              worksheet.columns = [
                ...worksheet.columns,
                { header: "WORK COUNTRY", key: "work_country", width: 10 },
                { header: "REASON", key: "reason", width: 10 },
                { header: "REASON ID", key: "reason_id", width: 10 },
                {
                  header: "STATUS",
                  key: "record_type_status",
                  width: 10,
                },
              ];

            for (i = 0; i < results.length; i++) {
              row = results[i];

              let is_placement_project =
                row.is_placement_project == true ? "Placement" : "Local";

                let full_name = row.full_name ? titleCase(row.full_name) :'' ;

              let project_name = row.project_name ? titleCase(row.project_name): "";

              let tmpRow = [
                is_placement_project,
                full_name,
                project_name,
                row.client_manager_name,
                row.client_manager_email,
                row.project_status,
                row.start_date,
                row.end_date,
                row.job_title,
                row.placement_type,
                row.placement_project_id,
                row.placement_code,
                row.is_primary_project,
                row.direct_customer_engagement,
                row.end_customer_id,
              ];
              if (
                [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                )
              ) {
                tmpRow = [
                  ...tmpRow,
                  row.qb_customer_id,
                  row.qb_customer_name,
                  row.qb_project_id,
                  row.qb_project_name,
                  row.qb_product_id,
                  row.qb_product_name,
                  row.qb_status,
                ];
              }
              tmpRow = [
                ...tmpRow,
                row.work_country,
                row.reason,
                row.reason_id,
                row.record_type_status,
              ];

              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/reports/projects-reports"
            );
            let fileName = `projects-report-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/reports/projects-reports/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/reports/projects-reports/${fileName}`
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);

              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_projects_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project_timesheet_submission_report
const project_timesheet_submission_report = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;
  let user_id = req.user.id;

  let keyword = req.query.keyword;

  if (keyword) {
    req.query.user_id = null;
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.is_primary_project = null;
    req.query.record_type_status = null;

    //Is Local or Placement Project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    // is Primary or Secondary project
    if (["primary", "secondary"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "primary") {
        req.query.is_primary_project = true;
      } else if (keyword.toLowerCase() == "secondary") {
        req.query.is_primary_project = false;
      } else {
        req.query.is_primary_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{

    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
      req.query.user_id = null;
    }
    if(req.query.project_name == undefined || req.query.project_name == "") {
      req.query.project_name = null;
    }
    if(req.query.placement_code == undefined || req.query.placement_code == "") {
      req.query.placement_code = null;
    }
    if (req.query.project_status == undefined || req.query.project_status == "") {
      req.query.project_status = null;
    }
    if(req.query.is_placement_project == undefined || req.query.is_placement_project == "" ) {
      req.query.is_placement_project = null;
    }
    if(req.query.is_primary_project == undefined || req.query.is_primary_project == "" ) {
      req.query.is_primary_project = null;
    }
    if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
      req.query.record_type_status = null;
    }
  }

   if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
        req.query.pagenumber = null;
      }
      if (req.query.pagesize == undefined || req.query.pagesize == "") {
        req.query.pagesize = null;
      }


  try {
     
     
      await con.query(
        `SELECT * from timesheets.get_project_timesheet_submission_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
        [
          req.query.keyword,
          org_id,
          user_id,
          req.query.start_date,
          req.query.end_date,
          req.query.project_id,
          req.query.is_placement_project,
          req.query.project_status,
          req.query.placement_type,
          req.query.record_type_status,
          req.query.client_name,
          req.query.pagenumber,
          req.query.pagesize,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "project_timesheet_submission_report";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let count =
              (results.rows &&
                results.rows[1] &&
                results.rows[1].j &&
                results.rows[1].j[0] &&
                results.rows[1].j[0].count) ||
              null;
            results =
              (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (results && results.length) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = results;
              returnMessage.count = count;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
            ///////////////
          }
        }
      );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "project_timesheet_submission_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_project_timesheet_submission_report
const export_project_timesheet_submission_report = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  let keyword = req.query.keyword;
  if (keyword) {
    req.query.user_id = null;
    req.query.project_name = null;
    req.query.placement_code = null;
    req.query.project_status = null;
    req.query.is_placement_project = null;
    req.query.is_primary_project = null;
    req.query.record_type_status = null;

    // is local and placement project
    if (["bench", "placement"].includes(keyword.toLowerCase())) {
      if (keyword.toLowerCase() == "bench") {
        req.query.is_placement_project = false;
      } else if (keyword.toLowerCase() == "placement") {
        req.query.is_placement_project = true;
      } else {
        req.query.is_placement_project = null;
      }
    }

    let project_status_keyword = keyword.replace(" ", "_");
    project_status_keyword = project_status_keyword.replace("-", "_");
    project_status_keyword = project_status_keyword.toUpperCase();
    // console.log(project_status_keyword)
    // PROJECTS_STATUS_MAPPING
    if (Object.keys(PROJECTS_STATUS_MAPPING).includes(project_status_keyword)) {
      req.query.project_status = project_status_keyword;
    }
  }
  else{

    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
      req.query.user_id = null;
    }
    if(req.query.project_name == undefined || req.query.project_name == "") {
      req.query.project_name = null;
    }
    if(req.query.placement_code == undefined || req.query.placement_code == "") {
      req.query.placement_code = null;
    }
    if (req.query.project_status == undefined || req.query.project_status == "") {
      req.query.project_status = null;
    }
    if(req.query.is_placement_project == undefined || req.query.is_placement_project == "" ) {
      req.query.is_placement_project = null;
    }
    if(req.query.is_primary_project == undefined || req.query.is_primary_project == "" ) {
      req.query.is_primary_project = null;
    }
    if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
      req.query.record_type_status = null;
    }
  }

  try {

    await con.query(
      `SELECT * from timesheets.export_project_timesheet_submission_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [
        req.query.keyword,
        org_id,
        req.user.user_id,
        req.query.start_date,
        req.query.end_date,
        req.query.project_id,
        req.query.is_placement_project,
        req.query.project_status,
        req.query.placement_type,
        req.query.record_type_status,
        req.query.client_name
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_project_timesheet_submission_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {
            var report_data = [];

            /////////////////////////////////////

            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet(
              "ProjectTimesheetSubmissionReport"
            );

              // Column for data in excel. key must match data key
              worksheet.columns = [
                { header: "EMPLOYEE ID", key: "employee_id", width: 15 },
                { header: "EMPLOYEE NAME", key: "full_name", width: 15 },
                { header: "PROJECT TYPE", key: "is_placement_project", width: 15 },
                { header: "PLACEMENT ID", key: "placement_code", width: 15 },
                { header: "PROJECT NAME", key: "project_name", width: 15 },
                { header: "LAST TIMESHEET SUBMISSION DATE", key: "last_timesheet_submission_date", width: 15 },
                { header: "REGULAR HOURS", key: "regular_hours_minutes", width: 15 },
                { header: "OT HOURS", key: "ot_hours_minutes", width: 15 },
                { header: "TOTAL HOURS SUBMITTED TILL NOW", key: "total_hours_minutes", width: 15 },
              ];
              for (i = 0; i < results.length; i++) {

                row = results[i];

                let is_placement_project = row.is_placement_project == true ? "Placement" : "Bench";

                let full_name = row.full_name ? titleCase(row.full_name) :'' ;

                let project_name = row.project_name;
                project_name = project_name ? titleCaseForHyphen(project_name) : "";

                let timesheet_date = row.last_timesheet_data && row.last_timesheet_data[0] && row.last_timesheet_data[0].timesheet_date;
                    timesheet_date = moment(timesheet_date, "YYYY-MM-DD");
                    timesheet_date = timesheet_date && timesheet_date.isValid() ? timesheet_date.format("DD-MMM-YYYY") : "-";

                let regular_hours_minutes = (row.total_timesheet_data && row.total_timesheet_data[0] && row.total_timesheet_data[0].regular_hours_minutes) || `-`;
                
                let ot_hours_minutes = (row.total_timesheet_data && row.total_timesheet_data[0] && row.total_timesheet_data[0].ot_hours_minutes) || `-`;
                
                let total_hours_minutes = (row.total_timesheet_data && row.total_timesheet_data[0] && row.total_timesheet_data[0].total_hours_minutes) || `-`;

                let tmpRow = [
                  row.employee_id,
                  full_name,
                  is_placement_project,
                  row.placement_code,
                  project_name,
                  timesheet_date,
                  regular_hours_minutes,
                  ot_hours_minutes,
                  total_hours_minutes
                ];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/reports/project-timesheet-submission-reports"
            );
            let fileName = `project-timesheet-submission-report-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/reports/project-timesheet-submission-reports/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {

                let orgData = await getOrgData(org_id);
                let newFileName = `project-timesheets-submission-reports-${((orgData && orgData.org_name) || ``)}.xlsx`;
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/reports/project-timesheet-submission-reports/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);
              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });

            ////////////////////////////////////
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_project_timesheet_submission_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_qb_logs_report
const get_qb_logs_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "employee_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "employee_wise_time_management_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
    if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
      req.query.pagenumber = null;
    }
    if (req.query.pagesize == undefined || req.query.pagesize == "") {
      req.query.pagesize = null;
    }
    if (req.query.keyword == undefined || req.query.keyword == "") {
      req.query.keyword = null;
    }
    if (req.query.start_date == undefined || req.query.start_date == "") {
      req.query.start_date = null;
    }
    if (req.query.end_date == undefined || req.query.end_date == "") {
      req.query.end_date = null;
    }
    if (req.query.api_name == undefined || req.query.api_name == "") {
      req.query.api_name = null;
    }
    if (req.query.request_status == undefined || req.query.request_status == "") {
      req.query.request_status = null;
    }
    if (
      req.query.record_type_status == undefined ||
      req.query.record_type_status == ""
    ) {
      req.query.record_type_status = null;
    }


    await con.query(
      `SELECT * from timesheets.get_qb_logs_report($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        req.query.keyword,
        org_id,
        req.query.start_date,
        req.query.end_date,
        req.query.api_name,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch user details";
          returnMessage.error = error;
          returnMessage.label = "get_qb_logs_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_qb_logs_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_qb_logs_report
const export_qb_logs_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.start_date == undefined || req.query.start_date == "") {
    req.query.start_date = null;
  }
  if (req.query.end_date == undefined || req.query.end_date == "") {
    req.query.end_date = null;
  }
  if (req.query.api_name == undefined || req.query.api_name == "") {
    req.query.api_name = null;
  }
  if (
    req.query.record_type_status == undefined ||
    req.query.record_type_status == ""
  ) {
    req.query.record_type_status = null;
  }

  try {
    await con.query(
      `SELECT * from timesheets.export_qb_logs_report($1,$2,$3,$4,$5,$6);`,
      [
        req.query.keyword,
        org_id,
        req.query.start_date,
        req.query.end_date,
        req.query.api_name,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_qb_logs_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[1].j) || null;

          if (results && results.length) {
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("QuickBookReports");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "Sr. No.", key: "serial", width: 10 },
              { header: "SERVICE NAME", key: "api_name", width: 10 },
              { header: "REQUEST STATUS", key: "request_status", width: 10 },
              { header: "REQUEST DATA", key: "request_data", width: 10 },
              { header: "RESPONSE DATA", key: "response_data", width: 10 },
            ];


            for (i = 0; i < results.length; i++) {
              row = results[i];

              let serial = i + 1;
              let full_name = row.full_name ? titleCase(row.full_name) : "";

              let tmpRow = [
                serial,
                row.api_name,
                row.request_status,
                row.request_data,
                row.response_data,
              ];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/reports/quickbook-logs-reports"
            );
            let fileName = `quickbook-logs-report-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/reports/quickbook-logs-reports/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {

                let orgData = await getOrgData(org_id);
                let newFileName = `quickbook-logs-reports-${((orgData && orgData.org_name) || ``)}.xlsx`
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/reports/quickbook-logs-reports/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);

              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_qb_logs_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_user_logs_report
const get_user_logs_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  // let user_id = req.user.id;
  let start_date = null;
  let end_date = null;

  try {

    if (req.query.start_date && req.query.end_date) {
      start_date = req.query.start_date;
      end_date = req.query.end_date;
    } else {
      let currentDate = moment().format("YYYY-MM-DD");
      start_date = moment(currentDate)
        .subtract(1, "months")
        .format("YYYY-MM-DD");
      end_date = moment(currentDate).format("YYYY-MM-DD");
    }
     if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "get_user_logs_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "get_user_logs_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
    await con.query(
      `SELECT * from timesheets.get_user_logs_report($1,$2,$3,$4,$5,$6,$7,$8,$9,$10);`,
      [
        req.query.keyword,
        start_date,
        end_date,
        org_id,
        req.query.user_id,
        req.query.ip_address,
	      req.query.browser_details,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch sync logs details";
          returnMessage.error = error;
          returnMessage.label = "get_user_logs_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_logs_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_user_logs_report
const export_user_logs_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  let start_date = null;
  let end_date = null;
  try {
    if (req.query.start_date && req.query.end_date) {
      start_date = req.query.start_date;
      end_date = req.query.end_date;
    } else {
      let currentDate = moment().format("YYYY-MM-DD");
      start_date = moment(currentDate)
        .subtract(1, "months")
        .format("YYYY-MM-DD");
      end_date = moment(currentDate).format("YYYY-MM-DD");

    }
    await con.query(
      `SELECT * from timesheets.export_user_logs_report($1,$2,$3,$4,$5,$6,$7,$8);`,
      [
        req.query.keyword,
        start_date,
        end_date,
        org_id,
        req.query.user_id,
        req.query.ip_address,
        req.query.browser_details,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_user_logs_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportUserLogsReport");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "Sr. NO.", key: "serial", width: 10 },
              { header: "EMPLOYEE ID", key: "employee_id", width: 10 },
              { header: "EMPLOYEE NAME", key: "full_name", width: 10 },
              { header: "LAST LOGIN", key: "login_time", width: 10 },
              { header: "LAST LOGOUT", key: "logout_time", width: 10 },
              { header: "IP ADDRESS", key: "ip_address", width: 10 },
              { header: "BROWSER DETAILS", key: "browser_details", width: 10 },
              { header: "DEVICE NAME", key: "device_name", width: 10 },
            ];

            for (i = 0; i < results.length; i++) {
              row = results[i];

              // 2023-05-19T18:11:44.566419


              let login_time = row.login_time;
              login_time = moment(login_time, "YYYY-MM-DDTHH:mm:ss");
              login_time = login_time && login_time.isValid() ? login_time.format("DD-MMM-YYYY HH:mm:ss")+ " GMT" : "-";

              let logout_time = row.logout_time;
              logout_time = moment(logout_time, "YYYY-MM-DDTHH:mm:ss");
              logout_time = logout_time && logout_time.isValid() ? logout_time.format("DD-MMM-YYYY HH:mm:ss")+ " GMT" : "-";

              let serial = i + 1;
              let full_name = row.full_name ? titleCase(row.full_name) : "";

              let device_name = row.browser_details;
              device_name = JSON.parse(device_name);
              device_name = device_name.os || "-";

              let browser_details = row.browser_details;
              browser_details = JSON.parse(browser_details);
              let browser_name = browser_details.name ||'-';
              let browser_version = browser_details.version ||'-';
              browser_details = (browser_name === '-' ? '-' : browser_name + " - " + browser_version);
              // browser_details = browser_name + ' - ' + browser_version;

              let ip_address =  row.ip_address;

              let tmpRow = [
                serial,
                row.employee_id,
                full_name,
                login_time,
                logout_time,
                ip_address,
                browser_details,
                device_name,
              ];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/reports/user-log-reports"
            );
            let fileName = `user-logs-report-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/reports/user-logs-report/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {
                let orgData = await getOrgData(org_id);
                let newFileName = `user-logs-report-${((orgData && orgData.org_name) || ``)}.xlsx`;
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/reports/user-logs-report/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);
              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_user_logs_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_employees_status_report
const get_employees_status_report = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  try {
    if (!req.query.start_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "start_date can not be null or empty";
      returnMessage.label = "get_employees_status_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.end_date) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "end_date can not be null or empty";
      returnMessage.label = "get_employees_status_report";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      if (req.query.keyword == undefined || req.query.keyword == "") {
        req.query.keyword = null;
      }
      if (req.query.start_date == undefined || req.query.start_date == "") {
        req.query.start_date = null;
      }
      if (req.query.end_date == undefined || req.query.end_date == "") {
        req.query.end_date = null;
      }
      if (req.query.employee_type == undefined || req.query.employee_type == "") {
      req.query.employee_type = null;
      }
      if (
        req.query.record_type_status == undefined ||
        req.query.record_type_status == ""
      ) {
        req.query.record_type_status = null;
      }
      if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
        req.query.pagenumber = null;
      }
      if (req.query.pagesize == undefined || req.query.pagesize == "") {
        req.query.pagesize = null;
      }


    await con.query(
      `SELECT * from timesheets.get_employees_status_report($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        req.query.keyword,
        req.query.start_date,
        req.query.end_date,
        org_id,
        req.query.employee_type,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch user details";
          returnMessage.error = error;
          returnMessage.label = "get_employees_status_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employees_status_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_employees_status_report
const export_employees_status_report = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

    if (req.query.keyword == undefined || req.query.keyword == "") {
      req.query.keyword = null;
    }
    if (req.query.start_date == undefined || req.query.start_date == "") {
      req.query.start_date = null;
    }
    if (req.query.end_date == undefined || req.query.end_date == "") {
      req.query.end_date = null;
    }
    if (req.query.employee_type == undefined || req.query.employee_type == "") {
    req.query.employee_type = null;
    }
    if (
      req.query.record_type_status == undefined ||
      req.query.record_type_status == ""
    ) {
      req.query.record_type_status = null;
    }

  try {
    await con.query(
      `SELECT * from timesheets.export_employees_status_report($1,$2,$3,$4,$5,$6);`,
      [
        req.query.keyword,
        req.query.start_date,
        req.query.end_date,
        org_id,
        req.query.employee_type,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_employees_status_report";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("EmployeesStatusReports");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "EMPLOYEE TYPE", key: "employee_type", width: 10 },
              { header: "EMPLOYEE STATUS", key: "record_type_status", width: 10 },
              { header: "NUMBER OF EMPLOYEES", key: "no_of_employees", width: 10 },
            ];

            for (i = 0; i < results.length; i++) {
              row = results[i];

              let tmpRow = [
                row.employee_type,
                row.record_type_status,
                row.no_of_employees,
              ];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/reports/employee-status-reports"
            );
            let fileName = `employee-status-report-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/reports/employee-status-reports/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {

                let orgData = await getOrgData(org_id);
                let newFileName = `employee-status-reports-${((orgData && orgData.org_name) || ``)}.xlsx`
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/reports/employee-status-reports/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);

              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_employees_status_report";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};



module.exports = {
  employee_wise_time_management_report,
  employee_wise_projects_time_management_report,
  export_employee_wise_time_management_report,
  project_wise_time_management_report,
  project_wise_employees_time_management_report,
  export_project_wise_time_management_report,
  project_wise_employee_timesheet_report,
  export_project_wise_employee_timesheet_report,
  timesheet_submission_report,
  export_timesheet_submission_report,
  get_employees_report,
  export_employees_report,
  get_projects_report,
  export_projects_report,
  project_timesheet_submission_report,
  export_project_timesheet_submission_report,
  get_qb_logs_report,
  export_qb_logs_report,
  get_user_logs_report,
  export_user_logs_report,
  get_employees_status_report,
  export_employees_status_report,
};
