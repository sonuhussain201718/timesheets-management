const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function employeeDocumentTypeValidator(data) {
  let errors = {};

  if (validator.isEmpty(data.document_type_name)) {
    errors.document_type_name = "document_type_name is invalid";
  }

  if (validator.isEmpty(data.description)) {
    errors.description = "description is invalid";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
