const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_all_customers,
  // filter_customers,
  get_customer_by_id,
  get_customers_list,
  insert_customer,
  edit_customer,
  export_all_customers,
  get_default_org_as_customer
} = require("../../controllers/customers2Controller");

// @route GET api/v1/customer/get_all_customers
// @desc  Route to get all customers
// @accesss public
router.get("/get_all_customers", get_all_customers);

// @route GET api/v1/customer/filter_customers
// @desc  Route to get customers by filter
// @accesss public
// router.get("/filter_customers", filter_customers);


// @route GET api/v1/customer/get_customer_by_id
// @desc  Route to get customers by id
// @accesss public
router.get("/get_customer_by_id", get_customer_by_id);

// @route GET api/v1/customer/get_customers_list
// @desc  Route to get customers list for client/customer dropdown field
// @accesss public
router.get("/get_customers_list", get_customers_list);

// @route POST api/v1/customer/insert_customer
// @desc  Route to post customers
// @accesss public
router.post("/insert_customer", insert_customer);

// @route PUT api/v1/customer/edit_customer
// @desc  Route to edit customers
// @accesss public
router.put("/edit_customer", edit_customer);

// @route GET api/v1/timesheets/export_all_customers
// @desc  Route to get export_all_customers
// @accesss public
router.get("/export_all_customers", export_all_customers);


// @route GET api/v1/customer/get_default_org_as_customer
// @desc  Route to get get_default_org_as_customer
// @accesss public
router.get("/get_default_org_as_customer", get_default_org_as_customer);

module.exports = router;
