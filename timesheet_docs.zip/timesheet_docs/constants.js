module.exports = {
  TIMESHEETS_LOGIN_URL:
    process.env.NODE_ENV === "production"
      ? `https://timesheets.msrcosmos.com/timetracker/login`
      : process.env.NODE_ENV === "development"
      ? `https://timesheets-uat.msrcosmos.com/timetracker/login`
      : `http://192.168.92.123:3011/timetracker/login`,
  ROLES: {
    SUPER_ADMIN: 1,
    ADMIN: 2,
    HR: 3,
    ACCOUNTS: 4,
    APPROVER: 5,
    SUPPORT: 6,
    EMPLOYEE: 7,
    TIMESHEET_ADMIN: 8,
  },
  EMPLOYEE_TYPE: {
    W2: "W2",
    C2C: "C2C",
    INTERNAL: "Internal",
  },
  PLACEMENT_STATUS_MAPPING: {
    PENDING_WITH_PAPER_WORK: "INITIATED",
    UNDER_CONTRACT_REVIEW: "INITIATED",
    AWAITING_FOR_LEGAL_APPROVAL: "INITIATED",
    PENDING_FOR_SIGNATURE: "INITIATED",
    INITIATION_FOR_CLOSURE: "INITIATED",
    TERMINATION_INITIATED: "INITIATED",
    CANDIDATE_JOINED: "IN_PROGRESS",
    PLACED: "IN_PROGRESS",
    PLACEMENT_ENDED: "COMPLETED",
    REJECTED: "REJECTED",
    PLACEMENT_CANCELLED: "CANCELLED",
    PLACEMENT_CLOSURE: "CANCELLED",
    TERMINATED: "CANCELLED",
  },
  PROJECTS_STATUS_MAPPING: {
    INITIATED: "Initiated",
    IN_PROGRESS: "In-Progress",
    COMPLETED: "Completed",
    CANCELLED: "Cancelled",
    REJECTED: "Rejected",
  },
  PROJECTS_STATUS: {
    INITIATED: "INITIATED",
    IN_PROGRESS: "IN_PROGRESS",
    COMPLETED: "COMPLETED",
    CANCELLED: "CANCELLED",
    REJECTED: "REJECTED",
  },
  TIMESHEET_STATUS: {
    SAVED: "SAVED",
    SUBMITTED: "SUBMITTED",
    APPROVED: "APPROVED",
    REJECTED: "REJECTED",
  },
  TS_COMMENT_TYPE: {
    WEEKLY: 1,
    DAILY: 2,
  },
  TS_COMMENT_USER_TYPE: {
    EMPLOYEE: 1,
    APPROVER: 2,
  },
  TS_ABSENT_TYPE: {
    LEAVE: 1,
    HOLIDAY: 2,
  },
  ALLOWED_PAST_ENTRY_DAYS: 180,
  DEFAULT_ECDB_TOOL_NAME: "Timesheet Tracker",
  PREVIEW_EXTENSIONS: ["jpg", "jpeg", "png", "gif", "pdf"],
  FCM_SETTINGS:
    process.env.NODE_ENV == "production"
      ? {
          type: "service_account",
          project_id: "timesheets---prod",
          private_key_id: "39b120e58a7b06c83d63368c976cfde2925cfdb7",
          private_key:
            "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCSTUwPk6y8CrJo\nsAXuCoFFB6M/ZQSxFzz4q75fg0O0SI0Z1xuAKnjww/HAnGH9NVRHIrhW9zgXL2/g\ndbM4vfRuZkJcpm16JCCxY5YWVDgobLbSrLIbrFksDvBbXEQIOHY+2UjLYtFvGQMX\nmW+BeNnpiGPftA7HoBB4iiv5LX4ztqOr6J544qDBEZXwmbyCxOPAKkMkFkrPC2kO\nKOY8U+HX8PCX0LRJWzQuGkg4KGa8S3keLeqhfBvtJZShUlN1kTXLMU4/Q/uvQF36\n3hSIJnkTjGIhbO/sAbdAtBmWKocnkTIwrD0rWtTVxLtjVt5+HFesV+NThHNR2Hpo\nuN7MwjnJAgMBAAECggEAAcvUZ1wOKrxcYqPnnLuxCNyOROrb9wMkpt5v7ssFJ6dc\n4SB2mFkdJUKYmx9oZhQTqfBrkDjGjeVRk7FKPyP45mqXvby22yEqrBbfirxjuJ5W\nE8nWQXf5G8z+pzZ/qNStofmntsSKsvkdBDsIZw/paAA6Tq6uoEWPMjWrEsr70c1z\nXGNfT0y6cb1k3ygFxA6V//fGQ6MC/LdUZHlqm1HfFsqDHdgXpchpvKLkE4av3TNO\nw7lqI2ufx1+NuQU3aK9o/FEf019589SuZkUg4Kb6QL0uVfHjo9L4UuJ5aOxI8Su3\nPrWV4aeI6L43S9OZbt20/hGdi668Fe99/sKraBzfEQKBgQDMVSZEuc4k/P0saZTt\niuklzf9vd1g142k/HDLKRKvNDPW6aaSJXsa6SFNfbHeM/WUzdnSYnlgEmsxjDcsR\nN/Cjrrcd727MxUNZauuBcCLWw5PQgI5ji2fNUPbDInazrtF5U3E5TVZI+yGXwVc5\nIDJxG8ByNnhIW7B9CsjsDk1s2QKBgQC3S7VcwQRCWRwhxCOnsJkHixNUFLF5lehc\n/ibrz2qL0BRWAJvsmLbAbxoo+KB14QwQl3sBLCPUMMvHzdnDrxG958lntmIau36O\nJHrcBbnuNE/hU82KH0OGoxZeZh5fjlVnW/3wbEMfyjZQ1n0T5h8UF+UTjxk048H2\nNR7dDxnecQKBgCzaXCYl6zxvVFvVaV2jan5j87hSKEjb/JRf6j5ASL4gJCihW/7T\nkSf/DF4b/zoxvW9Ih1uhFo0cNdVgh7zl3KrxhTzK/DVy78/HCp9FMECYefAA6ECt\nr0GAjkpTXF8g9tZ9HJOJiHFIvx0C0dS2Xpw5jUsE7e5kQh+QqH44vYIxAoGAZY49\n6ylKSdSDgLXip2tyLjrBN8nLVzlWqAds2yRtvQ9J5SirO5iVUON91AuFJCrPe3Xi\nghDJvSxYC9ki+YfLRbPh5GOp0XPmt6zAoZ1OmgtD4u2CqS+PQ06i+ySLWZhL+1t9\nxDLHshpgo8NjQ54xw/lFQ+P6LFKwydA+zG4sgBECgYApPic+lu6mP3iXuRHtMgLS\n9hFeOog3MMWOksungl0lbM8YZ3/pl+dvPU1MRzSUWhbk7Fe2jUmaFkjOZDYF7GHK\nkFLK3adROvsYUhjT27AtroeEbYb3yz0dINkfc2pom+yjhu+R48S8XibTMkBVaj2J\nosRZCu+X+slzvo/iy6HCmg==\n-----END PRIVATE KEY-----\n",
          client_email:
            "firebase-adminsdk-jur4i@timesheets---prod.iam.gserviceaccount.com",
          client_id: "101279238316440956451",
          auth_uri: "https://accounts.google.com/o/oauth2/auth",
          token_uri: "https://oauth2.googleapis.com/token",
          auth_provider_x509_cert_url:
            "https://www.googleapis.com/oauth2/v1/certs",
          client_x509_cert_url:
            "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-jur4i%40timesheets---prod.iam.gserviceaccount.com",
          universe_domain: "googleapis.com",
        }
      : {
          type: "service_account",
          project_id: "timesheets-qa",
          private_key_id: "c13170983861127435af6086e6badc18cb360563",
          private_key:
            "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCRdG5sTRSc0j3T\nrPrzObVuQsNr6tyHe8gGgcZElqx2qCPPsXfPOH6n9j4TVSFnFqqgFEbMdGc18rv9\n7fhFum/dGtXAmSMRS1+VVPsfNliHdhLjaG5Te662qKI7rFfjC9J8JLpZefUn3sXK\nyIl3pBysmnb5VY3uWTofh7rxESIkcYQ3LLViDQ+4787oMMdXCh/TAvqC5AtrVa5Y\nmiNgDkly0dViF4Gy3GIhm6s0cPMwicuYYx755t4Rm5GlG23QOe8hJCEuoD7gpaRh\nZuM4IgQamfOUBNmOjZMsxCKsVNkJ56MDtM/e4XIBLiVFraavE6isWsAnBAWUjZIb\nIGT+jUWdAgMBAAECggEAE4x6asPRSWJYPOK6t4XCBJekfBSMnwjb0UQPyZgWhbwD\nVB6d45PMMfa+UQrX+mrpc6pF+aSLWozNB0u8WmK8NhMtNz1doS1oI0HQnllHfK05\nzKZ0bXPp/1KauzpmdXVZTKYDBZOGh11BaAebsiC0Wd5Iryn4cVg8n5A2Z7/Nvufu\n5coNQYE+vJKx6ZICOy5aVMDRp+3OLsRv8jH2Cz+zdwpQtQ0M6drJG/8dmfNr4l24\n0wcoxtrpK/nGRFiP2kN0fpy2xlCe4WicPWri/r1xCr+NzEUNwVzt24KUMjbpjTI9\nuq3nsQ2FyBijoLCJMGgRHLTcJGXYNUb5WxE04whiAQKBgQDDBjDFooQ+WvVpGSX2\nAsk+0HpHzJcxj9xaLSd4KekQXcpk3i+Dmhyn9f+fIN4XBBdlLPYLgHotmWE4Sk/U\nEoy10rY1sPxHP0d/7al221vTatYOGZSyPT+OPo97L+N3sgA0ORaET6uf8Z9jmVSv\nBnXJhxkmHd6XgnPtkWbUZOw+8QKBgQC+7rCDStrjkRcKid7+hNUQWlVburvQ44kt\nYRqJz3Bc7RnQy5YXAfibg354oWDum09uEiP0m39KMewolLnOrCRO3slf5KmhE1C5\njVeRwAu4AVxpNCKqvC8eB4mH9Qc+WLlPQkImYxz5qF3R6SVLVkUBptOY1irgYLbc\n+uK4s8AJbQKBgFI63Pun/5yPG6TZzrDBEfujSbvWXvWt09pN6bN38GZPNZR8Pop9\nw5FqXwLIh/wqZHbrkz7cSCfL4Tsr0ib4P042708KNgUQgGRHYEnWSgyFooXFcXYJ\n7y9Z34OweHeynPVoEL9vHE1PQsZrE1LNJYL4rLjupTk67wh/Y10wxI/xAoGAPgT6\ngStHfrQab+no7XPoYa92Gp3FdEz0ujDYlfsz3HuH7zKyRjb1sk48PqLtAZShcHek\nBkicSFV/CI+G64MvKA9mCigUkaXciulGkKl5JQQMKIAu4pbOF0sLeYY2HCJlz0EO\ni7mWJ+Jw10aMPrR/JdIy2Wp38vp3a8By9NwufOECgYBS/moqoNKVpSDU/MH5KqLa\n9WK2qdCnTIA5MlE4lNwCRv8h1wE5L5dZvMY0XcLVyqdd74NvYe74YuVArgoNBNbM\nKwaJpJMzaIbAEe59OBO8F3OXoUrv5iRjU7hYqLP9pqcIqPiq1Db/h2xor1XteBo2\nTu0q4w7VHNse/2i+pCZYPg==\n-----END PRIVATE KEY-----\n",
          client_email:
            "firebase-adminsdk-n62um@timesheets-qa.iam.gserviceaccount.com",
          client_id: "101499703639112623175",
          auth_uri: "https://accounts.google.com/o/oauth2/auth",
          token_uri: "https://oauth2.googleapis.com/token",
          auth_provider_x509_cert_url:
            "https://www.googleapis.com/oauth2/v1/certs",
          client_x509_cert_url:
            "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-n62um%40timesheets-qa.iam.gserviceaccount.com",
          universe_domain: "googleapis.com",
        },
};
