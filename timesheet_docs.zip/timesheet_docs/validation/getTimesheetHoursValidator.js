const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function getTimesheetHoursValidator(data) {
  let errors = {};

  // org_id is optional
  /* if (!data.org_id) {
    errors.org_id = "org_id field is required";
  } */

  if (!data.start_date) {
    errors.start_date = "start_date field is required";
  }

  if (!data.end_date) {
    errors.end_date = "end_date field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
