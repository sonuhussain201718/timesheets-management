const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function quickbookConfigValidator(data) {
  let errors = {};

  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }

  if (!data.access_token) {
    errors.access_token = "access_token field is required";
  }

  if (!data.client_id) {
    errors.client_id = "client_id field is required";
  }

  if (!data.client_secret) {
    errors.client_secret = "client_secret field is required";
  }

  if (!data.environment) {
    errors.environment = "environment field is required";
  }

  if (!data.expires_in) {
    errors.expires_in = "expires_in field is required";
  }

  if (!data.refresh_token) {
    errors.refresh_token = "refresh_token field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
