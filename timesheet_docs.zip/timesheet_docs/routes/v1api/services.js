const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  getallservices,
  insertService,
  editservice,
  deleteservice,
  getservicebyid,
} = require("../../controllers/serviceController");

// @route GET api/v1/services/getallservices
// @desc  Route to get all services
// @accesss public
router.get("/getallservices", getallservices);

// @route GET api/v1/services/getservicebyid
// @desc  Route to get service by id
// @accesss public
router.get("/getservicebyid", getservicebyid);

// @route POST api/v1/services/insertservices
// @desc  Route to post services
// @accesss public
router.post("/insertservice", insertService);

// @route PUT api/v1/services/editservices
// @desc  Route to edit services
// @accesss public
router.put("/editservice", editservice);

// @route DELETE api/v1/services/deleteservice
// @desc  Route to delete services
// @accesss public
router.put("/deleteservice", deleteservice);

module.exports = router;
