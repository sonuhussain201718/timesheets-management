const { getMsgFormat, isEmpty } = require("../utils/helpers");
const createOrganizationValidator = require("../validation/createOrganizationValidator");
const quickbooksSettingValidator = require("../validation/quickbooksSettingValidator");

const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const { BlobServiceClient } = require("@azure/storage-blob");
const { v1: uuidv1 } = require("uuid");
const { res } = require("pino-std-serializers");
// con.connect();

// GET api for organizations List
const getallorganizations = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_organizations($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch organizations details";
          returnMessage.error = error;
          returnMessage.label = "getallorganizations";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallorganizations";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for organization details
const get_organization_by_org_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_organizations_by_orgid($1)`,
      [req.query.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch organization details";
          returnMessage.error = error;
          returnMessage.label = "get_organization_by_org_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getorganizationbyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for organization details
const get_organization_by_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_organizations_by_id($1)`,
      [req.query.id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch organization details";
          returnMessage.error = error;
          returnMessage.label = "get_organization_by_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j[0];
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getorganizationbyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for organization
const insertorganization = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    const { errors, isValid } = createOrganizationValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insertorganization";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    const exists_data = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [req.body.org_id]
    );

    if (
      exists_data &&
      exists_data.rows[0].get_organizations_by_orgid &&
      exists_data.rows[0].get_organizations_by_orgid[0]
    ) {
      returnMessage.isError = true;
      returnMessage.message = "org_id already exists";
      returnMessage.error = { org_id: "org_id already exists" };
      returnMessage.label = "insertorganization";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      var logo = "";
      if (req.files && req.files.logo) {
        const AZURE_STORAGE_CONNECTION_STRING =
          process.env.AZURE_STORAGE_CONNECTION_STRING;
        if (!AZURE_STORAGE_CONNECTION_STRING) {
          throw Error("Azure Storage Connection string not found");
        }

        const blobServiceClient = BlobServiceClient.fromConnectionString(
          AZURE_STORAGE_CONNECTION_STRING
        );
        const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
        const containerClient =
          blobServiceClient.getContainerClient(containerName);
        const createContainerResponse =
          await containerClient.createIfNotExists();

        // Create a unique name for the blob
        var logoFile = req.files.logo;
        var newLogoName = uuidv1() + (logoFile.name.replace(/[^a-zA-Z0-9,_;\-.!? ]/g, ''));

        const blockBlobClient = containerClient.getBlockBlobClient(
          `logo/${newLogoName}`
        );
        const uploadBlobResponse = await blockBlobClient.upload(
          logoFile.data,
          logoFile.data.length
        );

        if (uploadBlobResponse && uploadBlobResponse.requestId) {
          logo = newLogoName;
        }
      }

      await con.query(
        `SELECT timesheets.insert_organizations($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
        [
          req.body.allow_placement,
          req.body.createdby,
          req.body.domain,
          req.body.ecdb_tool_name,
          req.body.org_id,
          req.body.org_name,
          req.body.org_prefix,
          req.body.prospective_admin_id,
          logo,
          req.body.record_type_status,
          req.body.email_reminder_1,
          req.body.email_reminder_2,
          req.body.allowed_past_entry_days,
          (req.body.max_regular_hours || 8),
          (req.body.notify_to_email || null),
          (req.body.notification_enabled || true)
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to Add";
            returnMessage.error = error;
            returnMessage.label = "insertorganization";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.response = results.rows[0].insert_organizations;
            returnMessage.data = results.rows[1].insert_organizations;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insertorganization";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for organization
const editorganization = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    const { errors, isValid } = createOrganizationValidator(req.body);
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "editorganization";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    const old_data = await con.query(
      `SELECT timesheets.get_organizations_by_id($1)`,
      [req.body.id]
    );
    const exists_data = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [req.body.org_id]
    );

    if (old_data && old_data.rows[0].get_organizations_by_id) {
      if (
        exists_data &&
        exists_data.rows[0].get_organizations_by_orgid &&
        exists_data.rows[0].get_organizations_by_orgid[0] &&
        exists_data.rows[0].get_organizations_by_orgid[0].id !=
          old_data.rows[0].get_organizations_by_id[0].id
      ) {
        returnMessage.isError = true;
        returnMessage.message = "org_id already exists";
        returnMessage.error = { org_id: "org_id already exists" };
        returnMessage.label = "editorganization";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      } else {
        var logo = old_data.rows[0].get_organizations_by_id[0].logo;

        if (req.files && req.files.logo) {
          const AZURE_STORAGE_CONNECTION_STRING =
            process.env.AZURE_STORAGE_CONNECTION_STRING;
          if (!AZURE_STORAGE_CONNECTION_STRING) {
            throw Error("Azure Storage Connection string not found");
          }

          const blobServiceClient = BlobServiceClient.fromConnectionString(
            AZURE_STORAGE_CONNECTION_STRING
          );
          const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
          const containerClient =
            blobServiceClient.getContainerClient(containerName);
          const createContainerResponse =
            await containerClient.createIfNotExists();

          var logoFile = req.files.logo;
          var newLogoName = uuidv1() + (logoFile.name.replace(/[^a-zA-Z0-9,_;\-.!? ]/g, ''));

          const blockBlobClient = containerClient.getBlockBlobClient(
            `logo/${newLogoName}`
          );

          const uploadBlobResponse = await blockBlobClient.upload(
            logoFile.data,
            logoFile.data.length
          );

          if (uploadBlobResponse && uploadBlobResponse.requestId) {
            logo = newLogoName;
          }
        }

        await con.query(
          `SELECT timesheets.update_organizations($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,
          [
            req.body.id,
            req.body.allow_placement,
            req.body.domain,
            req.body.ecdb_tool_name,
            req.body.org_id,
            req.body.org_name,
            req.body.org_prefix,
            req.body.prospective_admin_id,
            logo,
            req.body.record_type_status,
            req.body.updatedby,
            req.body.email_reminder_1,
            req.body.email_reminder_2,
            req.body.allowed_past_entry_days,
            (req.body.max_regular_hours || 8),
            (req.body.notify_to_email || null),
            (req.body.notification_enabled || true)
          ],
          (error, results) => {
            if (error) {
              returnMessage.isError = true;
              returnMessage.message = "Failed to update";
              returnMessage.error = error;
              returnMessage.label = "editorganization";
              logger.log({
                level: "error",
                message: returnMessage,
              });
              res.status(400).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.data = results.rows[1].update_organizations;
              returnMessage.message = "Updated Successfully";
              res.status(200).json(returnMessage);
            }
          }
        );
      }
    } else {
      logger.log({
        level: "error",
        message: "Organization not found!",
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "editorganization";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// Edit organization setting api
const edit_organization_setting = async (req, res) => {
  const returnMessage = getMsgFormat();

  try{  
    let org_id = req.user.org_id;
    const org_details = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [org_id]
    );
    const org_result =
      (org_details &&
        org_details.rows[0].get_organizations_by_orgid &&
        org_details.rows[0].get_organizations_by_orgid[0]) ||
      null;

    let orgData = [
      org_result.id,
      org_result.allow_placement,
      org_result.domain,
      org_result.ecdb_tool_name,
      org_id,
      org_result.org_name,
      org_result.org_prefix,
      org_result.prospective_admin_id,
      org_result.logo,
      org_result.record_type_status,
      org_result.updatedby,
      org_result.email_reminder_1,
      org_result.email_reminder_2,
      req.body.allowed_past_entry_days,
      org_result.max_regular_hours,
      org_result.notify_to_email,
      org_result.notification_enabled
    ];

    if (!req.body.allowed_past_entry_days) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "allowed_past_entry_days can not be null or empty";
      returnMessage.label = "edit_organization_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
else{
  await con.query(
    `SELECT timesheets.update_organizations($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,
    orgData,
    (error, results) => {
      if (error) {
        returnMessage.isError = true;
        returnMessage.message = "Failed to update";
        returnMessage.error = error;
        returnMessage.label = "edit_organization_setting";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      } else {
        returnMessage.isError = false;
        returnMessage.data = results.rows[1].update_organizations;
        returnMessage.message = "Updated Successfully";
        res.status(200).json(returnMessage);
      }
    }
  );
}
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error occured! please try again";
    returnMessage.error = error;
    returnMessage.label ="edit_organozation_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// update_organization_qb_setting API
const update_organization_qb_setting = async (req, res) => {

  const returnMessage = getMsgFormat();

  try{

    let org_id = req.user.org_id;

    const { errors, isValid } = quickbooksSettingValidator({...req.body, org_id});

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "get_timesheet_hours_including_no_entries";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{

      let createdby = req.user.id;
      let updatedby = req.user.id;
      let {
        enable_quickbooks,
        qb_transactions_setting = null
      } = req.body;

      const org_details = await con.query( `SELECT timesheets.get_organizations_by_orgid($1)`, [org_id]);
      const org_result =  (org_details && org_details.rows[0].get_organizations_by_orgid && org_details.rows[0].get_organizations_by_orgid[0]) || null;
  
      if(org_result){
        let orgData = [
          org_result.id,
          enable_quickbooks,
          updatedby,
        ];
  
        await con.query(
          `SELECT timesheets.update_organization_qb_setting($1,$2,$3)`,
          orgData,
          async (error, results) => {
            if (error) {
              returnMessage.isError = true;
              returnMessage.message = "Failed to update";
              returnMessage.error = error;
              returnMessage.label = "update_organization_qb_setting";
              logger.log({
                level: "error",
                message: returnMessage,
              });
              res.status(400).json(returnMessage);
            } else {

              let delete_previous_setting = await con.query( `SELECT timesheets.delete_qb_transactions_setting($1)`, [org_id]);

              if(qb_transactions_setting && qb_transactions_setting.length){
                
                for(var i = 0; i < qb_transactions_setting.length; i++){
                  // qb_transactions_setting
                  let settingRow = qb_transactions_setting[i] || null;
                  let {
                    transaction_name = null,
                    is_enabled = false,
                    record_type_status = "Active",
                  } = settingRow;

                  let settingData = [
                    org_id,
                    transaction_name,
                    is_enabled,
                    createdby,
                    record_type_status,
                  ];
                  let insertSetting = await con.query(
                    `SELECT timesheets.insert_qb_transactions_setting($1,$2,$3,$4,$5)`, 
                    settingData
                  );
                  insertSetting = (insertSetting && insertSetting.rows && insertSetting.rows[1] && insertSetting.rows[1].insert_qb_transactions_setting && insertSetting.rows[1].insert_qb_transactions_setting[0]) || null;

                  // console.log("insertSetting", insertSetting);

                }
              }


              ///
              let qb_transactions_setting_data = await con.query( `SELECT * from timesheets.get_qb_transactions_setting($1);`, [org_id]);
              qb_transactions_setting_data = (qb_transactions_setting_data && qb_transactions_setting_data.rows && qb_transactions_setting_data.rows[0] && qb_transactions_setting_data.rows[0].j) || null;
              ///
              returnMessage.isError = false;
              returnMessage.data = results.rows[1].update_organization_qb_setting;
              returnMessage.qb_transactions_setting_data = qb_transactions_setting_data;
              returnMessage.message = "Updated Successfully";
              res.status(200).json(returnMessage);
            }
          }
        );
      }
      else{
        returnMessage.isError = true;
        returnMessage.message = "Organization not found!";
        returnMessage.label = "update_organization_qb_setting";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(404).json(returnMessage);
      }
    }
    

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error occured! please try again";
    returnMessage.error = error;
    returnMessage.label ="update_organization_qb_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// update_organization_adp_setting API
const update_organization_adp_setting = async (req, res) => {

  const returnMessage = getMsgFormat();

  try{

    let org_id = req.user.org_id;
    let updatedby = req.user.id;
    const org_details = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [org_id]
    );
    const org_result =  (org_details && org_details.rows[0].get_organizations_by_orgid && org_details.rows[0].get_organizations_by_orgid[0]) || null;

    if(org_result){
      let orgData = [
        org_result.id,
        req.body.enable_adp,
        req.body.validate_adp_employee,
        req.body.validate_adp_approver,
        updatedby,
      ];

      await con.query(
        `SELECT timesheets.update_organization_adp_setting($1,$2,$3,$4,$5)`,
        orgData,
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_organization_adp_setting";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data = results.rows[1].update_organization_adp_setting;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "Organization not found!";
      returnMessage.label = "update_organization_adp_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(404).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error occured! please try again";
    returnMessage.error = error;
    returnMessage.label ="update_organization_adp_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// POST API for update_organization_weekly_reminder_setting
const update_organization_weekly_reminder_setting = async (req, res) => {

  const returnMessage = getMsgFormat();

  try{

    let org_id = req.user.org_id;
    let updatedby = req.user.id;
    const org_details = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [org_id]
    );
    const org_result =  (org_details && org_details.rows[0].get_organizations_by_orgid && org_details.rows[0].get_organizations_by_orgid[0]) || null;

    if(org_result){
      let orgData = [
        org_result.id,
        req.body.email_reminder_1,
        req.body.email_reminder_2,
        updatedby,
      ];

      await con.query(
        `SELECT timesheets.update_organization_weekly_reminder_setting($1,$2,$3,$4)`,
        orgData,
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_organization_weekly_reminder_setting";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data = results.rows[1].update_organization_weekly_reminder_setting;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "Organization not found!";
      returnMessage.label = "update_organization_weekly_reminder_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(404).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error occured! please try again";
    returnMessage.error = error;
    returnMessage.label ="update_organization_weekly_reminder_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for get_qb_transaction_names
const get_qb_transaction_names = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {
    
    let qbTransactionNames = [
      "getemployeedatabyname",
      "getcustomerdatabyname",
      // "getvendordatabyname",
      "getitemdatabyname",
      "send_project_wise_timesheet_to_qb",

    ];
    returnMessage.isError = false;
    returnMessage.message = "Records Found";
    returnMessage.data = qbTransactionNames;
    res.status(200).json(returnMessage);
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_qb_transaction_names";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for qb transactions setting
const get_qb_transactions_setting = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {

    let org_id = req.user.org_id;    
    await con.query(
      `SELECT * from timesheets.get_qb_transactions_setting($1);`,
      [org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "get_qb_transactions_setting";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_qb_transactions_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for get_qb_transactions_setting_by_name

const get_qb_transactions_setting_by_name = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  try {

    if (!req.query.name) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "name can not be null or empty";
      returnMessage.label = "get_qb_transactions_setting_by_name";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      await con.query(
        `SELECT * from timesheets.get_qb_transactions_setting_by_name($1, $2)`,
        [req.user.org_id, req.query.name],
        (error, results) => {
          
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch data";
            returnMessage.error = error;
            returnMessage.label = "get_qb_transactions_setting_by_name";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = results.rows[0].j;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_qb_transactions_setting_by_name";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_client_manager_mandatory
const get_client_manager_mandatory = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  try {
      await con.query(
        `SELECT * from timesheets.get_client_manager_mandatory($1)`,
        [org_id],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch Quickbook Config details";
            returnMessage.error = error;
            returnMessage.label = "get_client_manager_mandatory";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;
            res.status(200).json(returnMessage);
          }
        }
      );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_client_manager_mandatory";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// PUT API for update_organization_hours_setting
const update_organization_hours_setting = async (req, res) => {

  const returnMessage = getMsgFormat();

  try{

    let org_id = req.user.org_id;
    let updatedby = req.user.id;
    const org_details = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [org_id]
    );
    const org_result =  (org_details && org_details.rows[0].get_organizations_by_orgid && org_details.rows[0].get_organizations_by_orgid[0]) || null;

    if(org_result){
      let orgData = [
        org_result.id,
        req.body.max_regular_hours,
        updatedby,
      ];

      await con.query(
        `SELECT timesheets.update_organization_hours_setting($1,$2,$3)`,
        orgData,
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_organization_hours_setting";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data = results.rows[1].update_organization_hours_setting;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "Organization not found!";
      returnMessage.label = "update_organization_hours_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(404).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error occured! please try again";
    returnMessage.error = error;
    returnMessage.label ="update_organization_hours_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// PUT API for update_organization_email_setting
const update_organization_email_setting = async (req, res) => {

  const returnMessage = getMsgFormat();

  try{

    let org_id = req.user.org_id;
    let updatedby = req.user.id;
    const org_details = await con.query(
      `SELECT timesheets.get_organizations_by_orgid($1)`,
      [org_id]
    );
    const org_result =  (org_details && org_details.rows[0].get_organizations_by_orgid && org_details.rows[0].get_organizations_by_orgid[0]) || null;

    if(org_result){
      let orgData = [
        org_result.id,
        req.body.notify_to_email,
        req.body.notification_enabled,
        updatedby,
      ];

      await con.query(
        `SELECT timesheets.update_organization_email_setting($1,$2,$3,$4)`,
        orgData,
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_organization_email_setting";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data = results.rows[1].update_organization_email_setting;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "Organization not found!";
      returnMessage.label = "update_organization_email_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(404).json(returnMessage);
    }

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error occured! please try again";
    returnMessage.error = error;
    returnMessage.label ="update_organization_email_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getallorganizations,
  get_organization_by_id,
  get_organization_by_org_id,
  insertorganization,
  editorganization,
  edit_organization_setting,
  update_organization_qb_setting,
  update_organization_adp_setting,
  update_organization_weekly_reminder_setting,
  get_qb_transaction_names,
  get_qb_transactions_setting,
  get_qb_transactions_setting_by_name,
  get_client_manager_mandatory,
  update_organization_hours_setting,
  update_organization_email_setting,
};
