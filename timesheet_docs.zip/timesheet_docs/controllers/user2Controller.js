const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const createuserValidator = require("../validation/createUser2Validator");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const axios = require("axios");
const { ROLES } = require("../constants");
const fs = require("fs");
const { BlobServiceClient } = require("@azure/storage-blob");
var mime = require("mime-types");
const excelJS = require("exceljs");
const path = require("path");
const { isQBEnabled, isEmailReminderOn, isAdpEnabled,isQBTransactionOn } = require("../utils/timesheet_helpers");
const { titleCase } = require("../utils/helpers");
const { getOrgData } = require("../utils/timesheet_helpers");

// test
const {
  EmployeeUpdatedEmailToEmployee
} = require("../Email/email");

// GET api for users List
const getalluser = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
   if (req.query.first_name == undefined || req.query.first_name == "") {
     req.query.first_name = null;
   }
   if (req.query.middle_name == undefined || req.query.middle_name == "") {
     req.query.middle_name = null;
   }
   if (req.query.last_name == undefined || req.query.last_name == "") {
     req.query.last_name = null;
   }
   if (req.query.full_name == undefined || req.query.full_name == "") {
     req.query.full_name = null;
   }
   if (req.query.email == undefined || req.query.email == "") {
     req.query.email = null;
   }
   if (req.query.user_status == undefined || req.query.user_status == "") {
     req.query.user_status = null;
   }
   if (req.query.employee_id == undefined || req.query.employee_id == "") {
     req.query.employee_id = null;
   }
   if (
     req.query.department_name == undefined ||
     req.query.department_name == ""
   ) {
     req.query.department_name = null;
   }
   if (req.query.employee_type == undefined || req.query.employee_type == "") {
     req.query.employee_type = null;
   }
   if (
     req.query.record_type_status == undefined ||
     req.query.record_type_status == ""
   ) {
     req.query.record_type_status = null;
   }
  try {
    await con.query(
      `SELECT * from timesheets.get_all_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15);`,
      [
        req.query.keyword,
        req.query.first_name,
        req.query.middle_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.user_status,
        req.query.employee_id,
        req.query.timetracker_employee_id,
        req.query.department_name,
        req.user.org_id,
        req.query.employee_type,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch user details";
          returnMessage.error = error;
          returnMessage.label = "getalluser";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          // don't pass qb details in API response
          let data = (results && results.rows && results.rows[1] && results.rows[1].j) || null;
          if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))) ){
            for (var i = 0; i < data.length; i++) {
              delete data[i].qb_employee_id;
              delete data[i].qb_employee_name;
            }
          }
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getalluser";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for users List
const getuserbyid = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "getuserbyid";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_id($1,$2)`,
        [req.query.id, req.user.org_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user details";
            returnMessage.error = error;
            returnMessage.label = "getuserbyid";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {

            let is_qb_enabled = await isQBEnabled(req.user.org_id);
            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;
            if((data) && (!is_qb_enabled || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
                delete data.qb_employee_id;
                delete data.qb_employee_name;
            }

            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = data;
              
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getuserbyid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for user by prospective_user_id
const get_user_by_prospective_user_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.prospective_user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "prospective_user_id can not be null or empty";
      returnMessage.label = "get_user_by_prospective_user_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_prospective_user_id($1,$2)`,
        [req.user.org_id, req.query.prospective_user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user details";
            returnMessage.error = error;
            returnMessage.label = "get_user_by_prospective_user_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
              let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

              let is_qb_enabled = await isQBEnabled(req.user.org_id);

              if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                  delete data.qb_employee_id;
                  delete data.qb_employee_name;
              }
            if (data) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_by_prospective_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project by prospective_user_id excluding id
const get_user_by_prospective_user_id_excluding_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_user_by_prospective_user_id_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.prospective_user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "prospective_user_id can not be null or empty";
      returnMessage.label = "get_user_by_prospective_user_id_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_prospective_user_id_excluding_id($1,$2,$3)`,
        [req.user.org_id, req.query.id, req.query.prospective_user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label =
              "get_user_by_prospective_user_id_excluding_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data.qb_employee_id;
                delete data.qb_employee_name;
            }

            if (data) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_by_prospective_user_id_excluding_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for user by prospective_user_id
const get_user_by_ecdb_user_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.ecdb_user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "ecdb_user_id can not be null or empty";
      returnMessage.label = "get_user_by_ecdb_user_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_ecdb_user_id($1,$2)`,
        [req.user.org_id, req.query.ecdb_user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user details";
            returnMessage.error = error;
            returnMessage.label = "get_user_by_ecdb_user_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            
            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data.qb_employee_id;
                delete data.qb_employee_name;
            }

            if (data) {

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_by_ecdb_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for project by ecdb_user_id excluding id
const get_user_by_ecdb_user_id_excluding_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_user_by_ecdb_user_id_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.ecdb_user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "ecdb_user_id can not be null or empty";
      returnMessage.label = "get_user_by_ecdb_user_id_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_ecdb_user_id_excluding_id($1,$2,$3)`,
        [req.user.org_id, req.query.id, req.query.ecdb_user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_user_by_ecdb_user_id_excluding_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            
            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data.qb_employee_id;
                delete data.qb_employee_name;
            }

            if (data) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_by_ecdb_user_id_excluding_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api for users
const insertuser = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createuserValidator({ ...req.body, org_id });

    let email_exists = false;
    let ecdb_user_exists = false;
    let prospective_user_exists = false;
    let adp_associate_exists = false;

    let {
      employee_type = null,
      role_id,
      prefix = null,
      first_name,
      middle_name,
      last_name,
      full_name,
      email,
      gender,
      adp_associate_id = null,
      phone_number,
      branch_id = null,
      branch_name = null,
      department_id = null,
      department_name = null,
      employee_id = null,
      ecdb_user_id = null,
      prospective_user_id = null,
      joining_date = null,
      leaving_date = null,
      qb_employee_name = "",
      qb_employee_id = null,
      user_status,
      work_location,
      work_country,
      work_state,
      work_city,
      work_street_address,
      permanent_address,
      work_address,
      zipcode,
      email_notifications = true,
      push_notifications = true,
      visa_status = null,
      adp_validated = false
    } = req.body;

    full_name = `${first_name} ${last_name}`.trim();
    let record_type_status =
      user_status.toLowerCase() == "active" ? "Active" : "Inactive";

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_user_by_email($1, $2)`,
        [org_id, email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_user_by_email &&
          email_exists.rows[0].get_user_by_email[0]) ||
        null;
    }

    // check if ecdb_user_id already exists
    if (ecdb_user_id) {
      ecdb_user_exists = await con.query(
        `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
        [org_id, ecdb_user_id]
      );
      ecdb_user_exists =
        (ecdb_user_exists &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id[0]) ||
        null;
    }

    // check if prospective_user_id already exists
    if (prospective_user_id) {
      prospective_user_exists = await con.query(
        `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
        [org_id, prospective_user_id]
      );
      prospective_user_exists =
        (prospective_user_exists &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id &&
          prospective_user_exists.rows[0]
            .get_user_by_prospective_user_id[0]) ||
        null;
    }

    // check if adp associate id already exists
    if(adp_associate_id) {
      adp_associate_exists = await con.query(`SELECT timesheets.get_user_by_adp_associate_id($1,$2 )`,
      [org_id,adp_associate_id]
      );
      adp_associate_exists =
        (adp_associate_exists &&
        adp_associate_exists.rows[0].get_user_by_adp_associate_id && 
        adp_associate_exists.rows[0].get_user_by_adp_associate_id[0]) || null;
    }

    if (email_exists && email_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "email already exists" };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (ecdb_user_exists && ecdb_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "ecdb_user_id already exists";
      returnMessage.error = { ecdb_user_id: "ecdb_user_id already exists" };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (prospective_user_exists && prospective_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "prospective_user_id already exists";
      returnMessage.error = { prospective_user_id: "prospective_user_id already exists" };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if(adp_associate_exists && adp_associate_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "adp_associate_id already exists";
      returnMessage.error = {
        adp_associate_id: "adp_associate_id already exists",
      };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.insert_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
        [
          org_id,
          employee_type,
          role_id,
          prefix,
          first_name,
          middle_name,
          last_name,
          full_name,
          email,
          gender,
          adp_associate_id,
          phone_number,
          branch_id,
          branch_name,
          department_id,
          department_name,
          work_country, // country_name
          work_state, // state_name
          employee_id,
          ecdb_user_id,
          prospective_user_id,
          joining_date,
          leaving_date,
          qb_employee_name,
          qb_employee_id,
          user_status,
          work_location,
          work_country,
          work_state,
          work_city,
          work_street_address,
          "", // work_status
          permanent_address,
          work_address,
          zipcode,
          email_notifications,
          push_notifications,
          req.user.id,
          record_type_status,
          visa_status,
          adp_validated
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insertuser";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            // don't pass qb details in API response
            let data = (results && results.rows && results.rows[1] && results.rows[1].insert_users) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data[0].qb_employee_id;
                delete data[0].qb_employee_name;
            }
            returnMessage.isError = false;
            returnMessage.response = results.rows[0].insert_users;
            returnMessage.data = data;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insertuser";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for users
const edituser = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createuserValidator({ ...req.body, org_id });

    let email_exists = false;
    let ecdb_user_exists = false;
    let prospective_user_exists = false;
    let adp_associate_exists = false;

    let {
      id = null,
      employee_type = null,
      role_id,
      prefix = null,
      first_name = null,
      middle_name = null,
      last_name,
      full_name,
      email,
      gender,
      adp_associate_id = null,
      phone_number,
      branch_id = null,
      branch_name = null,
      department_id = null,
      department_name = null,
      employee_id = null,
      ecdb_user_id = null,
      prospective_user_id = null,
      joining_date = null,
      leaving_date = null,
      qb_employee_name = "",
      qb_employee_id = null,
      user_status,
      work_location,
      work_country,
      work_state,
      work_city,
      work_street_address,
      permanent_address,
      work_address,
      zipcode,
      email_notifications = true,
      push_notifications = true,
      visa_status = null,
      adp_validated = false,
    } = req.body;

    full_name = `${first_name} ${last_name}`.trim();
    let record_type_status =
      user_status.toLowerCase() == "active" ? "Active" : "Inactive";

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edituser validation";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_user_by_email($1, $2)`,
        [org_id, email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_user_by_email &&
          email_exists.rows[0].get_user_by_email[0]) ||
        null;
    }

    // check if ecdb_user_id already exists
    if (ecdb_user_id) {
      ecdb_user_exists = await con.query(
        `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
        [org_id, ecdb_user_id]
      );
      ecdb_user_exists =
        (ecdb_user_exists &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id[0]) ||
        null;
    }

    // check if prospective_user_id already exists
    if (prospective_user_id) {
      prospective_user_exists = await con.query(
        `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
        [org_id, prospective_user_id]
      );
      prospective_user_exists =
        (prospective_user_exists &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id &&
          prospective_user_exists.rows[0]
            .get_user_by_prospective_user_id[0]) ||
        null;
    }

    // check if adp associate id already exists
    if(adp_associate_id) {
      adp_associate_exists = await con.query(`SELECT timesheets.get_user_by_adp_associate_id_excluding_id($1,$2, $3)`,
      [org_id, id, adp_associate_id]
      );
      adp_associate_exists =
        (adp_associate_exists &&
        adp_associate_exists.rows[0].get_user_by_adp_associate_id_excluding_id && 
        adp_associate_exists.rows[0].get_user_by_adp_associate_id_excluding_id[0]) || null;
    }

    if (email_exists && email_exists.id && email_exists.id != id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "email already exists" };
      returnMessage.label = "edituser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (
      ecdb_user_exists &&
      ecdb_user_exists.id &&
      ecdb_user_exists.id != id
    ) {
      returnMessage.isError = true;
      returnMessage.message = "ecdb_user_id already exists";
      returnMessage.error = { ecdb_user_id: "ecdb_user_id already exists" };
      returnMessage.label = "edituser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (
      prospective_user_exists &&
      prospective_user_exists.id &&
      prospective_user_exists.id != id
    ) {
      returnMessage.isError = true;
      returnMessage.message = "prospective_user_id already exists";
      returnMessage.error = { prospective_user_id: "prospective_user_id already exists" };
      returnMessage.label = "edituser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if(
      adp_associate_exists && 
      adp_associate_exists.id && 
      adp_associate_id.id != id
      ) {
      returnMessage.isError = true;
      returnMessage.message = "adp_associate_id already exists";
      returnMessage.error = {
        adp_associate_id: "adp_associate_id already exists",
      };
      returnMessage.label = "edituser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.update_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42)`,
        [
          id,
          org_id,
          employee_type,
          role_id,
          prefix,
          first_name,
          middle_name,
          last_name,
          full_name,
          email,
          gender,
          adp_associate_id,
          phone_number,
          branch_id,
          branch_name,
          department_id,
          department_name,
          work_country, // country_name
          work_state, // state_name
          employee_id,
          ecdb_user_id,
          prospective_user_id,
          joining_date,
          leaving_date,
          qb_employee_name,
          qb_employee_id,
          user_status,
          work_location,
          work_country,
          work_state,
          work_city,
          work_street_address,
          "", // work_status
          permanent_address,
          work_address,
          zipcode,
          email_notifications,
          push_notifications,
          req.user.id,
          record_type_status,
          visa_status,
          adp_validated
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "edituser";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            // don't pass qb details in API response
            let data = (results && results.rows && results.rows[1] && results.rows[1].update_users) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data[0].qb_employee_id;
                delete data[0].qb_employee_name;
            }

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "edituser";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for search users
const searchusers = async (req, res) => {
  const returnMessage = getMsgFormat();

  if (req.query.first_name == undefined || req.query.first_name == "") {
    req.query.first_name = null;
  }
  if (req.query.middle_name == undefined || req.query.middle_name == "") {
    req.query.middle_name = null;
  }
  if (req.query.last_name == undefined || req.query.last_name == "") {
    req.query.last_name = null;
  }
  if (req.query.full_name == undefined || req.query.full_name == "") {
    req.query.full_name = null;
  }
  if (req.query.email == undefined || req.query.email == "") {
    req.query.email = null;
  }
  if (req.query.user_status == undefined || req.query.user_status == "") {
    req.query.user_status = null;
  }
  if (req.query.employee_id == undefined || req.query.employee_id == "") {
    req.query.employee_id = null;
  }

  try {
    var output = [];
    await con.query(
      `SELECT * from timesheets.search_users($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        req.query.first_name,
        req.query.middle_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.user_status,
        req.query.employee_id,
        req.user.org_id,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to search user details";
          returnMessage.error = error;
          returnMessage.label = "searchusers";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {

          // don't pass qb details in API response
          let data = (results && results.rows && results.rows[0] && results.rows[0].j) || null;

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
            for (var i = 0; i < data.length; i++) {
              delete data[i].qb_employee_id;
              delete data[i].qb_employee_name;
            }
          }

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count =
            (results.rows && results.rows[1] && results.rows[1].j) || null;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "searchusers";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for filter users
// const filterusers = async (req, res) => {
//   const returnMessage = getMsgFormat();
//   if (req.query.first_name == undefined || req.query.first_name == "") {
//     req.query.first_name = null;
//   }
//   if (req.query.middle_name == undefined || req.query.middle_name == "") {
//     req.query.middle_name = null;
//   }
//   if (req.query.last_name == undefined || req.query.last_name == "") {
//     req.query.last_name = null;
//   }
//   if (req.query.full_name == undefined || req.query.full_name == "") {
//     req.query.full_name = null;
//   }
//   if (req.query.email == undefined || req.query.email == "") {
//     req.query.email = null;
//   }
//   if (req.query.user_status == undefined || req.query.user_status == "") {
//     req.query.user_status = null;
//   }
//   if (req.query.employee_id == undefined || req.query.employee_id == "") {
//     req.query.employee_id = null;
//   }
//   if (
//     req.query.department_name == undefined ||
//     req.query.department_name == ""
//   ) {
//     req.query.department_name = null;
//   }
//   if (req.query.employee_type == undefined || req.query.employee_type == "") {
//     req.query.employee_type = null;
//   }
//   if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
//     req.query.record_type_status = null;
//   }
//   try {
//     await con.query(
//       `SELECT * from timesheets.get_users_filter($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
//       [
//         req.query.first_name,
//         req.query.middle_name,
//         req.query.last_name,
//         req.query.full_name,
//         req.query.email,
//         req.query.user_status,
//         req.query.employee_id,
//         req.query.department_name,
//         req.user.org_id,
//         req.query.employee_type,
//         req.query.record_type_status,
//         req.query.pagenumber,
//         req.query.pagesize,
//       ],
//       (error, results) => {
//         if (error) {
//           returnMessage.isError = true;
//           returnMessage.message = "Failed to filter user details";
//           returnMessage.error = error;
//           returnMessage.label = "filterusers";
//           logger.log({
//             level: "error",
//             message: returnMessage,
//           });
//           res.status(400).json(returnMessage);
//         } else if (isEmpty(results.rows[0].j)) {
//           returnMessage.message = "No Records Found";
//           res.status(200).json(returnMessage);
//         } else {

              // let data = (results && results.rows && results.rows[0] && results.rows[0].j) || null;
              // if((data && data.length) && (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
              //   for (var i = 0; i < data.length; i++) {
              //     delete data[i].qb_employee_id;
              //     delete data[i].qb_employee_name;
              //   }
              // }
              
//           returnMessage.isError = false;
//           returnMessage.message = "Records Found";
//           returnMessage.data = data;
//           returnMessage.count =
//             (results.rows && results.rows[1] && results.rows[1].j) || null;
//           res.status(200).json(returnMessage);
//         }
//       }
//     );
//   } catch (error) {
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.label = "filterusers";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
// };

// GET api for employees List
const getallemployees = async (req, res) => {
  const returnMessage = getMsgFormat();

   if (req.query.keyword == undefined || req.query.keyword == "") {
     req.query.keyword = null;
   }
   if (req.query.first_name == undefined || req.query.first_name == "") {
     req.query.first_name = null;
   }
   if (req.query.middle_name == undefined || req.query.middle_name == "") {
     req.query.middle_name = null;
   }
   if (req.query.last_name == undefined || req.query.last_name == "") {
     req.query.last_name = null;
   }
   if (req.query.full_name == undefined || req.query.full_name == "") {
     req.query.full_name = null;
   }
   if (req.query.email == undefined || req.query.email == "") {
     req.query.email = null;
   }
   if (req.query.user_status == undefined || req.query.user_status == "") {
     req.query.user_status = null;
   }
   if (req.query.employee_id == undefined || req.query.employee_id == "") {
     req.query.employee_id = null;
   }
   if (
     req.query.department_name == undefined ||
     req.query.department_name == ""
   ) {
     req.query.department_name = null;
   }
   if (req.query.employee_type == undefined || req.query.employee_type == "") {
     req.query.employee_type = null;
   }
   if (
     req.query.record_type_status == undefined ||
     req.query.record_type_status == ""
   ) {
     req.query.record_type_status = null;
   }
  try {
    await con.query(
      `SELECT * from timesheets.get_all_employees($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15);`,
      [
        req.query.keyword,
        req.query.first_name,
        req.query.middle_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.user_status,
        req.query.employee_id,
        req.query.timetracker_employee_id,
        req.query.department_name,
        req.user.org_id,
        req.query.employee_type,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch employees details";
          returnMessage.error = error;
          returnMessage.label = "getallemployees";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          //  don't pass qb details in API response
          let data = (results && results.rows && results.rows[1] && results.rows[1].j) || null;
          if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))) ){

            for (var i = 0; i < data.length; i++) {
              delete data[i].qb_employee_id;
              delete data[i].qb_employee_name;
            }

          }

          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getallemployees";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api to search employees
const searchemployees = async (req, res) => {
  const returnMessage = getMsgFormat();

  if (req.query.first_name == undefined || req.query.first_name == "") {
    req.query.first_name = null;
  }
  if (req.query.middle_name == undefined || req.query.middle_name == "") {
    req.query.middle_name = null;
  }
  if (req.query.last_name == undefined || req.query.last_name == "") {
    req.query.last_name = null;
  }
  if (req.query.full_name == undefined || req.query.full_name == "") {
    req.query.full_name = null;
  }
  if (req.query.email == undefined || req.query.email == "") {
    req.query.email = null;
  }
  if (req.query.user_status == undefined || req.query.user_status == "") {
    req.query.user_status = null;
  }
  if (req.query.employee_id == undefined || req.query.employee_id == "") {
    req.query.employee_id = null;
  }

  try {
    var output = [];
    await con.query(
      `SELECT * from timesheets.search_employees($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        req.query.first_name,
        req.query.middle_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.user_status,
        req.query.employee_id,
        req.user.org_id,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to search user details";
          returnMessage.error = error;
          returnMessage.label = "searchemployees";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {

          let is_qb_enabled = await isQBEnabled(req.user.org_id);

          // don't pass qb details in API response
          let data = (results && results.rows && results.rows[0] && results.rows[0].j) || null;
          if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
            for (var i = 0; i < data.length; i++) {
              delete data[i].qb_employee_id;
              delete data[i].qb_employee_name;
            }
          }
          
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = data;
          returnMessage.count =
            (results.rows && results.rows[1] && results.rows[1].j) || null;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "searchemployees";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for filter employees
// const filteremployees = async (req, res) => {
//   const returnMessage = getMsgFormat();
//   if (req.query.first_name == undefined || req.query.first_name == "") {
//     req.query.first_name = null;
//   }
//   if (req.query.middle_name == undefined || req.query.middle_name == "") {
//     req.query.middle_name = null;
//   }
//   if (req.query.last_name == undefined || req.query.last_name == "") {
//     req.query.last_name = null;
//   }
//   if (req.query.full_name == undefined || req.query.full_name == "") {
//     req.query.full_name = null;
//   }
//   if (req.query.email == undefined || req.query.email == "") {
//     req.query.email = null;
//   }
//   if (req.query.user_status == undefined || req.query.user_status == "") {
//     req.query.user_status = null;
//   }
//   if (req.query.employee_id == undefined || req.query.employee_id == "") {
//     req.query.employee_id = null;
//   }
//   if (
//     req.query.department_name == undefined ||
//     req.query.department_name == ""
//   ) {
//     req.query.department_name = null;
//   }
//   if (req.query.employee_type == undefined || req.query.employee_type == "") {
//     req.query.employee_type = null;
//   }
//   if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
//     req.query.record_type_status = null;
//   }

//   try {
//     await con.query(
//       `SELECT * from timesheets.get_employees_filter($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
//       [
//         req.query.first_name,
//         req.query.middle_name,
//         req.query.last_name,
//         req.query.full_name,
//         req.query.email,
//         req.query.user_status,
//         req.query.employee_id,
//         req.query.department_name,
//         req.user.org_id,
//         req.query.employee_type,
//         req.query.record_type_status,
//         req.query.pagenumber,
//         req.query.pagesize,
//       ],
//       (error, results) => {
//         if (error) {
//           returnMessage.isError = true;
//           returnMessage.message = "Failed to filter employee details";
//           returnMessage.error = error;
//           returnMessage.label = "filteremployees";
//           logger.log({
//             level: "error",
//             message: returnMessage,
//           });
//           res.status(400).json(returnMessage);
//         } else if (isEmpty(results.rows[0].j)) {
//           returnMessage.message = "No Records Found";
//           res.status(200).json(returnMessage);
//         } else {
  
            // don't pass qb details in API response
            // let data = (results && results.rows && results.rows[0] && results.rows[0].j) || null;
            // if((data && data.length) && (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
            //   for (var i = 0; i < data.length; i++) {
            //     delete data[i].qb_employee_id;
            //     delete data[i].qb_employee_name;
            //   }
            // }
//           returnMessage.isError = false;
//           returnMessage.message = "Records Found";
//           returnMessage.data = data;
//           returnMessage.count =
//             (results.rows && results.rows[1] && results.rows[1].j) || null;
//           res.status(200).json(returnMessage);
//         }
//       }
//     );
//   } catch (error) {
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.label = "filteremployees";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
// };

// INSERT api for employee
const insertemployee = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createuserValidator({ ...req.body, org_id });

    let email_exists = false;
    let ecdb_user_exists = false;
    let prospective_user_exists = false;
    let adp_associate_exists = false;

    let {
      employee_type = null,
      prefix = null,
      first_name,
      middle_name,
      last_name,
      full_name,
      email,
      gender,
      adp_associate_id = null,
      phone_number,
      branch_id = null,
      branch_name = null,
      department_id = null,
      department_name = null,
      employee_id = null,
      ecdb_user_id = null,
      prospective_user_id = null,
      joining_date = null,
      leaving_date = null,
      qb_employee_name = "",
      qb_employee_id = null,
      user_status,
      work_location,
      work_country,
      work_state,
      work_city,
      work_street_address,
      permanent_address,
      work_address,
      zipcode,
      email_notifications = true,
      push_notifications = true,
      visa_status = null,
      adp_validated = false
    } = req.body;

    full_name = `${first_name} ${last_name}`.trim();
    let record_type_status =
      user_status.toLowerCase() == "active" ? "Active" : "Inactive";

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "insertemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_user_by_email($1, $2)`,
        [org_id, email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_user_by_email &&
          email_exists.rows[0].get_user_by_email[0]) ||
        null;
    }

    // check if ecdb_user_id already exists
    if (ecdb_user_id) {
      ecdb_user_exists = await con.query(
        `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
        [org_id, ecdb_user_id]
      );
      ecdb_user_exists =
        (ecdb_user_exists &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id[0]) ||
        null;
    }

    // check if prospective_user_id already exists
    if (prospective_user_id) {
      prospective_user_exists = await con.query(
        `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
        [org_id, prospective_user_id]
      );
      prospective_user_exists =
        (prospective_user_exists &&
          prospective_user_exists.rows[0].get_user_by_prospective_user_id &&
          prospective_user_exists.rows[0]
            .get_user_by_prospective_user_id[0]) ||
        null;
    }

    // check if adp associate id already exists
    if (adp_associate_id) {
      adp_associate_exists = await con.query(
        `SELECT timesheets.get_user_by_adp_associate_id($1,$2 )`,
        [org_id, adp_associate_id]
      );
      adp_associate_exists =
        (adp_associate_exists &&
          adp_associate_exists.rows[0].get_user_by_adp_associate_id &&
          adp_associate_exists.rows[0].get_user_by_adp_associate_id[0]) ||
        null;
    } 

    if (email_exists && email_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "email already exists" };
      returnMessage.label = "insertemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (ecdb_user_exists && ecdb_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "ecdb_user_id already exists";
      returnMessage.error = { ecdb_user_id: "ecdb_user_id already exists" };
      returnMessage.label = "insertemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (prospective_user_exists && prospective_user_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "prospective_user_id already exists";
      returnMessage.error = { prospective_user_id: "prospective_user_id already exists" };
      returnMessage.label = "insertemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (adp_associate_exists && adp_associate_exists.id) {
      returnMessage.isError = true;
      returnMessage.message = "adp_associate_id already exists";
      returnMessage.error = {
        adp_associate_id: "adp_associate_id already exists",
      };
      returnMessage.label = "insertuser";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.insert_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
        [
          org_id,
          employee_type,
          ROLES.EMPLOYEE,
          prefix,
          first_name,
          middle_name,
          last_name,
          full_name,
          email,
          gender,
          adp_associate_id,
          phone_number,
          branch_id,
          branch_name,
          department_id,
          department_name,
          work_country, // country_name
          work_state, // state_name
          employee_id,
          ecdb_user_id,
          prospective_user_id,
          joining_date,
          leaving_date,
          qb_employee_name,
          qb_employee_id,
          user_status,
          work_location,
          work_country,
          work_state,
          work_city,
          work_street_address,
          "", // work_status
          permanent_address,
          work_address,
          zipcode,
          email_notifications,
          push_notifications,
          req.user.id,
          record_type_status,
          visa_status,
          adp_validated
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "insertemployee";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            // don't pass qb details in API response
            let data = (results && results.rows && results.rows[1] && results.rows[1].insert_users) || null;
            if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data[0].qb_employee_id;
                delete data[0].qb_employee_name;
            }

            returnMessage.isError = false;
            returnMessage.response = results.rows[0].insert_users;
            returnMessage.data = data;
            returnMessage.message = "Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "insertemployee";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for users
const editemployee = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createuserValidator({ ...req.body, org_id });

    let email_exists = false;
    let ecdb_user_exists = false;
    let prospective_user_exists = false;
    let adp_associate_exists = false;

    let {
      id = null,
      employee_type = null,
      prefix = null,
      first_name,
      middle_name,
      last_name,
      full_name,
      email,
      gender,
      adp_associate_id = null,
      phone_number,
      branch_id = null,
      branch_name = null,
      department_id = null,
      department_name = null,
      employee_id = null,
      ecdb_user_id = null,
      prospective_user_id = null,
      joining_date = null,
      leaving_date = null,
      qb_employee_name = "",
      qb_employee_id = null,
      user_status,
      work_location,
      work_country,
      work_state,
      work_city,
      work_street_address,
      permanent_address,
      work_address,
      zipcode,
      email_notifications = true,
      push_notifications = true,
      visa_status = null,
      adp_validated = false
    } = req.body;

    full_name = `${first_name} ${last_name}`.trim();
    let record_type_status =
      user_status.toLowerCase() == "active" ? "Active" : "Inactive";

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edituser validation";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    // check if email already exists
    if (email) {
      email_exists = await con.query(
        `SELECT timesheets.get_user_by_email_excluding_id($1,$2,$3)`,
        [id, org_id, email]
      );
      email_exists =
        (email_exists &&
          email_exists.rows[0].get_user_by_email_excluding_id &&
          email_exists.rows[0].get_user_by_email_excluding_id[0]) ||
        null;
    }

    // check if ecdb_user_id already exists
    if (ecdb_user_id) {
      ecdb_user_exists = await con.query(
        `SELECT timesheets.get_user_by_ecdb_user_id_excluding_id($1,$2,$3)`,
        [org_id, id, ecdb_user_id]
      );
      ecdb_user_exists =
        (ecdb_user_exists &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id_excluding_id &&
          ecdb_user_exists.rows[0].get_user_by_ecdb_user_id_excluding_id[0]) ||
        null;
    }

    // check if prospective_user_id already exists
    if (prospective_user_id) {
      prospective_user_exists = await con.query(
        `SELECT timesheets.get_user_by_prospective_user_id_excluding_id($1, $2, $3)`,
        [org_id, id, prospective_user_id]
      );
      prospective_user_exists =
        (prospective_user_exists &&
          prospective_user_exists.rows[0]
            .get_user_by_prospective_user_id_excluding_id &&
          prospective_user_exists.rows[0]
            .get_user_by_prospective_user_id_excluding_id[0]) ||
        null;
    }

    // check if adp associate id already exists
    if(adp_associate_id) {
      adp_associate_exists = await con.query(`SELECT timesheets.get_user_by_adp_associate_id_excluding_id($1,$2,$3)`,
      [org_id, id, adp_associate_id]
      );
      adp_associate_exists =
        (adp_associate_exists &&
        adp_associate_exists.rows[0].get_user_by_adp_associate_id_excluding_id && 
        adp_associate_exists.rows[0].get_user_by_adp_associate_id_excluding_id[0]) || null;
    }

    if (email_exists && email_exists.id && email_exists.id != id) {
      returnMessage.isError = true;
      returnMessage.message = "email already exists";
      returnMessage.error = { email: "email already exists" };
      returnMessage.label = "editemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (
      ecdb_user_exists &&
      ecdb_user_exists.id &&
      ecdb_user_exists.id != id
    ) {
      returnMessage.isError = true;
      returnMessage.message = "ecdb_user_id already exists";
      returnMessage.error = { ecdb_user_id: "ecdb_user_id already exists" };
      returnMessage.label = "editemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else if (
      prospective_user_exists &&
      prospective_user_exists.id &&
      prospective_user_exists.id != id
    ) {
      returnMessage.isError = true;
      returnMessage.message = "prospective_user_id already exists";
      returnMessage.error = { prospective_user_id: "prospective_user_id already exists" };
      returnMessage.label = "editemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }else if(
      adp_associate_exists && 
      adp_associate_exists.id && 
      adp_associate_id.id != id
      ) {
      returnMessage.isError = true;
      returnMessage.message = "adp_associate_id already exists";
      returnMessage.error = {
        adp_associate_id: "adp_associate_id already exists",
      };
      returnMessage.label = "editemployee";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT timesheets.update_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42)`,
        [
          id,
          org_id,
          employee_type,
          ROLES.EMPLOYEE,
          prefix,
          first_name,
          middle_name,
          last_name,
          full_name,
          email,
          gender,
          adp_associate_id,
          phone_number,
          branch_id,
          branch_name,
          department_id,
          department_name,
          work_country, // country_name
          work_state, // state_name
          employee_id,
          ecdb_user_id,
          prospective_user_id,
          joining_date,
          leaving_date,
          qb_employee_name,
          qb_employee_id,
          user_status,
          work_location,
          work_country,
          work_state,
          work_city,
          work_street_address,
          "", // work_status
          permanent_address,
          work_address,
          zipcode,
          email_notifications,
          push_notifications,
          req.user.id,
          record_type_status,
          visa_status,
          adp_validated
        ],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "editemployee";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            // don't pass qb details in API response
            let data = (results && results.rows && results.rows[1] && results.rows[1].update_users) || null;
            if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data[0].qb_employee_id;
                delete data[0].qb_employee_name;
            }

            ////// Send Email to employee
            let consultant_data = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,[id, org_id]);
            consultant_data = (consultant_data && consultant_data.rows && consultant_data.rows[0] && consultant_data.rows[0].j && consultant_data.rows[0].j[0]) || null;

            let employee_name = (consultant_data && consultant_data.full_name) || null;
            let employee_email = (consultant_data && consultant_data.email) || null;
            // employee_email = "masood.m@msr-it.com";
            // employee_email = "sonu.hussain@msr-it.com";

            if (employee_email) {
              let emailData = {
                org_id: org_id,
                employee_name: employee_name,
                employee_email: employee_email,
              };

              let user_id= consultant_data.id;
              let is_email_reminder = await isEmailReminderOn(org_id, user_id);

              if(is_email_reminder){
                await EmployeeUpdatedEmailToEmployee(emailData);
              }
            }
            ////////////////////////////////////

            returnMessage.isError = false;
            returnMessage.data = data;
            returnMessage.message = "Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "editemployee";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for employees List
const get_employees_list = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_employees_list($1);`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch employees list";
          returnMessage.error = error;
          returnMessage.label = "get_employees_list";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employees_list";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for getuserbyemail
const getuserbyemail = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.email) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "Email can not be null or empty";
      returnMessage.label = "getuserbyemail";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_email($1,$2);`,
        [req.user.org_id, req.query.email],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user by email";
            returnMessage.error = error;
            returnMessage.label = "getuserbyemail";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {

            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data.qb_employee_id;
                delete data.qb_employee_name;
            }

            returnMessage.isError = false;
            returnMessage.message = "Email Already Exists";
            returnMessage.data = data;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getuserbyemail";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for getuserbyemailexcludingid
const getuserbyemailexcludingid = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "getuserbyemailexcludingid";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else if (!req.query.email) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "Email can not be null or empty";
      returnMessage.label = "getuserbyemailexcludingid";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_email_excluding_id($1,$2,$3)`,
        [req.query.id, req.user.org_id, req.query.email],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user details";
            returnMessage.error = error;
            returnMessage.label = "getuserbyemailexcludingid";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {

            let data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) || null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);
            if((data) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                delete data.qb_employee_id;
                delete data.qb_employee_name;
            }

            returnMessage.isError = false;
            returnMessage.message = "Email Already Exists";
            returnMessage.data =  data;
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getuserbyemailexcludingid";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_new_employee_id
const get_new_employee_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_new_employee_id($1)`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch user details";
          returnMessage.error = error;
          returnMessage.label = "get_new_employee_id";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].get_new_employee_id)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data =
            (results.rows &&
              results.rows[0] &&
              results.rows[0].get_new_employee_id &&
              results.rows[0].get_new_employee_id[0]) ||
            null;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_new_employee_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for all export users
  const export_all_users = async (req, res) => {
  const returnMessage = getMsgFormat();
  let org_id = req.user.org_id;

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.first_name == undefined || req.query.first_name == "") {
    req.query.first_name = null;
  }
  if (req.query.middle_name == undefined || req.query.middle_name == "") {
    req.query.middle_name = null;
  }
  if (req.query.last_name == undefined || req.query.last_name == "") {
    req.query.last_name = null;
  }
  if (req.query.full_name == undefined || req.query.full_name == "") {
    req.query.full_name = null;
  }
  if (req.query.email == undefined || req.query.email == "") {
    req.query.email = null;
  }
  if (req.query.user_status == undefined || req.query.user_status == "") {
    req.query.user_status = null;
  }
  if (req.query.employee_id == undefined || req.query.employee_id == "") {
    req.query.employee_id = null;
  }
  if (
    req.query.department_name == undefined ||
    req.query.department_name == ""
  ) {
    req.query.department_name = null;
  }
  if (req.query.employee_type == undefined || req.query.employee_type == "") {
    req.query.employee_type = null;
  }
  if (
    req.query.record_type_status == undefined ||
    req.query.record_type_status == ""
  ) {
    req.query.record_type_status = null;
  }
  try {
    await con.query(
      `SELECT * from timesheets.export_all_users($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13);`,
      [
        req.query.keyword,
        req.query.first_name,
        req.query.middle_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.user_status,
        req.query.employee_id,
        req.query.timetracker_employee_id,
        req.query.department_name,
        org_id,
        req.query.employee_type,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_users";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results = (results.rows && results.rows[0] && results.rows[0].j) || null;

            

          if (results && results.length) {

            // don't pass qb details in API response
            for (var i = 0; i < results.length; i++) {
              delete results[i].qb_employee_id;
              delete results[i].qb_employee_name;
            }

            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportUsersData");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "USER ID", key: "employee_id", width: 10 },
              { header: "TIMETRACKER USER ID", key: "timetracker_employee_id", width: 10, },
              { header: "FULL NAME", key: "full_name", width: 10 },
              { header: "EMAIL", key: "email", width: 10 },
              { header: "ROLE", key: "role_name", width: 10 },
              { header: "DEPARTMENT", key: "department_name", width: 10 },
              { header: "STATUS", key: "record_type_status", width: 10 },
            ];
            for (i = 0; i < results.length; i++) {
              row = results[i];

              let full_name = row.full_name ? titleCase(row.full_name) :'' ;
              let record_type_status = row.record_type_status;
              record_type_status = record_type_status.replace("Inactive", "In Active"); 

               let tmpRow = [
                  row.employee_id,
                  row.timetracker_employee_id,
                  full_name,
                  row.email,
                  row.role_name,
                  row.department_name,
                  record_type_status
                ];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/exports/users"
            );
            let fileName = `users-list-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/exports/users/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {

                let orgData = await getOrgData(org_id);
                let newFileName = `users-list-${((orgData && orgData.org_name) || ``)}.xlsx`;
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/exports/users/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);

              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_all_users";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_all_employees
const export_all_employees = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;

  if (req.query.keyword == undefined || req.query.keyword == "") {
    req.query.keyword = null;
  }
  if (req.query.first_name == undefined || req.query.first_name == "") {
    req.query.first_name = null;
  }
  if (req.query.middle_name == undefined || req.query.middle_name == "") {
    req.query.middle_name = null;
  }
  if (req.query.last_name == undefined || req.query.last_name == "") {
    req.query.last_name = null;
  }
  if (req.query.full_name == undefined || req.query.full_name == "") {
    req.query.full_name = null;
  }
  if (req.query.email == undefined || req.query.email == "") {
    req.query.email = null;
  }
  if (req.query.user_status == undefined || req.query.user_status == "") {
    req.query.user_status = null;
  }
  if (req.query.employee_id == undefined || req.query.employee_id == "") {
    req.query.employee_id = null;
  }
  if (
    req.query.department_name == undefined ||
    req.query.department_name == ""
  ) {
    req.query.department_name = null;
  }
  if (req.query.employee_type == undefined || req.query.employee_type == "") {
    req.query.employee_type = null;
  }
  if (
    req.query.record_type_status == undefined ||
    req.query.record_type_status == ""
  ) {
    req.query.record_type_status = null;
  }
  try {
    await con.query(
      `SELECT * from timesheets.export_all_employees($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13);`,
      [
        req.query.keyword,
        req.query.first_name,
        req.query.middle_name,
        req.query.last_name,
        req.query.full_name,
        req.query.email,
        req.query.user_status,
        req.query.employee_id,
        req.query.timetracker_employee_id,
        req.query.department_name,
        org_id,
        req.query.employee_type,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_employees";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            let is_qb_transaction_on = await isQBTransactionOn(org_id,'getemployeedatabyname');
            
            let is_adp_enabled = await isAdpEnabled(org_id);
            if(!is_adp_enabled){
              for (var i = 0; i < results.length; i++) {
                delete results[i].is_adp_enabled;
              }
            }

            // don't pass qb details in API response
            if(!is_qb_enabled || !is_qb_transaction_on || ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
              for (var i = 0; i < results.length; i++) {
                delete results[i].qb_employee_id;
                delete results[i].qb_employee_name;
              }
            }
            
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportEmployeesData");

             		 	 	 	 	
            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "CONSULTANT ID", key: "employee_id", width: 10 },
              { header: "TIMETRACKER EMPLOYEE ID", key: "timetracker_employee_id", width: 10 },
            ];

            if(is_qb_enabled && is_qb_transaction_on && [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)){
              worksheet.columns = [
                ...worksheet.columns,
                { header: "QB CONSULTANT ID", key: "qb_employee_id", width: 10 },
              ];
            }

            if(is_adp_enabled ){
              worksheet.columns = [
                ...worksheet.columns,
                { header: "ADP ASSOCIATE ID", key: "adp_associate_id", width: 10, },
              ];
            }

            worksheet.columns = [
              ...worksheet.columns,
              { header: "CONSULTANT TYPE", key: "employee_type", width: 10 },
              { header: "CONSULTANT NAME", key: "full_name", width: 10 },
              { header: "PHONE NUMBER", key: "phone_number", width: 10 },
              { header: "EMAIL", key: "email", width: 10 },
              { header: "STATUS", key: "record_type_status", width: 10 },
            ];
            
            for (i = 0; i < results.length; i++) {
              row = results[i];

                 let full_name = row.full_name ? titleCase(row.full_name) :'' ;
                 let record_type_status = row.record_type_status;
              record_type_status = record_type_status.replace("Inactive", "In Active"); 

              let tmpRow = [row.employee_id, row.timetracker_employee_id];
              if (is_qb_enabled && is_qb_transaction_on && 
                [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                )
              ) {
                tmpRow = [
                  ...tmpRow,
                row.qb_employee_id,
                ];
              }
              if (is_adp_enabled) {
                tmpRow = [
                  ...tmpRow,
                row.adp_associate_id,
                ];
              }
              tmpRow = [
                ...tmpRow,
                row.employee_type,
                full_name,
                row.phone_number,
                row.email,
                record_type_status,
              ];
              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/exports/employees"
            );
            let fileName = `employees-list-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/exports/employees/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {

                let orgData = await getOrgData(org_id);
                let newFileName = `employees-list-${((orgData && orgData.org_name) || ``)}.xlsx`;
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/exports/employees/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);

              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_all_employees";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for user by get_adpworkerid_details
const get_adpworkerid_details = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.workerid) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "workerid can not be null or empty";
      returnMessage.label = "get_adpworkerid_details";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {

      var response = await axios.get(`${process.env.PLACEMENT_API_URL}placements/incentives/adpworkerid?workerid=${req.query.workerid}`);
      response = (response && response.data) || null;

      if(response && response.data){
        returnMessage.isError = false;
        returnMessage.message = "Records Found";
        returnMessage.data = response.data;
        returnMessage.placement_api_response = response;
        res.status(200).json(returnMessage);
      }
      else{
        returnMessage.isError = false;
        returnMessage.message = "No Records Found";
        returnMessage.placement_api_response = response;
        res.status(200).json(returnMessage);
      }

    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_adpworkerid_details";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// const reset_employee_id = async(req,res) => {
//   const returnMessage = getMsgFormat();

//   try {
//   let user_data = await con.query(`SELECT * FROM timesheets.users`);
//   data = user_data.rows;
//   // if(data) {
//     for (var i = 0; i < data.length; i++) {
//     await con.query(
//       `UPDATE timesheets.users u SET 
//         employee_id=(
//         SELECT (SELECT org_prefix FROM timesheets.organizations o 
//           WHERE o.org_id = u.org_id ORDER BY id DESC LIMIT 1) || '' || LPAD(u.id::text, 4, '0') AS r2)
//         WHERE 
//           id=u.id;`,
//       (error, results) => {
//         if (error) {
//           returnMessage.isError = true;
//           returnMessage.message = "Failed to reset";
//           returnMessage.error = error;
//           returnMessage.label = "reset_employee_id";
//           logger.log({
//             level: "error",
//             message: returnMessage,
//           });
//           res.status(400).json(returnMessage);
//         } else {
//           returnMessage.isError = false;
//           // returnMessage.data = results;
//           returnMessage.message = "Updated Successfully";
//           res.status(200).json(returnMessage);
//         }
//       }
//     );
//   }
//   } catch (error) {
//     returnMessage.isError = true;
//     returnMessage.message = "Error Occured! please try again";
//     returnMessage.error = error;
//     returnMessage.label = "reset_employee_id";
//     logger.log({
//       level: "error",
//       message: returnMessage,
//     });
//     return res.status(500).json(returnMessage);
//   }
// }

// GET api for user by prospective_user_id
const get_user_by_adp_associate_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.adp_associate_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "adp_associate_id can not be null or empty";
      returnMessage.label = "get_user_by_adp_associate_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_adp_associate_id($1,$2)`,
        [req.user.org_id, req.query.adp_associate_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch user details";
            returnMessage.error = error;
            returnMessage.label = "get_user_by_adp_associate_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if (
              data &&
              (!is_qb_enabled ||
                ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                ))
            ) {
              delete data.qb_employee_id;
              delete data.qb_employee_name;
            }

            if (data) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_by_adp_associate_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for user by get_user_by_adp_associate_id_excluding_id
const get_user_by_adp_associate_id_excluding_id = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_user_by_adp_associate_id_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    
    } else if (!req.query.adp_associate_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "adp_associate_id can not be null or empty";
      returnMessage.label = "get_user_by_adp_associate_id_excluding_id";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      await con.query(
        `SELECT * from timesheets.get_user_by_adp_associate_id_excluding_id($1,$2,$3)`,
        [req.user.org_id, req.query.id, req.query.adp_associate_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch project details";
            returnMessage.error = error;
            returnMessage.label = "get_user_by_adp_associate_id_excluding_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            let data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;

            let is_qb_enabled = await isQBEnabled(req.user.org_id);

            if (
              data &&
              (!is_qb_enabled ||
                ![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(
                  req.user.role_id
                ))
            ) {
              delete data.qb_employee_id;
              delete data.qb_employee_name;
            }

            if (data) {
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_user_by_adp_associate_id_excluding_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api for users
const update_email_notification_setting = async (req, res) => {
  
  const returnMessage = getMsgFormat();
  try {

    let org_id = req.user.org_id;
    let {
      id = null,
      email_notifications
    } = req.body;
    
    if(!id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "please provide id";
      returnMessage.label = "update_email_notification_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else if(email_notifications == undefined) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "please provide email_notifications as true or false";
      returnMessage.label = "update_email_notification_setting";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{
      // check if user_exists already exists
        user_exists = await con.query(`SELECT timesheets.get_user_by_id($1, $2)`, [id, org_id]);
        user_exists = (user_exists && user_exists.rows[0].get_user_by_id && user_exists.rows[0].get_user_by_id[0]) || null;

        if (user_exists && user_exists.id) {
          await con.query(
            `SELECT timesheets.update_email_notification_setting($1,$2,$3)`,
            [
              id,
              email_notifications,
              req.user.id,
            ],
            async (error, results) => {
              if (error) {
                returnMessage.isError = true;
                returnMessage.message = "Failed to update";
                returnMessage.error = error;
                returnMessage.label = "update_email_notification_setting";
                logger.log({
                  level: "error",
                  message: returnMessage,
                });
                res.status(400).json(returnMessage);
              } else {
                
                let is_qb_enabled = await isQBEnabled(req.user.org_id);
                // don't pass qb details in API response
                let data = (results && results.rows && results.rows[1] && results.rows[1].update_email_notification_setting) || null;
                if((data && data.length) && (!is_qb_enabled || (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id)))){
                    delete data[0].qb_employee_id;
                    delete data[0].qb_employee_name;
                }

                returnMessage.isError = false;
                returnMessage.data = data;
                returnMessage.message = "Updated Successfully";
                res.status(200).json(returnMessage);
              }
            }
          );
        }
        else {
          returnMessage.isError = true;
          returnMessage.message = "User does not exists";
          returnMessage.label = "update_email_notification_setting";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        }
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "update_email_notification_setting";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_users_list
const get_users_list = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_users_list($1);`,
      [req.user.org_id],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch users list";
          returnMessage.error = error;
          returnMessage.label = "get_users_list";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_users_list";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getalluser,
  insertuser,
  edituser,
  getuserbyid,
  get_user_by_prospective_user_id,
  get_user_by_prospective_user_id_excluding_id,
  get_user_by_ecdb_user_id,
  get_user_by_ecdb_user_id_excluding_id,
  searchusers,
  // filterusers,
  export_all_users,
  getuserbyemail,
  getuserbyemailexcludingid,

  getallemployees,
  searchemployees,
  // filteremployees,
  insertemployee,
  editemployee,
  get_employees_list,
  get_new_employee_id,
  export_all_employees,
  get_adpworkerid_details,
  // reset_employee_id,
  get_user_by_adp_associate_id,
  get_user_by_adp_associate_id_excluding_id,
  update_email_notification_setting,
  get_users_list,
};
