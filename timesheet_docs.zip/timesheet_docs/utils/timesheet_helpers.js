const axios = require("axios");
const { getMsgFormat, isEmpty } = require("../utils/helpers");
const con = require("../utils/db");
const logger = require("../utils/logger");
const { ROLES, TIMESHEET_STATUS, PLACEMENT_STATUS_MAPPING } = require("../constants");


const secondsToHms = (d) => {
  d = Number(d);
  var h = Math.floor(d / 3600);
  var m = Math.floor(d % 3600 / 60);
  var s = Math.floor(d % 3600 % 60);

  var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
  return hDisplay + mDisplay + sDisplay; 
}

const secondsToHm = (d) => {
  
  let result = "00:00";

  if(d > 0){
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor(d % 3600 / 60);
  
    let hDisplay = h > 0 ? ( h < 10 ? `0${h}`: h)  : "00";
    let mDisplay = m > 0 ? ( m < 10 ? `0${m}`: m)  : "00";
    result = hDisplay + ":" + mDisplay;
  }
  
  return result;
}

const InsertTimesheetHistory = async (org_id, timesheet_id, is_reverted = false) => {

  const returnMessage = getMsgFormat();

  try {
      let timesheet_data = await con.query(
      `SELECT timesheets.get_timesheet_by_id($1,$2)`, [org_id,timesheet_id]);
      timesheet_data = (timesheet_data && timesheet_data.rows[0].get_timesheet_by_id && timesheet_data.rows[0].get_timesheet_by_id[0]) || null;
      
      // console.log("timesheet_data", org_id,timesheet_id, JSON.stringify(timesheet_data))

      if(timesheet_data && timesheet_data.id){
        var timesheetHistoryData = [
          timesheet_data.id,
          timesheet_data.org_id,
          timesheet_data.user_id,
          timesheet_data.project_id,
          timesheet_data.year,
          timesheet_data.month,
          timesheet_data.week_start_date,
          timesheet_data.week_end_date,
          timesheet_data.timesheet_date,
          timesheet_data.day_name,
          timesheet_data.regular_hours,
          timesheet_data.regular_minutes,
          timesheet_data.ot_hours,
          timesheet_data.ot_minutes,
          timesheet_data.absent_type,
          timesheet_data.absent_hours,
          timesheet_data.absent_minutes,
          timesheet_data.status,
          timesheet_data.user_notes,
          timesheet_data.approver_id,
          timesheet_data.approver_notes,
          timesheet_data.qb_timesheet_id,
          timesheet_data.qb_status,
          timesheet_data.createdby,
          timesheet_data.updatedby,
          timesheet_data.createdate,
          timesheet_data.updatedate,
          timesheet_data.record_type_status,
          is_reverted
        ];

        let results = await con.query(
          `SELECT timesheets.insert_timesheet_history($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29)`,
          timesheetHistoryData
        );
        var data = (results.rows && results.rows[1] && results.rows[1].insert_timesheet_history && results.rows[1].insert_timesheet_history[0]) || null;

        return data;
      }


  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "InsertTimesheetHistory";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return error;
  }
};

const InsertTimesheetStatusHistory = async (org_id, timesheet_status_id, is_reverted = false) => {

  const returnMessage = getMsgFormat();

  try {

      let timesheet_status_data = await con.query(
      `SELECT timesheets.get_timesheet_status_by_id($1,$2)`, [org_id,timesheet_status_id]);
      timesheet_status_data = (timesheet_status_data && timesheet_status_data.rows[0].get_timesheet_status_by_id && timesheet_status_data.rows[0].get_timesheet_status_by_id[0]) || null;
      
      // console.log("timesheet_status_data", org_id,timesheet_status_id, JSON.stringify(timesheet_status_data))

      if(timesheet_status_data && timesheet_status_data.id){
        var timesheetStatusHistoryData = [
          timesheet_status_data.id,
          timesheet_status_data.org_id,
          timesheet_status_data.user_id,
          timesheet_status_data.project_id,
          timesheet_status_data.year,
          timesheet_status_data.month,
          timesheet_status_data.week_start_date,
          timesheet_status_data.week_end_date,
          timesheet_status_data.status,
          timesheet_status_data.client_manager_email,
          timesheet_status_data.client_manager_name,
          timesheet_status_data.user_notes,
          timesheet_status_data.approver_id,
          timesheet_status_data.approver_notes,
          timesheet_status_data.createdby,
          timesheet_status_data.updatedby,
          timesheet_status_data.createdate,
          timesheet_status_data.updatedate,
          timesheet_status_data.record_type_status,
          is_reverted
        ];

        let results = await con.query(
          `SELECT timesheets.insert_timesheet_status_history($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)`, timesheetStatusHistoryData);
        var data = (results.rows && results.rows[1] && results.rows[1].insert_timesheet_status_history && results.rows[1].insert_timesheet_status_history[0]) || null;

        return data;
      }


  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "InsertTimesheetStatusHistory";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return error;
  }
};

const ResetTimesheetStatus = async (data = null, is_reverted = false) => {

  const returnMessage = getMsgFormat();

  if(data.org_id && data.project_id && data.week_start_date && data.week_end_date){

    try {
        
      let record_type_status = "Active";
      // get existing timesheet status
      let timesheet_status_data = await con.query(
      `SELECT timesheets.get_timesheet_status_by_week_and_project_id($1,$2,$3,$4)`, [data.org_id, data.week_start_date, data.week_end_date, data.project_id]);

      timesheet_status_data = (timesheet_status_data && timesheet_status_data.rows[0].get_timesheet_status_by_week_and_project_id && timesheet_status_data.rows[0].get_timesheet_status_by_week_and_project_id[0]) || null;

      // console.log("timesheet_status_data", JSON.stringify(timesheet_status_data));

      // get week timehseet data
      let timesheet_data = await con.query(
      `SELECT timesheets.get_timesheet_by_week_and_project_id($1,$2,$3,$4)`, [data.org_id, data.week_start_date, data.week_end_date, data.project_id]);

      
      timesheet_data = (timesheet_data && timesheet_data.rows[0].get_timesheet_by_week_and_project_id) || null;
      // console.log("timesheet_data", JSON.stringify(timesheet_data));

      let ts_days_length = timesheet_data.length || 0;
      
      let total_null = 0;
      let total_saved = 0;
      let total_submitted = 0;
      let total_approved = 0;
      let total_rejected = 0;
      let statusArr = [];
      let final_status = null;

      if(timesheet_data && timesheet_data.length){

        for(var i = 0; i < ts_days_length;i++){
          timesheetRow = timesheet_data[i];
          statusArr[timesheetRow.day_name] = timesheetRow.status;
         
          if(!timesheetRow.status){
            total_null++;
          }
          if(timesheetRow.status == TIMESHEET_STATUS.SAVED){
            total_saved++;
          }
          if(timesheetRow.status == TIMESHEET_STATUS.SUBMITTED){
            total_submitted++;
          }
          if(timesheetRow.status == TIMESHEET_STATUS.APPROVED){
            total_approved++;
          }
          if(timesheetRow.status == TIMESHEET_STATUS.REJECTED){
            total_rejected++;
          }
        }
      }

      // if(timesheet_status_data && timesheet_status_data.user_id == 1058){
      //   console.log(
      //     data.week_start_date,
      //     "ts_days_length", ts_days_length, 
      //     "total_approved", total_approved, 
      //     "total_saved", total_saved)
        
      // }
      

      if(total_rejected > 0){
        final_status = TIMESHEET_STATUS.REJECTED;
      }
      else if(total_submitted > 0){
        final_status = TIMESHEET_STATUS.SUBMITTED;
      }
      else if(total_approved > 0 && total_approved == ((ts_days_length - total_saved) - total_null)){
        final_status = TIMESHEET_STATUS.APPROVED;
      }
      else{
        final_status = TIMESHEET_STATUS.SAVED;
      }


      // console.log("final_status", final_status);

      update_ts_data = null;

      if(timesheet_status_data && timesheet_status_data.id){

        let tsStatusData = [
          timesheet_status_data.id,
          data.org_id,
          data.user_id,
          data.project_id,
          parseInt(data.year),
          parseInt(data.month),
          data.week_start_date,
          data.week_end_date,
          final_status,
          data.client_manager_email,
          data.client_manager_name,
          data.user_notes,
          data.approver_id,
          data.approver_notes,
          data.createdby,
          record_type_status,
        ];
        let results = await con.query(
          `SELECT timesheets.update_timesheet_status($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
          tsStatusData
        );
        update_ts_data = (results.rows && results.rows[1] && results.rows[1].update_timesheet_status && results.rows[1].update_timesheet_status[0]) || null;
        // console.log("update", update_ts_data);
      }
      else{
        let tsStatusData = [
          data.org_id,
          data.user_id,
          data.project_id,
          parseInt(data.year),
          parseInt(data.month),
          data.week_start_date,
          data.week_end_date,
          final_status,
          data.client_manager_email,
          data.client_manager_name,
          data.user_notes,
          data.approver_id,
          data.approver_notes,
          data.createdby,
          record_type_status,
        ];
        let results = await con.query(
          `SELECT timesheets.insert_timesheet_status($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
          tsStatusData
        );
        update_ts_data = (results.rows && results.rows[1] && results.rows[1].insert_timesheet_status && results.rows[1].insert_timesheet_status[0]) || null;
        // console.log("insert", update_ts_data);
      }

      if(update_ts_data && update_ts_data.id){
        await InsertTimesheetStatusHistory(data.org_id, update_ts_data.id, is_reverted);
      }
      return update_ts_data;

      } catch (error) {
        returnMessage.isError = true;
        returnMessage.message = "Error Occured! please try again";
        returnMessage.error = error;
        returnMessage.label = "ResetTimesheetStatus";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        return error;
      }
  }
  else{
    returnMessage.isError = true;
    returnMessage.message = "Invalid Data";
    returnMessage.label = "ResetTimesheetStatus";
    logger.log({
      level: "error",
      message: returnMessage,
    });
  }
};

const InsertQuickBooksLog = async (org_id, data) => {

  const returnMessage = getMsgFormat();

  try {

        let record_type_status = "Active";
      
        var logData = [
          org_id,
          data.api_name,
          data.request_data,
          data.response_data,
          data.request_status,
          data.createdby,
          record_type_status,
        ];

        let results = await con.query(
          `SELECT timesheets.insert_qb_logs($1,$2,$3,$4,$5,$6,$7)`,
          logData
        );
        var data = (results.rows && results.rows[1] && results.rows[1].insert_qb_logs && results.rows[1].insert_qb_logs[0]) || null;

        return data;

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "InsertQuickBooksLog";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return error;
  }
};


const SyncProjectsByUserId = async (org_id, user_id) => {

  const returnMessage = getMsgFormat();

  try {

    if (!org_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "org_id can not be null or empty";
      returnMessage.label = "SyncProjectsByUserId";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } 
    else if (!user_id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "user_id can not be null or empty";
      returnMessage.label = "SyncProjectsByUserId";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {
      
      
        user_data = await con.query(`SELECT timesheets.get_user_by_id($1,$2)`, [user_id, org_id]);
        
        user_data = (user_data && user_data.rows[0].get_user_by_id && user_data.rows[0].get_user_by_id[0]) || null;

        let ecdb_user_id = (user_data && user_data.ecdb_user_id) || null;
        let prospective_user_id = (user_data && user_data.prospective_user_id) || null;

        if(ecdb_user_id && prospective_user_id){

        // // to sync projects by user
        var response = await axios.get(`${process.env.PLACEMENT_API_URL}placements/placements/candidate/placementType/${ecdb_user_id}/${prospective_user_id}`);
  
        data = (response && response.data) || null;
        // console.log("data", data);
        var output = [];
        var sync_results = [];
  
        if (data && data.statusCode == 200 && data.information) {
          var jsondata = data.information;
  
          // insert customers and vendors as customers before adding projects data
          for (var i = 0; i < jsondata.length; i++) {
            let projectRow = jsondata[i] || null;
  
            let {
              orgId: org_id = null,
              customerId: placement_client_id = null,
              customerName: client_name = null,
              dba = null,
              is_placement_client = true,
              qb_customer_name = null,
              qb_customer_id = null,
              qb_vendor_name = null,
              qb_vendor_id = null,
              status = null,
              createdby = user_id,
              updatedby = user_id,
              vendors = null,
            } = projectRow;
  
            let record_type_status = status == "ACTIVE" ? "Active" : "Inactive";
  
            // insert/update customers
            if (placement_client_id && client_name) {
              
              let customer_exists = await con.query( `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`, [org_id, placement_client_id] );

              customer_exists = (customer_exists && customer_exists.rows[0].get_customer_by_placement_client_id && customer_exists.rows[0].get_customer_by_placement_client_id[0]) || null;
              let customer_id = (customer_exists && customer_exists.id) || 0;
  
              if (customer_id) {

                qb_customer_name = customer_exists.qb_customer_name;
                qb_customer_id = customer_exists.qb_customer_id;
                qb_vendor_name = customer_exists.qb_vendor_name;
                qb_vendor_id = customer_exists.qb_vendor_id;
  
                let customerData = [
                  customer_id,
                  org_id,
                  client_name,
                  dba,
                  is_placement_client,
                  placement_client_id,
                  qb_customer_name,
                  qb_customer_id,
                  qb_vendor_name,
                  qb_vendor_id,
                  updatedby,
                  "Active",
                ];
  
                let customer_result = await con.query(
                  `SELECT timesheets.update_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
                  customerData
                );
              } else {
                let customerData = [
                  org_id,
                  client_name,
                  dba,
                  is_placement_client,
                  placement_client_id,
                  qb_customer_name,
                  qb_customer_id,
                  qb_vendor_name,
                  qb_vendor_id,
                  createdby,
                  "Active",
                ];
  
                let customer_result = await con.query(
                  `SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                  customerData
                );
              }
            }
  
            // insert/update venors as customers
  
            if (vendors && vendors.length) {
              
              for (var j = 0; j < vendors.length; j++) {
                let vendorRow = vendors[j] || null;
  
                let {
                  id: placement_client_id = null,
                  name: client_name = null,
                  dba = null,
                  is_placement_client = true,
                  qb_customer_name = null,
                  qb_customer_id = null,
                  qb_vendor_name = null,
                  qb_vendor_id = null,
                  status = null,
                  createdby = 1,
                } = vendorRow;
  
                let record_type_status = (status == "ACTIVE") ? "Active" : "Inactive";
  
                let customer_exists = await con.query( `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`, [org_id, placement_client_id] );

                customer_exists = (customer_exists && customer_exists.rows[0].get_customer_by_placement_client_id && customer_exists.rows[0].get_customer_by_placement_client_id[0]) || null;
                let customer_id = (customer_exists && customer_exists.id) || 0;
  
                if (customer_id) {
                  qb_customer_name = customer_exists.qb_customer_name;
                  qb_customer_id = customer_exists.qb_customer_id;
                  qb_vendor_name = customer_exists.qb_vendor_name;
                  qb_vendor_id = customer_exists.qb_vendor_id;
  
                  let customerData = [
                    customer_id,
                    org_id,
                    client_name,
                    dba,
                    is_placement_client,
                    placement_client_id,
                    qb_customer_name,
                    qb_customer_id,
                    qb_vendor_name,
                    qb_vendor_id,
                    updatedby,
                    "Active",
                  ];
  
                  let customer_result = await con.query( `SELECT timesheets.update_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, customerData );
                } else {

                  let customerData = [
                    org_id,
                    client_name,
                    dba,
                    is_placement_client,
                    placement_client_id,
                    qb_customer_name,
                    qb_customer_id,
                    qb_vendor_name,
                    qb_vendor_id,
                    createdby,
                    "Active",
                  ];
  
                  let customer_result = await con.query( `SELECT timesheets.insert_customers($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`, customerData );

                }
              }
            }
          }
  
          // insert/update projects data
          for (var i = 0; i < jsondata.length; i++) {

            let projectRow = jsondata[i] || null;
            let end_customer = null;

            let {
              
              orgId: org_id = null,
              placementStatusName: project_status = null,
              candidateId: prospective_user_id = null,
              candidateType = null,
              candidateName = null,
              estStartDate: start_date = null,
              placementEndDate: end_date = null,
              customerId: placement_client_id = null,
              customerName = null,
              client_manager_name = null,
              client_manager_email = null,
              jobTitle: job_title = null,
              is_placement_project = true,
              placementTypeName: placement_type = null,
              placementId: placement_project_id = null,
              placementCode: placement_code = null,
              bill_rate = null,
              pay_rate = null,
              bill_rate_currency = null,
              ot_bill_rate = null,
              ot_pay_rate = null,
              ot_bill_rate_currency = null,
              is_primary_project = null,
              directCustomerEngagement: direct_customer_engagement = false,
              qb_customer_name = null,
              qb_customer_id = null,
              qb_project_name = null,
              qb_project_id = null,
              qb_product_id = null,
              qb_product_name = null,
              status = null,
              workCountry: work_country = null,
              work_email = null,
              work_phone = null,
              work_state = null,
              work_city = null,
              is_updated = false,
              terminateDate: cancel_date = null,
              terminateReasonName: reason = null,
              terminateReasonId: reason_id = null,
              qb_status = null,
              createdby = user_id,
              updatedby = user_id,
              vendors = null,
              history = null,
            } = projectRow;

            if(placement_type!="PERMANENT"){
              start_date_split = (start_date && start_date.split("-")) || null;
            start_date = (start_date_split && (`${start_date_split[2]}-${start_date_split[1]}-${start_date_split[0]}`)) || null;

            //yyyy-mm-dd
            end_date_split = (end_date && end_date.split("-")) || null;
            end_date = (end_date_split && (`${end_date_split[2]}-${end_date_split[1]}-${end_date_split[0]}`)) || null;
            
            //yyyy-mm-dd
            cancel_date_split = (cancel_date && cancel_date.split("-")) || null;
            cancel_date = (cancel_date_split && (`${cancel_date_split[2]}-${cancel_date_split[1]}-${cancel_date_split[0]}`)) || null;

            //// set bill rate / pay rate
            if (history && history.length) {
              bill_rate = (history[0] && history[0].billRate) || null;
              pay_rate = (history[0] && history[0].agreedPayRate) || null;

              ot_bill_rate = (history[0] && history[0].otBillRate) || null;
              ot_pay_rate = (history[0] && history[0].otPayRate) || null;
            }
  

            //////////////////
            if(candidateType == "EXISTING"){
              user_details = await con.query(
                `SELECT timesheets.get_user_by_ecdb_user_id($1, $2)`,
                [org_id, prospective_user_id]
              );
              user_details =
                (user_details &&
                  user_details.rows[0].get_user_by_ecdb_user_id &&
                  user_details.rows[0].get_user_by_ecdb_user_id[0]) ||
                null;
            }
            else{
              user_details = await con.query(
                `SELECT timesheets.get_user_by_prospective_user_id($1, $2)`,
                [org_id, prospective_user_id]
              );
              user_details =
                (user_details &&
                  user_details.rows[0].get_user_by_prospective_user_id &&
                  user_details.rows[0].get_user_by_prospective_user_id[0]) ||
                null;
            }
            let user_id = (user_details && user_details.id) || 0;
            candidateName = (user_details && user_details.full_name) || candidateName;
            // console.log("candidateName", candidateName, user_details);
            //////////////////
            let primeVendorId = null;
            let primeVendorName = null;
            end_customer = placement_client_id;
            let project_name = candidateName + "-" + customerName;

            //// set project name and end customer
            if(direct_customer_engagement){
              // end_customer = placement_client_id;
              project_name = candidateName + "-" + customerName;
            }
            else{
              // console.log(placement_project_id, direct_customer_engagement, "vendors", vendors)
              if (vendors && vendors.length) {
                for (var vendorI = 0; vendorI < vendors.length; vendorI++) {
                  tmpVendor = vendors[vendorI];
                  if(tmpVendor.isPrime){
                    primeVendorId = tmpVendor.id;
                    primeVendorName = tmpVendor.name;
                    // end_customer = tmpVendor.id;
                  }
                }

                if(primeVendorId){
                  // end_customer = primeVendorId;
                  project_name = candidateName + "-" + primeVendorName;
                }
                else{
                  // end_customer = vendors[0].id;
                  project_name = candidateName + "-" + vendors[0].name;
                }

              }
            }
  
              let end_customer_details = await con.query(
                `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
                [org_id, end_customer]
              );
              end_customer_details =
                (end_customer_details &&
                  end_customer_details.rows[0]
                    .get_customer_by_placement_client_id &&
                  end_customer_details.rows[0]
                    .get_customer_by_placement_client_id[0]) ||
                null;
              let end_customer_id =
                (end_customer_details && end_customer_details.id) || 0;
  
              let record_type_status = "Active";
              project_status = PLACEMENT_STATUS_MAPPING[project_status] || "IN_PROGRESS";
  
              // insert/update customers
              if (placement_project_id) {
                let project_exists = await con.query(
                  `SELECT timesheets.get_project_by_placement_project_id($1, $2)`,
                  [org_id, placement_project_id]
                );
                project_exists = (project_exists && project_exists.rows[0].get_project_by_placement_project_id && project_exists.rows[0].get_project_by_placement_project_id[0]) || null;
                let project_id = (project_exists && project_exists.id) || 0;
  
                
  
                let new_project_id = null;
  
                if (user_id) {
                  if (project_id) {

                    record_type_status = project_exists.record_type_status;
                    qb_customer_name = project_exists.qb_customer_name;
                    qb_customer_id = project_exists.qb_customer_id;
                    qb_project_name = project_exists.qb_project_name;
                    qb_project_id = project_exists.qb_project_id;
                    qb_product_id = project_exists.qb_product_id;
                    qb_product_name = project_exists.qb_product_name;
                    
                    work_country = work_country || project_exists.work_country;
                    client_manager_name = project_exists.client_manager_name;
                    client_manager_email = project_exists.client_manager_email;
                    job_title = project_exists.job_title;
  
                    let projectData = [
                      project_id,
                      org_id,
                      user_id,
                      project_name,
                      project_status,
                      start_date,
                      end_date,
                      client_manager_name,
                      client_manager_email,
                      job_title,
                      is_placement_project,
                      placement_type,
                      placement_project_id,
                      placement_code,
                      bill_rate,
                      pay_rate,
                      bill_rate_currency,
                      ot_bill_rate,
                      ot_pay_rate,
                      ot_bill_rate_currency,
                      is_primary_project,
                      direct_customer_engagement,
                      end_customer_id,
                      qb_customer_name,
                      qb_customer_id,
                      qb_project_name,
                      qb_project_id,
                      qb_product_id,
                      qb_product_name,
                      work_country,
                      work_email,
                      work_phone,
                      work_state,
                      work_city,
                      is_updated,
                      cancel_date,
                      reason,
                      reason_id,
                      qb_status,
                      createdby,
                      record_type_status,
                    ];
  
                    let result = await con.query(
                      `SELECT timesheets.update_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41)`,
                      projectData
                    );
                    result = (result.rows && result.rows[1] && result.rows[1].update_projects && result.rows[1].update_projects[0]) || null;
                    new_project_id = result.id || null;
                    sync_results.push(result);

                  } else {
                    let projectData = [
                      org_id,
                      user_id,
                      project_name,
                      project_status,
                      start_date,
                      end_date,
                      client_manager_name,
                      client_manager_email,
                      job_title,
                      is_placement_project,
                      placement_type,
                      placement_project_id,
                      placement_code,
                      bill_rate,
                      pay_rate,
                      bill_rate_currency,
                      ot_bill_rate,
                      ot_pay_rate,
                      ot_bill_rate_currency,
                      is_primary_project,
                      direct_customer_engagement,
                      end_customer_id,
                      qb_customer_name,
                      qb_customer_id,
                      qb_project_name,
                      qb_project_id,
                      qb_product_id,
                      qb_product_name,
                      work_country,
                      work_email,
                      work_phone,
                      work_state,
                      work_city,
                      is_updated,
                      cancel_date,
                      reason,
                      reason_id,
                      qb_status,
                      createdby,
                      record_type_status,
                    ];
  
                    let result = await con.query(
                      `SELECT timesheets.insert_projects($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40)`,
                      projectData
                    );
                    result = (result.rows && result.rows[1] && result.rows[1].insert_projects && result.rows[1].insert_projects[0]) || null;
                    new_project_id = result.id || null;
                    sync_results.push(result);
                  }
  
                  if (new_project_id) {
                    let delete_project_vendors = await con.query(
                      `SELECT timesheets.delete_project_vendors_by_project_id($1, $2)`,
                      [org_id, new_project_id]
                    );
                    delete_project_vendors = (delete_project_vendors && delete_project_vendors.rows[0].get_project_by_placement_project_id && delete_project_vendors.rows[0].get_project_by_placement_project_id[0]) || null;
  
                    // Insert Project Vendors
                    if (vendors && vendors.length && !direct_customer_engagement) {

                      if(primeVendorId){
                        tmpProjectVendorId = primeVendorId;
                      }
                      else{
                        tmpProjectVendorId = vendors[0].id;
                      }

                      for (var j = 0; j < vendors.length; j++) {
                        
                        let vendorRow = vendors[j] || null;
                        if (vendorRow.id == tmpProjectVendorId) {
                          let {
                            id: placement_client_id = null,
                            isPrime = false,
                            createdby = 1,
                            record_type_status = "Active",
                          } = vendorRow;
                          let vendor_details = await con.query(
                            `SELECT timesheets.get_customer_by_placement_client_id($1, $2)`,
                            [org_id, placement_client_id]
                          );
                          vendor_details = (vendor_details && vendor_details.rows[0].get_customer_by_placement_client_id && vendor_details.rows[0].get_customer_by_placement_client_id[0]) || null;
                          let customer_id = (vendor_details && vendor_details.id) || 0;
  
                          let projectVendorData = [
                            org_id,
                            new_project_id,
                            customer_id,
                            isPrime,
                            createdby,
                            record_type_status,
                          ];
  
                          let result = await con.query( `SELECT timesheets.insert_project_vendors($1,$2,$3,$4,$5,$6)`, projectVendorData );
                          result = (result && result.rows && result.rows[1] && result.rows[1].insert_project_vendors && result.rows[1].insert_project_vendors[0]) || null;
                        }
                      }
                    }
  
                    // Insert Project Bill Rates

                    let delete_project_bill_rates = await con.query(`SELECT timesheets.delete_project_bill_rates_by_project_id($1, $2)`, [org_id, new_project_id]);
                    delete_project_bill_rates = (delete_project_bill_rates && delete_project_bill_rates.rows[0].delete_project_bill_rates_by_project_id && delete_project_bill_rates.rows[0].delete_project_bill_rates_by_project_id[0]) || null;
  
                    if (history && history.length) {

                      for (var j = 0; j < history.length; j++) {
                        let billRatesRow = history[j] || null;
                        let {
                          effectiveBillRateStart = null,
                          billRate: bill_rate = null,
                          agreedPayRate: agreed_pay_rate = null,
                          bill_rate_currency = null,
                          otBillRate: ot_bill_rate = null,
                          otPayRate: ot_agreed_pay_rate = null,
                          ot_bill_rate_currency = null,
                          createdby = 1,
                          record_type_status = "Active",
                        } = billRatesRow;
  
                        let effective_date = (effectiveBillRateStart && new Date(effectiveBillRateStart)) || null;
                        let projectBillRateData = [
                          org_id,
                          new_project_id,
                          effective_date,
                          bill_rate,
                          agreed_pay_rate,
                          bill_rate_currency,
                          ot_bill_rate,
                          ot_agreed_pay_rate,
                          ot_bill_rate_currency,
                          createdby,
                          record_type_status,
                        ];
  
                        let result = await con.query(
                          `SELECT timesheets.insert_project_bill_rates($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                          projectBillRateData
                        );
                        result = (result && result.rows && result.rows[1] && result.rows[1].insert_project_bill_rates && result.rows[1].insert_project_bill_rates[0]) || null;
                      }
                    }
                    
                  }
                }
              }
            }
  
          }
        }
  
        // Insert Projects Sync Log
        // await con.query(`SELECT timesheets.insert_sync_logs($1,$2,$3,$4,$5)`, [
        //   (req.user && req.user.org_id) || null,
        //   "projects",
        //   (sync_results && sync_results.length) || 0,
        //   (req.user && req.user.id) || null,
        //   "Active",
        // ]);
      }
  
    }

    if (sync_results && sync_results.length) {

      let total_projects = await con.query(`SELECT * from timesheets.get_projects_by_user_id($1,$2)`, [org_id, user_id]);
      total_projects = (total_projects.rows && total_projects.rows[1] && total_projects.rows[1].j) || null;
      

      // don't pass qb details in API response
      // req.user is not accessible here
      // if((![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ACCOUNTS].includes(req.user.role_id))){
      //   for (var i = 0; i < sync_results.length; i++) {
      //     delete sync_results[i].qb_customer_id;
      //     delete sync_results[i].qb_customer_name;
      //     delete sync_results[i].qb_project_id;
      //     delete sync_results[i].qb_project_name;
      //     delete sync_results[i].qb_product_id;
      //     delete sync_results[i].qb_product_name;
      //     delete sync_results[i].qb_status;
      //   }
      // }

      let updatedby = user_id;

      for (var i = 0; i < sync_results.length; i++) {

       
        if(i == 0 && total_projects && total_projects.length == 1){

          // remove other primary projects
          await con.query(`SELECT timesheets.remove_primary_projects_by_user_id($1,$2,$3)`, [ org_id, user_id, updatedby ]);
  
          // Update project as primary
          let primary_result = await con.query(`SELECT timesheets.update_project_as_primary($1,$2,$3)`, [ sync_results[i].id, org_id, updatedby ]);
        }

        delete sync_results[i].bill_rate;
        delete sync_results[i].pay_rate;
        delete sync_results[i].bill_rate_currency;
        delete sync_results[i].ot_bill_rate;
        delete sync_results[i].ot_pay_rate;
        delete sync_results[i].ot_bill_rate_currency;
      }
    }

    return sync_results;

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "SyncProjectsByUserId";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return error;
  }
};


const UpdateProjectClientManagerDetails = async (data = {}) => {

  const returnMessage = getMsgFormat();
  results = null;
  try {
      
        if(data.id && data.org_id){

          let old_data = await con.query(`SELECT timesheets.get_project_by_id($1,$2)`,
          [data.org_id, data.id]
          );

          old_data = (old_data && old_data.rows[0].get_project_by_id && old_data.rows[0].get_project_by_id[0]) || null;

          var projectData = [
            data.id,
            data.org_id,
            data.client_manager_name || old_data.client_manager_name,
            data.client_manager_email || old_data.client_manager_email,
            data.updatedby,
          ];

          results = await con.query( `SELECT timesheets.update_project_client_manager_details($1,$2,$3,$4,$5)`,  projectData );
          results = (results.rows && results.rows[1] && results.rows[1].update_project_client_manager_details && results.rows[1].update_project_client_manager_details[0]) || null;
        }

        return results;

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "UpdateProjectClientManagerDetails";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return error;
  }
};

const ResetPrimaryProjectByUser = async (data = {}) => {

  const returnMessage = getMsgFormat();
  results = null;
  try {
      
        if(data.org_id && data.user_id && data.exlcuded_project_id){

          let earliest_project = await con.query(`SELECT * FROM timesheets.get_earliest_active_project_by_user_id_excluding_id($1,$2,$3)`,
          [data.org_id, data.exlcuded_project_id, data.user_id]
          );
          earliest_project = (earliest_project && earliest_project.rows[0].j && earliest_project.rows[0].j[0]) || null;
          // console.log("earliest_project", earliest_project);

          if(earliest_project && earliest_project.id){
            // remove other primary projects
            await con.query(`SELECT timesheets.remove_primary_projects_by_user_id($1,$2,$3)`, [ data.org_id, data.user_id, data.updatedby ]);

            // Update project as primary
            results = await con.query(`SELECT timesheets.update_project_as_primary($1,$2,$3)`, [ earliest_project.id, data.org_id, data.updatedby ]);
          }
          
          return results;
        }

        return results;

  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "ResetPrimaryProjectByUser";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return error;
  }
};

async function getOrgData(org_id = null) {

  let result = null;
  if(org_id){

    result = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    result = (result && result.rows[0].get_organizations_by_orgid && result.rows[0].get_organizations_by_orgid[0]) || null;

  }
  return result;
}

async function isQBEnabled(org_id = null) {

  let result = null;
  if(org_id){

    result = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    result = (result && result.rows[0].get_organizations_by_orgid && result.rows[0].get_organizations_by_orgid[0]) || null;
    result = (result && result.enable_quickbooks) || false;
    
  }
  return result;

}

async function isAdpEnabled(org_id = null) {

  let result = false;
  if(org_id){

    result = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    result = (result && result.rows[0].get_organizations_by_orgid && result.rows[0].get_organizations_by_orgid[0]) || null;
    result = (result && result.enable_adp) || false;
    
  }
  return result;
}

async function isValidateAdpEmployee(org_id = null) {

  let result = false;
  if(org_id){

    result = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    result = (result && result.rows[0].get_organizations_by_orgid && result.rows[0].get_organizations_by_orgid[0]) || null;
    result = (result && result.validate_adp_employee) || false;
    
  }
  return result;
}

async function isValidateAdpApprover(org_id = null) {

  let result = false;
  if(org_id){

    result = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    result = (result && result.rows[0].get_organizations_by_orgid && result.rows[0].get_organizations_by_orgid[0]) || null;
    result = (result && result.validate_adp_approver) || false;
    
  }
  return result;
}

async function isUserAdpValidated(org_id = null, user_id = null) {

  let result = false;
  if(org_id && user_id){

    result = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
    [user_id, org_id]);
    result = (result && result.rows && result.rows[0] && result.rows[0].j && result.rows[0].j[0]) || null;
    result = (result && result.adp_validated) || false;
    
  }
  return result;
}

async function getEmployeeType(org_id = null, user_id = null) {

  let employee_type = ``;
  if(org_id && user_id){

    result = await con.query(`SELECT * from timesheets.get_user_by_id($1,$2)`,
    [user_id, org_id]);
    result = (result && result.rows && result.rows[0] && result.rows[0].j && result.rows[0].j[0]) || null;
    employee_type = (result && result.employee_type) || ``;
    
  }
  return employee_type;
}

async function isEmailReminderOn(org_id = null, user_id = null) {
  let data = false;
  if (org_id && user_id) {
    data = await con.query("SELECT timesheets.get_user_by_id($1,$2)", [
      user_id,
      org_id,
    ]);
    data = (data && data.rows[0].get_user_by_id && data.rows[0].get_user_by_id[0]) || null;
    data = (data && data.email_notifications) || false;
  }
  return data;
}

async function isQBTransactionOn(org_id = null, transaction_name = null) {
  
  let result = null;
  if(org_id && transaction_name){

    qb_setting = await con.query(`SELECT  * FROM timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    qb_setting = (qb_setting && qb_setting.rows[0].j && qb_setting.rows[0].j[0]) || null;
    qb_setting = (qb_setting && qb_setting.enable_quickbooks) || false;

    qb_transaction_setting = await con.query(`SELECT * from timesheets.get_qb_transactions_setting_by_name($1, $2)`, [org_id, transaction_name]);
    qb_transaction_setting = (qb_transaction_setting && qb_transaction_setting.rows[0].j && qb_transaction_setting.rows[0].j[0]) || null;
    qb_transaction_setting = (qb_transaction_setting && qb_transaction_setting.is_enabled) || false;

    if(qb_setting && qb_transaction_setting){
      result = true;
    }
    
  }
  return result;

}

module.exports = {
  secondsToHms,
  secondsToHm,
  InsertTimesheetHistory,
  InsertTimesheetStatusHistory,
  ResetTimesheetStatus,
  InsertQuickBooksLog,
  SyncProjectsByUserId,
  UpdateProjectClientManagerDetails,
  ResetPrimaryProjectByUser,
  getOrgData,
  isQBEnabled,
  isEmailReminderOn,
  isQBTransactionOn,
  isAdpEnabled,
  isValidateAdpEmployee,
  isValidateAdpApprover,
  isUserAdpValidated,
  getEmployeeType,
};