const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const { refreshToken } = require("../../controllers/tokenController");

// @route GET api/v1/token/refreshToken
// @desc  Route to generate refresh tokens
// @accesss public
router.get("/refreshToken", refreshToken);

module.exports = router;
