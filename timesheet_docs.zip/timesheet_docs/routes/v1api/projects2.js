const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_all_projects,
  // filter_projects,
  get_project_by_id,
  get_project_by_placement_code,
  get_project_by_placement_code_excluding_id,
  get_projects_list,
  get_projects_by_user_id,
  insert_project,
  edit_project,
  delete_project,
  export_all_projects,
  sync_projects_by_user_id,
  get_primary_project_by_user_id,
  update_project_names,
  get_active_local_projects_by_user_id,
} = require("../../controllers/projects2Controller");

// @route GET api/v1/projects/get_all_projects
// @desc  Route to get all projects
// @accesss public
router.get("/get_all_projects", get_all_projects);

// @route GET api/v1/projects/filter_projects
// @desc  Route to get filter projects
// @accesss public
// router.get("/filter_projects", filter_projects);

// @route GET api/v1/projects/get_project_by_id
// @desc  Route to get projects by id
// @accesss public
router.get("/get_project_by_id", get_project_by_id);

// @route GET api/v1/projects/get_project_by_placement_code
// @desc  Route to get projects by placement code
// @accesss public
router.get("/get_project_by_placement_code", get_project_by_placement_code);

// @route GET api/v1/projects/get_project_by_placement_code_excluding_id
// @desc  Route to get projects by placement code
// @accesss public
router.get(
  "/get_project_by_placement_code_excluding_id",
  get_project_by_placement_code_excluding_id
);

// @route GET api/v1/projects/get_projects_list
// @desc  Route to get projects list for dropdown
// @accesss public
router.get("/get_projects_list", get_projects_list);

// @route GET api/v1/projects/get_projects_by_user_id
// @desc  Route to get projects by user_id
// @accesss public
router.get("/get_projects_by_user_id", get_projects_by_user_id);

// @route POST api/v1/projects/insert_project
// @desc  Route to post projects
// @accesss public
router.post("/insert_project", insert_project);

// @route PUT api/v1/projects/edit_project
// @desc  Route to edit projects
// @accesss public
router.put("/edit_project", edit_project);

// @route PUT api/v1/projects/delete_project
// @desc  Route to delete project
// @accesss public
router.put("/delete_project", delete_project);

// @route GET api/v1/projects/export_all_projects
// @desc  Route to get export_all_projects
// @accesss public
router.get("/export_all_projects", export_all_projects);


// @route GET api/v1/projects/sync_projects_by_user_id
// @desc  Route to sync projects by user id
// @accesss public
router.get("/sync_projects_by_user_id", sync_projects_by_user_id);

// @route GET api/v1/projects/get_primary_project_by_user_id
// @desc  Route to get_primary_project_by_user_id
// @accesss public
router.get("/get_primary_project_by_user_id", get_primary_project_by_user_id);

// @route POST api/v1/projects/update_project_names
// @desc  Route to update_project_names
// @accesss public
router.post("/update_project_names", update_project_names);

// @route GET api/v1/projects/get_active_local_projects_by_user_id
// @desc  Route to get_active_local_projects_by_user_id
// @accesss public
router.get("/get_active_local_projects_by_user_id", get_active_local_projects_by_user_id);

module.exports = router;
