const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_sync_logs_by_sync_type,
} = require("../../controllers/syncLogsController");

// @route GET api/v1/annoucements/get_sync_logs_by_sync_type
// @desc  Route to get all annoucements
// @accesss public
router.get("/get_sync_logs_by_sync_type", get_sync_logs_by_sync_type);

module.exports = router;
