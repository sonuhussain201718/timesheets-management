const express = require("express");
const router = express.Router();

const {
  gettimesheethoursincludingnorecords,

} = require("../../controllers/accountingToolsController");

// @route POST api/v1/cronjob/gettimesheethoursincludingnorecords
// @desc  Route to get gettimesheethoursincludingnorecords
// @accesss public
router.post("/gettimesheethoursincludingnorecords", gettimesheethoursincludingnorecords);

module.exports = router;
