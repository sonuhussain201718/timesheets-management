const { getMsgFormat, isEmpty } = require("../utils/helpers");
const quickbookConfigValidator = require("../validation/quickbookConfigValidator");
const con = require("../utils/db");
const logger = require("../utils/logger");
const QuickBooks = require("node-quickbooks");
const qbodata = require("../utils/qb");
const {
  InsertQuickBooksLog,
  isQBTransactionOn
} = require("../utils/timesheet_helpers");
// con.connect();

// GET api for customer by name
const getcustomerdatabyname = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {

  let is_qb_transaction_on = await isQBTransactionOn(org_id, "getcustomerdatabyname");

  if (is_qb_transaction_on) {
  qbo.findCustomers(
    { FullyQualifiedName: req.query.name },
    async function (e, customers) {
      if (e) {
        let api_name = "findCustomers";
        let request_data = JSON.stringify({
          FullyQualifiedName: req.query.name,
        });
        let response_data = JSON.stringify(e);
        let request_status = "FAILED";

        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else if (!isEmpty(customers.QueryResponse)) {
        let api_name = "findCustomers";
        let request_data = JSON.stringify({
          FullyQualifiedName: req.query.name,
        });
        let response_data = JSON.stringify(customers);
        let request_status = "SUCCESS";
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = false;
        returnMessage.data = customers;
        returnMessage.message = "Records Found";
        res.status(200).json(returnMessage);
      } else if (isEmpty(customers.QueryResponse)) {
        let api_name = "findCustomers";
        let request_data = JSON.stringify({
          FullyQualifiedName: req.query.name,
        });
        let response_data = JSON.stringify(customers);
        let request_status = "SUCCESS";
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = true;
        returnMessage.message = "No Records Found";
        res.status(200).json(returnMessage);
      }
    }
  );
} else {
  returnMessage.isError = true;
  returnMessage.message = "QB Transaction not enabled!";
  returnMessage.error = "QB Transaction not enabled!";
  returnMessage.label = "getcustomerdatabyname";
  logger.log({
    level: "error",
    message: returnMessage,
  });
  res.status(400).json(returnMessage);
}
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getcustomerdatabyname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for customer list
const getcustomerdata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.findCustomers(
      { field: "fetchAll", value: true },
      // { field: "FamilyName", value: "%sand%", operator: "LIKE" },
      async function (e, customers) {
        if (e) {

          let api_name = "findCustomers";
          let request_data = JSON.stringify({ field: "fetchAll", value: true });
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";
          
          let qbData = { api_name, request_data, response_data, request_status, createdby };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {
           let api_name = "findCustomers";
           let request_data = JSON.stringify({
             field: "fetchAll",
             value: true,
           });
           let response_data = JSON.stringify(customers);
           let request_status = "SUCCESS";
           let qbData = {
             api_name,
             request_data,
             response_data,
             request_status,
             createdby,
           };
           await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.data = customers;
          returnMessage.message = "Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for update customer
const updatecustomerdata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.createdby;
  const returnMessage = getMsgFormat();
  try {
    qbo.updateCustomer(
      {
        Id: req.query.id,
        SyncToken: req.query.token,
        ...req.body,
      },
      async function (e, customer) {
        if (e) {

            let api_name = "updateCustomer";
            let request_data = JSON.stringify({
              Id: req.query.id,
              SyncToken: req.query.token,
              ...req.body,
            });
            let response_data = JSON.stringify(e);
            let request_status = "FAILED";

            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {
          let api_name = "updateCustomer";
          let request_data = JSON.stringify({
            Id: req.query.id,
            SyncToken: req.query.token,
            ...req.body,
          });
          let response_data = JSON.stringify(customer);
          let request_status = "SUCCESS";
          let qbData = { api_name, request_data, response_data, request_status, createdby };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// POST api for add customer
const addcustomerdata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.createdby;
  const returnMessage = getMsgFormat();
  try {
    qbo.createCustomer(req.body, async function (e, customers) {
      if (e) {
        let api_name = "createCustomer";
        let request_data = JSON.stringify(req.body);
        let response_data = JSON.stringify(e);
        let request_status = "FAILED";

        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);
        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else {
        let api_name = "createCustomer";
        let request_data = JSON.stringify(req.body);
        let response_data = JSON.stringify(customers);
        let request_status = "SUCCESS";
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = false;
        returnMessage.message = "Customer added successfully";
        res.status(200).json(returnMessage);
      }
    });
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for vendor list
const getvendordata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.findVendors(
      {
        fetchAll: true,
      },
      async function (e, vendor) {
        if (e) {

           let api_name = "findVendors";
            let request_data = JSON.stringify({
              fetchAll: true,
            });
            let response_data = JSON.stringify(e);
            let request_status = "FAILED";

            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {
          let api_name = "findVendors";
          let request_data = JSON.stringify({
            fetchAll: true,
          });
          let response_data = JSON.stringify(vendor);
          let request_status = "SUCCESS";
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.data = vendor;
          returnMessage.message = "Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for vendor list
const getvendordatabyname = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {

  let is_qb_transaction_on = await isQBTransactionOn(org_id, "getvendordatabyname");

    if (is_qb_transaction_on) {
      qbo.findVendors(
        { DisplayName: req.query.name },
        async function (e, vendor) {
          if (e) {
            let api_name = "findVendors";
            let request_data = JSON.stringify({ DisplayName: req.query.name });
            let response_data = JSON.stringify(e);
            let request_status = "FAILED";

            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

            returnMessage.message = e.fault;
            res.status(400).json(returnMessage);
          } else {
            let api_name = "findVendors";
            let request_data = JSON.stringify({ DisplayName: req.query.name });
            let response_data = JSON.stringify(vendor);
            let request_status = "SUCCESS";
            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

            returnMessage.isError = false;
            returnMessage.data = vendor;
            returnMessage.message = "Records Found";
            res.status(200).json(returnMessage);
          }
        }
      );
    } else {
      returnMessage.isError = true;
      returnMessage.message = "QB Transaction not enabled!";
      returnMessage.error = "QB Transaction not enabled!";
      returnMessage.label = "getvendordatabyname";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    returnMessage.label = "getvendordatabyname";
    return res.status(400).json(returnMessage);
  }
};

// POST api for add vendor
const addvendordata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.createVendor(req.body, async function (e, vendors) {
      if (e) {

         let api_name = "createVendor";
          let request_data = JSON.stringify(req.body);
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";

          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);
        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else {

         let api_name = "createVendor";
         let request_data = JSON.stringify(req.body);
         let response_data = JSON.stringify(vendors);
         let request_status = "SUCCESS";
         let qbData = {
           api_name,
           request_data,
           response_data,
           request_status,
           createdby,
         };
         await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = false;
        returnMessage.message = "vendor added successfully";
        res.status(200).json(returnMessage);
      }
    });
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for employee list
const getemployeedata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.id
  const returnMessage = getMsgFormat();
  try {
    qbo.findEmployees(
      {
        fetchAll: true,
      },
      async function (e, employee) {
        if (e) {
           let api_name = "findEmployees";
            let request_data = JSON.stringify({
              fetchAll: true,
            });
            let response_data = JSON.stringify(e);
            let request_status = "FAILED";

            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {

            let api_name = "findEmployees";
            let request_data = JSON.stringify({
              fetchAll: true,
            });
            let response_data = JSON.stringify(employee);
            let request_status = "SUCCESS";
            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.data = employee;
          returnMessage.message = "Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// POST api for add employee
const addemployeedata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.body.createdby;
  const returnMessage = getMsgFormat();
  try {
    qbo.createEmployee(req.body, async function (e, employee) {
      if (e) {

        let api_name = "createEmployee";
        let request_data = JSON.stringify(req.body);
        let response_data = JSON.stringify(e);
        let request_status = "FAILED";

        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else {

        let api_name = "createEmployee";
        let request_data = JSON.stringify(req.body);
        let response_data = JSON.stringify(employee);
        let request_status = "SUCCESS";
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = false;
        returnMessage.message = "Employee added successfully";
        res.status(200).json(returnMessage);
      }
    });
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for update customer
const updateemployeedata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.createdby;
  const returnMessage = getMsgFormat();
  try {
    qbo.updateEmployee(
      {
        Id: req.query.id,
        SyncToken: req.query.token,
        ...req.body,
      },
      async function (e, customer) {
        if (e) {

        let api_name = "updateEmployee";
        let request_data = JSON.stringify({
          Id: req.query.id,
          SyncToken: req.query.token,
          ...req.body,
        });
        let response_data = JSON.stringify(e);
        let request_status = "FAILED";

        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {

          let api_name = "updateEmployee";
          let request_data = JSON.stringify({
            Id: req.query.id,
            SyncToken: req.query.token,
            ...req.body,
          });
          let response_data = JSON.stringify(customer);
          let request_status = "SUCCESS";
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);
          returnMessage.isError = false;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for employee
const getemployeedatabyname = async (req, res) => {
  var org_id = req.user.org_id;
  var createdby = req.user.id;
  var qbo = await qbodata(org_id);
  const returnMessage = getMsgFormat();
  try {

    let is_qb_transaction_on = await isQBTransactionOn(org_id, "getemployeedatabyname");

    if(is_qb_transaction_on){
      qbo.findEmployees(
        { DisplayName: req.body.DisplayName },
        async function (e, employee) {
          if (e) {
  
             let api_name = "findEmployees";
              let request_data = JSON.stringify({
                DisplayName: req.body.DisplayName,
              });
              let response_data = JSON.stringify(e);
              let request_status = "FAILED";
  
              let qbData = {
                api_name,
                request_data,
                response_data,
                request_status,
                createdby,
              };
              await InsertQuickBooksLog(org_id, qbData);
  
            returnMessage.message = e.fault;
            res.status(400).json(returnMessage);
          } else if (!isEmpty(employee.QueryResponse)) {
  
            let api_name = "findEmployees";
            let request_data = JSON.stringify({
              DisplayName: req.body.DisplayName,
            });
            let response_data = JSON.stringify(employee);
            let request_status = "SUCCESS";
            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);
  
            returnMessage.isError = false;
            returnMessage.data = employee;
            returnMessage.message = "Records Found";
            res.status(200).json(returnMessage);
          } else if (isEmpty(employee.QueryResponse)) {
            qbo.createEmployee(req.body, async function (e, employee) {
              if (e) {
  
                 let api_name = "findEmployees";
              let request_data = JSON.stringify({
                DisplayName: req.body.DisplayName,
              });
              let response_data = JSON.stringify(e);
              let request_status = "FAILED";
  
              let qbData = {
                api_name,
                request_data,
                response_data,
                request_status,
                createdby,
              };
              await InsertQuickBooksLog(org_id, qbData);
  
                returnMessage.message = e.fault;
                res.status(400).json(returnMessage);
              } else {
                qbo.findEmployees(
                  { DisplayName: req.body.DisplayName },
                  async function (e, createdemployee) {
  
                  let api_name = "findEmployees";
                  let request_data = JSON.stringify({
                    DisplayName: req.body.DisplayName,
                  });
                  let response_data = JSON.stringify(createdemployee);
                  let request_status = "SUCCESS";
                  let qbData = {
                    api_name,
                    request_data,
                    response_data,
                    request_status,
                    createdby,
                  };
                  await InsertQuickBooksLog(org_id, qbData);
  
                    returnMessage.isError = false;
                    returnMessage.data = createdemployee;
                    returnMessage.message = "Records Found";
                    res.status(200).json(returnMessage);
                  }
                );
              }
            });
          }
        }
      );
    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "QB Transaction not enabled!";
      returnMessage.error = "QB Transaction not enabled!";
      returnMessage.label = "getemployeedatabyname";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
    
    
  } catch (error) {
    console.log("error", error)
    returnMessage.message = "Error Occured! please try again";
    returnMessage.label = "getemployeedatabyname";
    return res.status(400).json(returnMessage);
  }
};

// GET api for timeactivity list
const gettimeactivitydata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.createdby;
  const returnMessage = getMsgFormat();
  try {
    qbo.findTimeActivities(
      {
        fetchAll: true,
      },
      // { field: "TxnDate", value: "2014-12-01", operator: ">" },
      // { field: "TxnDate", value: "2014-12-03", operator: "<" },
      // { field: "limit", value: 5 },
      async function (e, timeactivity) {
        if (e) {
          
          let api_name = "findTimeActivities";
            let request_data = JSON.stringify({
              fetchAll: true,
            });
            let response_data = JSON.stringify(e);
            let request_status = "FAILED";

            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {
          
            let api_name = "findTimeActivities";
            let request_data = JSON.stringify({
              fetchAll: true,
            });
            let response_data = JSON.stringify(timeactivity);
            let request_status = "SUCCESS";
            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);
          returnMessage.isError = false;
          returnMessage.data = timeactivity;
          returnMessage.message = "Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// POST api for add tmeactivity
const createtimeactivity = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.createTimeActivity(req.body, async function (e, timeactivity) {
      if (e) {

        let api_name = "createTimeActivity";
        let request_data = JSON.stringify(req.body);
        let response_data = JSON.stringify(e);
        let request_status = "FAILED";

        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);
        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else {

         let api_name = "createTimeActivity";
         let request_data = JSON.stringify(req.body);
         let response_data = JSON.stringify(timeactivity);
         let request_status = "SUCCESS";
         let qbData = {
           api_name,
           request_data,
           response_data,
           request_status,
           createdby,
         };
         await InsertQuickBooksLog(org_id, qbData);
        returnMessage.isError = false;
        returnMessage.message = "Timeactivity added successfully";
        res.status(200).json(returnMessage);
      }
    });
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for employee list
const gettimeactivitydatabyid = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.findTimeActivities({ id: req.query.id }, async function (e, timeactivity) {
      if (e) {

        let api_name = "findTimeActivities";
        let request_data = JSON.stringify({ id: req.query.id });
        let response_data = JSON.stringify(e);
        let request_status = "FAILED";
      
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);
        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else {

        let api_name = "findTimeActivities";
        let request_data = JSON.stringify({ id: req.query.id });
        let response_data = JSON.stringify(timeactivity);
        let request_status = "SUCCESS";
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = false;
        returnMessage.data = timeactivity;
        returnMessage.message = "Records Found";
        res.status(200).json(returnMessage);
      }
    });
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for update time activity
const updatetimeactivity = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.updateTimeActivity(
      {
        Id: req.query.Id,
        SyncToken: req.query.SyncToken,
        ...req.body,
      },
      async function (e, timeactivity) {
        if (e) {

          let api_name = "updateTimeActivity";
          let request_data = JSON.stringify({
            Id: req.query.Id,
            SyncToken: req.query.SyncToken,
            ...req.body,
          });
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";

          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {
          
            let api_name = "updateTimeActivity";
            let request_data = JSON.stringify({
              Id: req.query.Id,
              SyncToken: req.query.SyncToken,
              ...req.body,
            });
            let response_data = JSON.stringify(timeactivity);
            let request_status = "SUCCESS";
            let qbData = {
              api_name,
              request_data,
              response_data,
              request_status,
              createdby,
            };
            await InsertQuickBooksLog(org_id, qbData);
          returnMessage.isError = false;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for employee list
const deletetimeactivity = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  const returnMessage = getMsgFormat();
  try {
    qbo.deleteTimeActivity(
      {
        Id: req.query.Id,
        SyncToken: req.query.SyncToken,
      },
      async function (e, timeactivity) {
        if (e) {
          let api_name = "deleteTimeActivity";
          let request_data = JSON.stringify({
            Id: req.query.Id,
            SyncToken: req.query.SyncToken,
          });
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";
        
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
        await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {

          let api_name = "deleteTimeActivity";
          let request_data = JSON.stringify({
            Id: req.query.Id,
            SyncToken: req.query.SyncToken,
          });
          let response_data = JSON.stringify(timeactivity);
          let request_status = "SUCCESS";
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.message = "Deleted Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for item list
const getitemdata = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.createdby;
  const returnMessage = getMsgFormat();
  try {
    qbo.findItems(
      {
        fetchAll: true,
      },
      // { field: "TxnDate", value: "2014-12-01", operator: ">" },
      // { field: "TxnDate", value: "2014-12-03", operator: "<" },
      // { field: "limit", value: 5 },
      async function (e, item) {
        if (e) {

          let api_name = "findItems";
          let request_data = JSON.stringify({
            fetchAll: true,
          });
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";
        
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {

           let api_name = "findItems";
           let request_data = JSON.stringify({
             fetchAll: true,
           });
           let response_data = JSON.stringify(item);
           let request_status = "SUCCESS";
           let qbData = {
             api_name,
             request_data,
             response_data,
             request_status,
             createdby,
           };
           await InsertQuickBooksLog(org_id, qbData);
          returnMessage.isError = false;
          returnMessage.data = item;
          returnMessage.message = "Records Found";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// POST api for add tmeactivity
const createitem = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  let createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.createItem(req.body, async function (e, item) {
      if (e) {

        let api_name = "createItem";
  let request_data = JSON.stringify(req.body);
  let response_data = JSON.stringify(e);
  let request_status = "FAILED";

  let qbData = {
    api_name,
    request_data,
    response_data,
    request_status,
    createdby,
  };
  await InsertQuickBooksLog(org_id, qbData);

        returnMessage.message = e.fault;
        res.status(400).json(returnMessage);
      } else {

        let api_name = "createItem";
        let request_data = JSON.stringify(req.body);
        let response_data = JSON.stringify(item);
        let request_status = "SUCCESS";
        let qbData = {
          api_name,
          request_data,
          response_data,
          request_status,
          createdby,
        };
        await InsertQuickBooksLog(org_id, qbData);

        returnMessage.isError = false;
        returnMessage.message = "item added successfully";
        res.status(200).json(returnMessage);
      }
    });
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// GET api for employee list
const getitemdatabyname = async (req, res) => {
  console.log('req---',req)
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.createdby;
  const returnMessage = getMsgFormat();
  try {

    let is_qb_transaction_on = await isQBTransactionOn(org_id, "getitemdatabyname");
    if (is_qb_transaction_on) {
      qbo.findItems({ Name: req.query.name }, async function (e, item) {
        if (e) {
          let api_name = "findItems";
          let request_data = JSON.stringify({ Name: req.query.name });
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";

          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else if (isEmpty(item.QueryResponse)) {
          // var data = {
          //   Name: req.query.name,
          //   Type: "Service",
          //   ExpenseAccountRef: {
          //     name: "Cost of Goods Sold",
          //     value: "80",
          //   },
          // };
          // qbo.createItem(data, function (e, item) {
          //   if (e) {
          //     returnMessage.message = e.fault
          //     res.status(500).json(returnMessage);
          //   } else {
          //     qbo.findItems({ Name: req.query.name }, function (e, items) {
          //       if (e) {
          //         returnMessage.message = e.fault
          //         res.status(400).json(returnMessage);
          //       } else if (!isEmpty(items.QueryResponse)) {
          //         returnMessage.isError = false;
          //         returnMessage.data = items;
          //         returnMessage.message = "Records Found";
          //         res.status(200).json(returnMessage);
          //       }
          //     });
          //   }
          // });
          let api_name = "findItems";
          let request_data = JSON.stringify({ Name: req.query.name });
          let response_data = JSON.stringify(item);
          let request_status = "SUCCESS";
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = true;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else if (!isEmpty(item.QueryResponse)) {
          let api_name = "findItems";
          let request_data = JSON.stringify({ Name: req.query.name });
          let response_data = JSON.stringify(item);
          let request_status = "SUCCESS";
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.data = item;
          returnMessage.message = "Records Found";
          res.status(200).json(returnMessage);
        }
      });
    } else {
      returnMessage.isError = true;
      returnMessage.message = "QB Transaction not enabled!";
      returnMessage.error = "QB Transaction not enabled!";
      returnMessage.label = "getitemdatabyname";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "getitemdatabyname";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// PUT api for update time activity
const updateitem = async (req, res) => {
  var org_id = req.user.org_id;
  var qbo = await qbodata(org_id);
  var createdby = req.user.id;
  const returnMessage = getMsgFormat();
  try {
    qbo.updateItem(
      {
        Id: req.query.id,
        SyncToken: req.query.token,
        ...req.body,
      },
      async function (e, item) {
        if (e) {

          let api_name = "updateItem";
          let request_data = JSON.stringify({
            Id: req.query.id,
            SyncToken: req.query.token,
            ...req.body,
          });
          let response_data = JSON.stringify(e);
          let request_status = "FAILED";
        
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.message = e.fault;
          res.status(400).json(returnMessage);
        } else {

          let api_name = "updateItem";
          let request_data = JSON.stringify({
            Id: req.query.id,
            SyncToken: req.query.token,
            ...req.body,
          });
          let response_data = JSON.stringify(item);
          let request_status = "SUCCESS";
          let qbData = {
            api_name,
            request_data,
            response_data,
            request_status,
            createdby,
          };
          await InsertQuickBooksLog(org_id, qbData);

          returnMessage.isError = false;
          returnMessage.message = "Updated Successfully";
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.message = "Error Occured! please try again";
    return res.status(400).json(returnMessage);
  }
};

// ================= New APIs ==============
// GET api for qb logs List
const get_all_qb_logs = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    await con.query(
      `SELECT * from timesheets.get_all_qb_logs($1,$2,$3);`,
      [req.user.org_id, req.query.pagenumber, req.query.pagesize],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch qb logs details";
          returnMessage.error = error;
          returnMessage.label = "get_all_qb_logs";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[1].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[1].j;
          returnMessage.count = results.rows[2].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_qb_logs";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for filter QB Logs
const get_qb_logs_filter = async (req, res) => {
  const returnMessage = getMsgFormat();
  if (req.query.api_name == undefined || req.query.api_name == "") {
    req.query.api_name = null;
  }
  if (req.query.request_data == undefined || req.query.request_data == "") {
    req.query.request_data = null;
  }
  if (req.query.response_data == undefined || req.query.response_data == "") {
    req.query.response_data = null;
  }
  if (req.query.request_status == undefined || req.query.request_status == "") {
    req.query.request_status = null;
  }
  try {
    await con.query(
      `SELECT * from timesheets.get_qb_logs_filter($1,$2,$3,$4,$5,$6)`,
      [
        req.user.org_id,
        req.query.api_name,
        req.query.full_name,
        req.query.request_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to filter QB logs details";
          returnMessage.error = error;
          returnMessage.label = "get_qb_logs_filter";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data =
            (results.rows && results.rows[0] && results.rows[0].j) || null;
          returnMessage.count =
            (results.rows && results.rows[1] && results.rows[1].j) || null;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_qb_logs_filter";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for Quickbook data by org id
const get_quickbook_config = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  try {
      await con.query(
        `SELECT * from timesheets.get_quickbook_config($1)`,
        [org_id],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch Quickbook Config details";
            returnMessage.error = error;
            returnMessage.label = "get_quickbook_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else if (isEmpty(results.rows[0].j)) {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].j &&
                results.rows[0].j[0]) ||
              null;
            res.status(200).json(returnMessage);
          }
        }
      );
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_quickbook_config";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT or UPDATE api for quickbook_config
const update_quickbook_config = async (req, res) => {
  const returnMessage = getMsgFormat();
  try {
    let org_id = req.user.org_id;
    let createdby = req.user.id;
    const { errors, isValid } = quickbookConfigValidator({...req.body, org_id});
   
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "update_quickbook_config";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let {
          access_token,
          client_id,
          client_secret,
          environment,
          expires_in,
          refresh_token,
          record_type_status='ACTIVE',
          realm_id
        } = req.body;

    let exists_data = await con.query(
      `SELECT timesheets.get_quickbook_config($1)`,
      [org_id]
    );
    exists_data =
      (exists_data &&
        exists_data.rows[0].get_quickbook_config &&
        exists_data.rows[0].get_quickbook_config[0]) ||
      null;
    let id = (exists_data && exists_data.id) || null;

    // console.log("exists_data", JSON.stringify(exists_data));
    if (exists_data && exists_data.id) {
      await con.query(
        `SELECT timesheets.update_qb_authentication($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [
          id,
          access_token,
          client_id,
          client_secret,
          environment,
          expires_in,
          org_id,
          refresh_token,
          record_type_status,
          realm_id,
        ],
        (error, results) => {
          const updated_data = results.rows[1].update_qb_authentication;
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to update";
            returnMessage.error = error;
            returnMessage.label = "update_quickbook_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data = updated_data;
            returnMessage.message = "QuickBooks Config Updated Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    } else {
      await con.query(
        `SELECT timesheets.insert_qb_authentications($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [
          access_token,
          client_id,
          client_secret,
          environment,
          expires_in,
          org_id,
          realm_id,
          refresh_token,
          record_type_status,
        ],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to add";
            returnMessage.error = error;
            returnMessage.label = "update_quickbook_config";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.data =
              (results.rows &&
                results.rows[0] &&
                results.rows[0].insert_qb_authentications &&
                results.rows[0].insert_qb_authentications[0]) ||
              null;
            returnMessage.message = "QuickBooks Config Added Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.error = error;
    returnMessage.label = "update_quickbook_config";
    returnMessage.message = "Error Occured! please try again";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for get_qb_logs_api_names
const get_qb_logs_api_names = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {
    
    let qbLogsApiName = [
      "Select Service Name",
      "findCustomers",
      "updateCustomer",
      "createCustomer",
      "findVendors",
      "createVendor",
      "findEmployees",
      "createEmployee",
      "updateEmployee",
      "findTimeActivities",
      "createTimeActivity",
      "updateTimeActivity",
      "deleteTimeActivity",
      "findItems",
      "createItem",
      "updateItem",
    ];
    returnMessage.isError = false;
    returnMessage.message = "Records Found";
    returnMessage.data = qbLogsApiName;
    res.status(200).json(returnMessage);
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_qb_logs_api_names";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  getcustomerdata,
  getcustomerdatabyname,
  updatecustomerdata,
  addcustomerdata,
  getvendordata,
  getvendordatabyname,
  addvendordata,
  getemployeedata,
  addemployeedata,
  updateemployeedata,
  getemployeedatabyname,
  gettimeactivitydata,
  createtimeactivity,
  gettimeactivitydatabyid,
  updatetimeactivity,
  deletetimeactivity,
  getitemdata,
  createitem,
  getitemdatabyname,
  updateitem,

  get_all_qb_logs,
  get_qb_logs_filter,
  get_quickbook_config,
  update_quickbook_config,
  get_qb_logs_api_names,
};
