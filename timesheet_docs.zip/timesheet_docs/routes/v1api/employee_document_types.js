const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_all_employee_document_types,
  get_employee_document_types_by_id,
  insert_employee_document_type,
  update_employee_document_types,
  delete_employee_document_type,
  get_employee_document_types_list,
} = require("../../controllers/employeeDocumentTypeController");

// @route GET api/v1/employee_document_type/get_all_employee_document_types
// @desc Route to GET get_all_employee_document_types list
// @accesss public
router.get("/get_all_employee_document_types", get_all_employee_document_types);

// @route GET api/v1/employee_document_type/get_employee_document_types_by_id
// @desc Route to GET get_employee_document_types_by_id
// @accesss public
router.get(
  "/get_employee_document_types_by_id",
  get_employee_document_types_by_id
);

// @route POST api/v1/employee_document_type/insert_employee_document_types
// @desc Route to POST employee_document_types data
// @accesss public
router.post("/insert_employee_document_type", insert_employee_document_type);

// @route PUT api/v1/employee_document_type/update_employee_document_types
// @desc Route to PUT employee_document_types data
// @accesss public
router.put("/update_employee_document_types", update_employee_document_types);

// @route PUT api/v1/employee_document_type/delete_employee_document_type
// @desc Route to PUT delete_employee_document_type
// @accesss public
router.put("/delete_employee_document_type", delete_employee_document_type);

// @route GET api/v1/employee_document_type/get_employee_document_types_list
// @desc Route to GET get_employee_document_types_list
// @accesss public
router.get(
  "/get_employee_document_types_list",
  get_employee_document_types_list
);

module.exports = router;
