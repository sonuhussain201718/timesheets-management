const express = require("express");
const router = express.Router();

const authRouter = require("../../middlewares/auth");

const {
  get_all_timesheets_by_user,
  get_single_week_timesheet,
  get_monthly_timesheet_by_user,
  get_timesheet_history,
  get_per_day_timesheet_history,
  save_project_wise_timesheet,
  submit_project_wise_timesheet,
  submit_all_project_timesheets,
  unsubmit_project_wise_timesheet,
  unsubmit_all_project_timesheets,
  get_status_wise_total_hours_by_month,
  get_single_week_approver_timesheet,
  approve_project_wise_timesheet,
  approve_project_wise_single_day_timesheet,
  approve_all_project_timesheets,
  get_status_wise_emp_timesheet_by_month,
  get_status_wise_project_timesheet_by_month,
  reject_project_wise_timesheet,
  reject_project_wise_single_day_timesheet,
  reject_all_project_timesheets,
  revert_project_wise_single_day_timesheet,
  revert_project_wise_timesheet,
  revert_all_project_timesheets,
  get_day_and_dates_by_week,
  send_project_wise_timesheet_to_qb,
  approve_monthly_timesheets,
  reject_monthly_timesheets,
  revert_monthly_timesheets,
  get_multiple_week_timesheet,
  get_single_week_timesheet_by_project,
  get_multiple_week_timesheet_by_project,
  get_status_wise_monthly_emp_timesheet_by_month,
  get_status_wise_monthly_project_timesheet_by_month,
  approve_project_wise_monthly_timesheets,
  reject_project_wise_monthly_timesheets,
  revert_project_wise_monthly_timesheets,
  get_copy_last_week_hours_data,
} = require("../../controllers/timesheetsController");

// @route GET api/v1/timesheets/get_all_timesheets_by_user
// @desc  Route to get all timesheets by user
// @accesss public
router.get("/get_all_timesheets_by_user", get_all_timesheets_by_user);

// @route GET api/v1/timesheets/get_single_week_timesheet
// @desc  Route to get single week timesheet by user and week dates
// @accesss public
router.get("/get_single_week_timesheet", get_single_week_timesheet);

// @route GET api/v1/timesheets/get_monthly_timesheet_by_user
// @desc  Route to get monthly timesheets by user
// @accesss public
router.get("/get_monthly_timesheet_by_user", get_monthly_timesheet_by_user);

// @route GET api/v1/timesheets/get_timesheet_history
// @desc  Route to get timesheet history by week and project
// @accesss public
router.get("/get_timesheet_history", get_timesheet_history);

// @route GET api/v1/timesheets/get_per_day_timesheet_history
// @desc  Route to get per day timesheet history by date and project
// @accesss public
router.get("/get_per_day_timesheet_history", get_per_day_timesheet_history);

// @route POST api/v1/timesheets/save_project_wise_timesheet
// @desc  Route to post save_project_wise_timesheet
// @accesss public
router.post("/save_project_wise_timesheet", save_project_wise_timesheet);

// @route POST api/v1/timesheets/submit_project_wise_timesheet
// @desc  Route to post submit_project_wise_timesheet
// @accesss public
router.post("/submit_all_project_timesheets", submit_all_project_timesheets);

// @route POST api/v1/timesheets/submit_project_wise_timesheet
// @desc  Route to post submit_project_wise_timesheet
// @accesss public
router.post("/submit_project_wise_timesheet", submit_project_wise_timesheet);

// @route POST api/v1/timesheets/unsubmit_project_wise_timesheet
// @desc  Route to post unsubmit_project_wise_timesheet
// @accesss public
router.post(
  "/unsubmit_project_wise_timesheet",
  unsubmit_project_wise_timesheet
);

// @route POST api/v1/timesheets/unsubmit_all_project_timesheet
// @desc  Route to post unsubmit_all_project_timesheet
// @accesss public
router.post(
  "/unsubmit_all_project_timesheets",
  unsubmit_all_project_timesheets
);
// @route GET api/v1/timesheets/get_status_wise_total_hours_by_month
// @desc  Route to get status wise total hours by month
// @accesss public
router.get(
  "/get_status_wise_total_hours_by_month",
  get_status_wise_total_hours_by_month
);

// @route GET api/v1/timesheets/get_single_week_approver_timesheet
// @desc  Route to get single week approver timesheet by user and week dates
// @accesss public
router.get(
  "/get_single_week_approver_timesheet",
  get_single_week_approver_timesheet
);

// @route GET api/v1/timesheets/get_status_wise_emp_timesheet_by_month
// @desc  Route to get status wise empoyee timesheet by month
// @accesss public
router.get(
  "/get_status_wise_emp_timesheet_by_month",
  get_status_wise_emp_timesheet_by_month
);

// @route GET api/v1/timesheets/get_status_wise_project_timesheet_by_month
// @desc  Route to get status wise project timesheet by month
// @accesss public
router.get(
  "/get_status_wise_project_timesheet_by_month",
  get_status_wise_project_timesheet_by_month
);

// @route POST api/v1/timesheets/approve_project_wise_timesheet
// @desc  Route to post approve_project_wise_timesheet
// @accesss public
router.post("/approve_project_wise_timesheet", approve_project_wise_timesheet);

// @route POST api/v1/timesheets/approve_project_wise_single_day_timesheet
// @desc  Route to post approve_project_wise_single_day_timesheet
// @accesss public
router.post(
  "/approve_project_wise_single_day_timesheet",
  approve_project_wise_single_day_timesheet
);

// @route POST api/v1/timesheets/approve_all_project_timesheets
// @desc  Route to post approve_all_project_timesheets
// @accesss public
router.post("/approve_all_project_timesheets", approve_all_project_timesheets);

// @route POST api/v1/timesheets/reject_project_wise_timesheet
// @desc  Route to post reject_project_wise_timesheet
// @accesss public
router.post("/reject_project_wise_timesheet", reject_project_wise_timesheet);

// @route POST api/v1/timesheets/reject_project_wise_single_day_timesheet
// @desc  Route to post reject_project_wise_single_day_timesheet
// @accesss public
router.post(
  "/reject_project_wise_single_day_timesheet",
  reject_project_wise_single_day_timesheet
);

// @route POST api/v1/timesheets/reject_all_project_timesheets
// @desc  Route to post reject_all_project_timesheets
// @accesss public
router.post("/reject_all_project_timesheets", reject_all_project_timesheets);

// @route POST api/v1/timesheets/revert_project_wise_single_day_timesheet
// @desc  Route to post revert project wise single day timesheet
// @accesss public
router.post(
  "/revert_project_wise_single_day_timesheet",
  revert_project_wise_single_day_timesheet
);

// @route POST api/v1/timesheets/revert_project_wise_timesheet
// @desc  Route to post revert project wise timesheet
// @accesss public
router.post("/revert_project_wise_timesheet", revert_project_wise_timesheet);

// @route POST api/v1/timesheets/revert_all_project_timesheets
// @desc  Route to post revert all project wise timesheet
// @accesss public
router.post("/revert_all_project_timesheets", revert_all_project_timesheets);


// @route POST api/v1/timesheets/get_day_and_dates_by_week
// @desc  Route to post get_day_and_dates_by_week
// @accesss public
router.get("/get_day_and_dates_by_week", get_day_and_dates_by_week);


// @route POST api/v1/timesheets/send_project_wise_timesheet_to_qb
// @desc  Route to post send_project_wise_timesheet_to_qb
// @accesss public
router.post("/send_project_wise_timesheet_to_qb", send_project_wise_timesheet_to_qb);


// @route POST api/v1/timesheets/approve_monthly_timesheets
// @desc  Route to post approve_monthly_timesheets
// @accesss public
router.post("/approve_monthly_timesheets", approve_monthly_timesheets);

// @route POST api/v1/timesheets/reject_monthly_timesheets
// @desc  Route to post reject_monthly_timesheets
// @accesss public
router.post("/reject_monthly_timesheets", reject_monthly_timesheets);

// @route POST api/v1/timesheets/revert_monthly_timesheets
// @desc  Route to post revert_monthly_timesheets
// @accesss public
router.post("/revert_monthly_timesheets", revert_monthly_timesheets);

// @route GET api/v1/timesheets/get_multiple_week_timesheet
// @desc  Route to get single week timesheet by user and week dates
// @accesss public
router.get("/get_multiple_week_timesheet", get_multiple_week_timesheet);

// @route GET api/v1/timesheets/get_single_week_timesheet_by_project
// @desc  Route to get single week timesheet by user, project and week dates
// @accesss public
router.get("/get_single_week_timesheet_by_project", get_single_week_timesheet_by_project);

// @route GET api/v1/timesheets/get_multiple_week_timesheet_by_project
// @desc  Route to get multiple week timesheet by user, project and week dates
// @accesss public
router.get("/get_multiple_week_timesheet_by_project", get_multiple_week_timesheet_by_project);

// @route GET api/v1/timesheets/get_status_wise_monthly_emp_timesheet_by_month
// @desc  Route to get status wise monthly empoyee timesheet by month
// @accesss public
router.get("/get_status_wise_monthly_emp_timesheet_by_month", get_status_wise_monthly_emp_timesheet_by_month);


// @route GET api/v1/timesheets/get_status_wise_monthly_project_timesheet_by_month
// @desc  Route to get status wise monthly project timesheet by month
// @accesss public
router.get("/get_status_wise_monthly_project_timesheet_by_month", get_status_wise_monthly_project_timesheet_by_month);


// @route POST api/v1/timesheets/approve_project_wise_monthly_timesheets
// @desc  Route to post approve_project_wise_monthly_timesheets
// @accesss public
router.post("/approve_project_wise_monthly_timesheets", approve_project_wise_monthly_timesheets);

// @route POST api/v1/timesheets/reject_project_wise_monthly_timesheets
// @desc  Route to post reject_project_wise_monthly_timesheets
// @accesss public
router.post("/reject_project_wise_monthly_timesheets", reject_project_wise_monthly_timesheets);

// @route POST api/v1/timesheets/revert_project_wise_monthly_timesheets
// @desc  Route to post revert_project_wise_monthly_timesheets
// @accesss public
router.post("/revert_project_wise_monthly_timesheets", revert_project_wise_monthly_timesheets);

// @route get api/v1/timesheets/get_copy_last_week_hours_data
// @desc  Route to get copy_last_week_hours_data
// @accesss public
router.get("/get_copy_last_week_hours_data", get_copy_last_week_hours_data);

module.exports = router;
