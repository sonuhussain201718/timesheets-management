const { getMsgFormat, isEmpty } = require("../utils/helpers");
const con = require("../utils/db");
const logger = require("../utils/logger");
const moment = require("moment");
const getTimesheetHoursValidator = require("../validation/getTimesheetHoursValidator");

const {
  ALLOWED_PAST_ENTRY_DAYS,
  DEFAULT_ECDB_TOOL_NAME,
  PROJECTS_STATUS,
  TIMESHEET_STATUS
} = require("../constants");

// GET API for gettimesheethoursincludingnorecords (With old response format like HRMS)
const gettimesheethoursincludingnorecords = async (req, res) => {

  const returnMessage = getMsgFormat();

  const { errors, isValid } = getTimesheetHoursValidator(req.body);

  let response_data = {};

  try {    

    let {
      org_id = null,
      start_date = null,
      end_date = null,
      ecdb_user_id = null,
      placement_project_id = null,
    } = req.body;

    if (req.body.org_id == undefined || req.body.org_id == "") {
      req.body.org_id = null;
      org_id = null;
    }
  
    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.error = errors;
      returnMessage.label = "get_timesheet_hours_including_no_entries";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }
    else{

      let employees_list = null;

      let tmp_start_date = `${start_date}T00:00:00Z`;
      let tmp_end_date = `${end_date}T00:00:00Z`;

      let range = moment().range(moment(tmp_start_date), moment(tmp_end_date));

      let days = range.by("days");
      var dates = [...days].map((date) => date.format("YYYY-MM-DD"));
      // console.log("dates", dates);
      
      if (ecdb_user_id == undefined || ecdb_user_id == "") {
        ecdb_user_id = null;
      }
      if (placement_project_id == undefined || placement_project_id == "") {
        placement_project_id = null;
      }
  
      employees_list = await con.query(`SELECT * from timesheets.get_employees_for_accounts_api($1,$2)`, 
      [org_id, ecdb_user_id]);
      employees_list = (employees_list && employees_list.rows && employees_list.rows[0] && employees_list.rows[0].j) || null;

      if (employees_list && employees_list.length) {

        for(var i = 0; i < employees_list.length; i++){
          let empRow = employees_list[i];
          org_id = empRow.org_id;
          let { leaving_date = null } = empRow;

          // console.log("empRow", empRow);
          let empObj =  {
            emp_id: empRow.id,
            hrmsEmployeeId: empRow.employee_id,
            ecdb_user_id: empRow.ecdb_user_id,
            prospective_user_id: empRow.prospective_user_id,
            userfullname: empRow.full_name,
          };

          let projects = await con.query(`SELECT * from timesheets.get_timesheets_by_user_for_accounts_api($1,$2,$3,$4,$5)`,  [org_id, empRow.id, placement_project_id, start_date, end_date ]);
          projects = (projects && projects.rows && projects.rows[0] && projects.rows[0].j) || null;

          // if(empRow.id == 207){
          //   console.log("projects", projects);
          // }

          let tmp_projects = {};
          if(projects && projects.length){

            for(var j = 0; j < projects.length; j++){
              
              let { id:project_id, placement_project_id, project_name, project_status, start_date: project_start_date, end_date: project_end_date, cancel_date: project_cancel_date, timesheet_data = null } = projects[j];

              let tsp_project_start_date = null;
              let tsp_project_end_date = null;
              let tsp_project_cancel_date = null;
              let tsp_leaving_date = null;

              if(project_start_date){
                let tmp_project_start_date = moment(project_start_date).startOf("day");
                tsp_project_start_date = tmp_project_start_date.unix() || null;
              }

              if(project_status == PROJECTS_STATUS.COMPLETED && project_end_date){
                let tmp_project_end_date = moment(project_end_date).startOf("day");
                tsp_project_end_date = tmp_project_end_date.unix();
              }
              if(project_status == PROJECTS_STATUS.CANCELLED && project_cancel_date){
                let tmp_project_cancel_date = moment(project_cancel_date).startOf("day");
                tsp_project_cancel_date = tmp_project_cancel_date.unix();
              }
              
              if(leaving_date){
                let tmp_leaving_date = moment(leaving_date).startOf("day");
                tsp_leaving_date = tmp_leaving_date.unix() || null;
              }

              let projectObj = {
                project_id: project_id, 
                placement_project_id: placement_project_id || 0, 
                project_name: project_name,
                timesheet_data: null,
              };
              // if(empRow.id == 207){
              //   console.log("timesheet_data", timesheet_data);
              // }
              let tmp_timesheets = {};
               
              // if(timesheet_data && timesheet_data.length){

                if (dates && dates.length) {
                  for (var dateI = 0; dateI < dates.length; dateI++) {

                    let timesheet_date = dates[dateI];
                    let tmp_ts_date = moment(timesheet_date).startOf("day");
                    let tsp_timesheet_date = tmp_ts_date.unix();
                    // console.log("tsp_timesheet_date", tmp_ts_date, tsp_timesheet_date )

                    let tmp_timesheet_id = `${empRow.employee_id}_${project_id}_${timesheet_date}`;

                    let timesheetRow = (timesheet_data && timesheet_data.length && timesheet_data.filter((row)=> {
                      return  row.timesheet_date == timesheet_date;
                    })[0]) || {};

                    // console.log("timesheet_date", timesheet_date, timesheetRow);
                    let { regular_hours = 0, regular_minutes = 0,  ot_hours = 0, ot_minutes = 0,  absent_hours = 0, absent_minutes = 0, status = "NO_ENTRY", payroll_synced = false } = timesheetRow;
                    let record_exists = false;
                    
                    if(timesheetRow && timesheetRow.id){
                      record_exists = true;
                    }

                    // don't return already synced records in response
                    if(timesheetRow && timesheetRow.payroll_synced != true){
                      // show timesheet within project start and end date
                      if((!tsp_project_start_date || (tsp_timesheet_date >= tsp_project_start_date)) && (!tsp_project_end_date || (tsp_timesheet_date <= tsp_project_end_date)) && (!tsp_project_cancel_date || (tsp_timesheet_date <= tsp_project_cancel_date)) && (!tsp_leaving_date || (tsp_timesheet_date <= tsp_leaving_date))){

                        let project_bill_rates = await con.query(`SELECT * from timesheets.get_project_bill_rate_by_date($1,$2,$3)`,  [org_id, project_id, timesheet_date]);
                        project_bill_rates = (project_bill_rates && project_bill_rates.rows && project_bill_rates.rows[0] && project_bill_rates.rows[0].j && project_bill_rates.rows[0].j[0]) || null;

                        // console.log("project_bill_rates", project_bill_rates);
                        let date=new Date(timesheet_date);
                        let day=date.getDate();
                        if(status=='NO_ENTRY'){
                          if(day==1 || day ==16){
                            tmp_timesheets[timesheet_date] = {
                              date: timesheet_date,
                              tmp_timesheet_id: tmp_timesheet_id,
                              payroll_synced: payroll_synced,
                              record_exists: record_exists,
                              agreedPayRate: (project_bill_rates && project_bill_rates.agreed_pay_rate) || null,
                              otPayRate: (project_bill_rates && project_bill_rates.ot_agreed_pay_rate) || null,
                              // regular_hours: regular_hours,
                              // regular_minutes: regular_minutes,
                              // ot_hours: ot_hours,
                              // ot_minutes: ot_minutes,
                              // absent_hours: absent_hours,
                              // absent_minutes: absent_minutes,
                              hours: `${(regular_hours || `00`)}:${(regular_minutes || `00`)}`,
                              ot_hours: `${(ot_hours || `00`)}:${(ot_minutes || `00`)}`,
                              absent_hours: `${(absent_hours || `00`)}:${(absent_minutes || `00`)}`,
                              status: status
                            }
                          }
                        }else{
                          tmp_timesheets[timesheet_date] = {
                            date: timesheet_date,
                            tmp_timesheet_id: tmp_timesheet_id,
                            payroll_synced: payroll_synced,
                            record_exists: record_exists,
                            agreedPayRate: (project_bill_rates && project_bill_rates.agreed_pay_rate) || null,
                            otPayRate: (project_bill_rates && project_bill_rates.ot_agreed_pay_rate) || null,
                            // regular_hours: regular_hours,
                            // regular_minutes: regular_minutes,
                            // ot_hours: ot_hours,
                            // ot_minutes: ot_minutes,
                            // absent_hours: absent_hours,
                            // absent_minutes: absent_minutes,
                            hours: `${(regular_hours || `00`)}:${(regular_minutes || `00`)}`,
                            ot_hours: `${(ot_hours || `00`)}:${(ot_minutes || `00`)}`,
                            absent_hours: `${(absent_hours || `00`)}:${(absent_minutes || `00`)}`,
                            status: status
                          }
                        }
                       
                      }
                    }
                  }
                }
              // }

              projectObj["timesheet_data"] = tmp_timesheets;
              tmp_projects[project_id] = projectObj;

              await con.query(`SELECT * from timesheets.update_timesheet_mark_synced($1,$2,$3,$4)`,  [org_id, project_id, start_date, end_date]);
            }

          }

          // if employee is having project then only add employee in reponse
          if(projects && projects.length){
            empObj["timesheet"] = tmp_projects;
            response_data[empRow.id] = empObj;
          }

          
        }

        returnMessage.isError = false;
        returnMessage.data = response_data;
        returnMessage.message = "Records found";
        returnMessage.label = "get_timesheet_hours_including_no_entries";
        res.status(200).json(returnMessage);
  
      } else {
        
        returnMessage.isError = true;
        returnMessage.message = "No record found!";
        // returnMessage.error = error;
        returnMessage.label = "get_timesheet_hours_including_no_entries";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      }
    }

  } catch (error) {
    // console.log("error", error)
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_timesheet_hours_including_no_entries";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  gettimesheethoursincludingnorecords,
};