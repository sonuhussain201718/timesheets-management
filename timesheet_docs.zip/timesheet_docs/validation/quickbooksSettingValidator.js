const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function quickbooksSettingValidator(data) {
  let errors = {};

  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }

  if (data.enable_quickbooks == undefined) {
    errors.enable_quickbooks = "enable_quickbooks field is required";
  }

  if (!data.qb_transactions_setting || !data.qb_transactions_setting.length) {
    errors.end_date = "qb_transactions_setting field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
