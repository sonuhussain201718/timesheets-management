const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createAnnoucementValidator(data) {
  let errors = {};

  if (validator.isEmpty(data.title)) {
    errors.title = "title is invalid";
  }

  if (validator.isEmpty(data.description)) {
    errors.description = "description is invalid";
  }

  if (validator.isEmpty(String(data.org_id))) {
    errors.org_id = "org_id field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
