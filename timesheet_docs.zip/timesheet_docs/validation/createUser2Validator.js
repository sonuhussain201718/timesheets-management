const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function createUserValidator(data) {
  let errors = {};

  // if (data.hasOwnProperty("id") && !data.id) {
  //   errors.id = "id field is required";
  // }

  if (!data.org_id) {
    errors.org_id = "org_id field is required";
  }

  if (validator.isEmpty(data.email)) {
    errors.email = "email field is required";
  }

  if (!data.ecdb_user_id) {
    errors.ecdb_user_id = "ecdb_user_id field is required";
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
