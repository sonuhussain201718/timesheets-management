const validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function approveMonthlyTimesheetValidator(data) {
  let errors = {};

  if (validator.isEmpty(String(data.org_id))) {
    errors.org_id = "org_id field is required";
  }

  if (!data.user_id) {
    errors.user_id = "user_id field is required";
  }

  // if (!data.approver_notes) {
  //   errors.approver_notes = "approver_notes field is required";
  // }

  /* if (!data.timesheet_data || !data.timesheet_data.length) {
    errors.timesheet_data = "timesheet_data field is required";
  } */

  return {
    errors,
    isValid: isEmpty(errors),
  };
};
