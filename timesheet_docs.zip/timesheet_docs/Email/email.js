const nodemailer = require("nodemailer");
const aws = require("@aws-sdk/client-ses");
const isEmpty = require("../validation/is-empty");
const con = require("../utils/db");
const approvedEmailTemplate = require("../Template/approve");
const approvedSingleDayEmailTemplate = require("../Template/approved_single_day");
const organizationsSyncEmailTemplate = require("../Template/organizations_sync");
const usersSyncEmailTemplate = require("../Template/users_sync");
const projectsSyncEmailTemplate = require("../Template/projects_sync");
const rejectedEmailTemplate = require("../Template/reject");
const rejectedSingleDayEmailTemplate = require("../Template/reject_single_day");
const approvedMonthlyEmailTemplate = require("../Template/approve_monthly");
const rejectedMonthlyEmailTemplate = require("../Template/reject_monthly");
const submittedEmailTemplate = require("../Template/submit");
const pendingEmailTemplate = require("../Template/pending");

const projectUpdatedEmailTemplate = require("../Template/project_updated");
const employeeUpdatedEmailTemplate = require("../Template/employee_updated");
const weeklyReminderEmailTemplate = require("../Template/weekly_reminder");
const sgMail = require('@sendgrid/mail');

const logger = require("../utils/logger");
const { getMsgFormat } = require("../utils/helpers");

async function getOrgName(org_id = null) {

  let org_name = ``;
  if(org_id){
    let org_data = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);
    
    org_data = (org_data && org_data.rows[0].get_organizations_by_orgid && org_data.rows[0].get_organizations_by_orgid[0]) || null;
    if(org_data && org_data.org_name){
      org_name = org_data.org_name;
    };
  }
  return org_name;
}

async function getOrgData(org_id = null) {

  let org_data = null;
  if(org_id){
    
    org_data = await con.query(`SELECT timesheets.get_organizations_by_orgid($1)`,
    [org_id]);

    org_data = (org_data && org_data.rows[0].get_organizations_by_orgid && org_data.rows[0].get_organizations_by_orgid[0]) || null;

  }
  return org_data;
}

async function ApprovedEmailToEmployee(data) {
  
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);
    
    let mailTemplate = approvedEmailTemplate.approvedEmailTemplate({...data, org_name, week_range});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Timesheet Approved for week ${week_range}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function ApprovedSingleDayEmailToEmployee(data) {
  
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let timesheet_date = (data && data.timesheet_date) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);

    let mailTemplate = approvedSingleDayEmailTemplate.approvedSingleDayEmailTemplate({...data, org_name, week_range});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Timesheet Approved for date ${timesheet_date}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function RejectedEmailToEmployee(data) {

  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);

    let mailTemplate = rejectedEmailTemplate.rejectedEmailTemplate({...data, org_name, week_range});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Timesheet Rejected for week ${week_range}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function ApprovedMonthlyEmailToEmployee(data) {
  let year = (data && data.year) || null;
  let monthName = (data && data.monthName) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;

  let result = null;

  if (employee_email) {

    let org_name = await getOrgName(data.org_id);

    let mailTemplate =
      approvedMonthlyEmailTemplate.approvedMonthlyEmailTemplate({ ...data, org_name });
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Timesheet Approved for the month of ${monthName}, ${year}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function RejectedMonthlyEmailToEmployee(data) {

  let year = (data && data.year) || null;
  let monthName = (data && data.monthName) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);

    let mailTemplate = rejectedMonthlyEmailTemplate.rejectedMonthlyEmailTemplate({...data, org_name});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Timesheet Rejected for the month of ${monthName}, ${year}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function RejectedSingleDayEmailToEmployee(data) {

  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let timesheet_date = (data && data.timesheet_date) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let approver_notes = (data && data.approver_notes) || ``;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);

    let mailTemplate = rejectedSingleDayEmailTemplate.rejectedSingleDayEmailTemplate({...data, org_name, week_range});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Timesheet Rejected for date ${timesheet_date}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function SubmittedEmailToApprovers(data = {}) {

  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let approver_email = (data && data.approver_email) || null;
  let employee_name = (data && data.employee_name) || null;
  
  let result = null;
  
  if(approver_email){

    let org_name = await getOrgName(data.org_id);

    let mailTemplate = submittedEmailTemplate.submittedEmailTemplate({...data, org_name, week_range});
    let mailOptions = {
      org_id: data.org_id,
      to: approver_email,
      subject: `Timesheets - Timesheet Submitted By ${employee_name} For the Week ${week_range}`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function PendingEmail(data) {
  const email = data.user_email;

  let org_name = await getOrgName(data.org_id);

  var mailTemplate = pendingEmailTemplate.PendingEmailTemplate({...data, org_name});
  var mailOptions = {
    from: "hradmin@msrcosmos.com",
    to: email,
    subject: "Timesheet Status Email",
    html: mailTemplate,
  };
  sendTimesheetEmail(mailOptions);
}

async function TestEmail(data) {
  const to = data.user_email;
  var subject = 'test email';
  var mailTemplate = 'This is test email';

  var mailOptions = {
    org_id: data.org_id,
    to: to,
    subject: subject,
    html: mailTemplate,
  };
  sendTimesheetEmail(mailOptions);
}

async function OrganizationsSyncEmail(data) {
  
  let email = process.env.ADMIN_EMAIL;

  let global_config_data = await con.query(`SELECT timesheets.get_global_config()`, []);
  global_config_data = (global_config_data && global_config_data.rows[0].get_global_config && global_config_data.rows[0].get_global_config[0]) || null;
  if(global_config_data && global_config_data.notify_to_email){
    email = global_config_data.notify_to_email;
  };
  
  if(global_config_data && global_config_data.notification_enabled){

    let mailTemplate = organizationsSyncEmailTemplate.organizationsSyncEmailTemplate(data);
    let mailOptions = {
      org_id: data.org_id,
      to: email,
      subject: "Timesheets - Organizations Data Synced",
      html: mailTemplate,
    };
    var info = await sendEmail(mailOptions);
    return info;
  }
  else{
    return false;
  }
}

async function UsersSyncEmail(data) {
  
  // let email = process.env.ADMIN_EMAIL;
  let email = null;
  let org_data = await getOrgData(data.org_id);

  if(org_data && org_data.notify_to_email && org_data.notification_enabled){
    email = org_data.notify_to_email;
  };

  let org_name = (org_data && org_data.org_name) || null;

  if(org_data && org_data.notify_to_email && org_data.notification_enabled){

    let mailTemplate = usersSyncEmailTemplate.usersSyncEmailTemplate({...data, org_name});
    let mailOptions = {
      org_id: data.org_id,
      to: email,
      subject: `Timesheets - ${(org_name && `${org_name} - `) || ``} Users Data Synced`,
      html: mailTemplate,
    };
    var info = await sendEmail(mailOptions);
    return info;
  }
  else{
    return false;
  }
}

async function ProjectsSyncEmail(data) {
  
  // let email = process.env.ADMIN_EMAIL;
  let email = null;
  let org_data = await getOrgData(data.org_id);
  
  if(org_data && org_data.notify_to_email && org_data.notification_enabled){
    email = org_data.notify_to_email;
  };

  let org_name = (org_data && org_data.org_name) || null;

  if(org_data && org_data.notify_to_email && org_data.notification_enabled){

    let mailTemplate = projectsSyncEmailTemplate.projectsSyncEmailTemplate({...data, org_name});
    let mailOptions = {
      org_id: data.org_id,
      to: email,
      subject: `Timesheets - ${(org_name && `${org_name} - `) || ``} Projects Data Synced`,
      html: mailTemplate,
    };
    var info = await sendEmail(mailOptions);
    return info;
  }
  else{
    return false;
  }
}

async function sendTimesheetEmail(data) {

  var info = await sendEmail(data);
  return info;
}

async function sendEmail(data = null) {

  // console.log("data", data);
  const returnMessage = getMsgFormat();

  if (!isEmpty(data) && data.hasOwnProperty("to") && data.hasOwnProperty("html")) {
    
    if (!data.hasOwnProperty("subject")) {
      data.subject = "Email from Unified console";
    }

    let ses = null;
    let { org_id = null } = data || null;
    
    try{
      
      if(org_id){

        let email_config = await con.query( `SELECT timesheets.get_email_config_by_org_id($1)`,[org_id] );
        email_config = (email_config && email_config.rows[0].get_email_config_by_org_id && email_config.rows[0].get_email_config_by_org_id[0] ) || null;
  
        if(email_config && email_config.from_email){
          data.from = email_config.from_email;
        }
        else{
          // data.from = process.env.AWS_SES_FROM_EMAIL;
          data.from = process.env.SENDGRID_FROM_EMAIL;
        }
        
      }
      else{
        // data.from = process.env.AWS_SES_FROM_EMAIL;
        data.from = process.env.SENDGRID_FROM_EMAIL;
      }
    
      // Send Email Using AWS
      // console.log("data", data);
      // ses = await new aws.SES({
      //   apiVersion: process.env.AWS_SES_VERSION,
      //   region: process.env.AWS_SES_REGION,
      //   credentials: {
      //     accessKeyId: process.env.AWS_SES_ACCESS_KEY,
      //     secretAccessKey: process.env.AWS_SES_SECRET,
      //   },
      // });

      // var transporter = await nodemailer.createTransport({
      //   SES: { ses, aws },
      // });

      // // send mail with defined transport object
      // var info = await transporter.sendMail(data);
      // // console.log("mail sent successfully", info);
      // return info;

      // send email using SendGrid
      sgMail.setApiKey(process.env.SENDGRID_API_KEY);
      const emailOptions = {
        to: data.to,
        from: data.from, // Use the email address or domain you verified above
        subject: data.subject,
        text: 'Email from timesheets portal',
        html: data.html,
      };
      let emailResponse = await sgMail.send(emailOptions);
      console.log("mail sent successfully", emailResponse);
      return emailResponse;
    }
    catch (error) {
      
      // if (error.response) {
      //   console.error(error.response.body)
      // }

      returnMessage.isError = true;
      returnMessage.error = error;
      returnMessage.message = "Failed to send email";
      returnMessage.label = "sendEmail";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      
      // console.log("Error sending email. error ", error);
    }
  }
  else {
    returnMessage.isError = true;
    returnMessage.error = data;
    returnMessage.message = "Incorrect email data";
    returnMessage.label = "sendEmail";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    // console.log(`Incorrect email data`, data );
  }
}

async function ProjectUpdatedEmailToEmployee(data) {
  
  let project_name = (data && data.project_name) || null;
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);
    
    let mailTemplate = projectUpdatedEmailTemplate.projectUpdatedEmailTemplate({...data, org_name, project_name});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Project Details Updated`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}


async function EmployeeUpdatedEmailToEmployee(data) {
  
  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);
    
    let mailTemplate = employeeUpdatedEmailTemplate.employeeUpdatedEmailTemplate({...data, org_name});
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Consultant Details Updated`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

async function WeeklyReminderEmailToEmployee(data) {

  let employee_name = (data && data.employee_name) || null;
  let employee_email = (data && data.employee_email) || null;
  let week_start_date = (data && data.week_start_date) || null;
  let week_end_date = (data && data.week_end_date) || null;
  let week_range = `${week_start_date} - ${week_end_date}`;
  let unsubmitted_dates = (data && data.unsubmitted_dates) || null;
  unsubmitted_dates = (unsubmitted_dates && unsubmitted_dates.length && unsubmitted_dates.map((d)=>{
    return `<strong>${d}</strong><br/>`;
  })).join(` `) || ``;

  // console.log("unsubmitted_dates", unsubmitted_dates)
  
  let result = null;
  
  if(employee_email){

    let org_name = await getOrgName(data.org_id);
    
    let mailTemplate = weeklyReminderEmailTemplate.weeklyReminderEmailTemplate({...data, org_name, week_range, unsubmitted_dates});
    // console.log("mailTemplate", mailTemplate);
    let mailOptions = {
      org_id: data.org_id,
      to: employee_email,
      subject: `Timesheets - Weekly Timesheet Reminder`,
      html: mailTemplate,
    };
    result = await sendEmail(mailOptions);
  }
  return result;
}

module.exports = {
  sendTimesheetEmail,
  ApprovedEmailToEmployee,
  ApprovedSingleDayEmailToEmployee,
  RejectedEmailToEmployee,
  ApprovedMonthlyEmailToEmployee,
  RejectedMonthlyEmailToEmployee,
  RejectedSingleDayEmailToEmployee,
  SubmittedEmailToApprovers,
  PendingEmail,
  TestEmail,
  UsersSyncEmail,
  OrganizationsSyncEmail,
  ProjectsSyncEmail,
  ProjectUpdatedEmailToEmployee,
  EmployeeUpdatedEmailToEmployee,
  WeeklyReminderEmailToEmployee
};
