const pg = require("pg");
var config = {
  user: process.env.PGUSER,
  host: process.env.PGHOST,
  database: process.env.PGDATABASE,
  password: process.env.PGPASSWORD,
  port: process.env.PGPORT,
  
};

if (process.env.NODE_ENV === "production" || process.env.NODE_ENV === "development") {
  // to disable ssl check
  var config = {
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT,
    // to disable ssl check
    ssl: {
      // cert: fs.readFileSync("<the cert path>"),
      rejectUnauthorized: false,
    },
  };
}

const pool = new pg.Pool(config);
module.exports = pool;
