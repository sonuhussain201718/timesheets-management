const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const createEmployeeDocumentValidator = require("../validation/createEmployeeDocumentValidator");
const con = require("../utils/db");
const logger = require("../utils/logger");
const moment = require("moment");
const { BlobServiceClient } = require("@azure/storage-blob");
const { v1: uuidv1 } = require("uuid");
const fs = require("fs");
var mime = require("mime-types");
const excelJS = require("exceljs");
const path = require("path");
const {
  getOrgData,
} = require("../utils/timesheet_helpers");
const {
  titleCaseForHyphen,
  
} = require("../utils/helpers");

// GET api to get_all_employee_documents
const get_all_employee_documents = async (req, res) => {

  const returnMessage = getMsgFormat();
  const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;

  let org_id = req.user.org_id;
  let keyword = req.query.keyword;

  if (keyword) {
    req.query.user_id = null;
    req.query.document_type_name = null;
    req.query.record_type_status = null;
  }
  else{

    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
      req.query.user_id = null;
    }
    if(req.query.document_type_name == undefined || req.query.document_type_name == "") {
      req.query.document_type_name = null;
    }
    if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
      req.query.record_type_status = null;
    }
  }
  
  if (req.query.pagenumber == undefined || req.query.pagenumber == "") {
    req.query.pagenumber = null;
  }
  if (req.query.pagesize == undefined || req.query.pagesize == "") {
    req.query.pagesize = null;
  }
  

  try {

    await con.query(
      `SELECT * from timesheets.get_all_employee_documents($1,$2,$3,$4,$5,$6,$7);`,
      [
        org_id,
        req.query.keyword,
        req.query.user_id,
        req.query.document_type_name,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch employee documents";
          returnMessage.error = error;
          returnMessage.label = "get_all_employee_documents";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {

          if (results) {
            let data = (results.rows && results.rows[0] && results.rows[0].j) || null;
            let count = (results.rows && results.rows[1] && results.rows[1].j) || null;

            if (data && data.length) {
              for (var i = 0; i < data.length; i++) {
                let row = data[i];
                if (row.document_file) {
                  // console.log("row", row);
    
                  if(row.hrms_doc_id){
                    data[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/hrms_employeedocs/${row.document_file}`, true );
                    data[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/hrms_employeedocs/${row.document_file}` );
                  }
                  else{
                    
                    data[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/employee_documents/${row.document_file}`, true );

                    data[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/employee_documents/${row.document_file}` );
                  }
                  
                }
              }
            }

            

            returnMessage.isError = false;
            returnMessage.message = "Records Found";
            returnMessage.data = data;
            returnMessage.count = count;
            res.status(200).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_employee_documents";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api for export_all_employee_documents
const export_all_employee_documents = async (req, res) => {

  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  let keyword = req.query.keyword;

  if (keyword) {
    req.query.user_id = null;
    req.query.document_type_name = null;
    req.query.record_type_status = null;
  }
  else{

    req.query.keyword = null;

    if (req.query.user_id == undefined || req.query.user_id == "") {
      req.query.user_id = null;
    }
    if(req.query.document_type_name == undefined || req.query.document_type_name == "") {
      req.query.document_type_name = null;
    }
    if (req.query.record_type_status == undefined || req.query.record_type_status == "") {
      req.query.record_type_status = null;
    }
  }

  try {
    await con.query(
      `SELECT * from timesheets.export_all_employee_documents($1,$2,$3,$4,$5);`,
      [
        org_id,
        req.query.keyword,
        req.query.user_id,
        req.query.document_type_name,
        req.query.record_type_status
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_employee_documents";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          
          results = (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {
            for (var i = 0; i < results.length; i++) {
             
            }
          }

          if (results && results.length) {
            
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportEmployeeDocumentsData");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              {
                header: "Document Type",
                key: "document_type_name",
                width: 10,
              },
              { header: "CONSULTANT NAME", key: "full_name", width: 10 },
            ];

            for (i = 0; i < results.length; i++) {
              
              row = results[i];

              let tmpRow = [
                row.document_type_name,
                row.full_name,
              ];
              
              tmpRow = [...tmpRow];

              worksheet.addRow(tmpRow); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/exports/employee_documents"
            );
            let fileName = `employee-documents-list-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/exports/employee_documents/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {
                let orgData = await getOrgData(org_id);
                let newFileName  = `employee-documents-list-${((orgData && orgData.org_name) || ``)}.xlsx`
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/exports/employee_documents/${fileName}`,
                  false,
                  newFileName
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);
              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_all_employee_documents";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api to get_employee_document_by_id

const get_employee_document_by_id = async (req, res) => {

  const returnMessage = getMsgFormat();
  const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;

  try {

    if (!req.query.id) {
      returnMessage.isError = true;
      returnMessage.message = "Invalid Parameters";
      returnMessage.error = "id can not be null or empty";
      returnMessage.label = "get_employee_document_by_id";
      logger.log({
        level: "errr",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    } else {

      await con.query(
        `SELECT * from timesheets.get_employee_document_by_id($1,$2)`,
        [req.user.org_id, req.query.id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch details";
            returnMessage.error = error;
            returnMessage.label = "get_employee_document_by_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            // console.log("results", results, results.rows)
            data = (results.rows && results.rows[0] && results.rows[0].j && results.rows[0].j[0]) ||
              null;


            if (data) {

                if (data.document_file) {
                  // console.log("row", row);
    
                  if(data.hrms_doc_id){
                    data.blobUrl = getBlobUrl(containerName, `${data.org_id}/hrms_employeedocs/${data.document_file}`, true );
                    data.blobDownloadUrl = getBlobUrl(containerName, `${data.org_id}/hrms_employeedocs/${data.document_file}` );
                  }
                  else{
                    
                    data.blobUrl = getBlobUrl(containerName, `${data.org_id}/${data.user_id}/employee_documents/${data.document_file}`, true );

                    data.blobDownloadUrl = getBlobUrl(containerName, `${data.org_id}/${data.user_id}/employee_documents/${data.document_file}` );
                  }
                  
                }
              
              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employee_document_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// GET api to get_employee_documents_by_user_id

const get_employee_documents_by_user_id = async (req, res) => {

  const returnMessage = getMsgFormat();
  const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;

  try {
    if(!req.query.user_id){
      returnMessage.isError=true
      returnMessage.message="Invalid Parameters"
      returnMessage.error="user_id can not be null or empty"
      returnMessage.label = "get_employee_documents_by_user_id";
      logger.log({
        level:'error',
        message:returnMessage
      })
      return res.status(400).json(returnMessage)
    }
    else{
      await con.query(
        `SELECT * from timesheets.get_employee_documents_by_user_id($1,$2)`,
        [req.user.org_id, req.query.user_id],
        async (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to fetch details";
            returnMessage.error = error;
            returnMessage.label = "get_employee_documents_by_user_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            data = (results.rows && results.rows[0] && results.rows[0].j) || null;

            if (data && data.length) {

              for (var i = 0; i < data.length; i++) {
                  let row = data[i];
                  if (row.document_file) {
                    // console.log("row", row);
      
                    if(row.hrms_doc_id){
                      data[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/hrms_employeedocs/${row.document_file}`, true );
                      data[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/hrms_employeedocs/${row.document_file}` );
                    }
                    else{
                      
                      data[i].blobUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/employee_documents/${row.document_file}`, true );
  
                      data[i].blobDownloadUrl = getBlobUrl(containerName, `${row.org_id}/${row.user_id}/employee_documents/${row.document_file}` );
                    }
                    
                  }
                }

              returnMessage.isError = false;
              returnMessage.message = "Records Found";
              returnMessage.data = data;
              res.status(200).json(returnMessage);
            } else {
              returnMessage.isError = false;
              returnMessage.message = "No Records Found";
              res.status(200).json(returnMessage);
            }
          }
        }
      );
    }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_employee_documents_by_user_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// INSERT api to insert_employee_document
const insert_employee_document = async (req, res) => {
  const returnMessage = getMsgFormat();

  try {
    let org_id = req.user.org_id;
    const { errors, isValid } = createEmployeeDocumentValidator({ ...req.body, org_id });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "insert_employee_document";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let {
      employee_document_type_id = null,
      user_id = null,
    } = req.body;
    let record_type_status = "Active";

    let createdby = req.user.id;
    let updatedby = req.user.id;


    if (req.files && req.files.document_file) {

        var uploaded_file = {};

        req.files.document_file = !req.files.document_file.length ? req.files.document_file : req.files.document_file[0];

        const AZURE_STORAGE_CONNECTION_STRING = process.env.AZURE_STORAGE_CONNECTION_STRING;
        if (!AZURE_STORAGE_CONNECTION_STRING) {
          throw Error("Azure Storage Connection string not found");
        }

        const blobServiceClient = BlobServiceClient.fromConnectionString(
          AZURE_STORAGE_CONNECTION_STRING
        );
        const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
        const containerClient =
          blobServiceClient.getContainerClient(containerName);
        const createContainerResponse = await containerClient.createIfNotExists();

        // Create a unique name for the blob
        var document_file = req.files.document_file;

        // Create a unique name for the blob
        var docFile = document_file;
        var original_name = docFile.name;
        var document_name = uuidv1() + (docFile.name.replace(/[^a-zA-Z0-9,_;\-.!? ]/g, ''));
        const blockBlobClient = containerClient.getBlockBlobClient(
          `${org_id}/${user_id}/employee_documents/${document_name}`
        );

        let contentType = mime.lookup(document_name);
        // console.log("contentType", contentType);
        const blobOptions = { blobHTTPHeaders: { blobContentType: contentType } };

        const uploadBlobResponse = await blockBlobClient.upload(
          docFile.data,
          docFile.data.length, 
          blobOptions
        );

        // console.log("uploadBlobResponse", JSON.stringify(uploadBlobResponse));

        if (uploadBlobResponse && uploadBlobResponse.requestId) {
          uploaded_file = {
            document_name,
            original_name,
          };
        }
  
        var empDocData = [
          org_id,
          employee_document_type_id,
          user_id,
          uploaded_file.document_name || null,
          createdby,
          record_type_status,
        ];
  
        // console.log("empDocData", empDocData);
  
        let results = await con.query( `SELECT timesheets.insert_employee_documents($1,$2,$3,$4,$5,$6)`,
        empDocData
        );
  
        var data = (results.rows && results.rows[1] && results.rows[1].insert_employee_documents && results.rows[1].insert_employee_documents[0]) || null;
  
        if (data) {
  
          returnMessage.isError = false;
          returnMessage.data = data;
          returnMessage.message = "Added Successfully";
          returnMessage.statuscode = 200;
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = true;
          returnMessage.message = "Failed to add";
          returnMessage.label = "insert_employee_document";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        }
    }
    else{
      returnMessage.isError = true;
      returnMessage.message = "Please select file";
      returnMessage.label = "insert_employee_document";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      res.status(400).json(returnMessage);
    }

  } catch (error) {

    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "insert_employee_document";
    ``;
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

// EDIT api to edit_employee_document
const edit_employee_document = async (req, res) => {
  
  const returnMessage = getMsgFormat();

  try {

    let org_id = req.user.org_id;
    const { errors, isValid } = createEmployeeDocumentValidator({ ...req.body, org_id });

    if (!isValid) {
      returnMessage.isError = true;
      returnMessage.message = "Validation failed";
      returnMessage.errors = { ...errors };
      returnMessage.label = "edit_project";
      logger.log({
        level: "error",
        message: returnMessage,
      });
      return res.status(400).json(returnMessage);
    }

    let createdby = req.user.id;
    let updatedby = req.user.id;

    let {
      id = null,
      employee_document_type_id = null,
      user_id = null,
      record_type_status = null,
    } = req.body;

    let old_data = await con.query(
      `SELECT * from timesheets.get_employee_document_by_id($1,$2)`,
      [org_id, id]
    );

    old_data = (old_data && old_data.rows[0].j && old_data.rows[0].j[0]) || null;
    var uploaded_file = {};

    if (req.files && req.files.document_file) {
      
      req.files.document_file = !req.files.document_file.length ? req.files.document_file : req.files.document_file[0];

      const AZURE_STORAGE_CONNECTION_STRING = process.env.AZURE_STORAGE_CONNECTION_STRING;
      if (!AZURE_STORAGE_CONNECTION_STRING) {
        throw Error("Azure Storage Connection string not found");
      }

      const blobServiceClient = BlobServiceClient.fromConnectionString(
        AZURE_STORAGE_CONNECTION_STRING
      );
      const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
      const containerClient =
        blobServiceClient.getContainerClient(containerName);
      const createContainerResponse = await containerClient.createIfNotExists();

      // Create a unique name for the blob
      var document_file = req.files.document_file;

      // Create a unique name for the blob
      var docFile = document_file;
      var original_name = docFile.name;
      var document_name = uuidv1() + (docFile.name.replace(/[^a-zA-Z0-9,_;\-.!? ]/g, ''));
      const blockBlobClient = containerClient.getBlockBlobClient(
        `${org_id}/${user_id}/employee_documents/${document_name}`
      );

      let contentType = mime.lookup(document_name);
      // console.log("contentType", contentType);
      const blobOptions = { blobHTTPHeaders: { blobContentType: contentType } };

      const uploadBlobResponse = await blockBlobClient.upload(
        docFile.data,
        docFile.data.length, 
        blobOptions
      );

      // console.log("uploadBlobResponse", JSON.stringify(uploadBlobResponse));

      if (uploadBlobResponse && uploadBlobResponse.requestId) {
        uploaded_file = {
          document_name,
          original_name,
        };
      }
    }
    else{
      uploaded_file = {
        document_name: old_data.document_file,
        original_name: old_data.document_file,
      };
    }

    record_type_status = old_data.record_type_status;
    
    var empDocData = [
      id,
      org_id,
      employee_document_type_id,
      user_id,
      uploaded_file.document_name || null,
      createdby,
      record_type_status,
    ];

      // console.log("empDocData", empDocData);

      let results = await con.query(
        `SELECT timesheets.update_employee_documents($1,$2,$3,$4,$5,$6,$7)`,
        empDocData
      );
      var data = (results.rows && results.rows[1] && results.rows[1].update_employee_documents && results.rows[1].update_employee_documents[0]) || null;

      if(data){
        ////////////////////////////////////
        returnMessage.isError = false;
        returnMessage.data = data;
        returnMessage.message = "Updated Successfully";
        returnMessage.statuscode = 200;
        res.status(200).json(returnMessage);
      } else {
        returnMessage.isError = true;
        returnMessage.message = "Failed to update";
        returnMessage.label = "edit_employee_document";
        logger.log({
          level: "error",
          message: returnMessage,
        });
        res.status(400).json(returnMessage);
      }
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "edit_employee_document";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
}

// DELETE api to delete_employee_document_by_id
const delete_employee_document_by_id = async (req, res) => {

  const returnMessage = getMsgFormat();
  try {

    let org_id = req.user.org_id;
    let updatedby = req.user.id;

    if(!req.body.id){
      returnMessage.isError=true
      returnMessage.message="Invalid Parameters"
      returnMessage.error="id can not be null or empty"
      returnMessage.label = "delete_employee_document_by_id";
      logger.log({
        level:'error',
        message:returnMessage
      })
      return res.status(400).json(returnMessage)
    }
    else{
      await con.query(
        `SELECT timesheets.delete_employee_document_by_id($1,$2,$3)`,
        [org_id, req.body.id, updatedby],
        (error, results) => {
          if (error) {
            returnMessage.isError = true;
            returnMessage.message = "Failed to Delete";
            returnMessage.label = "delete_employee_document_by_id";
            logger.log({
              level: "error",
              message: returnMessage,
            });
            res.status(400).json(returnMessage);
          } else {
            returnMessage.isError = false;
            returnMessage.message = "Deleted Successfully";
            res.status(200).json(returnMessage);
          }
        }
      );
    }
    
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "delete_employee_document_by_id";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


module.exports = {
  get_all_employee_documents,
  export_all_employee_documents,
  get_employee_document_by_id,
  get_employee_documents_by_user_id,
  insert_employee_document,
  edit_employee_document,
  delete_employee_document_by_id,
};
