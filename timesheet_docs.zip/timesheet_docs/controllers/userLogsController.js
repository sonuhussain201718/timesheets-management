const { getMsgFormat, isEmpty, getBlobUrl } = require("../utils/helpers");
const con = require("../utils/db");
const qbo = require("../utils/qb");
const logger = require("../utils/logger");
const axios = require("axios");
const fs = require("fs");
const { BlobServiceClient } = require("@azure/storage-blob");
var mime = require("mime-types");
const excelJS = require("exceljs");
const path = require("path");
// con.connect();
const moment = require("moment");

// GET api for get_all_user_logs
const get_all_user_logs = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  // let user_id = req.user.id;
  let start_date = null;
  let end_date = null;

  try {
    if (req.query.start_date && req.query.end_date) {
      start_date = req.query.start_date;
      end_date = req.query.end_date;
    } else {
      let currentDate = moment().format("YYYY-MM-DD");
      start_date = moment(currentDate)
        .subtract(1, "months")
        .format("YYYY-MM-DD");
      end_date = moment(currentDate).format("YYYY-MM-DD");
    }
    await con.query(
      `SELECT * from timesheets.get_all_user_logs($1,$2,$3,$4,$5,$6,$7,$8,$9,$10);`,
      [
        req.query.keyword,
        start_date,
        end_date,
        org_id,
        req.query.user_id,
        req.query.ip_address,
	      req.query.browser_details,
        req.query.record_type_status,
        req.query.pagenumber,
        req.query.pagesize,
      ],
      (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch sync logs details";
          returnMessage.error = error;
          returnMessage.label = "get_all_user_logs";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else if (isEmpty(results.rows[0].j)) {
          returnMessage.isError = false;
          returnMessage.message = "No Records Found";
          res.status(200).json(returnMessage);
        } else {
          returnMessage.isError = false;
          returnMessage.message = "Records Found";
          returnMessage.data = results.rows[0].j;
          returnMessage.count = results.rows[1].j;
          res.status(200).json(returnMessage);
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "get_all_user_logs";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};


// GET api for export_all_user_logs
const export_all_user_logs = async (req, res) => {
  const returnMessage = getMsgFormat();

  let org_id = req.user.org_id;
  let start_date = null;
  let end_date = null;
  try {
    if (req.query.start_date && req.query.end_date) {
      start_date = req.query.start_date;
      end_date = req.query.end_date;
    } else {
      let currentDate = moment().format("YYYY-MM-DD");
      start_date = moment(currentDate)
        .subtract(1, "months")
        .format("YYYY-MM-DD");
      end_date = moment(currentDate).format("YYYY-MM-DD");

    }
    await con.query(
      `SELECT * from timesheets.export_all_user_logs($1,$2,$3,$4,$5,$6,$7,$8);`,
      [
        req.query.keyword,
        start_date,
        end_date,
        org_id,
        req.query.user_id,
        req.query.ip_address,
        req.query.browser_details,
        req.query.record_type_status,
      ],
      async (error, results) => {
        if (error) {
          returnMessage.isError = true;
          returnMessage.message = "Failed to fetch data";
          returnMessage.error = error;
          returnMessage.label = "export_all_user_logs";
          logger.log({
            level: "error",
            message: returnMessage,
          });
          res.status(400).json(returnMessage);
        } else {
          results =
            (results.rows && results.rows[0] && results.rows[0].j) || null;

          if (results && results.length) {
            const workbook = new excelJS.Workbook(); // Create a new workbook
            const worksheet = workbook.addWorksheet("ExportUserLogsData");

            // Column for data in excel. key must match data key
            worksheet.columns = [
              { header: "EMPLOYEE NAME", key: "full_name", width: 10 },
              {
                header: "LOGIN TIME",
                key: "login_time",
                width: 10,
              },
              { header: "LOGOUT TIME", key: "logout_time", width: 10 },
            ];

            for (i = 0; i < results.length; i++) {
              row = results[i];
              worksheet.addRow(row); // Add data in worksheet
            }

            // Making first line in excel bold
            worksheet.getRow(1).eachCell((cell) => {
              cell.font = { bold: true };
            });

            let folderPath = path.join(
              global.appDir,
              "./",
              "public/exports/user_logs"
            );
            let fileName = `user_logs-list-${new Date().getTime()}.xlsx`;
            let filePath = `${folderPath}/${fileName}`;

            await workbook.xlsx.writeFile(filePath).then(async () => {
              const AZURE_STORAGE_CONNECTION_STRING =
                process.env.AZURE_STORAGE_CONNECTION_STRING;
              if (!AZURE_STORAGE_CONNECTION_STRING) {
                throw Error("Azure Storage Connection string not found");
              }
              const blobServiceClient = BlobServiceClient.fromConnectionString(
                AZURE_STORAGE_CONNECTION_STRING
              );

              const containerName = `${process.env.AZURE_STORAGE_BLOB_DEFAULT_CONTAINER}`;
              const containerClient =
                blobServiceClient.getContainerClient(containerName);
              const createContainerResponse =
                await containerClient.createIfNotExists();

              //////////Upload to Azure Blob//////
              const blockBlobClient = containerClient.getBlockBlobClient(
                `${org_id}/exports/user_logs/${fileName}`
              );

              let contentType = mime.lookup(fileName);
              const blobOptions = {
                blobHTTPHeaders: { blobContentType: contentType },
              };

              const uploadBlobResponse = await blockBlobClient.uploadFile(
                filePath,
                blobOptions
              );

              let blobUrl = "";
              if (uploadBlobResponse && uploadBlobResponse.requestId) {
                blobUrl = getBlobUrl(
                  containerName,
                  `${org_id}/exports/user_logs/${fileName}`
                );
              }

              //delete local file after upload to azure
              fs.unlinkSync(filePath);
              //////////////
              returnMessage.isError = false;
              returnMessage.message = "File downloaded successfully";
              returnMessage.data = {
                // url: filePath,
                blobUrl: blobUrl,
              };
              res.status(200).json(returnMessage);
            });
          } else {
            returnMessage.isError = false;
            returnMessage.message = "No Records Found";
            res.status(200).json(returnMessage);
          }
          ///////////////
        }
      }
    );
  } catch (error) {
    returnMessage.isError = true;
    returnMessage.message = "Error Occured! please try again";
    returnMessage.error = error;
    returnMessage.label = "export_all_user_logs";
    logger.log({
      level: "error",
      message: returnMessage,
    });
    return res.status(500).json(returnMessage);
  }
};

module.exports = {
  get_all_user_logs,
  export_all_user_logs,
};
